package plugin.google.maps;

import org.json.JSONObject;

public interface AsyncHttpGetInterface {
  public void onPostExecute(JSONObject result) ;
}
