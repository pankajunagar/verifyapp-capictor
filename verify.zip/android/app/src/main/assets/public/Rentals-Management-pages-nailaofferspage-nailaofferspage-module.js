(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["Rentals-Management-pages-nailaofferspage-nailaofferspage-module"],{

/***/ "./src/app/Rentals Management/pages/nailaofferspage/nailaofferspage.html":
/*!*******************************************************************************!*\
  !*** ./src/app/Rentals Management/pages/nailaofferspage/nailaofferspage.html ***!
  \*******************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ion-header no-border>\r\n  <ion-toolbar color=\"primary\">\r\n    <ion-buttons slot=\"start\">\r\n      <ion-menu-button></ion-menu-button>\r\n    </ion-buttons>\r\n    <!-- <ion-buttons slot=\"end\" expand=\"full\" class=\"ion-button\" (click)=\"openScanner()\">\r\n      <ion-button style=\"color: black\">\r\n          <img src=\"../../../../assets/icons.png\" width=\"30px\" height=\"30px\"/>\r\n      </ion-button>\r\n    </ion-buttons> -->\r\n\r\n    <ion-title>Product catalog</ion-title>\r\n  </ion-toolbar>\r\n\r\n</ion-header>\r\n\r\n\r\n<ion-content *ngIf=\"listbanner\" padding>\r\n\r\n    <ion-searchbar placeholder=\"Browse products\" mode=\"ios\"\r\n    [(ngModel)]=\"searchTerm\" (ionChange)=\"setFilteredItems()\"\r\n  ></ion-searchbar>\r\n  <ion-row class=\"center-text\">\r\n    <ion-col *ngFor=\"let item of items\" size=\"6\">\r\n\r\n      <ion-card class=\"myCard\">\r\n        <img \r\n          src={{item.img1}} />\r\n        <div class=\"myOverlay\">\r\n          <div class=\"card-title\">{{item.product_name}}</div>\r\n        </div>\r\n      </ion-card>\r\n\r\n    </ion-col>\r\n    <!-- <ion-col>\r\n\r\n      <ion-card class=\"myCard\">\r\n        <img style=\"    height: 155px;\"\r\n          src=\"assets/imgs/dryer.jpg\" />\r\n        <div class=\"myOverlay\">\r\n          <div class=\"card-title\">Styling</div>\r\n        </div>\r\n      </ion-card>\r\n    </ion-col> -->\r\n\r\n  </ion-row>\r\n\r\n\r\n\r\n</ion-content>"

/***/ }),

/***/ "./src/app/Rentals Management/pages/nailaofferspage/nailaofferspage.module.ts":
/*!************************************************************************************!*\
  !*** ./src/app/Rentals Management/pages/nailaofferspage/nailaofferspage.module.ts ***!
  \************************************************************************************/
/*! exports provided: NailaOffersPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "NailaOffersPageModule", function() { return NailaOffersPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _ApplicationPageModule__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../ApplicationPageModule */ "./src/app/Rentals Management/ApplicationPageModule.ts");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _modals_create_notice_create_notice_component__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../../modals/create-notice/create-notice.component */ "./src/app/Rentals Management/modals/create-notice/create-notice.component.ts");
/* harmony import */ var _nailaofferspage__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./nailaofferspage */ "./src/app/Rentals Management/pages/nailaofferspage/nailaofferspage.ts");








// import { BarcodeScanner } from '@ionic-native/barcode-scanner/ngx';
// import { NailasearchPage } from './nailasearchpage';

var routes = [
    {
        path: '',
        component: _nailaofferspage__WEBPACK_IMPORTED_MODULE_8__["NailaOffersPage"]
    }
];
var NailaOffersPageModule = /** @class */ (function () {
    function NailaOffersPageModule() {
    }
    NailaOffersPageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_2__["NgModule"])({
            entryComponents: [_modals_create_notice_create_notice_component__WEBPACK_IMPORTED_MODULE_7__["CreateNoticeComponent"]],
            imports: [
                _angular_common__WEBPACK_IMPORTED_MODULE_3__["CommonModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormsModule"],
                _ApplicationPageModule__WEBPACK_IMPORTED_MODULE_1__["ApplicationPageModule"],
                _ionic_angular__WEBPACK_IMPORTED_MODULE_6__["IonicModule"],
                _angular_router__WEBPACK_IMPORTED_MODULE_5__["RouterModule"].forChild(routes)
            ],
            providers: [
            // BarcodeScanner
            ],
            declarations: [_nailaofferspage__WEBPACK_IMPORTED_MODULE_8__["NailaOffersPage"]]
        })
    ], NailaOffersPageModule);
    return NailaOffersPageModule;
}());



/***/ }),

/***/ "./src/app/Rentals Management/pages/nailaofferspage/nailaofferspage.scss":
/*!*******************************************************************************!*\
  !*** ./src/app/Rentals Management/pages/nailaofferspage/nailaofferspage.scss ***!
  \*******************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "img {\n  width: 100%;\n  height: 100%; }\n\n.myCard {\n  position: relative;\n  height: 145px;\n  width: 42vw !important; }\n\n.myOverlay {\n  width: 100%;\n  height: 35px;\n  position: absolute;\n  z-index: 99;\n  font-size: 12px;\n  bottom: 0px;\n  color: #fff;\n  background: linear-gradient(to bottom, transparent, black); }\n\nion-col {\n  margin-left: -2vw; }\n\n.card-title {\n  margin-top: 2vw; }\n\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvUmVudGFscyBNYW5hZ2VtZW50L3BhZ2VzL25haWxhb2ZmZXJzcGFnZS9EOlxcbmF2am90XFx2ZXJpZnkvc3JjXFxhcHBcXFJlbnRhbHMgTWFuYWdlbWVudFxccGFnZXNcXG5haWxhb2ZmZXJzcGFnZVxcbmFpbGFvZmZlcnNwYWdlLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDRSxXQUFVO0VBQ1YsWUFBVyxFQUFBOztBQUdiO0VBQ0Usa0JBQWlCO0VBQ2pCLGFBQWE7RUFDWCxzQkFBc0IsRUFBQTs7QUFJMUI7RUFDRSxXQUFXO0VBQ1gsWUFBWTtFQUNaLGtCQUFrQjtFQUNsQixXQUFXO0VBQ1gsZUFBZTtFQUNmLFdBQVc7RUFHWCxXQUFXO0VBQ1gsMERBQXlELEVBQUE7O0FBSTNEO0VBQ0UsaUJBQWlCLEVBQUE7O0FBR25CO0VBQ0UsZUFBZSxFQUFBIiwiZmlsZSI6InNyYy9hcHAvUmVudGFscyBNYW5hZ2VtZW50L3BhZ2VzL25haWxhb2ZmZXJzcGFnZS9uYWlsYW9mZmVyc3BhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbImltZ3tcclxuICB3aWR0aDoxMDAlO1xyXG4gIGhlaWdodDoxMDAlO1xyXG59XHJcblxyXG4ubXlDYXJke1xyXG4gIHBvc2l0aW9uOnJlbGF0aXZlO1xyXG4gIGhlaWdodDogMTQ1cHg7XHJcbiAgICB3aWR0aDogNDJ2dyAhaW1wb3J0YW50O1xyXG5cclxufVxyXG5cclxuLm15T3ZlcmxheXtcclxuICB3aWR0aDogMTAwJTtcclxuICBoZWlnaHQ6IDM1cHg7XHJcbiAgcG9zaXRpb246IGFic29sdXRlO1xyXG4gIHotaW5kZXg6IDk5O1xyXG4gIGZvbnQtc2l6ZTogMTJweDtcclxuICBib3R0b206IDBweDtcclxuICAvLyBvcGFjaXR5OiAwLjU7XHJcbiAgLy8gYmFja2dyb3VuZDogIzAwMDtcclxuICBjb2xvcjogI2ZmZjtcclxuICBiYWNrZ3JvdW5kOiBsaW5lYXItZ3JhZGllbnQodG8gYm90dG9tLHRyYW5zcGFyZW50LCBibGFjayk7XHJcblxyXG5cclxufVxyXG5pb24tY29se1xyXG4gIG1hcmdpbi1sZWZ0OiAtMnZ3O1xyXG59XHJcblxyXG4uY2FyZC10aXRsZXtcclxuICBtYXJnaW4tdG9wOiAydnc7XHJcbn1cclxuIl19 */"

/***/ }),

/***/ "./src/app/Rentals Management/pages/nailaofferspage/nailaofferspage.ts":
/*!*****************************************************************************!*\
  !*** ./src/app/Rentals Management/pages/nailaofferspage/nailaofferspage.ts ***!
  \*****************************************************************************/
/*! exports provided: NailaOffersPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "NailaOffersPage", function() { return NailaOffersPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _services_naila_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../services/naila.service */ "./src/app/Rentals Management/services/naila.service.ts");



// import { Slides } from 'ionic-angular';
var NailaOffersPage = /** @class */ (function () {
    function NailaOffersPage(nailaservice) {
        this.nailaservice = nailaservice;
    }
    NailaOffersPage.prototype.ngOnInit = function () {
        var _this = this;
        this.nailaservice.listRelatedProducts('1').subscribe(function (data) {
            _this.listbanner = data;
            _this.items = _this.listbanner.data;
            _this.listbanner.data.forEach(function (element) {
                element.name = element.product_name;
            });
            console.log(_this.listbanner);
        });
    };
    NailaOffersPage.prototype.setFilteredItems = function () {
        this.items = this.listbanner.data;
        this.items = this.filterItems(this.searchTerm);
    };
    NailaOffersPage.prototype.filterItems = function (searchTerm) {
        return this.items.filter(function (item) {
            return item.name.toLowerCase().indexOf(searchTerm.toLowerCase()) > -1;
        });
    };
    NailaOffersPage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-nailaofferspage',
            template: __webpack_require__(/*! ./nailaofferspage.html */ "./src/app/Rentals Management/pages/nailaofferspage/nailaofferspage.html"),
            styles: [__webpack_require__(/*! ./nailaofferspage.scss */ "./src/app/Rentals Management/pages/nailaofferspage/nailaofferspage.scss")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_services_naila_service__WEBPACK_IMPORTED_MODULE_2__["NailaService"]])
    ], NailaOffersPage);
    return NailaOffersPage;
}());



/***/ })

}]);
//# sourceMappingURL=Rentals-Management-pages-nailaofferspage-nailaofferspage-module.js.map