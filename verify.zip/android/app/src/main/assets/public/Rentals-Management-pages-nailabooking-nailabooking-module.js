(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["Rentals-Management-pages-nailabooking-nailabooking-module"],{

/***/ "./src/app/Rentals Management/pages/nailabooking/nailabooking.html":
/*!*************************************************************************!*\
  !*** ./src/app/Rentals Management/pages/nailabooking/nailabooking.html ***!
  \*************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ion-header no-border>\r\n  <ion-toolbar color=\"primary\">\r\n    <ion-buttons slot=\"start\">\r\n      <ion-menu-button></ion-menu-button>\r\n    </ion-buttons>\r\n    <!-- <ion-buttons slot=\"end\" expand=\"full\" class=\"ion-button\" (click)=\"openScanner()\">\r\n      <ion-button style=\"color: black\">\r\n          <img src=\"../../../../assets/icons.png\" width=\"30px\" height=\"30px\"/>\r\n      </ion-button>\r\n    </ion-buttons> -->\r\n\r\n    <ion-title>Bookings</ion-title>\r\n  </ion-toolbar>\r\n\r\n  <ion-segment value=\"all\">\r\n    <ion-segment-button (click)=\"filterpastandupcomingBooking('upcoming')\">\r\n      <ion-label>Upcoming</ion-label>\r\n    </ion-segment-button>\r\n    <ion-segment-button (click)=\"filterpastandupcomingBooking('past')\">\r\n      <ion-label>Past</ion-label>\r\n    </ion-segment-button>\r\n  </ion-segment>\r\n</ion-header>\r\n\r\n<ion-content padding>\r\n\r\n\r\n<ng-container *ngIf=\"listbooking.length\">\r\n  <ng-container style=\"    border-bottom: 1px solid black;\r\n  \" *ngFor=\"let data of listbooking; let i= index\">\r\n    <label style=\"text-decoration: underline;\r\n    margin-left: -2vw;\">\r\n      Booking Id: #{{data.unique_id.substr(data.unique_id.length - 4)}}\r\n    </label>\r\n\r\n    <ion-row style=\"    margin-top: 5vw;\" *ngFor=\"let item of data.booking_services_details\">\r\n      <ion-col size=\"3\">\r\n        <img class=\"float-left\" style=\"width: 70px;\r\n      height: 43px;\r\n      margin-top: 5px;\r\n      position: absolute;\r\n      border-radius: 5px;\" src={{item.service.image.url}} alt=\"\">\r\n      </ion-col>\r\n      <ion-col size=\"9\">\r\n\r\n\r\n\r\n\r\n        <ion-list class=\"padding-bottom-0\">\r\n          <ion-item lines=\"none\">\r\n            <ion-label style=\"text-align: start;\" class=\"margin-0\">\r\n              <p class=\"\" text-wrap>\r\n                <small class=\"float-left font-weight-600 text-black\">{{item.service.name}}</small>\r\n                <!-- <span class=\"center-text\"> hello</span>-->\r\n              </p>\r\n              <small class=\"font-10  txt-grey\">\r\n                {{item.service.no_of_minuties}} min\r\n              </small>\r\n            </ion-label>\r\n            <!-- <small class=\"float-right \">Rs.900</small>  -->\r\n            <ion-label style=\"text-align: end;     padding-right: 10px;\" class=\"margin-0 \">\r\n              <p class=\"\" text-wrap>\r\n                <small class=\"font-10\">{{data.schedule_on | date :  \"dd|MM|yyyy\"}}</small>\r\n                <!-- <span class=\"center-text\"> hello</span>-->\r\n              </p>\r\n              <small class=\"font-10 txt-grey\">\r\n                Rs. {{item.service.offer_price}}\r\n              </small>\r\n            </ion-label>\r\n            <!-- <small class=\"float-right \">Details</small>  -->\r\n\r\n          </ion-item>\r\n        </ion-list>\r\n\r\n      </ion-col>\r\n\r\n\r\n\r\n    </ion-row>\r\n    <ion-row>\r\n    <ion-col size=\"3\"></ion-col>\r\n\r\n    <ion-col size=\"9\">\r\n\r\n\r\n      <ion-list class=\"padding-bottom-0\">\r\n        <ion-item style=\"--min-height: 10px;\" lines=\"none\">\r\n          <ion-label (click)=\"presentInvoiceAlert(data)\" style=\"text-align: start;\" class=\"margin-0\">\r\n            <p class=\"\" text-wrap>\r\n              <small class=\"float-left text-nunderline font-10 text-ncolor\">View Invoice</small>\r\n              <!-- <span class=\"center-text\"> hello</span>-->\r\n            </p>\r\n\r\n          </ion-label>\r\n          <!-- <small class=\"float-right \">Rs.900</small>  -->\r\n          <ion-label style=\"text-align: end; padding-right: 10px;\" class=\"margin-0 \">\r\n            <p class=\"\" text-wrap>\r\n              <small (click)=\"presentAlert(item)\" class=\"font-10 text-ncolor text-nunderline\">Raise Ticket</small>\r\n              <!-- <span class=\"center-text\"> hello</span>-->\r\n            </p>\r\n\r\n          </ion-label>\r\n          <!-- <small class=\"float-right \">Details</small>  -->\r\n\r\n        </ion-item>\r\n      </ion-list>\r\n\r\n    </ion-col>\r\n    </ion-row>\r\n    <!-- <hr> -->\r\n  </ng-container>\r\n</ng-container>\r\n\r\n\r\n<ng-container *ngIf=\"!listbooking.length\">\r\n    <ion-row>\r\n        <p style=\"display: inline-flex;\r\n        justify-content: center;\r\n        text-align: center;\r\n        width: 100%;\r\n        margin-top: 25vh;\">No {{bookingname}} bookings!</p>\r\n      </ion-row>\r\n</ng-container>\r\n\r\n\r\n  <!-- \r\n  <ion-infinite-scroll [hidden]=\"disableInfiniteScroll\" threshold=\"5px\" (ionInfinite)=\"searchTicket($event)\">\r\n    <ion-infinite-scroll-content loadingSpinner=\"bubbles\"\r\n      loadingText=\"{{transService.getTranslatedData('infinite-scroll')}}\">\r\n    </ion-infinite-scroll-content>\r\n  </ion-infinite-scroll> -->\r\n</ion-content>"

/***/ }),

/***/ "./src/app/Rentals Management/pages/nailabooking/nailabooking.module.ts":
/*!******************************************************************************!*\
  !*** ./src/app/Rentals Management/pages/nailabooking/nailabooking.module.ts ***!
  \******************************************************************************/
/*! exports provided: NailabookingPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "NailabookingPageModule", function() { return NailabookingPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _ApplicationPageModule__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../ApplicationPageModule */ "./src/app/Rentals Management/ApplicationPageModule.ts");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _modals_create_notice_create_notice_component__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../../modals/create-notice/create-notice.component */ "./src/app/Rentals Management/modals/create-notice/create-notice.component.ts");
/* harmony import */ var _nailabooking__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./nailabooking */ "./src/app/Rentals Management/pages/nailabooking/nailabooking.ts");








// import { BarcodeScanner } from '@ionic-native/barcode-scanner/ngx';

// import { NailabookingPage } from './nailaofferslisting';
var routes = [
    {
        path: '',
        component: _nailabooking__WEBPACK_IMPORTED_MODULE_8__["NailabookingPage"]
    }
];
var NailabookingPageModule = /** @class */ (function () {
    function NailabookingPageModule() {
    }
    NailabookingPageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_2__["NgModule"])({
            entryComponents: [_modals_create_notice_create_notice_component__WEBPACK_IMPORTED_MODULE_7__["CreateNoticeComponent"]],
            imports: [
                _angular_common__WEBPACK_IMPORTED_MODULE_3__["CommonModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormsModule"],
                _ApplicationPageModule__WEBPACK_IMPORTED_MODULE_1__["ApplicationPageModule"],
                _ionic_angular__WEBPACK_IMPORTED_MODULE_6__["IonicModule"],
                _angular_router__WEBPACK_IMPORTED_MODULE_5__["RouterModule"].forChild(routes)
            ],
            providers: [
            // BarcodeScanner
            ],
            declarations: [_nailabooking__WEBPACK_IMPORTED_MODULE_8__["NailabookingPage"]]
        })
    ], NailabookingPageModule);
    return NailabookingPageModule;
}());



/***/ }),

/***/ "./src/app/Rentals Management/pages/nailabooking/nailabooking.scss":
/*!*************************************************************************!*\
  !*** ./src/app/Rentals Management/pages/nailabooking/nailabooking.scss ***!
  \*************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "ion-navbar {\n  border-bottom-right-radius: 15px;\n  border-bottom-left-radius: 15px;\n  background-color: black; }\n\nion-card {\n  position: relative;\n  text-align: center;\n  border-radius: 20px !important; }\n\n.card-title {\n  position: absolute;\n  top: 20vh;\n  background-color: yellow;\n  font-size: 2.0em;\n  height: 15vh;\n  width: 100%;\n  font-weight: bold;\n  color: #fff; }\n\nion-card-content {\n  text-align: left;\n  background: red;\n  line-height: 1.5;\n  width: 100%;\n  padding-top: 7px;\n  padding-bottom: 7px; }\n\nlabel {\n  padding-left: 3vw; }\n\n.service ion-card-content {\n  text-align: center;\n  line-height: 1.5;\n  width: 100%;\n  font-size: 6px;\n  background: transparent;\n  padding: 5px 1px 3px; }\n\n.service ion-card {\n  position: relative;\n  text-align: center;\n  border-radius: 10px !important; }\n\nion-list {\n  padding-top: 0px !important; }\n\nion-toolbar {\n  border-bottom-left-radius: 25px;\n  border-bottom-right-radius: 25px; }\n\n.list-offers {\n  margin-right: 5px; }\n\nh6 {\n  padding-left: 4vw;\n  font-weight: 500; }\n\nhr {\n  border-width: 0.2px !important;\n  height: 0px !important; }\n\nion-item {\n  --detail-icon-color: goldenrod;\n  --detail-icon-opacity:1; }\n\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvUmVudGFscyBNYW5hZ2VtZW50L3BhZ2VzL25haWxhYm9va2luZy9EOlxcbmF2am90XFx2ZXJpZnkvc3JjXFxhcHBcXFJlbnRhbHMgTWFuYWdlbWVudFxccGFnZXNcXG5haWxhYm9va2luZ1xcbmFpbGFib29raW5nLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDRSxnQ0FBZ0M7RUFDaEMsK0JBQStCO0VBQy9CLHVCQUF1QixFQUFBOztBQU9uQjtFQUNFLGtCQUFrQjtFQUNsQixrQkFBa0I7RUFDbEIsOEJBQThCLEVBQUE7O0FBR2hDO0VBQ0ksa0JBQWtCO0VBQ2xCLFNBQVM7RUFDVCx3QkFBd0I7RUFDeEIsZ0JBQWdCO0VBQ2hCLFlBQVk7RUFDWixXQUFXO0VBQ1gsaUJBQWlCO0VBQ2pCLFdBQVcsRUFBQTs7QUFRbkI7RUFDSSxnQkFBZ0I7RUFDUixlQUFlO0VBQ3ZCLGdCQUFnQjtFQUNoQixXQUFXO0VBQ1gsZ0JBQWdCO0VBQ2hCLG1CQUFtQixFQUFBOztBQUd2QjtFQUNJLGlCQUFpQixFQUFBOztBQUVyQjtFQUVRLGtCQUFrQjtFQUNsQixnQkFBZ0I7RUFDaEIsV0FBVztFQUNYLGNBQWM7RUFDZCx1QkFBdUI7RUFDdkIsb0JBQW9CLEVBQUE7O0FBUDVCO0VBVVEsa0JBQWtCO0VBQ2xCLGtCQUFrQjtFQUNsQiw4QkFBOEIsRUFBQTs7QUFtQnRDO0VBQ0UsMkJBQTJCLEVBQUE7O0FBSTdCO0VBQ0UsK0JBQStCO0VBQy9CLGdDQUFnQyxFQUFBOztBQUdsQztFQUNFLGlCQUFpQixFQUFBOztBQUduQjtFQUNFLGlCQUFpQjtFQUNqQixnQkFBZ0IsRUFBQTs7QUFHbkI7RUFDRSw4QkFBOEI7RUFDOUIsc0JBQXNCLEVBQUE7O0FBR3hCO0VBRUMsOEJBQW9CO0VBQ3BCLHVCQUFzQixFQUFBIiwiZmlsZSI6InNyYy9hcHAvUmVudGFscyBNYW5hZ2VtZW50L3BhZ2VzL25haWxhYm9va2luZy9uYWlsYWJvb2tpbmcuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbImlvbi1uYXZiYXJ7XHJcbiAgYm9yZGVyLWJvdHRvbS1yaWdodC1yYWRpdXM6IDE1cHg7XHJcbiAgYm9yZGVyLWJvdHRvbS1sZWZ0LXJhZGl1czogMTVweDtcclxuICBiYWNrZ3JvdW5kLWNvbG9yOiBibGFjaztcclxufVxyXG5cclxuXHJcblxyXG5cclxuXHJcbiAgICAgIGlvbi1jYXJkIHtcclxuICAgICAgICBwb3NpdGlvbjogcmVsYXRpdmU7XHJcbiAgICAgICAgdGV4dC1hbGlnbjogY2VudGVyO1xyXG4gICAgICAgIGJvcmRlci1yYWRpdXM6IDIwcHggIWltcG9ydGFudDtcclxuICAgICAgfVxyXG5cclxuICAgICAgLmNhcmQtdGl0bGUge1xyXG4gICAgICAgICAgcG9zaXRpb246IGFic29sdXRlO1xyXG4gICAgICAgICAgdG9wOiAyMHZoO1xyXG4gICAgICAgICAgYmFja2dyb3VuZC1jb2xvcjogeWVsbG93O1xyXG4gICAgICAgICAgZm9udC1zaXplOiAyLjBlbTtcclxuICAgICAgICAgIGhlaWdodDogMTV2aDtcclxuICAgICAgICAgIHdpZHRoOiAxMDAlO1xyXG4gICAgICAgICAgZm9udC13ZWlnaHQ6IGJvbGQ7XHJcbiAgICAgICAgICBjb2xvcjogI2ZmZjtcclxuICAgICAgfVxyXG5cclxuICAgICBcclxuICAgICAgLy8gaW9uLXNsaWRle1xyXG4gICAgICAvLyAgICAgd2lkdGg6IDI0NXB4ICFpbXBvcnRhbnQ7XHJcbiAgICAgIC8vIH1cclxuXHJcbiAgaW9uLWNhcmQtY29udGVudHtcclxuICAgICAgdGV4dC1hbGlnbjogbGVmdDtcclxuICAgICAgICAgICAgICBiYWNrZ3JvdW5kOiByZWQ7XHJcbiAgICAgIGxpbmUtaGVpZ2h0OiAxLjU7XHJcbiAgICAgIHdpZHRoOiAxMDAlO1xyXG4gICAgICBwYWRkaW5nLXRvcDogN3B4O1xyXG4gICAgICBwYWRkaW5nLWJvdHRvbTogN3B4O1xyXG4gIH1cclxuXHJcbiAgbGFiZWx7XHJcbiAgICAgIHBhZGRpbmctbGVmdDogM3Z3O1xyXG4gIH1cclxuICAuc2VydmljZXtcclxuICAgICAgaW9uLWNhcmQtY29udGVudHtcclxuICAgICAgICAgIHRleHQtYWxpZ246IGNlbnRlcjtcclxuICAgICAgICAgIGxpbmUtaGVpZ2h0OiAxLjU7XHJcbiAgICAgICAgICB3aWR0aDogMTAwJTtcclxuICAgICAgICAgIGZvbnQtc2l6ZTogNnB4O1xyXG4gICAgICAgICAgYmFja2dyb3VuZDogdHJhbnNwYXJlbnQ7XHJcbiAgICAgICAgICBwYWRkaW5nOiA1cHggMXB4IDNweDtcclxuICAgICAgfVxyXG4gICAgICBpb24tY2FyZHtcclxuICAgICAgICAgIHBvc2l0aW9uOiByZWxhdGl2ZTtcclxuICAgICAgICAgIHRleHQtYWxpZ246IGNlbnRlcjtcclxuICAgICAgICAgIGJvcmRlci1yYWRpdXM6IDEwcHggIWltcG9ydGFudDsgIFxyXG4gICAgICAgICAgXHJcbiAgICAgIH1cclxuICB9XHJcblxyXG4gIC8vIC5ib3JkZXItdG9wIHtcclxuICAvLyAgIGJvcmRlci10b3A6IDFweCBzb2xpZCBsaWdodGdyYXk7XHJcbiAgLy8gfVxyXG4gIFxyXG4gIGlvbi1pdGVtIHtcclxuICAgIC8vIGJvcmRlci10b3A6IDFweCBzb2xpZCBsaWdodGdyYXk7XHJcbiAgICAvLyBib3JkZXItYm90dG9tOiAxcHggc29saWQgbGlnaHRncmF5O1xyXG4gIH1cclxuICBcclxuICAvLyBpb24tbGFiZWwge1xyXG4gIC8vICAgcGFkZGluZy10b3A6IDEwcHggIWltcG9ydGFudDtcclxuICAvLyAgIHBhZGRpbmctYm90dG9tOiAxMHB4ICFpbXBvcnRhbnQ7XHJcbiAgLy8gfVxyXG4gIFxyXG4gIGlvbi1saXN0IHtcclxuICAgIHBhZGRpbmctdG9wOiAwcHggIWltcG9ydGFudDtcclxuICB9XHJcbiAgXHJcblxyXG4gIGlvbi10b29sYmFye1xyXG4gICAgYm9yZGVyLWJvdHRvbS1sZWZ0LXJhZGl1czogMjVweDtcclxuICAgIGJvcmRlci1ib3R0b20tcmlnaHQtcmFkaXVzOiAyNXB4O1xyXG4gIH1cclxuXHJcbiAgLmxpc3Qtb2ZmZXJze1xyXG4gICAgbWFyZ2luLXJpZ2h0OiA1cHg7XHJcbiAgfVxyXG5cclxuICBoNntcclxuICAgIHBhZGRpbmctbGVmdDogNHZ3O1xyXG4gICAgZm9udC13ZWlnaHQ6IDUwMDtcclxuICAgIH1cclxuXHJcbiBocntcclxuICAgYm9yZGVyLXdpZHRoOiAwLjJweCAhaW1wb3J0YW50O1xyXG4gICBoZWlnaHQ6IDBweCAhaW1wb3J0YW50O1xyXG4gfVxyXG5cclxuIGlvbi1pdGVtIHtcclxuICAvLyBib3JkZXItdG9wOiAxcHggc29saWQgbGlnaHRncmF5O1xyXG4gIC0tZGV0YWlsLWljb24tY29sb3I6IGdvbGRlbnJvZDtcclxuICAtLWRldGFpbC1pY29uLW9wYWNpdHk6MTtcclxuICAvLyAtLWJvcmRlci13aWR0aDogMHB4IDBweCAwLjFweCAwcHggIWltcG9ydGFudDtcclxuICAvLyAtLWJvcmRlci1jb2xvcjogI0YwRjBGMCAhaW1wb3J0YW50O1xyXG59XHJcblxyXG4iXX0= */"

/***/ }),

/***/ "./src/app/Rentals Management/pages/nailabooking/nailabooking.ts":
/*!***********************************************************************!*\
  !*** ./src/app/Rentals Management/pages/nailabooking/nailabooking.ts ***!
  \***********************************************************************/
/*! exports provided: NailabookingPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "NailabookingPage", function() { return NailabookingPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _services_naila_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../services/naila.service */ "./src/app/Rentals Management/services/naila.service.ts");




// import { ApprovalpopupComponent } from '../../modals/approvalpopup/approvalpopup.component';
var NailabookingPage = /** @class */ (function () {
    function NailabookingPage(nailaservice, alertController) {
        this.nailaservice = nailaservice;
        this.alertController = alertController;
        this.sliderConfig = {
            slidesPerView: 1.2,
            spaceBetween: 5
            // centeredSlides: true
        };
        this.sliderConfig2 = {
            slidesPerView: 3.2,
            spaceBetween: 5
            // centeredSlides: true
        };
        this.searchTerm = "";
        this.a = false;
        this.upcomingbooking = [];
        this.pastbooking = [];
        this.listbooking = [];
        this.bookingList = [];
        this.bookingname = "upcoming";
        this.items = [
            { title: "one" },
            { title: "two" },
            { title: "three" },
            { title: "four" },
            { title: "five" },
            { title: "six" }
        ];
    }
    NailabookingPage.prototype.ngOnInit = function () {
        this.setFilteredItems();
        this.listAllBookings("upcoming");
    };
    NailabookingPage.prototype.listAllBookings = function (data) {
        var _this = this;
        this.bookingList = [];
        this.listbooking.splice(0, this.listbooking.length);
        var id = window.localStorage.getItem("user_id");
        this.nailaservice.listAllBookings(id).subscribe(function (bookinglistdata) {
            _this.bookingList = bookinglistdata;
            _this.filterpastandupcomingBooking(data);
        });
    };
    // upcomingdata(data){
    //   this.listbooking=[];
    //   this.
    // }
    NailabookingPage.prototype.filterpastandupcomingBooking = function (data) {
        var _this = this;
        debugger;
        var date = new Date();
        this.upcomingbooking = [];
        this.pastbooking = [];
        this.bookingList.forEach(function (element) {
            if (new Date(element.schedule_on).getTime() >= date.getTime() && element.service_status === null) {
                _this.upcomingbooking.push(element);
            }
            else {
                _this.pastbooking.push(element);
            }
        });
        console.log("===================upcoming================", this.upcomingbooking, "==================================");
        console.log("-----------------past---------------", this.pastbooking, "---------------------------------------------");
        if (data == "upcoming") {
            debugger;
            // this.listbooking.splice(0,this.listbooking.length)
            this.listbooking = this.upcomingbooking;
            this.bookingname = "upcoming";
        }
        else {
            debugger;
            // this.listbooking.splice(0,this.listbooking.length)
            this.bookingname = "past";
            this.listbooking = this.pastbooking;
        }
    };
    NailabookingPage.prototype.setFilteredItems = function () {
        this.items = this.filterItems(this.searchTerm);
    };
    NailabookingPage.prototype.filterItems = function (searchTerm) {
        return this.items.filter(function (item) {
            return item.title.toLowerCase().indexOf(searchTerm.toLowerCase()) > -1;
        });
    };
    NailabookingPage.prototype.presentAlert = function (item) {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function () {
            var alert;
            var _this = this;
            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.alertController.create({
                            // message: 'Enter your issue.',
                            inputs: [
                                {
                                    name: "description",
                                    placeholder: "Description"
                                }
                            ],
                            buttons: [
                                {
                                    text: "Submit",
                                    handler: function (data) {
                                        var ticketdata = {
                                            title: item.service.name,
                                            description: data.description,
                                            booking_id: item.service_id
                                        };
                                        _this.nailaservice.createTicket(ticketdata).subscribe(function (data) { });
                                        // let validateObj = (data);
                                        console.log("==================", data, "========================");
                                    }
                                }
                            ]
                        })];
                    case 1:
                        alert = _a.sent();
                        return [4 /*yield*/, alert.present()];
                    case 2:
                        _a.sent();
                        return [2 /*return*/];
                }
            });
        });
    };
    NailabookingPage.prototype.presentInvoiceAlert = function (item) {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function () {
            var alert;
            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                switch (_a.label) {
                    case 0:
                        debugger;
                        return [4 /*yield*/, this.alertController.create({
                                cssClass: 'my-custom-invoice-class',
                                header: "Tracking Id: " + item.unique_id,
                                subHeader: "Total Amount: Rs." + item.total_amount,
                                message: "Payment Mode: " + (item.payment_status),
                                buttons: ['OK']
                            })];
                    case 1:
                        alert = _a.sent();
                        return [4 /*yield*/, alert.present()];
                    case 2:
                        _a.sent();
                        return [2 /*return*/];
                }
            });
        });
    };
    NailabookingPage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: "app-nailabooking",
            template: __webpack_require__(/*! ./nailabooking.html */ "./src/app/Rentals Management/pages/nailabooking/nailabooking.html"),
            styles: [__webpack_require__(/*! ./nailabooking.scss */ "./src/app/Rentals Management/pages/nailabooking/nailabooking.scss")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_services_naila_service__WEBPACK_IMPORTED_MODULE_3__["NailaService"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["AlertController"]])
    ], NailabookingPage);
    return NailabookingPage;
}());



/***/ })

}]);
//# sourceMappingURL=Rentals-Management-pages-nailabooking-nailabooking-module.js.map