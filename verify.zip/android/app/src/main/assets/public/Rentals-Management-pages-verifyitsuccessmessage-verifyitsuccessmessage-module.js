(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["Rentals-Management-pages-verifyitsuccessmessage-verifyitsuccessmessage-module"],{

/***/ "./src/app/Rentals Management/pages/verifyitsuccessmessage/verifyitsuccessmessage.module.ts":
/*!**************************************************************************************************!*\
  !*** ./src/app/Rentals Management/pages/verifyitsuccessmessage/verifyitsuccessmessage.module.ts ***!
  \**************************************************************************************************/
/*! exports provided: VerifyItSuccessMessageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "VerifyItSuccessMessageModule", function() { return VerifyItSuccessMessageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _ApplicationPageModule__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./../../ApplicationPageModule */ "./src/app/Rentals Management/ApplicationPageModule.ts");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _modals_create_notice_create_notice_component__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../../modals/create-notice/create-notice.component */ "./src/app/Rentals Management/modals/create-notice/create-notice.component.ts");
/* harmony import */ var _verifyitsuccessmessage_page__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./verifyitsuccessmessage.page */ "./src/app/Rentals Management/pages/verifyitsuccessmessage/verifyitsuccessmessage.page.ts");







// import { HomePage } from './home.page';


// import { VerifyitDashboardPage } from './verifyitdashboard.page';
// import { VerifyitDashboardPage } from './VerifyitDashboardPage.page';
// import { BarcodeScanner } from '@ionic-native/barcode-scanner/ngx';
var routes = [
    {
        path: '',
        component: _verifyitsuccessmessage_page__WEBPACK_IMPORTED_MODULE_8__["VerifyItSuccessMessagePage"]
    }
];
var VerifyItSuccessMessageModule = /** @class */ (function () {
    function VerifyItSuccessMessageModule() {
    }
    VerifyItSuccessMessageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_2__["NgModule"])({
            entryComponents: [_modals_create_notice_create_notice_component__WEBPACK_IMPORTED_MODULE_7__["CreateNoticeComponent"]],
            imports: [
                _angular_common__WEBPACK_IMPORTED_MODULE_3__["CommonModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormsModule"],
                _ApplicationPageModule__WEBPACK_IMPORTED_MODULE_1__["ApplicationPageModule"],
                _ionic_angular__WEBPACK_IMPORTED_MODULE_6__["IonicModule"],
                _angular_router__WEBPACK_IMPORTED_MODULE_5__["RouterModule"].forChild(routes)
            ],
            providers: [
            // BarcodeScanner
            ],
            declarations: [_verifyitsuccessmessage_page__WEBPACK_IMPORTED_MODULE_8__["VerifyItSuccessMessagePage"]]
        })
    ], VerifyItSuccessMessageModule);
    return VerifyItSuccessMessageModule;
}());



/***/ }),

/***/ "./src/app/Rentals Management/pages/verifyitsuccessmessage/verifyitsuccessmessage.page.html":
/*!**************************************************************************************************!*\
  !*** ./src/app/Rentals Management/pages/verifyitsuccessmessage/verifyitsuccessmessage.page.html ***!
  \**************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ion-header no-border>\r\n    <ion-toolbar color=\"primary\">\r\n      <ion-buttons slot=\"start\">\r\n        <ion-menu-button></ion-menu-button>\r\n      </ion-buttons>\r\n      <!-- <ion-buttons slot=\"end\" expand=\"full\" class=\"ion-button\" (click)=\"openScanner()\">\r\n        <ion-button style=\"color: black\">\r\n            <img src=\"../../../../assets/icons.png\" width=\"30px\" height=\"30px\"/>\r\n        </ion-button>\r\n      </ion-buttons> -->\r\n  \r\n      <ion-title>NOWVERIFYIT</ion-title>\r\n    </ion-toolbar>\r\n  \r\n  </ion-header>\r\n\r\n\r\n\r\n  <ion-content>\r\n    <ion-row>\r\n      <ion-col size=\"12\">\r\n  \r\n        <ion-img src=\"assets/Tick-Image.png\"></ion-img>\r\n  \r\n      </ion-col>\r\n      <ion-col size=\"12\">\r\n        <ion-label>Data submitted successfully.</ion-label>\r\n      </ion-col>\r\n\r\n    </ion-row>\r\n    \r\n    <ion-row>\r\n\r\n      <ion-col>\r\n  \r\n        <ion-button  ion-button type=\"submit\" text-uppercase class=\"write-btn\" block\r\n        [routerLink]=\"['/verifyit-dashboard']\">Home\r\n  \r\n      </ion-button>\r\n      </ion-col>\r\n    </ion-row>\r\n  \r\n  \r\n  </ion-content>"

/***/ }),

/***/ "./src/app/Rentals Management/pages/verifyitsuccessmessage/verifyitsuccessmessage.page.scss":
/*!**************************************************************************************************!*\
  !*** ./src/app/Rentals Management/pages/verifyitsuccessmessage/verifyitsuccessmessage.page.scss ***!
  \**************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "ion-button {\n  display: block;\n  justify-content: center;\n  margin-top: 6vh;\n  /* width: 80%; */\n  margin-left: 5vh;\n  margin-right: 5vh; }\n\nion-list {\n  display: inline-flex;\n  justify-content: center; }\n\n.transparentBody {\n  background: transparent !important; }\n\n.aclass {\n  width: 100%; }\n\nh4 {\n  text-align: center;\n  text-transform: capitalize; }\n\nion-label {\n  display: flex;\n  justify-content: center;\n  font-weight: 500; }\n\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvUmVudGFscyBNYW5hZ2VtZW50L3BhZ2VzL3ZlcmlmeWl0c3VjY2Vzc21lc3NhZ2UvRDpcXG5hdmpvdFxcdmVyaWZ5L3NyY1xcYXBwXFxSZW50YWxzIE1hbmFnZW1lbnRcXHBhZ2VzXFx2ZXJpZnlpdHN1Y2Nlc3NtZXNzYWdlXFx2ZXJpZnlpdHN1Y2Nlc3NtZXNzYWdlLnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFDQTtFQUNFLGNBQWM7RUFDZCx1QkFBdUI7RUFDdkIsZUFBZTtFQUNmLGdCQUFBO0VBQ0EsZ0JBQWdCO0VBQ2hCLGlCQUFpQixFQUFBOztBQUduQjtFQUNFLG9CQUFvQjtFQUNwQix1QkFBdUIsRUFBQTs7QUFHekI7RUFDRSxrQ0FBa0MsRUFBQTs7QUFHcEM7RUFDRSxXQUFXLEVBQUE7O0FBR2I7RUFDRSxrQkFBa0I7RUFDbEIsMEJBQTBCLEVBQUE7O0FBRTVCO0VBQ0UsYUFBYTtFQUNiLHVCQUF1QjtFQUN2QixnQkFBZ0IsRUFBQSIsImZpbGUiOiJzcmMvYXBwL1JlbnRhbHMgTWFuYWdlbWVudC9wYWdlcy92ZXJpZnlpdHN1Y2Nlc3NtZXNzYWdlL3ZlcmlmeWl0c3VjY2Vzc21lc3NhZ2UucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiXHJcbmlvbi1idXR0b257XHJcbiAgZGlzcGxheTogYmxvY2s7XHJcbiAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XHJcbiAgbWFyZ2luLXRvcDogNnZoO1xyXG4gIC8qIHdpZHRoOiA4MCU7ICovXHJcbiAgbWFyZ2luLWxlZnQ6IDV2aDtcclxuICBtYXJnaW4tcmlnaHQ6IDV2aDtcclxuXHJcbn1cclxuaW9uLWxpc3R7XHJcbiAgZGlzcGxheTogaW5saW5lLWZsZXg7XHJcbiAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XHJcbn1cclxuXHJcbi50cmFuc3BhcmVudEJvZHkge1xyXG4gIGJhY2tncm91bmQ6IHRyYW5zcGFyZW50ICFpbXBvcnRhbnQ7XHJcbn1cclxuXHJcbi5hY2xhc3N7XHJcbiAgd2lkdGg6IDEwMCU7XHJcbn1cclxuXHJcbmg0e1xyXG4gIHRleHQtYWxpZ246IGNlbnRlcjtcclxuICB0ZXh0LXRyYW5zZm9ybTogY2FwaXRhbGl6ZTtcclxufVxyXG5pb24tbGFiZWx7XHJcbiAgZGlzcGxheTogZmxleDtcclxuICBqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlcjtcclxuICBmb250LXdlaWdodDogNTAwO1xyXG59Il19 */"

/***/ }),

/***/ "./src/app/Rentals Management/pages/verifyitsuccessmessage/verifyitsuccessmessage.page.ts":
/*!************************************************************************************************!*\
  !*** ./src/app/Rentals Management/pages/verifyitsuccessmessage/verifyitsuccessmessage.page.ts ***!
  \************************************************************************************************/
/*! exports provided: VerifyItSuccessMessagePage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "VerifyItSuccessMessagePage", function() { return VerifyItSuccessMessagePage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _ionic_native_nfc_ngx__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ionic-native/nfc/ngx */ "./node_modules/@ionic-native/nfc/ngx/index.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _services_naila_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../services/naila.service */ "./src/app/Rentals Management/services/naila.service.ts");
/* harmony import */ var _ionic_native_qr_scanner_ngx__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic-native/qr-scanner/ngx */ "./node_modules/@ionic-native/qr-scanner/ngx/index.js");
/* harmony import */ var _services_utils_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../../services/utils.service */ "./src/app/Rentals Management/services/utils.service.ts");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var src_app_common_services_alert_service_service__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! src/app/common-services/alert-service.service */ "./src/app/common-services/alert-service.service.ts");
/* harmony import */ var _ionic_native_geolocation_ngx__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @ionic-native/geolocation/ngx */ "./node_modules/@ionic-native/geolocation/ngx/index.js");
/* harmony import */ var _ionic_native_barcode_scanner_ngx__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @ionic-native/barcode-scanner/ngx */ "./node_modules/@ionic-native/barcode-scanner/ngx/index.js");










// import { LoadingController } from 'ionic-angular';


var VerifyItSuccessMessagePage = /** @class */ (function () {
    function VerifyItSuccessMessagePage(nfc, ndef, platform, loading, ngZone, qrScanner, utilservice, router, barcodeScanner, alertService, geolocation, apiSvc) {
        this.nfc = nfc;
        this.ndef = ndef;
        this.platform = platform;
        this.loading = loading;
        this.ngZone = ngZone;
        this.qrScanner = qrScanner;
        this.utilservice = utilservice;
        this.router = router;
        this.barcodeScanner = barcodeScanner;
        this.alertService = alertService;
        this.geolocation = geolocation;
        this.apiSvc = apiSvc;
        this.cred = {
            tagId: null,
            verified: null,
            product_name: null,
            manufactured: null,
            model_number: null,
            serial_number: null,
            brand: null,
            img: { default: { main: null } },
            product_details: {
                water_resistant: null,
                display_type: null,
                series: null,
                occassion: null,
                strap: null
            },
            how_to_use_it: { english: null, spanish: null, portugues: null }
        };
        this.credKeys = {
            key12: null,
            key1: null,
            key2: null,
            key3: null,
            key4: null,
            key5: null,
            key6: null,
            key7: null,
            key8: null,
            key9: null,
            key10: null,
            key11: null,
            key13: null
        };
        this.canNFC = false;
        // trying
        this.readingTag = false;
        this.writingTag = false;
        this.isWriting = false;
        this.writtenInput = "";
        this.subscriptions = new Array();
        this.data = {
            lat: 0,
            long: 0,
            tagId: ""
        };
        this.res = {};
        this.ionViewDidLoad();
        this.userType = window.localStorage.getItem("userType");
        // this.alertService.presentthis.alertService.presentAlert(''," user info data",window.localStorage.getItem('userType'));
    }
    VerifyItSuccessMessagePage.prototype.ngOnInit = function () {
        // this.geolocation
        //   .getCurrentPosition()
        //   .then(resp => {
        //     this.data.lat = resp.coords.latitude;
        //     this.data.long = resp.coords.longitude;
        //   })
        //   .catch(error => {
        //     console.log("Error getting location", error);
        //   });
        var _this = this;
        this.utilservice.LoadPage.subscribe(function (data) {
            // this.alertService.presentAlert('',this.utilservice.userType)
            // this.ionViewWillEnter();
            if (_this.userType == 1) {
                _this.userType = 2;
            }
            else {
                _this.userType = 1;
            }
        });
    };
    VerifyItSuccessMessagePage.prototype.presentLoading = function () {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function () {
            var loading;
            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.loading.create({})];
                    case 1:
                        loading = _a.sent();
                        return [4 /*yield*/, loading.present()];
                    case 2:
                        _a.sent();
                        return [2 /*return*/];
                }
            });
        });
    };
    VerifyItSuccessMessagePage.prototype.ionViewDidLoad = function () {
        var _this = this;
        debugger;
        this.userType = window.localStorage.getItem("userType");
        this.platform.ready().then(function () {
            _this.nfc
                .enabled()
                .then(function (resolve) {
                _this.canNFC = true;
                // this.setStatus("NFC Compatable.");
                _this.tagListenerSuccess();
            })
                .catch(function (reject) {
                _this.canNFC = false;
                // this.alertService.presentAlert(
                //   "",
                //   JSON.stringify("NFC is not supported by your Device")
                // );
                // this.setStatus("NFC Not Compatable.");
            });
        });
    };
    VerifyItSuccessMessagePage.prototype.tagListenerSuccess = function () {
        var _this = this;
        this.geolocation
            .getCurrentPosition()
            .then(function (resp) {
            _this.data.lat = resp.coords.latitude;
            _this.data.long = resp.coords.longitude;
        })
            .catch(function (error) {
            console.log("Error getting location", error);
        });
        this.subscriptions.push(this.nfc.addNdefListener().subscribe(function (data) {
            if (_this.readingTag) {
                var payload = data.tag.ndefMessage[0].payload;
                var tagId_1 = _this.nfc.bytesToString(payload).substring(3);
                _this.readingTag = false;
                _this.presentLoading();
                _this.apiSvc.callGetTag(tagId_1).subscribe(function (callgettagresult) {
                    _this.utilservice.callgettagresult = callgettagresult;
                    _this.res = callgettagresult;
                    _this.cred.product_name = _this.res.product_name;
                    // this.alertService.presentAlert('',this.cred.product_name)
                    _this.cred.verified = _this.res.verified;
                    _this.cred.tagId = tagId_1;
                    _this.data.tagId = tagId_1;
                    _this.apiSvc.callRecordScan(_this.data).subscribe(function (callrecordscanresult) {
                        _this.utilservice.callrecordscanresult = callrecordscanresult;
                        _this.loading.dismiss();
                        _this.router.navigateByUrl("/verifyit-product-info");
                        //location
                    }, function (err) {
                        _this.loading.dismiss();
                        _this.alertService.presentAlert("", "call record scan went wrong");
                    });
                    _this.cred.model_number = _this.res.model_number;
                    _this.cred.serial_number = _this.res.serial_number;
                    _this.cred.brand = _this.res.brand;
                    _this.cred.img = _this.res.img;
                    _this.cred.product_details = _this.res.product_details;
                    _this.cred.how_to_use_it = _this.res.how_to_use_it;
                    _this.cred.manufactured = _this.res.manufactured;
                    _this.credKeys.key1 = "Product Name";
                    _this.credKeys.key2 = "Model Number";
                    _this.credKeys.key3 = "Serial Number";
                    _this.credKeys.key4 = "Brand";
                    _this.credKeys.key5 = "Water Resistant";
                    _this.credKeys.key6 = "Display Type";
                    _this.credKeys.key7 = "Series";
                    _this.credKeys.key8 = "Occassion";
                    _this.credKeys.key9 = "Strap";
                    _this.credKeys.key10 = "Manufactured";
                    _this.credKeys.key11 = "Instructions";
                    _this.credKeys.key12 = "Wine Information";
                    _this.credKeys.key13 = "Verified";
                    // this.helperSvc.hideLoading();
                });
            }
        }, function (err) {
            _this.loading.dismiss();
            _this.alertService.presentAlert("", "Something went wrong!");
        }));
    };
    VerifyItSuccessMessagePage.prototype.setStatus = function (message) {
        var _this = this;
        this.alertService.presentAlert("", message);
        this.ngZone.run(function () {
            _this.statusMessage = message;
        });
    };
    VerifyItSuccessMessagePage.prototype.readTag = function () {
        var _this = this;
        if (this.canNFC) {
            setTimeout(function () {
                _this.alertService.presentAlert("", "Please place your mobile near NFC tag.");
                _this.readingTag = true;
                _this.tagListenerSuccess();
            }, 100);
        }
        else {
            this.alertService.presentAlert("", "NFC is not supported by your Device");
        }
    };
    // boughtIt(tagId){
    //       this.apiSvc.callPostBoughtIt(tagId).subscribe((res) => {
    //         this.alertService.presentAlert('',res);
    //         // this.helperSvc.hideLoading();
    //   });
    //   // this.navCtrl.push(ThankyouPage,{})
    //   this.alertService.presentAlert('','thank you')
    // }
    VerifyItSuccessMessagePage.prototype.ionViewWillLeave = function () {
        this.subscriptions.forEach(function (sub) {
            sub.unsubscribe();
        });
    };
    VerifyItSuccessMessagePage.prototype.scanqrcode = function () {
        var _this = this;
        this.options = {
            prompt: "Scan your barcode "
        };
        this.barcodeScanner.scan(this.options).then(function (barcodeData) {
            console.log(barcodeData);
            _this.tagId = barcodeData.text;
            _this.gettag(_this.tagId);
        }, function (err) {
            console.log("Error occured : " + err);
        });
    };
    VerifyItSuccessMessagePage.prototype.gettag = function (tagId) {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function () {
            var _this = this;
            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                switch (_a.label) {
                    case 0:
                        this.geolocation
                            .getCurrentPosition()
                            .then(function (resp) {
                            _this.data.lat = resp.coords.latitude;
                            _this.data.long = resp.coords.longitude;
                        })
                            .catch(function (error) {
                            console.log("Error getting location", error);
                        });
                        return [4 /*yield*/, this.presentLoading()];
                    case 1:
                        _a.sent();
                        this.apiSvc.callGetTag(tagId).subscribe(function (callgettagresult) {
                            _this.utilservice.callgettagresult = callgettagresult;
                            _this.res = callgettagresult;
                            _this.cred.product_name = _this.res.product_name;
                            // this.alertService.presentAlert('',this.cred.product_name)
                            _this.cred.verified = _this.res.verified;
                            _this.cred.tagId = tagId;
                            _this.data.tagId = tagId;
                            _this.apiSvc.callRecordScan(_this.data).subscribe(function (callrecordscanresult) {
                                _this.utilservice.callrecordscanresult = callrecordscanresult;
                                _this.loading.dismiss();
                                _this.router.navigateByUrl("/verifyit-product-info");
                                //location
                            }, function (err) {
                                _this.loading.dismiss();
                                _this.alertService.presentAlert("", "call record scan went wrong");
                            });
                            _this.cred.model_number = _this.res.model_number;
                            _this.cred.serial_number = _this.res.serial_number;
                            _this.cred.brand = _this.res.brand;
                            _this.cred.img = _this.res.img;
                            _this.cred.product_details = _this.res.product_details;
                            _this.cred.how_to_use_it = _this.res.how_to_use_it;
                            _this.cred.manufactured = _this.res.manufactured;
                            _this.credKeys.key1 = "Product Name";
                            _this.credKeys.key2 = "Model Number";
                            _this.credKeys.key3 = "Serial Number";
                            _this.credKeys.key4 = "Brand";
                            _this.credKeys.key5 = "Water Resistant";
                            _this.credKeys.key6 = "Display Type";
                            _this.credKeys.key7 = "Series";
                            _this.credKeys.key8 = "Occassion";
                            _this.credKeys.key9 = "Strap";
                            _this.credKeys.key10 = "Manufactured";
                            _this.credKeys.key11 = "Instructions";
                            _this.credKeys.key12 = "Wine Information";
                            _this.credKeys.key13 = "Verified";
                            // this.helperSvc.hideLoading();
                        });
                        return [2 /*return*/];
                }
            });
        });
    };
    VerifyItSuccessMessagePage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: "app-verifyitsuccessmessage",
            template: __webpack_require__(/*! ./verifyitsuccessmessage.page.html */ "./src/app/Rentals Management/pages/verifyitsuccessmessage/verifyitsuccessmessage.page.html"),
            styles: [__webpack_require__(/*! ./verifyitsuccessmessage.page.scss */ "./src/app/Rentals Management/pages/verifyitsuccessmessage/verifyitsuccessmessage.page.scss")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_ionic_native_nfc_ngx__WEBPACK_IMPORTED_MODULE_2__["NFC"],
            _ionic_native_nfc_ngx__WEBPACK_IMPORTED_MODULE_2__["Ndef"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["Platform"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["LoadingController"],
            _angular_core__WEBPACK_IMPORTED_MODULE_1__["NgZone"],
            _ionic_native_qr_scanner_ngx__WEBPACK_IMPORTED_MODULE_5__["QRScanner"],
            _services_utils_service__WEBPACK_IMPORTED_MODULE_6__["Utils"],
            _angular_router__WEBPACK_IMPORTED_MODULE_7__["Router"],
            _ionic_native_barcode_scanner_ngx__WEBPACK_IMPORTED_MODULE_10__["BarcodeScanner"],
            src_app_common_services_alert_service_service__WEBPACK_IMPORTED_MODULE_8__["AlertServiceService"],
            _ionic_native_geolocation_ngx__WEBPACK_IMPORTED_MODULE_9__["Geolocation"],
            _services_naila_service__WEBPACK_IMPORTED_MODULE_4__["NailaService"]])
    ], VerifyItSuccessMessagePage);
    return VerifyItSuccessMessagePage;
}());



/***/ })

}]);
//# sourceMappingURL=Rentals-Management-pages-verifyitsuccessmessage-verifyitsuccessmessage-module.js.map