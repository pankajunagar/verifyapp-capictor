(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["main"],{

/***/ "./node_modules/@ionic/core/dist/esm-es5 lazy recursive ^\\.\\/.*\\.entry\\.js$ include: \\.entry\\.js$ exclude: \\.system\\.entry\\.js$":
/*!*********************************************************************************************************************************************!*\
  !*** ./node_modules/@ionic/core/dist/esm-es5 lazy ^\.\/.*\.entry\.js$ include: \.entry\.js$ exclude: \.system\.entry\.js$ namespace object ***!
  \*********************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var map = {
	"./ion-action-sheet-controller_8.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-action-sheet-controller_8.entry.js",
		"common",
		12
	],
	"./ion-action-sheet-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-action-sheet-ios.entry.js",
		"common",
		13
	],
	"./ion-action-sheet-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-action-sheet-md.entry.js",
		"common",
		14
	],
	"./ion-alert-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-alert-ios.entry.js",
		"common",
		15
	],
	"./ion-alert-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-alert-md.entry.js",
		"common",
		16
	],
	"./ion-app_8-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-app_8-ios.entry.js",
		0,
		"common",
		17
	],
	"./ion-app_8-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-app_8-md.entry.js",
		0,
		"common",
		18
	],
	"./ion-avatar_3-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-avatar_3-ios.entry.js",
		"common",
		19
	],
	"./ion-avatar_3-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-avatar_3-md.entry.js",
		"common",
		20
	],
	"./ion-back-button-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-back-button-ios.entry.js",
		"common",
		21
	],
	"./ion-back-button-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-back-button-md.entry.js",
		"common",
		22
	],
	"./ion-backdrop-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-backdrop-ios.entry.js",
		23
	],
	"./ion-backdrop-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-backdrop-md.entry.js",
		24
	],
	"./ion-button_2-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-button_2-ios.entry.js",
		"common",
		25
	],
	"./ion-button_2-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-button_2-md.entry.js",
		"common",
		26
	],
	"./ion-card_5-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-card_5-ios.entry.js",
		"common",
		27
	],
	"./ion-card_5-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-card_5-md.entry.js",
		"common",
		28
	],
	"./ion-checkbox-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-checkbox-ios.entry.js",
		"common",
		29
	],
	"./ion-checkbox-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-checkbox-md.entry.js",
		"common",
		30
	],
	"./ion-chip-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-chip-ios.entry.js",
		"common",
		31
	],
	"./ion-chip-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-chip-md.entry.js",
		"common",
		32
	],
	"./ion-col_3.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-col_3.entry.js",
		33
	],
	"./ion-datetime_3-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-datetime_3-ios.entry.js",
		"common",
		34
	],
	"./ion-datetime_3-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-datetime_3-md.entry.js",
		"common",
		35
	],
	"./ion-fab_3-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-fab_3-ios.entry.js",
		"common",
		36
	],
	"./ion-fab_3-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-fab_3-md.entry.js",
		"common",
		37
	],
	"./ion-img.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-img.entry.js",
		38
	],
	"./ion-infinite-scroll_2-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-infinite-scroll_2-ios.entry.js",
		"common",
		39
	],
	"./ion-infinite-scroll_2-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-infinite-scroll_2-md.entry.js",
		"common",
		40
	],
	"./ion-input-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-input-ios.entry.js",
		"common",
		41
	],
	"./ion-input-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-input-md.entry.js",
		"common",
		42
	],
	"./ion-item-option_3-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-item-option_3-ios.entry.js",
		"common",
		43
	],
	"./ion-item-option_3-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-item-option_3-md.entry.js",
		"common",
		44
	],
	"./ion-item_8-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-item_8-ios.entry.js",
		"common",
		45
	],
	"./ion-item_8-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-item_8-md.entry.js",
		"common",
		46
	],
	"./ion-loading-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-loading-ios.entry.js",
		"common",
		47
	],
	"./ion-loading-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-loading-md.entry.js",
		"common",
		48
	],
	"./ion-menu_4-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-menu_4-ios.entry.js",
		"common",
		49
	],
	"./ion-menu_4-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-menu_4-md.entry.js",
		"common",
		50
	],
	"./ion-modal-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-modal-ios.entry.js",
		0,
		"common",
		51
	],
	"./ion-modal-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-modal-md.entry.js",
		0,
		"common",
		52
	],
	"./ion-nav_5.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-nav_5.entry.js",
		0,
		"common",
		53
	],
	"./ion-popover-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-popover-ios.entry.js",
		0,
		"common",
		54
	],
	"./ion-popover-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-popover-md.entry.js",
		0,
		"common",
		55
	],
	"./ion-progress-bar-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-progress-bar-ios.entry.js",
		"common",
		56
	],
	"./ion-progress-bar-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-progress-bar-md.entry.js",
		"common",
		57
	],
	"./ion-radio_2-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-radio_2-ios.entry.js",
		"common",
		58
	],
	"./ion-radio_2-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-radio_2-md.entry.js",
		"common",
		59
	],
	"./ion-range-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-range-ios.entry.js",
		"common",
		60
	],
	"./ion-range-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-range-md.entry.js",
		"common",
		61
	],
	"./ion-refresher_2-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-refresher_2-ios.entry.js",
		"common",
		62
	],
	"./ion-refresher_2-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-refresher_2-md.entry.js",
		"common",
		63
	],
	"./ion-reorder_2-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-reorder_2-ios.entry.js",
		"common",
		64
	],
	"./ion-reorder_2-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-reorder_2-md.entry.js",
		"common",
		65
	],
	"./ion-ripple-effect.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-ripple-effect.entry.js",
		66
	],
	"./ion-route_4.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-route_4.entry.js",
		"common",
		67
	],
	"./ion-searchbar-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-searchbar-ios.entry.js",
		"common",
		68
	],
	"./ion-searchbar-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-searchbar-md.entry.js",
		"common",
		69
	],
	"./ion-segment_2-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-segment_2-ios.entry.js",
		"common",
		70
	],
	"./ion-segment_2-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-segment_2-md.entry.js",
		"common",
		71
	],
	"./ion-select_3-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-select_3-ios.entry.js",
		"common",
		72
	],
	"./ion-select_3-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-select_3-md.entry.js",
		"common",
		73
	],
	"./ion-slide_2-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-slide_2-ios.entry.js",
		74
	],
	"./ion-slide_2-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-slide_2-md.entry.js",
		75
	],
	"./ion-spinner.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-spinner.entry.js",
		"common",
		76
	],
	"./ion-split-pane-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-split-pane-ios.entry.js",
		77
	],
	"./ion-split-pane-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-split-pane-md.entry.js",
		78
	],
	"./ion-tab-bar_2-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-tab-bar_2-ios.entry.js",
		"common",
		79
	],
	"./ion-tab-bar_2-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-tab-bar_2-md.entry.js",
		"common",
		80
	],
	"./ion-tab_2.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-tab_2.entry.js",
		"common",
		9
	],
	"./ion-text.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-text.entry.js",
		"common",
		81
	],
	"./ion-textarea-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-textarea-ios.entry.js",
		"common",
		82
	],
	"./ion-textarea-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-textarea-md.entry.js",
		"common",
		83
	],
	"./ion-toast-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-toast-ios.entry.js",
		"common",
		84
	],
	"./ion-toast-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-toast-md.entry.js",
		"common",
		85
	],
	"./ion-toggle-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-toggle-ios.entry.js",
		"common",
		86
	],
	"./ion-toggle-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-toggle-md.entry.js",
		"common",
		87
	],
	"./ion-virtual-scroll.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-virtual-scroll.entry.js",
		88
	]
};
function webpackAsyncContext(req) {
	var ids = map[req];
	if(!ids) {
		return Promise.resolve().then(function() {
			var e = new Error("Cannot find module '" + req + "'");
			e.code = 'MODULE_NOT_FOUND';
			throw e;
		});
	}
	return Promise.all(ids.slice(1).map(__webpack_require__.e)).then(function() {
		var id = ids[0];
		return __webpack_require__(id);
	});
}
webpackAsyncContext.keys = function webpackAsyncContextKeys() {
	return Object.keys(map);
};
webpackAsyncContext.id = "./node_modules/@ionic/core/dist/esm-es5 lazy recursive ^\\.\\/.*\\.entry\\.js$ include: \\.entry\\.js$ exclude: \\.system\\.entry\\.js$";
module.exports = webpackAsyncContext;

/***/ }),

/***/ "./node_modules/moment/locale sync recursive ^\\.\\/.*$":
/*!**************************************************!*\
  !*** ./node_modules/moment/locale sync ^\.\/.*$ ***!
  \**************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var map = {
	"./af": "./node_modules/moment/locale/af.js",
	"./af.js": "./node_modules/moment/locale/af.js",
	"./ar": "./node_modules/moment/locale/ar.js",
	"./ar-dz": "./node_modules/moment/locale/ar-dz.js",
	"./ar-dz.js": "./node_modules/moment/locale/ar-dz.js",
	"./ar-kw": "./node_modules/moment/locale/ar-kw.js",
	"./ar-kw.js": "./node_modules/moment/locale/ar-kw.js",
	"./ar-ly": "./node_modules/moment/locale/ar-ly.js",
	"./ar-ly.js": "./node_modules/moment/locale/ar-ly.js",
	"./ar-ma": "./node_modules/moment/locale/ar-ma.js",
	"./ar-ma.js": "./node_modules/moment/locale/ar-ma.js",
	"./ar-sa": "./node_modules/moment/locale/ar-sa.js",
	"./ar-sa.js": "./node_modules/moment/locale/ar-sa.js",
	"./ar-tn": "./node_modules/moment/locale/ar-tn.js",
	"./ar-tn.js": "./node_modules/moment/locale/ar-tn.js",
	"./ar.js": "./node_modules/moment/locale/ar.js",
	"./az": "./node_modules/moment/locale/az.js",
	"./az.js": "./node_modules/moment/locale/az.js",
	"./be": "./node_modules/moment/locale/be.js",
	"./be.js": "./node_modules/moment/locale/be.js",
	"./bg": "./node_modules/moment/locale/bg.js",
	"./bg.js": "./node_modules/moment/locale/bg.js",
	"./bm": "./node_modules/moment/locale/bm.js",
	"./bm.js": "./node_modules/moment/locale/bm.js",
	"./bn": "./node_modules/moment/locale/bn.js",
	"./bn-bd": "./node_modules/moment/locale/bn-bd.js",
	"./bn-bd.js": "./node_modules/moment/locale/bn-bd.js",
	"./bn.js": "./node_modules/moment/locale/bn.js",
	"./bo": "./node_modules/moment/locale/bo.js",
	"./bo.js": "./node_modules/moment/locale/bo.js",
	"./br": "./node_modules/moment/locale/br.js",
	"./br.js": "./node_modules/moment/locale/br.js",
	"./bs": "./node_modules/moment/locale/bs.js",
	"./bs.js": "./node_modules/moment/locale/bs.js",
	"./ca": "./node_modules/moment/locale/ca.js",
	"./ca.js": "./node_modules/moment/locale/ca.js",
	"./cs": "./node_modules/moment/locale/cs.js",
	"./cs.js": "./node_modules/moment/locale/cs.js",
	"./cv": "./node_modules/moment/locale/cv.js",
	"./cv.js": "./node_modules/moment/locale/cv.js",
	"./cy": "./node_modules/moment/locale/cy.js",
	"./cy.js": "./node_modules/moment/locale/cy.js",
	"./da": "./node_modules/moment/locale/da.js",
	"./da.js": "./node_modules/moment/locale/da.js",
	"./de": "./node_modules/moment/locale/de.js",
	"./de-at": "./node_modules/moment/locale/de-at.js",
	"./de-at.js": "./node_modules/moment/locale/de-at.js",
	"./de-ch": "./node_modules/moment/locale/de-ch.js",
	"./de-ch.js": "./node_modules/moment/locale/de-ch.js",
	"./de.js": "./node_modules/moment/locale/de.js",
	"./dv": "./node_modules/moment/locale/dv.js",
	"./dv.js": "./node_modules/moment/locale/dv.js",
	"./el": "./node_modules/moment/locale/el.js",
	"./el.js": "./node_modules/moment/locale/el.js",
	"./en-au": "./node_modules/moment/locale/en-au.js",
	"./en-au.js": "./node_modules/moment/locale/en-au.js",
	"./en-ca": "./node_modules/moment/locale/en-ca.js",
	"./en-ca.js": "./node_modules/moment/locale/en-ca.js",
	"./en-gb": "./node_modules/moment/locale/en-gb.js",
	"./en-gb.js": "./node_modules/moment/locale/en-gb.js",
	"./en-ie": "./node_modules/moment/locale/en-ie.js",
	"./en-ie.js": "./node_modules/moment/locale/en-ie.js",
	"./en-il": "./node_modules/moment/locale/en-il.js",
	"./en-il.js": "./node_modules/moment/locale/en-il.js",
	"./en-in": "./node_modules/moment/locale/en-in.js",
	"./en-in.js": "./node_modules/moment/locale/en-in.js",
	"./en-nz": "./node_modules/moment/locale/en-nz.js",
	"./en-nz.js": "./node_modules/moment/locale/en-nz.js",
	"./en-sg": "./node_modules/moment/locale/en-sg.js",
	"./en-sg.js": "./node_modules/moment/locale/en-sg.js",
	"./eo": "./node_modules/moment/locale/eo.js",
	"./eo.js": "./node_modules/moment/locale/eo.js",
	"./es": "./node_modules/moment/locale/es.js",
	"./es-do": "./node_modules/moment/locale/es-do.js",
	"./es-do.js": "./node_modules/moment/locale/es-do.js",
	"./es-mx": "./node_modules/moment/locale/es-mx.js",
	"./es-mx.js": "./node_modules/moment/locale/es-mx.js",
	"./es-us": "./node_modules/moment/locale/es-us.js",
	"./es-us.js": "./node_modules/moment/locale/es-us.js",
	"./es.js": "./node_modules/moment/locale/es.js",
	"./et": "./node_modules/moment/locale/et.js",
	"./et.js": "./node_modules/moment/locale/et.js",
	"./eu": "./node_modules/moment/locale/eu.js",
	"./eu.js": "./node_modules/moment/locale/eu.js",
	"./fa": "./node_modules/moment/locale/fa.js",
	"./fa.js": "./node_modules/moment/locale/fa.js",
	"./fi": "./node_modules/moment/locale/fi.js",
	"./fi.js": "./node_modules/moment/locale/fi.js",
	"./fil": "./node_modules/moment/locale/fil.js",
	"./fil.js": "./node_modules/moment/locale/fil.js",
	"./fo": "./node_modules/moment/locale/fo.js",
	"./fo.js": "./node_modules/moment/locale/fo.js",
	"./fr": "./node_modules/moment/locale/fr.js",
	"./fr-ca": "./node_modules/moment/locale/fr-ca.js",
	"./fr-ca.js": "./node_modules/moment/locale/fr-ca.js",
	"./fr-ch": "./node_modules/moment/locale/fr-ch.js",
	"./fr-ch.js": "./node_modules/moment/locale/fr-ch.js",
	"./fr.js": "./node_modules/moment/locale/fr.js",
	"./fy": "./node_modules/moment/locale/fy.js",
	"./fy.js": "./node_modules/moment/locale/fy.js",
	"./ga": "./node_modules/moment/locale/ga.js",
	"./ga.js": "./node_modules/moment/locale/ga.js",
	"./gd": "./node_modules/moment/locale/gd.js",
	"./gd.js": "./node_modules/moment/locale/gd.js",
	"./gl": "./node_modules/moment/locale/gl.js",
	"./gl.js": "./node_modules/moment/locale/gl.js",
	"./gom-deva": "./node_modules/moment/locale/gom-deva.js",
	"./gom-deva.js": "./node_modules/moment/locale/gom-deva.js",
	"./gom-latn": "./node_modules/moment/locale/gom-latn.js",
	"./gom-latn.js": "./node_modules/moment/locale/gom-latn.js",
	"./gu": "./node_modules/moment/locale/gu.js",
	"./gu.js": "./node_modules/moment/locale/gu.js",
	"./he": "./node_modules/moment/locale/he.js",
	"./he.js": "./node_modules/moment/locale/he.js",
	"./hi": "./node_modules/moment/locale/hi.js",
	"./hi.js": "./node_modules/moment/locale/hi.js",
	"./hr": "./node_modules/moment/locale/hr.js",
	"./hr.js": "./node_modules/moment/locale/hr.js",
	"./hu": "./node_modules/moment/locale/hu.js",
	"./hu.js": "./node_modules/moment/locale/hu.js",
	"./hy-am": "./node_modules/moment/locale/hy-am.js",
	"./hy-am.js": "./node_modules/moment/locale/hy-am.js",
	"./id": "./node_modules/moment/locale/id.js",
	"./id.js": "./node_modules/moment/locale/id.js",
	"./is": "./node_modules/moment/locale/is.js",
	"./is.js": "./node_modules/moment/locale/is.js",
	"./it": "./node_modules/moment/locale/it.js",
	"./it-ch": "./node_modules/moment/locale/it-ch.js",
	"./it-ch.js": "./node_modules/moment/locale/it-ch.js",
	"./it.js": "./node_modules/moment/locale/it.js",
	"./ja": "./node_modules/moment/locale/ja.js",
	"./ja.js": "./node_modules/moment/locale/ja.js",
	"./jv": "./node_modules/moment/locale/jv.js",
	"./jv.js": "./node_modules/moment/locale/jv.js",
	"./ka": "./node_modules/moment/locale/ka.js",
	"./ka.js": "./node_modules/moment/locale/ka.js",
	"./kk": "./node_modules/moment/locale/kk.js",
	"./kk.js": "./node_modules/moment/locale/kk.js",
	"./km": "./node_modules/moment/locale/km.js",
	"./km.js": "./node_modules/moment/locale/km.js",
	"./kn": "./node_modules/moment/locale/kn.js",
	"./kn.js": "./node_modules/moment/locale/kn.js",
	"./ko": "./node_modules/moment/locale/ko.js",
	"./ko.js": "./node_modules/moment/locale/ko.js",
	"./ku": "./node_modules/moment/locale/ku.js",
	"./ku.js": "./node_modules/moment/locale/ku.js",
	"./ky": "./node_modules/moment/locale/ky.js",
	"./ky.js": "./node_modules/moment/locale/ky.js",
	"./lb": "./node_modules/moment/locale/lb.js",
	"./lb.js": "./node_modules/moment/locale/lb.js",
	"./lo": "./node_modules/moment/locale/lo.js",
	"./lo.js": "./node_modules/moment/locale/lo.js",
	"./lt": "./node_modules/moment/locale/lt.js",
	"./lt.js": "./node_modules/moment/locale/lt.js",
	"./lv": "./node_modules/moment/locale/lv.js",
	"./lv.js": "./node_modules/moment/locale/lv.js",
	"./me": "./node_modules/moment/locale/me.js",
	"./me.js": "./node_modules/moment/locale/me.js",
	"./mi": "./node_modules/moment/locale/mi.js",
	"./mi.js": "./node_modules/moment/locale/mi.js",
	"./mk": "./node_modules/moment/locale/mk.js",
	"./mk.js": "./node_modules/moment/locale/mk.js",
	"./ml": "./node_modules/moment/locale/ml.js",
	"./ml.js": "./node_modules/moment/locale/ml.js",
	"./mn": "./node_modules/moment/locale/mn.js",
	"./mn.js": "./node_modules/moment/locale/mn.js",
	"./mr": "./node_modules/moment/locale/mr.js",
	"./mr.js": "./node_modules/moment/locale/mr.js",
	"./ms": "./node_modules/moment/locale/ms.js",
	"./ms-my": "./node_modules/moment/locale/ms-my.js",
	"./ms-my.js": "./node_modules/moment/locale/ms-my.js",
	"./ms.js": "./node_modules/moment/locale/ms.js",
	"./mt": "./node_modules/moment/locale/mt.js",
	"./mt.js": "./node_modules/moment/locale/mt.js",
	"./my": "./node_modules/moment/locale/my.js",
	"./my.js": "./node_modules/moment/locale/my.js",
	"./nb": "./node_modules/moment/locale/nb.js",
	"./nb.js": "./node_modules/moment/locale/nb.js",
	"./ne": "./node_modules/moment/locale/ne.js",
	"./ne.js": "./node_modules/moment/locale/ne.js",
	"./nl": "./node_modules/moment/locale/nl.js",
	"./nl-be": "./node_modules/moment/locale/nl-be.js",
	"./nl-be.js": "./node_modules/moment/locale/nl-be.js",
	"./nl.js": "./node_modules/moment/locale/nl.js",
	"./nn": "./node_modules/moment/locale/nn.js",
	"./nn.js": "./node_modules/moment/locale/nn.js",
	"./oc-lnc": "./node_modules/moment/locale/oc-lnc.js",
	"./oc-lnc.js": "./node_modules/moment/locale/oc-lnc.js",
	"./pa-in": "./node_modules/moment/locale/pa-in.js",
	"./pa-in.js": "./node_modules/moment/locale/pa-in.js",
	"./pl": "./node_modules/moment/locale/pl.js",
	"./pl.js": "./node_modules/moment/locale/pl.js",
	"./pt": "./node_modules/moment/locale/pt.js",
	"./pt-br": "./node_modules/moment/locale/pt-br.js",
	"./pt-br.js": "./node_modules/moment/locale/pt-br.js",
	"./pt.js": "./node_modules/moment/locale/pt.js",
	"./ro": "./node_modules/moment/locale/ro.js",
	"./ro.js": "./node_modules/moment/locale/ro.js",
	"./ru": "./node_modules/moment/locale/ru.js",
	"./ru.js": "./node_modules/moment/locale/ru.js",
	"./sd": "./node_modules/moment/locale/sd.js",
	"./sd.js": "./node_modules/moment/locale/sd.js",
	"./se": "./node_modules/moment/locale/se.js",
	"./se.js": "./node_modules/moment/locale/se.js",
	"./si": "./node_modules/moment/locale/si.js",
	"./si.js": "./node_modules/moment/locale/si.js",
	"./sk": "./node_modules/moment/locale/sk.js",
	"./sk.js": "./node_modules/moment/locale/sk.js",
	"./sl": "./node_modules/moment/locale/sl.js",
	"./sl.js": "./node_modules/moment/locale/sl.js",
	"./sq": "./node_modules/moment/locale/sq.js",
	"./sq.js": "./node_modules/moment/locale/sq.js",
	"./sr": "./node_modules/moment/locale/sr.js",
	"./sr-cyrl": "./node_modules/moment/locale/sr-cyrl.js",
	"./sr-cyrl.js": "./node_modules/moment/locale/sr-cyrl.js",
	"./sr.js": "./node_modules/moment/locale/sr.js",
	"./ss": "./node_modules/moment/locale/ss.js",
	"./ss.js": "./node_modules/moment/locale/ss.js",
	"./sv": "./node_modules/moment/locale/sv.js",
	"./sv.js": "./node_modules/moment/locale/sv.js",
	"./sw": "./node_modules/moment/locale/sw.js",
	"./sw.js": "./node_modules/moment/locale/sw.js",
	"./ta": "./node_modules/moment/locale/ta.js",
	"./ta.js": "./node_modules/moment/locale/ta.js",
	"./te": "./node_modules/moment/locale/te.js",
	"./te.js": "./node_modules/moment/locale/te.js",
	"./tet": "./node_modules/moment/locale/tet.js",
	"./tet.js": "./node_modules/moment/locale/tet.js",
	"./tg": "./node_modules/moment/locale/tg.js",
	"./tg.js": "./node_modules/moment/locale/tg.js",
	"./th": "./node_modules/moment/locale/th.js",
	"./th.js": "./node_modules/moment/locale/th.js",
	"./tk": "./node_modules/moment/locale/tk.js",
	"./tk.js": "./node_modules/moment/locale/tk.js",
	"./tl-ph": "./node_modules/moment/locale/tl-ph.js",
	"./tl-ph.js": "./node_modules/moment/locale/tl-ph.js",
	"./tlh": "./node_modules/moment/locale/tlh.js",
	"./tlh.js": "./node_modules/moment/locale/tlh.js",
	"./tr": "./node_modules/moment/locale/tr.js",
	"./tr.js": "./node_modules/moment/locale/tr.js",
	"./tzl": "./node_modules/moment/locale/tzl.js",
	"./tzl.js": "./node_modules/moment/locale/tzl.js",
	"./tzm": "./node_modules/moment/locale/tzm.js",
	"./tzm-latn": "./node_modules/moment/locale/tzm-latn.js",
	"./tzm-latn.js": "./node_modules/moment/locale/tzm-latn.js",
	"./tzm.js": "./node_modules/moment/locale/tzm.js",
	"./ug-cn": "./node_modules/moment/locale/ug-cn.js",
	"./ug-cn.js": "./node_modules/moment/locale/ug-cn.js",
	"./uk": "./node_modules/moment/locale/uk.js",
	"./uk.js": "./node_modules/moment/locale/uk.js",
	"./ur": "./node_modules/moment/locale/ur.js",
	"./ur.js": "./node_modules/moment/locale/ur.js",
	"./uz": "./node_modules/moment/locale/uz.js",
	"./uz-latn": "./node_modules/moment/locale/uz-latn.js",
	"./uz-latn.js": "./node_modules/moment/locale/uz-latn.js",
	"./uz.js": "./node_modules/moment/locale/uz.js",
	"./vi": "./node_modules/moment/locale/vi.js",
	"./vi.js": "./node_modules/moment/locale/vi.js",
	"./x-pseudo": "./node_modules/moment/locale/x-pseudo.js",
	"./x-pseudo.js": "./node_modules/moment/locale/x-pseudo.js",
	"./yo": "./node_modules/moment/locale/yo.js",
	"./yo.js": "./node_modules/moment/locale/yo.js",
	"./zh-cn": "./node_modules/moment/locale/zh-cn.js",
	"./zh-cn.js": "./node_modules/moment/locale/zh-cn.js",
	"./zh-hk": "./node_modules/moment/locale/zh-hk.js",
	"./zh-hk.js": "./node_modules/moment/locale/zh-hk.js",
	"./zh-mo": "./node_modules/moment/locale/zh-mo.js",
	"./zh-mo.js": "./node_modules/moment/locale/zh-mo.js",
	"./zh-tw": "./node_modules/moment/locale/zh-tw.js",
	"./zh-tw.js": "./node_modules/moment/locale/zh-tw.js"
};


function webpackContext(req) {
	var id = webpackContextResolve(req);
	return __webpack_require__(id);
}
function webpackContextResolve(req) {
	var id = map[req];
	if(!(id + 1)) { // check for number or string
		var e = new Error("Cannot find module '" + req + "'");
		e.code = 'MODULE_NOT_FOUND';
		throw e;
	}
	return id;
}
webpackContext.keys = function webpackContextKeys() {
	return Object.keys(map);
};
webpackContext.resolve = webpackContextResolve;
module.exports = webpackContext;
webpackContext.id = "./node_modules/moment/locale sync recursive ^\\.\\/.*$";

/***/ }),

/***/ "./src/$$_lazy_route_resource lazy recursive":
/*!**********************************************************!*\
  !*** ./src/$$_lazy_route_resource lazy namespace object ***!
  \**********************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var map = {
	"../Rentals Management/pages/beauticianbooking/beauticianbooking.module": [
		"./src/app/Rentals Management/pages/beauticianbooking/beauticianbooking.module.ts",
		"Rentals-Management-pages-beauticianbooking-beauticianbooking-module"
	],
	"../Rentals Management/pages/calendar/calendar.module": [
		"./src/app/Rentals Management/pages/calendar/calendar.module.ts",
		"Rentals-Management-pages-calendar-calendar-module"
	],
	"../Rentals Management/pages/contact-us/contact-us.module": [
		"./src/app/Rentals Management/pages/contact-us/contact-us.module.ts",
		"Rentals-Management-pages-contact-us-contact-us-module"
	],
	"../Rentals Management/pages/create-ticket/create-ticket.module": [
		"./src/app/Rentals Management/pages/create-ticket/create-ticket.module.ts",
		"Rentals-Management-pages-create-ticket-create-ticket-module"
	],
	"../Rentals Management/pages/estimate/estimate.module": [
		"./src/app/Rentals Management/pages/estimate/estimate.module.ts",
		"Rentals-Management-pages-estimate-estimate-module"
	],
	"../Rentals Management/pages/home/home.module": [
		"./src/app/Rentals Management/pages/home/home.module.ts",
		"Rentals-Management-pages-home-home-module"
	],
	"../Rentals Management/pages/material-search/material-search.module": [
		"./src/app/Rentals Management/pages/material-search/material-search.module.ts"
	],
	"../Rentals Management/pages/nailaaccountpage/nailaaccountpage.module": [
		"./src/app/Rentals Management/pages/nailaaccountpage/nailaaccountpage.module.ts",
		"default~Rentals-Management-pages-nailaaccountpage-nailaaccountpage-module~Rentals-Management-pages-n~0f6f80ab",
		"common",
		"Rentals-Management-pages-nailaaccountpage-nailaaccountpage-module"
	],
	"../Rentals Management/pages/nailabeauticianattendance/nailabeauticianattendance.module": [
		"./src/app/Rentals Management/pages/nailabeauticianattendance/nailabeauticianattendance.module.ts",
		"default~Rentals-Management-pages-nailaaccountpage-nailaaccountpage-module~Rentals-Management-pages-n~0f6f80ab",
		"common",
		"Rentals-Management-pages-nailabeauticianattendance-nailabeauticianattendance-module"
	],
	"../Rentals Management/pages/nailabooking/nailabooking.module": [
		"./src/app/Rentals Management/pages/nailabooking/nailabooking.module.ts",
		"Rentals-Management-pages-nailabooking-nailabooking-module"
	],
	"../Rentals Management/pages/nailacart/nailacart.module": [
		"./src/app/Rentals Management/pages/nailacart/nailacart.module.ts",
		"Rentals-Management-pages-nailacart-nailacart-module"
	],
	"../Rentals Management/pages/nailaofferslisting/nailaofferslisting.module": [
		"./src/app/Rentals Management/pages/nailaofferslisting/nailaofferslisting.module.ts",
		"Rentals-Management-pages-nailaofferslisting-nailaofferslisting-module"
	],
	"../Rentals Management/pages/nailaofferspage/nailaofferspage.module": [
		"./src/app/Rentals Management/pages/nailaofferspage/nailaofferspage.module.ts",
		"Rentals-Management-pages-nailaofferspage-nailaofferspage-module"
	],
	"../Rentals Management/pages/nailasearchpage/nailasearchpage.module": [
		"./src/app/Rentals Management/pages/nailasearchpage/nailasearchpage.module.ts",
		"Rentals-Management-pages-nailasearchpage-nailasearchpage-module"
	],
	"../Rentals Management/pages/nailaservicepage/nailaservicepage.module": [
		"./src/app/Rentals Management/pages/nailaservicepage/nailaservicepage.module.ts",
		"Rentals-Management-pages-nailaservicepage-nailaservicepage-module"
	],
	"../Rentals Management/pages/nailaticket/nailaticket.module": [
		"./src/app/Rentals Management/pages/nailaticket/nailaticket.module.ts",
		"Rentals-Management-pages-nailaticket-nailaticket-module"
	],
	"../Rentals Management/pages/notice-board/notice-board.module": [
		"./src/app/Rentals Management/pages/notice-board/notice-board.module.ts",
		"Rentals-Management-pages-notice-board-notice-board-module"
	],
	"../Rentals Management/pages/notice-details/notice-details.module": [
		"./src/app/Rentals Management/pages/notice-details/notice-details.module.ts",
		"Rentals-Management-pages-notice-details-notice-details-module"
	],
	"../Rentals Management/pages/profile/profile.module": [
		"./src/app/Rentals Management/pages/profile/profile.module.ts",
		"Rentals-Management-pages-profile-profile-module"
	],
	"../Rentals Management/pages/project-search/project-search.module": [
		"./src/app/Rentals Management/pages/project-search/project-search.module.ts"
	],
	"../Rentals Management/pages/ticket-category-search/ticket-category-search.module": [
		"./src/app/Rentals Management/pages/ticket-category-search/ticket-category-search.module.ts"
	],
	"../Rentals Management/pages/ticket-details/ticket-details.module": [
		"./src/app/Rentals Management/pages/ticket-details/ticket-details.module.ts",
		"Rentals-Management-pages-ticket-details-ticket-details-module"
	],
	"../Rentals Management/pages/ticket-filter/ticket-filter.module": [
		"./src/app/Rentals Management/pages/ticket-filter/ticket-filter.module.ts"
	],
	"../Rentals Management/pages/ticket-sub-category-search/ticket-sub-category-search.module": [
		"./src/app/Rentals Management/pages/ticket-sub-category-search/ticket-sub-category-search.module.ts"
	],
	"../Rentals Management/pages/tickets/tickets.module": [
		"./src/app/Rentals Management/pages/tickets/tickets.module.ts",
		"Rentals-Management-pages-tickets-tickets-module"
	],
	"../Rentals Management/pages/unit-search/unit-search.module": [
		"./src/app/Rentals Management/pages/unit-search/unit-search.module.ts"
	],
	"../Rentals Management/pages/user-approval/user-approval.module": [
		"./src/app/Rentals Management/pages/user-approval/user-approval.module.ts",
		"Rentals-Management-pages-user-approval-user-approval-module"
	],
	"../Rentals Management/pages/user-search/user-search.module": [
		"./src/app/Rentals Management/pages/user-search/user-search.module.ts"
	],
	"../Rentals Management/pages/verifyitProductinfo/verifyitProductinfo.module": [
		"./src/app/Rentals Management/pages/verifyitProductinfo/verifyitProductinfo.module.ts",
		"default~Rentals-Management-pages-verifyitProductinfo-verifyitProductinfo-module~Rentals-Management-p~8f8ff555",
		"common",
		"Rentals-Management-pages-verifyitProductinfo-verifyitProductinfo-module"
	],
	"../Rentals Management/pages/verifyitaccountspage/verifyitaccountspage.module": [
		"./src/app/Rentals Management/pages/verifyitaccountspage/verifyitaccountspage.module.ts",
		"default~Rentals-Management-pages-nailaaccountpage-nailaaccountpage-module~Rentals-Management-pages-n~0f6f80ab",
		"common",
		"Rentals-Management-pages-verifyitaccountspage-verifyitaccountspage-module"
	],
	"../Rentals Management/pages/verifyitdashboard/verifyitdashboard.module": [
		"./src/app/Rentals Management/pages/verifyitdashboard/verifyitdashboard.module.ts",
		"Rentals-Management-pages-verifyitdashboard-verifyitdashboard-module"
	],
	"../Rentals Management/pages/verifyitproductcatalog/verifyitproductcatalog.module": [
		"./src/app/Rentals Management/pages/verifyitproductcatalog/verifyitproductcatalog.module.ts",
		"Rentals-Management-pages-verifyitproductcatalog-verifyitproductcatalog-module"
	],
	"../Rentals Management/pages/verifyitproductcataloginfo/verifyitproductcataloginfo.module": [
		"./src/app/Rentals Management/pages/verifyitproductcataloginfo/verifyitproductcataloginfo.module.ts",
		"default~Rentals-Management-pages-verifyitProductinfo-verifyitProductinfo-module~Rentals-Management-p~8f8ff555",
		"common",
		"Rentals-Management-pages-verifyitproductcataloginfo-verifyitproductcataloginfo-module"
	],
	"../Rentals Management/pages/verifyitstoreproductinfo/verifyitstoreproductinfo.module": [
		"./src/app/Rentals Management/pages/verifyitstoreproductinfo/verifyitstoreproductinfo.module.ts",
		"Rentals-Management-pages-verifyitstoreproductinfo-verifyitstoreproductinfo-module"
	],
	"../Rentals Management/pages/verifyitsuccessmessage/verifyitsuccessmessage.module": [
		"./src/app/Rentals Management/pages/verifyitsuccessmessage/verifyitsuccessmessage.module.ts",
		"Rentals-Management-pages-verifyitsuccessmessage-verifyitsuccessmessage-module"
	],
	"../app/Rentals Management/pages/verifyitdashboard/verifyitdashboard.module": [
		"./src/app/Rentals Management/pages/verifyitdashboard/verifyitdashboard.module.ts",
		"Rentals-Management-pages-verifyitdashboard-verifyitdashboard-module"
	],
	"../app/Rentals Management/rental-management.module": [
		"./src/app/Rentals Management/rental-management.module.ts"
	],
	"../app/login/login.module": [
		"./src/app/login/login.module.ts",
		"app-login-login-module"
	]
};
function webpackAsyncContext(req) {
	var ids = map[req];
	if(!ids) {
		return Promise.resolve().then(function() {
			var e = new Error("Cannot find module '" + req + "'");
			e.code = 'MODULE_NOT_FOUND';
			throw e;
		});
	}
	return Promise.all(ids.slice(1).map(__webpack_require__.e)).then(function() {
		var id = ids[0];
		return __webpack_require__(id);
	});
}
webpackAsyncContext.keys = function webpackAsyncContextKeys() {
	return Object.keys(map);
};
webpackAsyncContext.id = "./src/$$_lazy_route_resource lazy recursive";
module.exports = webpackAsyncContext;

/***/ }),

/***/ "./src/app/Building-Management/services/building-user.service.ts":
/*!***********************************************************************!*\
  !*** ./src/app/Building-Management/services/building-user.service.ts ***!
  \***********************************************************************/
/*! exports provided: BuildingUserService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "BuildingUserService", function() { return BuildingUserService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/fesm5/http.js");
/* harmony import */ var src_app_conatants_MainAppSetting__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/conatants/MainAppSetting */ "./src/app/conatants/MainAppSetting.ts");




var BuildingUserService = /** @class */ (function () {
    function BuildingUserService(http, appSettings) {
        this.http = http;
        this.appSettings = appSettings;
    }
    BuildingUserService.prototype.getUsers = function () {
        return this.http.get(this.appSettings.getApi() + "/api/user/type?fields=firstName&fields=lastName&fields=types&fields=_id&status=active&types=vendor&types=employee&types=contract-employee&types=technician&types=admin&types=housekeeper", {
            headers: new _angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpHeaders"]({
                'Content-Type': 'application/json',
                Authorization: localStorage.getItem('token')
            })
        });
    };
    BuildingUserService.prototype.getUserById = function (id) {
        return this.http.get(this.appSettings.getApi() + "/api/user/" + id, {
            headers: new _angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpHeaders"]({
                'Content-Type': 'application/json',
                Authorization: localStorage.getItem('token')
            })
        });
    };
    BuildingUserService.prototype.getUserApprovals = function () {
        return this.http.get(this.appSettings.getApi() + "/api/approval", {
            headers: new _angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpHeaders"]({
                'Content-Type': 'application/json',
                Authorization: localStorage.getItem('token')
            })
        });
    };
    BuildingUserService.prototype.updateUser = function (data) {
        return this.http.put(this.appSettings.getApi() + "/api/user/" + data._id, data, {
            headers: new _angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpHeaders"]({
                'Content-Type': 'application/json',
                Authorization: localStorage.getItem('token')
            })
        });
    };
    BuildingUserService.prototype.approve = function (id) {
        return this.http.post(this.appSettings.getApi() + "/api/approval/" + id + "/approve", '', this.appSettings.getHttpHeadesWithToken());
    };
    BuildingUserService.prototype.reject = function (id, data) {
        console.log(data);
        var userData = {
            notes: data
        };
        return this.http.post(this.appSettings.getApi() + "/api/approval/" + id + "/reject", userData, this.appSettings.getHttpHeadesWithToken());
    };
    BuildingUserService = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
            providedIn: 'root'
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpClient"],
            src_app_conatants_MainAppSetting__WEBPACK_IMPORTED_MODULE_3__["MainAppSetting"]])
    ], BuildingUserService);
    return BuildingUserService;
}());



/***/ }),

/***/ "./src/app/Rentals Management/ApplicationPageModule.ts":
/*!*************************************************************!*\
  !*** ./src/app/Rentals Management/ApplicationPageModule.ts ***!
  \*************************************************************/
/*! exports provided: ApplicationPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ApplicationPageModule", function() { return ApplicationPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _pipes_agofilter__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./pipes/agofilter */ "./src/app/Rentals Management/pipes/agofilter.ts");
/* harmony import */ var _modals_create_notice_create_notice_component__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./modals/create-notice/create-notice.component */ "./src/app/Rentals Management/modals/create-notice/create-notice.component.ts");







var ApplicationPageModule = /** @class */ (function () {
    function ApplicationPageModule() {
    }
    ApplicationPageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_2__["NgModule"])({
            imports: [
                _angular_common__WEBPACK_IMPORTED_MODULE_1__["CommonModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormsModule"],
                _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["IonicModule"]
            ],
            declarations: [
                _pipes_agofilter__WEBPACK_IMPORTED_MODULE_5__["AgoFilter"],
                _modals_create_notice_create_notice_component__WEBPACK_IMPORTED_MODULE_6__["CreateNoticeComponent"]
            ],
            entryComponents: [],
            exports: [
                _pipes_agofilter__WEBPACK_IMPORTED_MODULE_5__["AgoFilter"],
                _modals_create_notice_create_notice_component__WEBPACK_IMPORTED_MODULE_6__["CreateNoticeComponent"]
            ]
        })
    ], ApplicationPageModule);
    return ApplicationPageModule;
}());



/***/ }),

/***/ "./src/app/Rentals Management/modals/approvalpopup/approvalpopup.component.html":
/*!**************************************************************************************!*\
  !*** ./src/app/Rentals Management/modals/approvalpopup/approvalpopup.component.html ***!
  \**************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ""

/***/ }),

/***/ "./src/app/Rentals Management/modals/approvalpopup/approvalpopup.component.scss":
/*!**************************************************************************************!*\
  !*** ./src/app/Rentals Management/modals/approvalpopup/approvalpopup.component.scss ***!
  \**************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "ion-button {\n  --background: #ffffff;\n  --color: #000000; }\n\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvUmVudGFscyBNYW5hZ2VtZW50L21vZGFscy9hcHByb3ZhbHBvcHVwL0Q6XFxuYXZqb3RcXHZlcmlmeS9zcmNcXGFwcFxcUmVudGFscyBNYW5hZ2VtZW50XFxtb2RhbHNcXGFwcHJvdmFscG9wdXBcXGFwcHJvdmFscG9wdXAuY29tcG9uZW50LnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDRSxxQkFBYTtFQUNiLGdCQUFRLEVBQUEiLCJmaWxlIjoic3JjL2FwcC9SZW50YWxzIE1hbmFnZW1lbnQvbW9kYWxzL2FwcHJvdmFscG9wdXAvYXBwcm92YWxwb3B1cC5jb21wb25lbnQuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbImlvbi1idXR0b24ge1xyXG4gIC0tYmFja2dyb3VuZDogI2ZmZmZmZjtcclxuICAtLWNvbG9yOiAjMDAwMDAwO1xyXG59XHJcbiJdfQ== */"

/***/ }),

/***/ "./src/app/Rentals Management/modals/approvalpopup/approvalpopup.component.ts":
/*!************************************************************************************!*\
  !*** ./src/app/Rentals Management/modals/approvalpopup/approvalpopup.component.ts ***!
  \************************************************************************************/
/*! exports provided: ApprovalpopupComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ApprovalpopupComponent", function() { return ApprovalpopupComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");


var ApprovalpopupComponent = /** @class */ (function () {
    function ApprovalpopupComponent() {
        this.paymentAmount = 333;
        this.currency = 'INR';
        this.currencyIcon = '₹';
        this.razor_key = 'rzp_test_W6w8NUHKBgXqpL';
        this.cardDetails = {};
    }
    ApprovalpopupComponent.prototype.payWithRazor = function () {
        var options = {
            description: 'Credits towards consultation',
            image: 'https://i.imgur.com/3g7nmJC.png',
            currency: this.currency,
            key: this.razor_key,
            amount: this.paymentAmount,
            name: 'Naila',
            prefill: {
                email: 'hmohit7@gmail.com',
                contact: '9880013407',
                name: 'Naila'
            },
            theme: {
                color: '#F37254'
            },
            modal: {
                ondismiss: function () {
                    alert('dismissed');
                }
            }
        };
        var successCallback = function (payment_id) {
            alert('payment_id: ' + payment_id);
        };
        var cancelCallback = function (error) {
            alert(error.description + ' (Error ' + error.code + ')');
        };
        RazorpayCheckout.open(options, successCallback, cancelCallback);
    };
    ApprovalpopupComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-razor',
            template: __webpack_require__(/*! ./approvalpopup.component.html */ "./src/app/Rentals Management/modals/approvalpopup/approvalpopup.component.html"),
            styles: [__webpack_require__(/*! ./approvalpopup.component.scss */ "./src/app/Rentals Management/modals/approvalpopup/approvalpopup.component.scss")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [])
    ], ApprovalpopupComponent);
    return ApprovalpopupComponent;
}());



/***/ }),

/***/ "./src/app/Rentals Management/modals/create-notice/create-notice.component.html":
/*!**************************************************************************************!*\
  !*** ./src/app/Rentals Management/modals/create-notice/create-notice.component.html ***!
  \**************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ion-header>\r\n  <ion-toolbar color=\"primary\">\r\n    <ion-title>{{transService.getTranslatedData('create-notice-modal.title')}}</ion-title>\r\n    <ion-buttons slot=\"end\">\r\n      <ion-button (click)=\"dismiss()\">\r\n        <ion-icon slot=\"icon-only\" name=\"close\"></ion-icon>\r\n      </ion-button>\r\n    </ion-buttons>\r\n  </ion-toolbar>\r\n</ion-header>\r\n<ion-content>\r\n\r\n  <div class=\"full-width max-available-height webkit-center\">\r\n    <ion-list>\r\n      <ion-item>\r\n        <ion-icon class=\"icon-18 margin-bottom-5\" name=\"home\"></ion-icon>\r\n        <ion-input [(ngModel)]=\"notice.noticeBelongsToName\" (click)=\"openProjectSearchModal()\" inputmode=\"text\"\r\n          class=\"gotham  margin-left-10\" readonly\r\n          placeholder=\"{{transService.getTranslatedData('create-notice-modal.select-project-title')}}\">\r\n        </ion-input>\r\n        <ion-icon class=\"float-right\" name=\"arrow-dropdown\"></ion-icon>\r\n      </ion-item>\r\n\r\n      <ion-item>\r\n        <!-- <ion-label>Default Label</ion-label> -->\r\n        <ion-input [(ngModel)]=\"notice.title\" inputmode=\"text\" class=\"gotham \"\r\n          placeholder=\"{{transService.getTranslatedData('create-notice-modal.topic')}}\"></ion-input>\r\n      </ion-item>\r\n      <ion-item>\r\n        <ion-textarea [(ngModel)]=\"notice.body\" rows='7' class=\"gotham \"\r\n          placeholder=\"{{transService.getTranslatedData('create-notice-modal.message')}}\"></ion-textarea>\r\n      </ion-item>\r\n\r\n      <ion-item-divider class=\"grey-back\">\r\n        <ion-label>\r\n          {{transService.getTranslatedData('create-notice-modal.select-file')}}\r\n        </ion-label>\r\n      </ion-item-divider>\r\n\r\n      <!-- <ion-header no-border class=\"grey-back padding-top-bottom\">\r\n        <ion-title class=\"center-text gotham-bold \">Upload file</ion-title>\r\n      </ion-header> -->\r\n\r\n      <div class=\"ticket-details-list  center-text\">\r\n        <ion-icon class=\"font-70 \" name=\"cloud-upload\"></ion-icon><br>\r\n        <ion-button no-border color=\"light\"  style=\"color:black;\">\r\n          {{transService.getTranslatedData('create-notice-modal.add-picture')}}</ion-button>\r\n      </div>\r\n\r\n      <ion-row class=\"width-80-percent margin-10\">\r\n        <div *ngIf=\"images.length > 0\">\r\n          <ion-item *ngFor=\"let url of images\" lines='none' class=\"ion-image-item\">\r\n            <ion-thumbnail class=\"margin-0 icon-90 image\">\r\n              <ion-icon class=\"img-icon\" (click)=\"removeImage()\" color=\"danger\" name=\"close-circle\">\r\n              </ion-icon>\r\n              <ion-img src=\"{{webView.convertFileSrc(url)}}\"></ion-img>\r\n            </ion-thumbnail>\r\n          </ion-item>\r\n        </div>\r\n      </ion-row>\r\n    </ion-list>\r\n\r\n  </div>\r\n</ion-content>\r\n<ion-button [disabled]=\"!notice.discussionBelongsToRefId || !notice.title || !notice.body\" size=\"large\"\r\n  (click)=\"createNotice()\" color=\"danger\">{{transService.getTranslatedData('create-notice-modal.submit')}}</ion-button>"

/***/ }),

/***/ "./src/app/Rentals Management/modals/create-notice/create-notice.component.scss":
/*!**************************************************************************************!*\
  !*** ./src/app/Rentals Management/modals/create-notice/create-notice.component.scss ***!
  \**************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "ion-button > button {\n  background-color: white; }\n\n.ion-image-item {\n  --inner-padding-bottom: 0px;\n  --inner-padding-end: 0px;\n  --inner-padding-start: 0px;\n  --inner-padding-top: 0px;\n  --min-height: 24px;\n  --padding-bottom: 0px;\n  --padding-end: 0px;\n  --padding-start: 0px;\n  --padding-top: 0px;\n  --transition: background-color 15ms linear; }\n\n.ion-item {\n  --inner-padding-bottom: 0px !important;\n  --inner-padding-end: 0px !important;\n  --inner-padding-start: 0px !important;\n  --inner-padding-top: 0px !important;\n  --padding-bottom: 0px !important;\n  --padding-end: 0px !important;\n  --padding-start: 0px !important;\n  --padding-top: 0px !important; }\n\n.img-icon {\n  font-size: x-large !important;\n  position: absolute !important; }\n\n.image {\n  justify-content: flex-end !important;\n  display: flex !important; }\n\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvUmVudGFscyBNYW5hZ2VtZW50L21vZGFscy9jcmVhdGUtbm90aWNlL0Q6XFxuYXZqb3RcXHZlcmlmeS9zcmNcXGFwcFxcUmVudGFscyBNYW5hZ2VtZW50XFxtb2RhbHNcXGNyZWF0ZS1ub3RpY2VcXGNyZWF0ZS1ub3RpY2UuY29tcG9uZW50LnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDRSx1QkFBdUIsRUFBQTs7QUFFekI7RUFDRSwyQkFBdUI7RUFDdkIsd0JBQW9CO0VBQ3BCLDBCQUFzQjtFQUN0Qix3QkFBb0I7RUFDcEIsa0JBQWE7RUFDYixxQkFBaUI7RUFDakIsa0JBQWM7RUFDZCxvQkFBZ0I7RUFDaEIsa0JBQWM7RUFDZCwwQ0FBYSxFQUFBOztBQUdmO0VBQ0Usc0NBQXVCO0VBQ3ZCLG1DQUFvQjtFQUNwQixxQ0FBc0I7RUFDdEIsbUNBQW9CO0VBRXBCLGdDQUFpQjtFQUNqQiw2QkFBYztFQUNkLCtCQUFnQjtFQUNoQiw2QkFBYyxFQUFBOztBQUVoQjtFQUNFLDZCQUE2QjtFQUM3Qiw2QkFBNkIsRUFBQTs7QUFFL0I7RUFDRSxvQ0FBb0M7RUFDcEMsd0JBQXdCLEVBQUEiLCJmaWxlIjoic3JjL2FwcC9SZW50YWxzIE1hbmFnZW1lbnQvbW9kYWxzL2NyZWF0ZS1ub3RpY2UvY3JlYXRlLW5vdGljZS5jb21wb25lbnQuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbImlvbi1idXR0b24gPiBidXR0b24ge1xyXG4gIGJhY2tncm91bmQtY29sb3I6IHdoaXRlO1xyXG59XHJcbi5pb24taW1hZ2UtaXRlbSB7XHJcbiAgLS1pbm5lci1wYWRkaW5nLWJvdHRvbTogMHB4O1xyXG4gIC0taW5uZXItcGFkZGluZy1lbmQ6IDBweDtcclxuICAtLWlubmVyLXBhZGRpbmctc3RhcnQ6IDBweDtcclxuICAtLWlubmVyLXBhZGRpbmctdG9wOiAwcHg7XHJcbiAgLS1taW4taGVpZ2h0OiAyNHB4O1xyXG4gIC0tcGFkZGluZy1ib3R0b206IDBweDtcclxuICAtLXBhZGRpbmctZW5kOiAwcHg7XHJcbiAgLS1wYWRkaW5nLXN0YXJ0OiAwcHg7XHJcbiAgLS1wYWRkaW5nLXRvcDogMHB4O1xyXG4gIC0tdHJhbnNpdGlvbjogYmFja2dyb3VuZC1jb2xvciAxNW1zIGxpbmVhcjtcclxufVxyXG5cclxuLmlvbi1pdGVtIHtcclxuICAtLWlubmVyLXBhZGRpbmctYm90dG9tOiAwcHggIWltcG9ydGFudDtcclxuICAtLWlubmVyLXBhZGRpbmctZW5kOiAwcHggIWltcG9ydGFudDtcclxuICAtLWlubmVyLXBhZGRpbmctc3RhcnQ6IDBweCAhaW1wb3J0YW50O1xyXG4gIC0taW5uZXItcGFkZGluZy10b3A6IDBweCAhaW1wb3J0YW50O1xyXG5cclxuICAtLXBhZGRpbmctYm90dG9tOiAwcHggIWltcG9ydGFudDtcclxuICAtLXBhZGRpbmctZW5kOiAwcHggIWltcG9ydGFudDtcclxuICAtLXBhZGRpbmctc3RhcnQ6IDBweCAhaW1wb3J0YW50O1xyXG4gIC0tcGFkZGluZy10b3A6IDBweCAhaW1wb3J0YW50O1xyXG59XHJcbi5pbWctaWNvbiB7XHJcbiAgZm9udC1zaXplOiB4LWxhcmdlICFpbXBvcnRhbnQ7XHJcbiAgcG9zaXRpb246IGFic29sdXRlICFpbXBvcnRhbnQ7XHJcbn1cclxuLmltYWdlIHtcclxuICBqdXN0aWZ5LWNvbnRlbnQ6IGZsZXgtZW5kICFpbXBvcnRhbnQ7XHJcbiAgZGlzcGxheTogZmxleCAhaW1wb3J0YW50O1xyXG59XHJcbiJdfQ== */"

/***/ }),

/***/ "./src/app/Rentals Management/modals/create-notice/create-notice.component.ts":
/*!************************************************************************************!*\
  !*** ./src/app/Rentals Management/modals/create-notice/create-notice.component.ts ***!
  \************************************************************************************/
/*! exports provided: CreateNoticeComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CreateNoticeComponent", function() { return CreateNoticeComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _services_notice_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./../../services/notice.service */ "./src/app/Rentals Management/services/notice.service.ts");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var src_app_common_services_alert_service_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! src/app/common-services/alert-service.service */ "./src/app/common-services/alert-service.service.ts");
/* harmony import */ var _pages_project_search_project_search_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../../pages/project-search/project-search.page */ "./src/app/Rentals Management/pages/project-search/project-search.page.ts");
/* harmony import */ var _ionic_native_ionic_webview_ngx__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @ionic-native/ionic-webview/ngx */ "./node_modules/@ionic-native/ionic-webview/ngx/index.js");
/* harmony import */ var src_app_common_services_translate_translate_service_service__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! src/app/common-services/translate/translate-service.service */ "./src/app/common-services/translate/translate-service.service.ts");









var CreateNoticeComponent = /** @class */ (function () {
    function CreateNoticeComponent(modalController, loadingCtrl, noticeService, router, alertService, route, webView, transService, actionSheet) {
        this.modalController = modalController;
        this.loadingCtrl = loadingCtrl;
        this.noticeService = noticeService;
        this.router = router;
        this.alertService = alertService;
        this.route = route;
        this.webView = webView;
        this.transService = transService;
        this.actionSheet = actionSheet;
        this.notice = {
            discussionBelongsTo: 'Project',
            discussionType: 'Notice',
            raisedByEmployee: true,
        };
        this.flag = false;
        this.images = [];
    }
    CreateNoticeComponent.prototype.ngOnInit = function () { };
    CreateNoticeComponent.prototype.presentLoading = function () {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function () {
            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                this.loadingCtrl.create({
                    spinner: "lines"
                }).then(function (loading) {
                    loading.present();
                });
                return [2 /*return*/];
            });
        });
    };
    CreateNoticeComponent.prototype.closeModal = function () {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function () {
            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.modalController.dismiss()];
                    case 1:
                        _a.sent();
                        return [2 /*return*/];
                }
            });
        });
    };
    CreateNoticeComponent.prototype.openProjectSearchModal = function () {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function () {
            var modal;
            var _this = this;
            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.modalController.create({
                            component: _pages_project_search_project_search_page__WEBPACK_IMPORTED_MODULE_6__["ProjectSearchPage"],
                            componentProps: {
                                id: this.notice.discussionBelongsToRefId,
                                name: this.notice.noticeBelongsToName
                            }
                        })];
                    case 1:
                        modal = _a.sent();
                        modal.onDidDismiss().then(function (project) {
                            if (project !== null && project.data) {
                                console.log(project);
                                _this.notice.noticeBelongsToName = project.data.ticketBelongsToName;
                                _this.notice.discussionBelongsToRefId = project.data.ticketBelongsToRefId;
                                console.log(_this.notice);
                            }
                        });
                        return [4 /*yield*/, modal.present()];
                    case 2: return [2 /*return*/, _a.sent()];
                }
            });
        });
    };
    CreateNoticeComponent.prototype.createNotice = function () {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function () {
            var _this = this;
            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                this.presentLoading();
                if (this.images.length > 0) {
                    this.alertService.upload(this.images[0], this.notice, 'CREATENOTICE').then(function () {
                        _this.loadingCtrl.dismiss();
                        _this.alertService.presentAlert(_this.transService.getTranslatedData('alert-title'), _this.transService.getTranslatedData('create-notice-modal.notice-created'));
                        _this.flag = true;
                        _this.modalController.dismiss(_this.flag);
                        _this.router.navigateByUrl('/rentals-notice-board');
                    }, function (err) {
                        _this.loadingCtrl.dismiss();
                        if (err.error.message == "You don't have permission for this operation!") {
                            _this.alertService.presentAlert('', "You don't have permission for this operation!");
                            _this.modalController.dismiss();
                        }
                        else {
                            _this.alertService.presentAlert(_this.transService.getTranslatedData('alert-title'), err);
                        }
                    });
                }
                else {
                    this.noticeService.createNotice(this.notice)
                        .subscribe(function (data) {
                        _this.alertService.presentAlert(_this.transService.getTranslatedData('alert-title'), _this.transService.getTranslatedData('create-notice-modal.notice-created'));
                        _this.flag = true;
                        _this.loadingCtrl.dismiss();
                        _this.modalController.dismiss(_this.flag);
                        _this.router.navigateByUrl('/rentals-notice-board');
                    }, function (err) {
                        _this.loadingCtrl.dismiss();
                        if (err.error.message == "You don't have permission for this operation!") {
                            _this.alertService.presentAlert('', "You don't have permission for this operation!");
                            _this.modalController.dismiss();
                        }
                        else {
                            _this.alertService.presentAlert(_this.transService.getTranslatedData('alert-title'), err.error.error);
                        }
                    });
                }
                return [2 /*return*/];
            });
        });
    };
    // async fileSourceOption(type) {
    //   if (this.images.length < 1) {
    //     const caller = await this.alertService.capturePhoto(type);
    //     console.log("in add-visitor Page\n\n");
    //     if (caller != undefined) {
    //       console.log(caller);
    //       this.images.push(caller);
    //       console.log(this.images);
    //     }
    //   } else {
    //     this.alertService.presentAlert(this.transService.getTranslatedData('alert-title'), this.transService.getTranslatedData('create-notice-modal.picture-limit'))
    //   }
    // }
    CreateNoticeComponent.prototype.removeImage = function () {
        this.images = [];
    };
    CreateNoticeComponent.prototype.dismiss = function () {
        this.modalController.dismiss(this.flag);
    };
    CreateNoticeComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_4__["Component"])({
            selector: 'app-create-notice',
            template: __webpack_require__(/*! ./create-notice.component.html */ "./src/app/Rentals Management/modals/create-notice/create-notice.component.html"),
            styles: [__webpack_require__(/*! ./create-notice.component.scss */ "./src/app/Rentals Management/modals/create-notice/create-notice.component.scss")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_ionic_angular__WEBPACK_IMPORTED_MODULE_3__["ModalController"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["LoadingController"],
            _services_notice_service__WEBPACK_IMPORTED_MODULE_2__["NoticeService"],
            _angular_router__WEBPACK_IMPORTED_MODULE_1__["Router"],
            src_app_common_services_alert_service_service__WEBPACK_IMPORTED_MODULE_5__["AlertServiceService"],
            _angular_router__WEBPACK_IMPORTED_MODULE_1__["ActivatedRoute"],
            _ionic_native_ionic_webview_ngx__WEBPACK_IMPORTED_MODULE_7__["WebView"],
            src_app_common_services_translate_translate_service_service__WEBPACK_IMPORTED_MODULE_8__["translateService"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["ActionSheetController"]])
    ], CreateNoticeComponent);
    return CreateNoticeComponent;
}());



/***/ }),

/***/ "./src/app/Rentals Management/pages/material-search/material-search.module.ts":
/*!************************************************************************************!*\
  !*** ./src/app/Rentals Management/pages/material-search/material-search.module.ts ***!
  \************************************************************************************/
/*! exports provided: MaterialSearchPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "MaterialSearchPageModule", function() { return MaterialSearchPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _material_search_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./material-search.page */ "./src/app/Rentals Management/pages/material-search/material-search.page.ts");







var routes = [
    {
        path: '',
        component: _material_search_page__WEBPACK_IMPORTED_MODULE_6__["MaterialSearchPage"]
    }
];
var MaterialSearchPageModule = /** @class */ (function () {
    function MaterialSearchPageModule() {
    }
    MaterialSearchPageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            imports: [
                _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
                _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["IonicModule"],
                _angular_router__WEBPACK_IMPORTED_MODULE_4__["RouterModule"].forChild(routes)
            ],
            declarations: [_material_search_page__WEBPACK_IMPORTED_MODULE_6__["MaterialSearchPage"]]
        })
    ], MaterialSearchPageModule);
    return MaterialSearchPageModule;
}());



/***/ }),

/***/ "./src/app/Rentals Management/pages/material-search/material-search.page.html":
/*!************************************************************************************!*\
  !*** ./src/app/Rentals Management/pages/material-search/material-search.page.html ***!
  \************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ion-header>\r\n  <ion-toolbar color=\"primary\">\r\n    <ion-buttons slot=\"end\">\r\n      <ion-button (click)=\"closeModal(false)\">\r\n        <ion-icon name=\"close\"></ion-icon>\r\n      </ion-button>\r\n    </ion-buttons>\r\n    <ion-title>Material search</ion-title>\r\n  </ion-toolbar>\r\n  <ion-searchbar [(ngModel)]=\"filterData.searchText\" (ngModelChange)=\"resetFilterAndSearch()\">\r\n  </ion-searchbar>\r\n</ion-header>\r\n\r\n<ion-content>\r\n\r\n  <div class=\"center-text margin-top-10\" [hidden]=\"!loading\">\r\n    <ion-spinner></ion-spinner>\r\n  </div>\r\n\r\n  <ion-list>\r\n    <ion-radio-group>\r\n      <ion-item *ngFor=\"let material of materials\">\r\n        <ion-label>{{material.name}}</ion-label>\r\n        <ion-radio slot=\"end\" (click)=\"selectMaterial(material)\"></ion-radio>\r\n      </ion-item>\r\n    </ion-radio-group>\r\n  </ion-list>\r\n\r\n  <ion-infinite-scroll [hidden]=\"disableInfiniteScroll\" threshold=\"5px\" (ionInfinite)=\"searchMaterial($event)\">\r\n    <ion-infinite-scroll-content loadingSpinner=\"bubbles\" loadingText=\"Loading more data...\">\r\n    </ion-infinite-scroll-content>\r\n  </ion-infinite-scroll>\r\n\r\n</ion-content>"

/***/ }),

/***/ "./src/app/Rentals Management/pages/material-search/material-search.page.scss":
/*!************************************************************************************!*\
  !*** ./src/app/Rentals Management/pages/material-search/material-search.page.scss ***!
  \************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "ion-searchbar {\n  padding: 0px; }\n\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvUmVudGFscyBNYW5hZ2VtZW50L3BhZ2VzL21hdGVyaWFsLXNlYXJjaC9EOlxcbmF2am90XFx2ZXJpZnkvc3JjXFxhcHBcXFJlbnRhbHMgTWFuYWdlbWVudFxccGFnZXNcXG1hdGVyaWFsLXNlYXJjaFxcbWF0ZXJpYWwtc2VhcmNoLnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNJLFlBQVksRUFBQSIsImZpbGUiOiJzcmMvYXBwL1JlbnRhbHMgTWFuYWdlbWVudC9wYWdlcy9tYXRlcmlhbC1zZWFyY2gvbWF0ZXJpYWwtc2VhcmNoLnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbImlvbi1zZWFyY2hiYXIge1xyXG4gICAgcGFkZGluZzogMHB4O1xyXG4gIH1cclxuICAiXX0= */"

/***/ }),

/***/ "./src/app/Rentals Management/pages/material-search/material-search.page.ts":
/*!**********************************************************************************!*\
  !*** ./src/app/Rentals Management/pages/material-search/material-search.page.ts ***!
  \**********************************************************************************/
/*! exports provided: MaterialSearchPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "MaterialSearchPage", function() { return MaterialSearchPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _services_ticket_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../services/ticket.service */ "./src/app/Rentals Management/services/ticket.service.ts");
/* harmony import */ var src_app_common_services_alert_service_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/common-services/alert-service.service */ "./src/app/common-services/alert-service.service.ts");





var MaterialSearchPage = /** @class */ (function () {
    function MaterialSearchPage(loadingCtrl, ticketService, modalController, alertService) {
        this.loadingCtrl = loadingCtrl;
        this.ticketService = ticketService;
        this.modalController = modalController;
        this.alertService = alertService;
        this.materials = [];
        this.loading = false;
        this.disableInfiniteScroll = false;
        this.selectedMaterial = {};
        this.filterData = {
            skip: 0,
            searchText: ''
        };
        this.searchMaterial('');
    }
    MaterialSearchPage.prototype.ngOnInit = function () {
    };
    MaterialSearchPage.prototype.closeModal = function (sendData) {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function () {
            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                switch (_a.label) {
                    case 0:
                        if (!sendData) return [3 /*break*/, 2];
                        console.log('Send data');
                        return [4 /*yield*/, this.modalController.dismiss(this.selectedMaterial)];
                    case 1:
                        _a.sent();
                        return [3 /*break*/, 4];
                    case 2:
                        console.log('Dont Send data');
                        return [4 /*yield*/, this.modalController.dismiss()];
                    case 3:
                        _a.sent();
                        _a.label = 4;
                    case 4: return [2 /*return*/];
                }
            });
        });
    };
    MaterialSearchPage.prototype.selectMaterial = function (material) {
        this.selectedMaterial = material;
        this.closeModal(true);
    };
    // async presentLoading() {
    //   this.loading = await this.loadingCtrl.create({
    //   });
    //   this.loading.present();
    // }
    // type, searchtext, skip, token, status
    MaterialSearchPage.prototype.searchMaterial = function (event) {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function () {
            var _this = this;
            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                if (!event) {
                    this.loading = true;
                }
                this.ticketService.searchMaterials(this.filterData)
                    .subscribe(function (data) {
                    _this.materials = _this.materials.concat(data.data);
                    _this.filterData.skip = data.query.skip + 10;
                    console.log(_this.materials);
                    event ? event.target.complete() : _this.loading = false;
                    console.log('loading should dismiss');
                    if (data.query.current >= data.query.total) {
                        _this.disableInfiniteScroll = true;
                    }
                }, function (err) {
                    _this.loading = false;
                    _this.alertService.presentAlert('', err.error.error);
                });
                return [2 /*return*/];
            });
        });
    };
    MaterialSearchPage.prototype.resetFilterAndSearch = function () {
        this.materials = [];
        this.filterData.skip = 0;
        this.disableInfiniteScroll = false;
        this.searchMaterial('');
    };
    MaterialSearchPage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-material-search',
            template: __webpack_require__(/*! ./material-search.page.html */ "./src/app/Rentals Management/pages/material-search/material-search.page.html"),
            styles: [__webpack_require__(/*! ./material-search.page.scss */ "./src/app/Rentals Management/pages/material-search/material-search.page.scss")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_ionic_angular__WEBPACK_IMPORTED_MODULE_2__["LoadingController"],
            _services_ticket_service__WEBPACK_IMPORTED_MODULE_3__["TicketService"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["ModalController"],
            src_app_common_services_alert_service_service__WEBPACK_IMPORTED_MODULE_4__["AlertServiceService"]])
    ], MaterialSearchPage);
    return MaterialSearchPage;
}());



/***/ }),

/***/ "./src/app/Rentals Management/pages/notice-create/notice-create.module.ts":
/*!********************************************************************************!*\
  !*** ./src/app/Rentals Management/pages/notice-create/notice-create.module.ts ***!
  \********************************************************************************/
/*! exports provided: NoticeCreatePageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "NoticeCreatePageModule", function() { return NoticeCreatePageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _notice_create_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./notice-create.page */ "./src/app/Rentals Management/pages/notice-create/notice-create.page.ts");







var routes = [
    {
        path: '',
        component: _notice_create_page__WEBPACK_IMPORTED_MODULE_6__["NoticeCreatePage"]
    }
];
var NoticeCreatePageModule = /** @class */ (function () {
    function NoticeCreatePageModule() {
    }
    NoticeCreatePageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            imports: [
                _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
                _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["IonicModule"],
                _angular_router__WEBPACK_IMPORTED_MODULE_4__["RouterModule"].forChild(routes)
            ],
            declarations: [_notice_create_page__WEBPACK_IMPORTED_MODULE_6__["NoticeCreatePage"]]
        })
    ], NoticeCreatePageModule);
    return NoticeCreatePageModule;
}());



/***/ }),

/***/ "./src/app/Rentals Management/pages/notice-create/notice-create.page.html":
/*!********************************************************************************!*\
  !*** ./src/app/Rentals Management/pages/notice-create/notice-create.page.html ***!
  \********************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ion-header>\r\n  <ion-toolbar color=\"primary\">\r\n    <ion-buttons slot=\"start\">\r\n      <ion-back-button></ion-back-button>\r\n    </ion-buttons>\r\n    <ion-title>{{transService.getTranslatedData('create-notice.title')}}</ion-title>\r\n  </ion-toolbar>\r\n</ion-header>\r\n\r\n<ion-content>\r\n\r\n  <div class=\"full-width max-available-height webkit-center\">\r\n    <ion-list>\r\n      <ion-item>\r\n        <ion-icon class=\"icon-15\" name=\"home\"></ion-icon>\r\n        <ion-input [(ngModel)]=\"notice.noticeBelongsToName\" (click)=\"openProjectSearchModal()\" inputmode=\"text\"\r\n          class=\"gotham  margin-left-10\"\r\n          placeholder=\"{{transService.getTranslatedData('create-notice.select-project-title')}}\">\r\n        </ion-input>\r\n        <ion-icon class=\"float-right\" name=\"arrow-dropdown\"></ion-icon>\r\n      </ion-item>\r\n\r\n      <ion-item>\r\n        <!-- <ion-label>Default Label</ion-label> -->\r\n        <ion-input [(ngModel)]=\"notice.title\" inputmode=\"text\" class=\"gotham \"\r\n          placeholder=\"{{transService.getTranslatedData('create-notice.topic')}}\"></ion-input>\r\n      </ion-item>\r\n      <ion-item>\r\n        <ion-textarea [(ngModel)]=\"notice.body\" rows='7' class=\"gotham \"\r\n          placeholder=\"{{transService.getTranslatedData('create-notice.message')}}\"></ion-textarea>\r\n      </ion-item>\r\n\r\n      <ion-item-divider class=\"grey-back\">\r\n        <ion-label>\r\n          {{transService.getTranslatedData('create-notice.select-file')}}\r\n        </ion-label>\r\n      </ion-item-divider>\r\n\r\n      <!-- <ion-header no-border class=\"grey-back padding-top-bottom\">\r\n        <ion-title class=\"center-text gotham-bold \">Upload file</ion-title>\r\n      </ion-header> -->\r\n\r\n      <div class=\"ticket-details-list  center-text\">\r\n        <ion-icon class=\"font-70 \" name=\"cloud-upload\"></ion-icon><br>\r\n        <ion-button no-border color=\"light\"  style=\"color:black;\">\r\n          {{transService.getTranslatedData('create-notice.add-picture')}}</ion-button>\r\n      </div>\r\n    </ion-list>\r\n    <ion-row class=\"width-80-percent margin-10 justify-center margin-10 margin-bottom-20\">\r\n      <div *ngIf=\"images.length > 0\">\r\n        <ion-item *ngFor=\"let url of images\" lines='none' class=\"ion-image-item\">\r\n          <ion-thumbnail class=\"margin-0 icon-90 image\">\r\n            <ion-icon class=\"img-icon\" (click)=\"removeImage()\" color=\"danger\" name=\"close-circle\">\r\n            </ion-icon>\r\n            <ion-img src=\"{{webView.convertFileSrc(url)}}\"></ion-img>\r\n          </ion-thumbnail>\r\n        </ion-item>\r\n      </div>\r\n    </ion-row>\r\n\r\n  </div>\r\n</ion-content>\r\n<ion-button [disabled]=\"!notice.discussionBelongsToRefId || !notice.title || !notice.body\" size=\"large\"\r\n  (click)=\"createNotice()\" color=\"success\">{{transService.getTranslatedData('create-notice.submit')}}</ion-button>"

/***/ }),

/***/ "./src/app/Rentals Management/pages/notice-create/notice-create.page.scss":
/*!********************************************************************************!*\
  !*** ./src/app/Rentals Management/pages/notice-create/notice-create.page.scss ***!
  \********************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "ion-button > button {\n  background-color: white; }\n\n.ion-image-item {\n  --inner-padding-bottom: 0px;\n  --inner-padding-end: 0px;\n  --inner-padding-start: 0px;\n  --inner-padding-top: 0px;\n  --min-height: 24px;\n  --padding-bottom: 0px;\n  --padding-end: 0px;\n  --padding-start: 0px;\n  --padding-top: 0px;\n  --transition: background-color 15ms linear; }\n\n.ion-item {\n  --inner-padding-bottom: 0px !important;\n  --inner-padding-end: 0px !important;\n  --inner-padding-start: 0px !important;\n  --inner-padding-top: 0px !important;\n  --padding-bottom: 0px !important;\n  --padding-end: 0px !important;\n  --padding-start: 0px !important;\n  --padding-top: 0px !important; }\n\n.img-icon {\n  font-size: x-large !important;\n  position: absolute !important; }\n\n.image {\n  justify-content: flex-end !important;\n  display: flex !important; }\n\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvUmVudGFscyBNYW5hZ2VtZW50L3BhZ2VzL25vdGljZS1jcmVhdGUvRDpcXG5hdmpvdFxcdmVyaWZ5L3NyY1xcYXBwXFxSZW50YWxzIE1hbmFnZW1lbnRcXHBhZ2VzXFxub3RpY2UtY3JlYXRlXFxub3RpY2UtY3JlYXRlLnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNFLHVCQUF1QixFQUFBOztBQUV6QjtFQUNFLDJCQUF1QjtFQUN2Qix3QkFBb0I7RUFDcEIsMEJBQXNCO0VBQ3RCLHdCQUFvQjtFQUNwQixrQkFBYTtFQUNiLHFCQUFpQjtFQUNqQixrQkFBYztFQUNkLG9CQUFnQjtFQUNoQixrQkFBYztFQUNkLDBDQUFhLEVBQUE7O0FBR2Y7RUFDRSxzQ0FBdUI7RUFDdkIsbUNBQW9CO0VBQ3BCLHFDQUFzQjtFQUN0QixtQ0FBb0I7RUFFcEIsZ0NBQWlCO0VBQ2pCLDZCQUFjO0VBQ2QsK0JBQWdCO0VBQ2hCLDZCQUFjLEVBQUE7O0FBRWhCO0VBQ0UsNkJBQTZCO0VBQzdCLDZCQUE2QixFQUFBOztBQUUvQjtFQUNFLG9DQUFvQztFQUNwQyx3QkFBd0IsRUFBQSIsImZpbGUiOiJzcmMvYXBwL1JlbnRhbHMgTWFuYWdlbWVudC9wYWdlcy9ub3RpY2UtY3JlYXRlL25vdGljZS1jcmVhdGUucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiaW9uLWJ1dHRvbiA+IGJ1dHRvbiB7XHJcbiAgYmFja2dyb3VuZC1jb2xvcjogd2hpdGU7XHJcbn1cclxuLmlvbi1pbWFnZS1pdGVtIHtcclxuICAtLWlubmVyLXBhZGRpbmctYm90dG9tOiAwcHg7XHJcbiAgLS1pbm5lci1wYWRkaW5nLWVuZDogMHB4O1xyXG4gIC0taW5uZXItcGFkZGluZy1zdGFydDogMHB4O1xyXG4gIC0taW5uZXItcGFkZGluZy10b3A6IDBweDtcclxuICAtLW1pbi1oZWlnaHQ6IDI0cHg7XHJcbiAgLS1wYWRkaW5nLWJvdHRvbTogMHB4O1xyXG4gIC0tcGFkZGluZy1lbmQ6IDBweDtcclxuICAtLXBhZGRpbmctc3RhcnQ6IDBweDtcclxuICAtLXBhZGRpbmctdG9wOiAwcHg7XHJcbiAgLS10cmFuc2l0aW9uOiBiYWNrZ3JvdW5kLWNvbG9yIDE1bXMgbGluZWFyO1xyXG59XHJcblxyXG4uaW9uLWl0ZW0ge1xyXG4gIC0taW5uZXItcGFkZGluZy1ib3R0b206IDBweCAhaW1wb3J0YW50O1xyXG4gIC0taW5uZXItcGFkZGluZy1lbmQ6IDBweCAhaW1wb3J0YW50O1xyXG4gIC0taW5uZXItcGFkZGluZy1zdGFydDogMHB4ICFpbXBvcnRhbnQ7XHJcbiAgLS1pbm5lci1wYWRkaW5nLXRvcDogMHB4ICFpbXBvcnRhbnQ7XHJcblxyXG4gIC0tcGFkZGluZy1ib3R0b206IDBweCAhaW1wb3J0YW50O1xyXG4gIC0tcGFkZGluZy1lbmQ6IDBweCAhaW1wb3J0YW50O1xyXG4gIC0tcGFkZGluZy1zdGFydDogMHB4ICFpbXBvcnRhbnQ7XHJcbiAgLS1wYWRkaW5nLXRvcDogMHB4ICFpbXBvcnRhbnQ7XHJcbn1cclxuLmltZy1pY29uIHtcclxuICBmb250LXNpemU6IHgtbGFyZ2UgIWltcG9ydGFudDtcclxuICBwb3NpdGlvbjogYWJzb2x1dGUgIWltcG9ydGFudDtcclxufVxyXG4uaW1hZ2Uge1xyXG4gIGp1c3RpZnktY29udGVudDogZmxleC1lbmQgIWltcG9ydGFudDtcclxuICBkaXNwbGF5OiBmbGV4ICFpbXBvcnRhbnQ7XHJcbn1cclxuIl19 */"

/***/ }),

/***/ "./src/app/Rentals Management/pages/notice-create/notice-create.page.ts":
/*!******************************************************************************!*\
  !*** ./src/app/Rentals Management/pages/notice-create/notice-create.page.ts ***!
  \******************************************************************************/
/*! exports provided: NoticeCreatePage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "NoticeCreatePage", function() { return NoticeCreatePage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _project_search_project_search_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../project-search/project-search.page */ "./src/app/Rentals Management/pages/project-search/project-search.page.ts");
/* harmony import */ var _services_notice_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../services/notice.service */ "./src/app/Rentals Management/services/notice.service.ts");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var src_app_common_services_alert_service_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! src/app/common-services/alert-service.service */ "./src/app/common-services/alert-service.service.ts");
/* harmony import */ var src_app_common_services_translate_translate_service_service__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! src/app/common-services/translate/translate-service.service */ "./src/app/common-services/translate/translate-service.service.ts");
/* harmony import */ var _ionic_native_ionic_webview_ngx__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @ionic-native/ionic-webview/ngx */ "./node_modules/@ionic-native/ionic-webview/ngx/index.js");









var NoticeCreatePage = /** @class */ (function () {
    function NoticeCreatePage(modalController, loadingCtrl, noticeService, router, alertService, route, transService, webView) {
        this.modalController = modalController;
        this.loadingCtrl = loadingCtrl;
        this.noticeService = noticeService;
        this.router = router;
        this.alertService = alertService;
        this.route = route;
        this.transService = transService;
        this.webView = webView;
        this.notice = {
            discussionBelongsTo: 'Project',
            discussionType: 'Notice',
            raisedByEmployee: true,
        };
        this.images = [];
    }
    NoticeCreatePage.prototype.presentLoading = function () {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function () {
            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                switch (_a.label) {
                    case 0:
                        spinner: "lines";
                        return [4 /*yield*/, this.loadingCtrl.create({}).then(function (loading) {
                                loading.present();
                            })];
                    case 1:
                        _a.sent();
                        return [2 /*return*/];
                }
            });
        });
    };
    NoticeCreatePage.prototype.ngOnInit = function () {
    };
    NoticeCreatePage.prototype.closeModal = function () {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function () {
            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.modalController.dismiss()];
                    case 1:
                        _a.sent();
                        return [2 /*return*/];
                }
            });
        });
    };
    NoticeCreatePage.prototype.openProjectSearchModal = function () {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function () {
            var modal;
            var _this = this;
            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.modalController.create({
                            component: _project_search_project_search_page__WEBPACK_IMPORTED_MODULE_3__["ProjectSearchPage"],
                            componentProps: {
                                id: this.notice.discussionBelongsToRefId,
                                name: this.notice.noticeBelongsToName
                            }
                        })];
                    case 1:
                        modal = _a.sent();
                        modal.onDidDismiss().then(function (project) {
                            if (project !== null && project.data) {
                                console.log(project);
                                _this.notice.noticeBelongsToName = project.data.ticketBelongsToName;
                                _this.notice.discussionBelongsToRefId = project.data.ticketBelongsToRefId;
                                console.log(_this.notice);
                            }
                        });
                        return [4 /*yield*/, modal.present()];
                    case 2: return [2 /*return*/, _a.sent()];
                }
            });
        });
    };
    NoticeCreatePage.prototype.createNotice = function () {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function () {
            var _this = this;
            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.presentLoading()];
                    case 1:
                        _a.sent();
                        if (this.images.length > 0) {
                            this.alertService.upload(this.images[0], this.notice, 'CREATENOTICE').then(function () {
                                _this.loadingCtrl.dismiss();
                                _this.alertService.presentAlert(_this.transService.getTranslatedData('alert-title'), _this.transService.getTranslatedData('create-notice.notice-created'));
                                _this.router.navigateByUrl('/rentals-notice-board');
                            }, function (err) {
                                _this.loadingCtrl.dismiss();
                                _this.alertService.presentAlert(_this.transService.getTranslatedData('alert-title'), err);
                            });
                        }
                        else {
                            this.noticeService.createNotice(this.notice)
                                .subscribe(function (data) {
                                _this.loadingCtrl.dismiss();
                                _this.alertService.presentAlert(_this.transService.getTranslatedData('alert-title'), _this.transService.getTranslatedData('create-notice.notice-created'));
                                _this.router.navigateByUrl('/rentals-notice-board');
                            }, function (err) {
                                _this.loadingCtrl.dismiss();
                                _this.alertService.presentAlert(_this.transService.getTranslatedData('alert-title'), err.error.error);
                            });
                        }
                        return [2 /*return*/];
                }
            });
        });
    };
    // async fileSourceOption(type) {
    //   if (this.images.length < 1) {
    //     let image_url;
    //     let caller = await this.alertService.capturePhoto(type);
    //     image_url = caller;
    //     console.log("in add-visitor Page\n\n");
    //     if (image_url != undefined) {
    //       console.log(image_url);
    //       this.images.push(image_url);
    //       console.log(this.images);
    //     }
    //   } else {
    //     this.alertService.presentAlert(this.transService.getTranslatedData('alert-title'),
    //       this.transService.getTranslatedData('create-notice.picture-limit'))
    //   }
    // }
    NoticeCreatePage.prototype.removeImage = function () {
        this.images = [];
    };
    NoticeCreatePage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-notice-create',
            template: __webpack_require__(/*! ./notice-create.page.html */ "./src/app/Rentals Management/pages/notice-create/notice-create.page.html"),
            styles: [__webpack_require__(/*! ./notice-create.page.scss */ "./src/app/Rentals Management/pages/notice-create/notice-create.page.scss")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_ionic_angular__WEBPACK_IMPORTED_MODULE_2__["ModalController"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["LoadingController"],
            _services_notice_service__WEBPACK_IMPORTED_MODULE_4__["NoticeService"],
            _angular_router__WEBPACK_IMPORTED_MODULE_5__["Router"],
            src_app_common_services_alert_service_service__WEBPACK_IMPORTED_MODULE_6__["AlertServiceService"],
            _angular_router__WEBPACK_IMPORTED_MODULE_5__["ActivatedRoute"],
            src_app_common_services_translate_translate_service_service__WEBPACK_IMPORTED_MODULE_7__["translateService"],
            _ionic_native_ionic_webview_ngx__WEBPACK_IMPORTED_MODULE_8__["WebView"]])
    ], NoticeCreatePage);
    return NoticeCreatePage;
}());



/***/ }),

/***/ "./src/app/Rentals Management/pages/profile/profile.page.html":
/*!********************************************************************!*\
  !*** ./src/app/Rentals Management/pages/profile/profile.page.html ***!
  \********************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ion-header class=\"margin-bottom-minus-1\">\r\n  <ion-toolbar color=\"primary\">\r\n    <ion-buttons slot=\"start\">\r\n      <ion-back-button></ion-back-button>\r\n    </ion-buttons>\r\n    <ion-title class=\"padding-0\">{{transService.getTranslatedData('profile.title')}}</ion-title>\r\n  </ion-toolbar>\r\n</ion-header>\r\n\r\n<!-- Profile Modal -->\r\n<ion-content class=\"full-width grey-back max-available-height\">\r\n  <div class=\"profile-cover-head\">\r\n    <!-- Place to add the heading-->\r\n    <div class=\"profile-main-head center-text\">\r\n      <b>\r\n        <span class=\" txt-white float-right font-weight-600\"\r\n          (click)=\"logOut()\">{{transService.getTranslatedData('profile.logout-tag')}}</span>\r\n      </b>\r\n    </div>\r\n    <!-- Name of the PM -->\r\n    <div class=\"center-text\">\r\n      <h4 class=\"txt-white font-weight-600 \">{{data.firstName}} {{data.lastName}}.</h4>\r\n    </div>\r\n    <div class=\"profile-pic margin-top-10 center-text\">\r\n      <img class=\"img-circle\" src=\"assets/placeholder-person.jpg\" height=\"120\" width=\"120\">\r\n    </div>\r\n\r\n  </div>\r\n  <ion-list class=\"padding-top-0\">\r\n    <ion-header no-border class=\" grey-back\">\r\n      <ion-title class=\"center-text padding-bottom-10 padding-top-30  \">\r\n        {{transService.getTranslatedData('profile.contact-information')}}</ion-title>\r\n    </ion-header>\r\n    <ion-item>\r\n      <ion-grid>\r\n        <ion-row>\r\n          <ion-col size=\"5\">\r\n            <p class=\" font-14 gotham\">{{transService.getTranslatedData('profile.phone-number')}}</p>\r\n          </ion-col>\r\n          <ion-col size=\"7\">\r\n            <p class=\" font-14 gotham\">{{data.phoneNumber}}</p>\r\n          </ion-col>\r\n        </ion-row>\r\n      </ion-grid>\r\n    </ion-item>\r\n    <ion-item>\r\n      <ion-grid>\r\n        <ion-row>\r\n          <ion-col size=\"4.8\">\r\n            <p class=\" font-14 gotham\">{{transService.getTranslatedData('profile.email')}}</p>\r\n          </ion-col>\r\n          <ion-col size=\"7.2\">\r\n            <p class=\" font-14 gotham\">{{data.email}}</p>\r\n          </ion-col>\r\n        </ion-row>\r\n      </ion-grid>\r\n    </ion-item>\r\n    <ion-header no-border class=\"padding-top-bottom-10 grey-back\">\r\n      <ion-title class=\"center-text gotham \">{{transService.getTranslatedData('profile.personal-information')}}\r\n      </ion-title>\r\n    </ion-header>\r\n    <ion-item>\r\n      <ion-grid>\r\n        <ion-row>\r\n          <ion-col size=\"4.8\">\r\n            <p class=\" font-14 gotham\">{{transService.getTranslatedData('profile.dob')}}</p>\r\n          </ion-col>\r\n          <ion-col size=\"7.2\">\r\n            <p class=\" font-14 gotham\">{{data.dob|date:'dd/MM/yyyy'}}</p>\r\n          </ion-col>\r\n        </ion-row>\r\n      </ion-grid>\r\n    </ion-item>\r\n    <ion-item>\r\n      <ion-grid>\r\n        <ion-row>\r\n          <ion-col size=\"4.8\">\r\n            <p class=\" font-14 gotham\">{{transService.getTranslatedData('profile.gender')}}</p>\r\n          </ion-col>\r\n          <ion-col size=\"7.2\">\r\n            <p class=\" font-14 gotham\">{{data.gender}}</p>\r\n          </ion-col>\r\n        </ion-row>\r\n      </ion-grid>\r\n    </ion-item>\r\n    <ion-item>\r\n      <ion-grid>\r\n        <ion-row>\r\n          <ion-col size=\"4.8\">\r\n            <p class=\" font-14 gotham\">{{transService.getTranslatedData('profile.address')}}</p>\r\n          </ion-col>\r\n          <ion-col size=\"7.2\">\r\n            <p><span class=\" font-14 gotham\">{{data.address}}</span></p>\r\n          </ion-col>\r\n        </ion-row>\r\n      </ion-grid>\r\n    </ion-item>\r\n    <ion-header no-border class=\"padding-top-bottom-10 grey-back\">\r\n      <ion-title class=\"center-text gotham \">{{transService.getTranslatedData('profile.bank-information')}}</ion-title>\r\n    </ion-header>\r\n    <ion-item>\r\n      <ion-grid>\r\n        <ion-row>\r\n          <ion-col size=\"4.8\">\r\n            <p class=\" font-14 gotham\">{{transService.getTranslatedData('profile.account-number')}}</p>\r\n          </ion-col>\r\n          <ion-col size=\"7.2\">\r\n            <p class=\"font-14 gotham\" *ngIf=\"data.bankAccount\">{{data.bankAccount.number}}</p>\r\n          </ion-col>\r\n        </ion-row>\r\n      </ion-grid>\r\n    </ion-item>\r\n    <ion-item>\r\n      <ion-grid>\r\n        <ion-row>\r\n          <ion-col size=\"4.8\">\r\n            <p class=\" font-14 gotham\">{{transService.getTranslatedData('profile.ifsc')}}</p>\r\n          </ion-col>\r\n          <ion-col size=\"7.2\">\r\n            <p class=\" font-14 gotham\">{{data.ifsc}}</p>\r\n          </ion-col>\r\n        </ion-row>\r\n      </ion-grid>\r\n    </ion-item>\r\n  </ion-list>\r\n</ion-content>"

/***/ }),

/***/ "./src/app/Rentals Management/pages/profile/profile.page.scss":
/*!********************************************************************!*\
  !*** ./src/app/Rentals Management/pages/profile/profile.page.scss ***!
  \********************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL1JlbnRhbHMgTWFuYWdlbWVudC9wYWdlcy9wcm9maWxlL3Byb2ZpbGUucGFnZS5zY3NzIn0= */"

/***/ }),

/***/ "./src/app/Rentals Management/pages/profile/profile.page.ts":
/*!******************************************************************!*\
  !*** ./src/app/Rentals Management/pages/profile/profile.page.ts ***!
  \******************************************************************/
/*! exports provided: ProfilePage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ProfilePage", function() { return ProfilePage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var src_app_common_services_alert_service_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/common-services/alert-service.service */ "./src/app/common-services/alert-service.service.ts");
/* harmony import */ var src_app_common_services_translate_translate_service_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! src/app/common-services/translate/translate-service.service */ "./src/app/common-services/translate/translate-service.service.ts");
/* harmony import */ var _ionic_storage__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/storage */ "./node_modules/@ionic/storage/fesm5/ionic-storage.js");
/* harmony import */ var _services_rentals_user_service__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../../services/rentals-user.service */ "./src/app/Rentals Management/services/rentals-user.service.ts");








var ProfilePage = /** @class */ (function () {
    function ProfilePage(router, userService, alertService, loadingCtrl, transService, storage) {
        this.router = router;
        this.userService = userService;
        this.alertService = alertService;
        this.loadingCtrl = loadingCtrl;
        this.transService = transService;
        this.storage = storage;
        this.user_id = window.localStorage.getItem('user_id');
        this.token = window.localStorage.getItem('token');
        this.data = {};
        this.getProfile(window.localStorage.getItem('user_id'));
    }
    ProfilePage.prototype.ngOnInit = function () {
        console.log(this.user_id);
    };
    ProfilePage.prototype.getProfile = function (id) {
        var _this = this;
        this.userService.getUserById(id).subscribe(function (data) {
            _this.data = data;
            console.log(data);
        }, function (error) {
            _this.alertService.presentAlert(_this.transService.getTranslatedData('alert-title'), error.message.message);
        });
    };
    ProfilePage.prototype.presentLoading = function () {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function () {
            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.loadingCtrl.create({
                            spinner: 'lines'
                        }).then(function (loading) {
                            loading.present();
                        })];
                    case 1:
                        _a.sent();
                        return [2 /*return*/];
                }
            });
        });
    };
    ProfilePage.prototype.logOut = function () {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function () {
            var _this = this;
            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                this.presentLoading();
                this.data.businessAppDevice = {};
                this.userService.updateUser(this.data).subscribe(function () {
                    localStorage.clear();
                    _this.storage.clear();
                    _this.loadingCtrl.dismiss();
                    _this.router.navigateByUrl('/login');
                });
                return [2 /*return*/];
            });
        });
    };
    ProfilePage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_2__["Component"])({
            selector: 'app-profile',
            template: __webpack_require__(/*! ./profile.page.html */ "./src/app/Rentals Management/pages/profile/profile.page.html"),
            styles: [__webpack_require__(/*! ./profile.page.scss */ "./src/app/Rentals Management/pages/profile/profile.page.scss")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_router__WEBPACK_IMPORTED_MODULE_3__["Router"],
            _services_rentals_user_service__WEBPACK_IMPORTED_MODULE_7__["RentalsUserService"],
            src_app_common_services_alert_service_service__WEBPACK_IMPORTED_MODULE_4__["AlertServiceService"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_1__["LoadingController"],
            src_app_common_services_translate_translate_service_service__WEBPACK_IMPORTED_MODULE_5__["translateService"],
            _ionic_storage__WEBPACK_IMPORTED_MODULE_6__["Storage"]])
    ], ProfilePage);
    return ProfilePage;
}());



/***/ }),

/***/ "./src/app/Rentals Management/pages/project-search/project-search.module.ts":
/*!**********************************************************************************!*\
  !*** ./src/app/Rentals Management/pages/project-search/project-search.module.ts ***!
  \**********************************************************************************/
/*! exports provided: ProjectSearchPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ProjectSearchPageModule", function() { return ProjectSearchPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _project_search_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./project-search.page */ "./src/app/Rentals Management/pages/project-search/project-search.page.ts");







var routes = [
    {
        path: '',
        component: _project_search_page__WEBPACK_IMPORTED_MODULE_6__["ProjectSearchPage"]
    }
];
var ProjectSearchPageModule = /** @class */ (function () {
    function ProjectSearchPageModule() {
    }
    ProjectSearchPageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            imports: [
                _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
                _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["IonicModule"],
                _angular_router__WEBPACK_IMPORTED_MODULE_4__["RouterModule"].forChild(routes)
            ],
            declarations: [_project_search_page__WEBPACK_IMPORTED_MODULE_6__["ProjectSearchPage"]]
        })
    ], ProjectSearchPageModule);
    return ProjectSearchPageModule;
}());



/***/ }),

/***/ "./src/app/Rentals Management/pages/project-search/project-search.page.html":
/*!**********************************************************************************!*\
  !*** ./src/app/Rentals Management/pages/project-search/project-search.page.html ***!
  \**********************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ion-header>\r\n  <ion-toolbar color=\"primary\">\r\n    <ion-buttons slot=\"end\">\r\n      <ion-button (click)=\"closeModal(false)\">\r\n        <ion-icon name=\"close\"></ion-icon>\r\n      </ion-button>\r\n    </ion-buttons>\r\n    <ion-title>{{transService.getTranslatedData('project-search.title')}}</ion-title>\r\n  </ion-toolbar>\r\n  <ion-searchbar [(ngModel)]=\"filterData.searchText\"\r\n    placeholder=\"{{transService.getTranslatedData('search-placeholder')}}\" (ngModelChange)=\"resetFilterAndSearch()\">\r\n  </ion-searchbar>\r\n</ion-header>\r\n\r\n<ion-content>\r\n\r\n  <div class=\"center-text margin-top-10\" [hidden]=\"!loading\">\r\n    <ion-spinner></ion-spinner>\r\n  </div>\r\n\r\n  <!-- <ion-list>\r\n\r\n    <ion-radio-group>\r\n      <ion-item *ngFor=\"let project of projects\">\r\n        <ion-label>{{project.name}} {{selectedProject}}</ion-label>\r\n        <ion-radio value=\"project._id\" slot=\"end\" [(ngModel)]=\"selectedProject\"></ion-radio>\r\n      </ion-item>\r\n    </ion-radio-group>\r\n\r\n  </ion-list> -->\r\n\r\n  <ion-list>\r\n    <ion-radio-group [(ngModel)]=\"selectedProject.ticketBelongsToRefId\">\r\n      <ion-item *ngFor=\"let project of projects\">\r\n        <ion-label>{{project.name}}</ion-label>\r\n        <ion-radio value=\"{{project._id}}\" slot=\"end\" (click)=\"selectProject(project)\"></ion-radio>\r\n      </ion-item>\r\n    </ion-radio-group>\r\n  </ion-list>\r\n\r\n  <ion-infinite-scroll [hidden]=\"disableInfiniteScroll\" threshold=\"5px\" (ionInfinite)=\"searchProject($event)\">\r\n    <ion-infinite-scroll-content loadingSpinner=\"bubbles\"\r\n      loadingText=\"{{transService.getTranslatedData('infinite-scroll')}}\">\r\n    </ion-infinite-scroll-content>\r\n  </ion-infinite-scroll>\r\n\r\n</ion-content>"

/***/ }),

/***/ "./src/app/Rentals Management/pages/project-search/project-search.page.scss":
/*!**********************************************************************************!*\
  !*** ./src/app/Rentals Management/pages/project-search/project-search.page.scss ***!
  \**********************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "ion-searchbar {\n  padding: 0px; }\n\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvUmVudGFscyBNYW5hZ2VtZW50L3BhZ2VzL3Byb2plY3Qtc2VhcmNoL0Q6XFxuYXZqb3RcXHZlcmlmeS9zcmNcXGFwcFxcUmVudGFscyBNYW5hZ2VtZW50XFxwYWdlc1xccHJvamVjdC1zZWFyY2hcXHByb2plY3Qtc2VhcmNoLnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNJLFlBQVksRUFBQSIsImZpbGUiOiJzcmMvYXBwL1JlbnRhbHMgTWFuYWdlbWVudC9wYWdlcy9wcm9qZWN0LXNlYXJjaC9wcm9qZWN0LXNlYXJjaC5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyJpb24tc2VhcmNoYmFyIHtcclxuICAgIHBhZGRpbmc6IDBweDtcclxuICB9XHJcbiAgIl19 */"

/***/ }),

/***/ "./src/app/Rentals Management/pages/project-search/project-search.page.ts":
/*!********************************************************************************!*\
  !*** ./src/app/Rentals Management/pages/project-search/project-search.page.ts ***!
  \********************************************************************************/
/*! exports provided: ProjectSearchPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ProjectSearchPage", function() { return ProjectSearchPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _services_project_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../services/project.service */ "./src/app/Rentals Management/services/project.service.ts");
/* harmony import */ var src_app_common_services_alert_service_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/common-services/alert-service.service */ "./src/app/common-services/alert-service.service.ts");
/* harmony import */ var src_app_common_services_translate_translate_service_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! src/app/common-services/translate/translate-service.service */ "./src/app/common-services/translate/translate-service.service.ts");






var ProjectSearchPage = /** @class */ (function () {
    function ProjectSearchPage(loadingCtrl, projectService, modalController, navParams, alertService, transService) {
        this.loadingCtrl = loadingCtrl;
        this.projectService = projectService;
        this.modalController = modalController;
        this.navParams = navParams;
        this.alertService = alertService;
        this.transService = transService;
        this.projects = [];
        this.loading = false;
        this.disableInfiniteScroll = false;
        this.selectedProject = {};
        this.filterData = {
            skip: 0,
            searchText: ''
        };
        if (this.navParams.get('id')) {
            this.selectedProject.ticketBelongsToRefId = this.navParams.get('id');
            this.selectedProject.ticketBelongsToName = this.navParams.get('name');
        }
        this.searchProject('');
    }
    ProjectSearchPage.prototype.ngOnInit = function () {
    };
    ProjectSearchPage.prototype.closeModal = function (sendData) {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function () {
            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                switch (_a.label) {
                    case 0:
                        if (!sendData) return [3 /*break*/, 2];
                        console.log('Send data');
                        return [4 /*yield*/, this.modalController.dismiss(this.selectedProject)];
                    case 1:
                        _a.sent();
                        return [3 /*break*/, 4];
                    case 2:
                        console.log('Dont Send data');
                        return [4 /*yield*/, this.modalController.dismiss()];
                    case 3:
                        _a.sent();
                        _a.label = 4;
                    case 4: return [2 /*return*/];
                }
            });
        });
    };
    ProjectSearchPage.prototype.selectProject = function (project) {
        this.selectedProject.ticketBelongsToName = project.name;
        this.selectedProject.ticketBelongsToRefId = project._id;
        this.closeModal(true);
    };
    // async presentLoading() {
    //   this.loading = await this.loadingCtrl.create({
    //   });
    //   this.loading.present();
    // }
    // type, searchtext, skip, token, status
    ProjectSearchPage.prototype.searchProject = function (event) {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function () {
            var _this = this;
            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                if (!event) {
                    this.loading = true;
                }
                this.projectService.getProjects(this.filterData)
                    .subscribe(function (data) {
                    _this.projects = _this.projects.concat(data.data.searchResult);
                    _this.filterData.skip = data.data.query.skip + 10;
                    console.log(_this.projects);
                    event ? event.target.complete() : _this.loading = false;
                    console.log('loading should dismiss');
                    if (data.data.query.current >= data.data.query.total) {
                        _this.disableInfiniteScroll = true;
                    }
                }, function (err) {
                    _this.loading = false;
                    _this.alertService.presentAlert(_this.transService.getTranslatedData('alert-title'), err.error.error);
                });
                return [2 /*return*/];
            });
        });
    };
    ProjectSearchPage.prototype.resetFilterAndSearch = function () {
        this.projects = [];
        this.filterData.skip = 0;
        this.disableInfiniteScroll = false;
        this.searchProject('');
    };
    ProjectSearchPage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-project-search',
            template: __webpack_require__(/*! ./project-search.page.html */ "./src/app/Rentals Management/pages/project-search/project-search.page.html"),
            styles: [__webpack_require__(/*! ./project-search.page.scss */ "./src/app/Rentals Management/pages/project-search/project-search.page.scss")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_ionic_angular__WEBPACK_IMPORTED_MODULE_2__["LoadingController"],
            _services_project_service__WEBPACK_IMPORTED_MODULE_3__["ProjectService"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["ModalController"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["NavParams"],
            src_app_common_services_alert_service_service__WEBPACK_IMPORTED_MODULE_4__["AlertServiceService"],
            src_app_common_services_translate_translate_service_service__WEBPACK_IMPORTED_MODULE_5__["translateService"]])
    ], ProjectSearchPage);
    return ProjectSearchPage;
}());



/***/ }),

/***/ "./src/app/Rentals Management/pages/ticket-category-search/ticket-category-search.module.ts":
/*!**************************************************************************************************!*\
  !*** ./src/app/Rentals Management/pages/ticket-category-search/ticket-category-search.module.ts ***!
  \**************************************************************************************************/
/*! exports provided: TicketCategorySearchPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "TicketCategorySearchPageModule", function() { return TicketCategorySearchPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _ticket_category_search_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./ticket-category-search.page */ "./src/app/Rentals Management/pages/ticket-category-search/ticket-category-search.page.ts");







var routes = [
    {
        path: '',
        component: _ticket_category_search_page__WEBPACK_IMPORTED_MODULE_6__["TicketCategorySearchPage"]
    }
];
var TicketCategorySearchPageModule = /** @class */ (function () {
    function TicketCategorySearchPageModule() {
    }
    TicketCategorySearchPageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            imports: [
                _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
                _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["IonicModule"],
                _angular_router__WEBPACK_IMPORTED_MODULE_4__["RouterModule"].forChild(routes)
            ],
            declarations: [_ticket_category_search_page__WEBPACK_IMPORTED_MODULE_6__["TicketCategorySearchPage"]]
        })
    ], TicketCategorySearchPageModule);
    return TicketCategorySearchPageModule;
}());



/***/ }),

/***/ "./src/app/Rentals Management/pages/ticket-category-search/ticket-category-search.page.html":
/*!**************************************************************************************************!*\
  !*** ./src/app/Rentals Management/pages/ticket-category-search/ticket-category-search.page.html ***!
  \**************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ion-header>\r\n  <ion-toolbar color=\"primary\">\r\n    <ion-buttons slot=\"end\">\r\n      <ion-button (click)=\"closeModal(false)\">\r\n        <ion-icon name=\"close\"></ion-icon>\r\n      </ion-button>\r\n    </ion-buttons>\r\n    <ion-title>{{transService.getTranslatedData('ticket-category.title')}}</ion-title>\r\n  </ion-toolbar>\r\n  <!-- <ion-searchbar></ion-searchbar> -->\r\n</ion-header>\r\n\r\n<ion-content>\r\n  <div class=\"center-text margin-top-10\" [hidden]=\"!loading\">\r\n    <ion-spinner></ion-spinner>\r\n  </div>\r\n  <p class=\"gotham center-text\" *ngIf=\"categories.length==0 && !loading\">\r\n    {{transService.getTranslatedData('ticket-category.empty-array')}}</p>\r\n  <ion-list>\r\n    <ion-radio-group [(ngModel)]=\"this.selectedCategory.ticketCategory\">\r\n      <ion-item *ngFor=\"let category of categories\">\r\n        <ion-label>{{category.name}}</ion-label>\r\n        <ion-radio value=\"{{category._id}}\" slot=\"end\" (click)=\"selectCategory(category)\"></ion-radio>\r\n      </ion-item>\r\n    </ion-radio-group>\r\n  </ion-list>\r\n</ion-content>"

/***/ }),

/***/ "./src/app/Rentals Management/pages/ticket-category-search/ticket-category-search.page.scss":
/*!**************************************************************************************************!*\
  !*** ./src/app/Rentals Management/pages/ticket-category-search/ticket-category-search.page.scss ***!
  \**************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL1JlbnRhbHMgTWFuYWdlbWVudC9wYWdlcy90aWNrZXQtY2F0ZWdvcnktc2VhcmNoL3RpY2tldC1jYXRlZ29yeS1zZWFyY2gucGFnZS5zY3NzIn0= */"

/***/ }),

/***/ "./src/app/Rentals Management/pages/ticket-category-search/ticket-category-search.page.ts":
/*!************************************************************************************************!*\
  !*** ./src/app/Rentals Management/pages/ticket-category-search/ticket-category-search.page.ts ***!
  \************************************************************************************************/
/*! exports provided: TicketCategorySearchPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "TicketCategorySearchPage", function() { return TicketCategorySearchPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _services_ticket_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../services/ticket.service */ "./src/app/Rentals Management/services/ticket.service.ts");
/* harmony import */ var src_app_common_services_alert_service_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/common-services/alert-service.service */ "./src/app/common-services/alert-service.service.ts");
/* harmony import */ var src_app_common_services_translate_translate_service_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! src/app/common-services/translate/translate-service.service */ "./src/app/common-services/translate/translate-service.service.ts");






var TicketCategorySearchPage = /** @class */ (function () {
    function TicketCategorySearchPage(modalController, ticketService, navParams, alertService, transService) {
        this.modalController = modalController;
        this.ticketService = ticketService;
        this.navParams = navParams;
        this.alertService = alertService;
        this.transService = transService;
        this.categories = [];
        this.selectedCategory = {};
        this.loading = false;
        this.selectedCategory.name = this.navParams.get('name');
        this.selectedCategory.ticketCategory = this.navParams.get('ticketCategory');
        this.selectedCategory.subCategory = this.navParams.get('subCategories');
        var categoryFilter = {
            ticketBelongsTo: this.navParams.get('ticketBelongsTo'),
            ticketBelongsToRefId: this.navParams.get('ticketBelongsToRefId')
        };
        this.getCategories(categoryFilter);
    }
    TicketCategorySearchPage.prototype.ngOnInit = function () {
    };
    TicketCategorySearchPage.prototype.selectCategory = function (category) {
        this.selectedCategory.name = category.name;
        this.selectedCategory.ticketCategory = category._id;
        this.selectedCategory.subCategory = category.subCategory;
        this.closeModal(true);
    };
    TicketCategorySearchPage.prototype.closeModal = function (sendData) {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function () {
            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                switch (_a.label) {
                    case 0:
                        if (!sendData) return [3 /*break*/, 2];
                        console.log('Send data');
                        return [4 /*yield*/, this.modalController.dismiss(this.selectedCategory)];
                    case 1:
                        _a.sent();
                        return [3 /*break*/, 4];
                    case 2:
                        console.log('Dont Send data');
                        return [4 /*yield*/, this.modalController.dismiss()];
                    case 3:
                        _a.sent();
                        _a.label = 4;
                    case 4: return [2 /*return*/];
                }
            });
        });
    };
    TicketCategorySearchPage.prototype.getCategories = function (categoryFilter) {
        var _this = this;
        this.loading = true;
        this.ticketService.getTicketCategories(categoryFilter)
            .subscribe(function (data) {
            _this.loading = false;
            _this.categories = data;
        }, function (err) {
            _this.loading = false;
            _this.alertService.presentAlert(_this.transService.getTranslatedData('alert-title'), err.error.error);
        });
    };
    TicketCategorySearchPage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-ticket-category-search',
            template: __webpack_require__(/*! ./ticket-category-search.page.html */ "./src/app/Rentals Management/pages/ticket-category-search/ticket-category-search.page.html"),
            styles: [__webpack_require__(/*! ./ticket-category-search.page.scss */ "./src/app/Rentals Management/pages/ticket-category-search/ticket-category-search.page.scss")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_ionic_angular__WEBPACK_IMPORTED_MODULE_2__["ModalController"],
            _services_ticket_service__WEBPACK_IMPORTED_MODULE_3__["TicketService"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["NavParams"],
            src_app_common_services_alert_service_service__WEBPACK_IMPORTED_MODULE_4__["AlertServiceService"],
            src_app_common_services_translate_translate_service_service__WEBPACK_IMPORTED_MODULE_5__["translateService"]])
    ], TicketCategorySearchPage);
    return TicketCategorySearchPage;
}());



/***/ }),

/***/ "./src/app/Rentals Management/pages/ticket-filter/ticket-filter.module.ts":
/*!********************************************************************************!*\
  !*** ./src/app/Rentals Management/pages/ticket-filter/ticket-filter.module.ts ***!
  \********************************************************************************/
/*! exports provided: TicketFilterPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "TicketFilterPageModule", function() { return TicketFilterPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _ticket_filter_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./ticket-filter.page */ "./src/app/Rentals Management/pages/ticket-filter/ticket-filter.page.ts");







// import { BarcodeScanner } from '@ionic-native/barcode-scanner/ngx';
var routes = [
    {
        path: '',
        component: _ticket_filter_page__WEBPACK_IMPORTED_MODULE_6__["TicketFilterPage"]
    }
];
var TicketFilterPageModule = /** @class */ (function () {
    function TicketFilterPageModule() {
    }
    TicketFilterPageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            imports: [
                _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
                _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["IonicModule"],
                _angular_router__WEBPACK_IMPORTED_MODULE_4__["RouterModule"].forChild(routes)
            ],
            providers: [
            // BarcodeScanner
            ],
            declarations: [_ticket_filter_page__WEBPACK_IMPORTED_MODULE_6__["TicketFilterPage"]]
        })
    ], TicketFilterPageModule);
    return TicketFilterPageModule;
}());



/***/ }),

/***/ "./src/app/Rentals Management/pages/ticket-filter/ticket-filter.page.html":
/*!********************************************************************************!*\
  !*** ./src/app/Rentals Management/pages/ticket-filter/ticket-filter.page.html ***!
  \********************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ion-header>\r\n  <ion-toolbar color=\"primary\">\r\n    <ion-buttons slot=\"end\">\r\n      <ion-button (click)=\"closeModal(false)\">\r\n        <ion-icon name=\"close\"></ion-icon>\r\n      </ion-button>\r\n    </ion-buttons>\r\n    <ion-title>{{transService.getTranslatedData('ticket-filter.title')}}</ion-title>\r\n  </ion-toolbar>\r\n</ion-header>\r\n\r\n<ion-content>\r\n  <div class=\"max-available-height full-width \">\r\n    <div class=\"\">\r\n      <ion-row class=\"\">\r\n        <ion-list class=\"full-width\">\r\n\r\n          <ion-grid fixed>\r\n            <ion-list-header class=\"font-17\">{{transService.getTranslatedData('ticket-filter.ticket-status')}}\r\n            </ion-list-header>\r\n            <ion-row>\r\n\r\n              <ion-col class=\"padding-left-10\">\r\n\r\n                <ion-chip [ngClass]=\"ticketFilter.status.indexOf('open') != -1 ? 'selected' : 'a'\" outline=\"true\"\r\n                  color=\"primary\" (click)=\"selectTicketStatus('open')\">\r\n                  <ion-label class=\"font-16 font-weight-500\">{{transService.getTranslatedData('ticket-filter.open')}}\r\n                  </ion-label>\r\n                </ion-chip>\r\n\r\n                <ion-chip [ngClass]=\"ticketFilter.status.indexOf('in-progress') != -1 ? 'selected' : 'a'\" outline=\"true\"\r\n                  color=\"primary\" (click)=\"selectTicketStatus('in-progress')\">\r\n                  <ion-label class=\"font-16 font-weight-500\">\r\n                    {{transService.getTranslatedData('ticket-filter.in-progress')}}</ion-label>\r\n                </ion-chip>\r\n\r\n                <ion-chip [ngClass]=\"ticketFilter.status.indexOf('resolved') != -1 ? 'selected' : 'a'\" outline=\"true\"\r\n                  color=\"primary\" (click)=\"selectTicketStatus('resolved')\">\r\n                  <ion-label class=\"font-16 font-weight-500\">\r\n                    {{transService.getTranslatedData('ticket-filter.resolved')}}</ion-label>\r\n                </ion-chip>\r\n\r\n                <ion-chip [ngClass]=\"ticketFilter.status.indexOf('rejected') != -1 ? 'selected' : 'a'\" outline=\"true\"\r\n                  color=\"primary\" (click)=\"selectTicketStatus('rejected')\">\r\n                  <ion-label class=\"font-16 font-weight-500\">\r\n                    {{transService.getTranslatedData('ticket-filter.rejected')}}</ion-label>\r\n                </ion-chip>\r\n\r\n                <!-- <ion-chip [ngClass]=\"ticketFilter.status == 'all' ? 'all' : 'b'\" outline=\"true\" color=\"primary\"\r\n                  (click)=\"selectTicketStatus('all')\">\r\n                  <ion-label class=\"font-16 font-weight-500\">All</ion-label>\r\n                </ion-chip> -->\r\n\r\n              </ion-col>\r\n            </ion-row>\r\n\r\n          </ion-grid>\r\n\r\n          <ion-grid class=\"margin-top-10\" fixed>\r\n            <ion-list-header class=\"font-17\">{{transService.getTranslatedData('ticket-filter.raised-for')}}\r\n            </ion-list-header>\r\n            <ion-row>\r\n\r\n              <ion-col class=\"padding-left-10\">\r\n                <ion-chip [ngClass]=\"ticketFilter.ticketBelongsTo.indexOf('Home') != -1 ? 'selected' : 'a'\"\r\n                  outline=\"true\" color=\"primary\" (click)=\"selectTicketBelongsTo('Home')\">\r\n                  <ion-label class=\"font-16 font-weight-500\">{{transService.getTranslatedData('ticket-filter.unit')}}\r\n                  </ion-label>\r\n                </ion-chip>\r\n\r\n                <ion-chip [ngClass]=\"ticketFilter.ticketBelongsTo.indexOf('Project') != -1 ? 'selected' : 'a'\"\r\n                  outline=\"true\" color=\"primary\" (click)=\"selectTicketBelongsTo('Project')\">\r\n                  <ion-label class=\"font-16 font-weight-500\">\r\n                    {{transService.getTranslatedData('ticket-filter.common-area')}}</ion-label>\r\n                </ion-chip>\r\n              </ion-col>\r\n            </ion-row>\r\n\r\n          </ion-grid>\r\n\r\n          <ion-grid class=\"margin-top-10\" fixed>\r\n            <ion-list-header class=\"font-17\">{{transService.getTranslatedData('ticket-filter.ticket-type')}}\r\n            </ion-list-header>\r\n            <ion-row>\r\n              <ion-col class=\"padding-left-10\">\r\n\r\n                <ion-chip [ngClass]=\"ticketFilter.type.indexOf('on-demand') != -1 ? 'selected' : 'a'\" outline=\"true\"\r\n                  color=\"primary\" (click)=\"selectTicketType('on-demand')\">\r\n                  <ion-label class=\"font-16 font-weight-500\">\r\n                    {{transService.getTranslatedData('ticket-filter.on-demand')}}</ion-label>\r\n                </ion-chip>\r\n\r\n                <ion-chip [ngClass]=\"ticketFilter.type.indexOf('ppm') != -1 ? 'selected' : 'a'\" outline=\"true\"\r\n                  color=\"primary\" (click)=\"selectTicketType('ppm')\">\r\n                  <ion-label class=\"font-16 font-weight-500\">{{transService.getTranslatedData('ticket-filter.ppm')}}\r\n                  </ion-label>\r\n                </ion-chip>\r\n\r\n              </ion-col>\r\n            </ion-row>\r\n          </ion-grid>\r\n\r\n          <ion-grid class=\"margin-top-10\" fixed>\r\n            <ion-list-header class=\"font-17\">{{transService.getTranslatedData('ticket-filter.priority')}}\r\n            </ion-list-header>\r\n            <ion-row>\r\n              <ion-col class=\"padding-left-10\">\r\n\r\n                <ion-chip [ngClass]=\"ticketFilter.priority.indexOf('low') != -1 ? 'selected' : 'a'\" outline=\"true\"\r\n                  color=\"primary\" (click)=\"selectTicketPriority('low')\">\r\n                  <ion-label class=\"font-16 font-weight-500\">{{transService.getTranslatedData('ticket-filter.low')}}\r\n                  </ion-label>\r\n                </ion-chip>\r\n\r\n                <ion-chip [ngClass]=\"ticketFilter.priority.indexOf('high') != -1 ? 'selected' : 'a'\" outline=\"true\"\r\n                  color=\"primary\" (click)=\"selectTicketPriority('high')\">\r\n                  <ion-label class=\"font-16 font-weight-500\">{{transService.getTranslatedData('ticket-filter.high')}}\r\n                  </ion-label>\r\n                </ion-chip>\r\n\r\n              </ion-col>\r\n            </ion-row>\r\n          </ion-grid>\r\n\r\n\r\n          <ion-item class=\"margin-bottom-10\">\r\n            <ion-label position=\"stacked\" class=\"font-20\">{{transService.getTranslatedData('ticket-filter.project')}}\r\n            </ion-label>\r\n            <ion-input inputmode=\"text\" [(ngModel)]=\"ticketFilter.ticketBelongsToName\" class=\"margin-top-10\"\r\n              placeholder=\"{{transService.getTranslatedData('ticket-filter.project-placeholder')}}\"\r\n              (click)=\"openProjectSearchModal()\"></ion-input>\r\n            <ion-icon slot=\"end\" name=\"ios-arrow-down\"></ion-icon>\r\n          </ion-item>\r\n\r\n          <ion-item class=\"margin-bottom-10\">\r\n            <ion-label position=\"stacked\" class=\"font-20\">{{transService.getTranslatedData('ticket-filter.poc')}}\r\n            </ion-label>\r\n            <ion-input inputmode=\"text\" [(ngModel)]=\"ticketFilter.contactPointName\" class=\"margin-top-10\"\r\n              placeholder=\"{{transService.getTranslatedData('ticket-filter.poc-placeholder')}}\"\r\n              (click)=\"openUserSearchModal('poc')\">\r\n            </ion-input>\r\n            <ion-icon slot=\"end\" name=\"ios-arrow-down\"></ion-icon>\r\n          </ion-item>\r\n\r\n          <ion-item class=\"margin-bottom-10\">\r\n            <ion-label position=\"stacked\" class=\"font-20\">\r\n              {{transService.getTranslatedData('ticket-filter.technician')}}</ion-label>\r\n            <ion-input inputmode=\"text\" [(ngModel)]=\"ticketFilter.agentName\" class=\"margin-top-10\"\r\n              placeholder=\"{{transService.getTranslatedData('ticket-filter.technician-placeholder')}}\"\r\n              (click)=\"openUserSearchModal('agent')\"></ion-input>\r\n            <ion-icon slot=\"end\" name=\"ios-arrow-down\"></ion-icon>\r\n          </ion-item>\r\n\r\n          <!-- <ion-item class=\"margin-bottom-10\">\r\n            <ion-label position=\"stacked\" class=\"font-20\">\r\n              {{transService.getTranslatedData('ticket-filter.assets')}}</ion-label>\r\n            <ion-input inputmode=\"text\" [(ngModel)]=\"ticketFilter.assetId\" class=\"margin-top-10\"\r\n              placeholder=\"{{transService.getTranslatedData('ticket-filter.assets')}}\"\r\n              (click)=\"openScanner()\"></ion-input>\r\n            <ion-icon slot=\"end\" name=\"ios-arrow-down\"></ion-icon>\r\n          </ion-item> -->\r\n          \r\n          <ion-item class=\"margin-bottom-10\">\r\n            <ion-label position=\"stacked\" class=\"font-20\">{{transService.getTranslatedData('ticket-filter.SJD')}}\r\n            </ion-label>\r\n            <ion-datetime displayFormat=\"DD-MMM-YYYY\"\r\n              placeholder=\"{{transService.getTranslatedData('ticket-filter.date-placeholder')}}\"\r\n              picker-format=\"DD-MMM-YYYY\" [(ngModel)]=\"ticketFilter.startDate\"></ion-datetime>\r\n            <ion-icon slot=\"end\" name=\"ios-arrow-down\"></ion-icon>\r\n          </ion-item>\r\n\r\n          <ion-item class=\"margin-bottom-10\">\r\n            <ion-label position=\"stacked\" class=\"font-20\">{{transService.getTranslatedData('ticket-filter.EJD')}}\r\n            </ion-label>\r\n            <ion-datetime displayFormat=\"DD-MMM-YYYY\"\r\n              placeholder=\"{{transService.getTranslatedData('ticket-filter.date-placeholder')}}\"\r\n              picker-format=\"DD-MMM-YYYY\" [(ngModel)]=\"ticketFilter.endDate\"></ion-datetime>\r\n            <ion-icon slot=\"end\" name=\"ios-arrow-down\"></ion-icon>\r\n          </ion-item>\r\n\r\n          <!-- <ion-item class=\"margin-bottom-10\">\r\n            <ion-label position=\"stacked\" class=\"font-20\">ASSET</ion-label>\r\n            <ion-input class=\"margin-top-10\" type=\"text\" placeholder=\"Awesome Input\"></ion-input>\r\n            <ion-icon slot=\"end\" name=\"ios-arrow-down\"></ion-icon>\r\n          </ion-item> -->\r\n        </ion-list>\r\n      </ion-row>\r\n    </div>\r\n  </div>\r\n\r\n\r\n</ion-content>\r\n<ion-button size=\"large\" (click)=\"closeModal(true)\" color=\"danger\">\r\n  {{transService.getTranslatedData('ticket-filter.apply')}}</ion-button>"

/***/ }),

/***/ "./src/app/Rentals Management/pages/ticket-filter/ticket-filter.page.scss":
/*!********************************************************************************!*\
  !*** ./src/app/Rentals Management/pages/ticket-filter/ticket-filter.page.scss ***!
  \********************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ".selected {\n  background-color: #9d4065 !important;\n  color: #f7f7f7 !important; }\n\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvUmVudGFscyBNYW5hZ2VtZW50L3BhZ2VzL3RpY2tldC1maWx0ZXIvRDpcXG5hdmpvdFxcdmVyaWZ5L3NyY1xcYXBwXFxSZW50YWxzIE1hbmFnZW1lbnRcXHBhZ2VzXFx0aWNrZXQtZmlsdGVyXFx0aWNrZXQtZmlsdGVyLnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNFLG9DQUFvQztFQUNwQyx5QkFBeUIsRUFBQSIsImZpbGUiOiJzcmMvYXBwL1JlbnRhbHMgTWFuYWdlbWVudC9wYWdlcy90aWNrZXQtZmlsdGVyL3RpY2tldC1maWx0ZXIucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiLnNlbGVjdGVkIHtcclxuICBiYWNrZ3JvdW5kLWNvbG9yOiAjOWQ0MDY1ICFpbXBvcnRhbnQ7XHJcbiAgY29sb3I6ICNmN2Y3ZjcgIWltcG9ydGFudDtcclxufVxyXG4iXX0= */"

/***/ }),

/***/ "./src/app/Rentals Management/pages/ticket-filter/ticket-filter.page.ts":
/*!******************************************************************************!*\
  !*** ./src/app/Rentals Management/pages/ticket-filter/ticket-filter.page.ts ***!
  \******************************************************************************/
/*! exports provided: TicketFilterPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "TicketFilterPage", function() { return TicketFilterPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _pages_project_search_project_search_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../pages/project-search/project-search.page */ "./src/app/Rentals Management/pages/project-search/project-search.page.ts");
/* harmony import */ var _pages_user_search_user_search_page__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../pages/user-search/user-search.page */ "./src/app/Rentals Management/pages/user-search/user-search.page.ts");
/* harmony import */ var src_app_common_services_alert_service_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! src/app/common-services/alert-service.service */ "./src/app/common-services/alert-service.service.ts");
/* harmony import */ var src_app_common_services_translate_translate_service_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! src/app/common-services/translate/translate-service.service */ "./src/app/common-services/translate/translate-service.service.ts");
/* harmony import */ var _services_ticket_service__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../../services/ticket.service */ "./src/app/Rentals Management/services/ticket.service.ts");







// import { BarcodeScanner } from '@ionic-native/barcode-scanner/ngx';

var TicketFilterPage = /** @class */ (function () {
    function TicketFilterPage(modalController, navParams, transService, alertService, 
    // private barcodeScanner: BarcodeScanner,
    ticketService, alertCtrl) {
        this.modalController = modalController;
        this.navParams = navParams;
        this.transService = transService;
        this.alertService = alertService;
        this.ticketService = ticketService;
        this.alertCtrl = alertCtrl;
        this.ticketFilter = {
            status: ['open', 'in-progress'],
            ticketBelongsTo: ['Home', 'Project'],
            type: ['on-demand'],
            priority: ['low', 'high']
        };
        if (this.navParams.get('data')) {
            this.ticketFilter = this.navParams.get('data');
            console.log(this.ticketFilter);
        }
    }
    TicketFilterPage.prototype.ngOnInit = function () {
    };
    TicketFilterPage.prototype.selectTicketStatus = function (value) {
        this.ticketFilter.status.indexOf(value) === -1 ? this.ticketFilter.status.push(value) : this.ticketFilter.status.splice(this.ticketFilter.status.indexOf(value), 1);
        // this.ticketFilter.status = _.union([value], this.ticketFilter.status);
        console.log(this.ticketFilter.status);
    };
    TicketFilterPage.prototype.selectTicketBelongsTo = function (value) {
        this.ticketFilter.ticketBelongsTo.indexOf(value) === -1 ? this.ticketFilter.ticketBelongsTo.push(value) : this.ticketFilter.ticketBelongsTo.splice(this.ticketFilter.ticketBelongsTo.indexOf(value), 1);
        console.log(this.ticketFilter.ticketBelongsTo);
    };
    TicketFilterPage.prototype.selectTicketType = function (value) {
        this.ticketFilter.type.indexOf(value) === -1 ? this.ticketFilter.type.push(value) : this.ticketFilter.type.splice(this.ticketFilter.type.indexOf(value), 1);
        console.log(this.ticketFilter.type);
    };
    TicketFilterPage.prototype.selectTicketPriority = function (value) {
        this.ticketFilter.priority.indexOf(value) === -1 ? this.ticketFilter.priority.push(value) : this.ticketFilter.priority.splice(this.ticketFilter.priority.indexOf(value), 1);
        console.log(this.ticketFilter.priority);
    };
    TicketFilterPage.prototype.openProjectSearchModal = function () {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function () {
            var modal;
            var _this = this;
            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.modalController.create({
                            component: _pages_project_search_project_search_page__WEBPACK_IMPORTED_MODULE_3__["ProjectSearchPage"],
                            componentProps: {
                                id: this.ticketFilter.ticketBelongsToRefId,
                                name: this.ticketFilter.ticketBelongsToName
                            }
                        })];
                    case 1:
                        modal = _a.sent();
                        modal.onDidDismiss().then(function (project) {
                            if (project !== null && project.data) {
                                _this.ticketFilter.ticketBelongsToName = project.data.ticketBelongsToName;
                                _this.ticketFilter.ticketBelongsToRefId = project.data.ticketBelongsToRefId;
                                console.log(_this.ticketFilter);
                            }
                        });
                        return [4 /*yield*/, modal.present()];
                    case 2: return [2 /*return*/, _a.sent()];
                }
            });
        });
    };
    TicketFilterPage.prototype.openUserSearchModal = function (type) {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function () {
            var id, name, modal;
            var _this = this;
            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                switch (_a.label) {
                    case 0:
                        if (type === 'agent') {
                            id = this.ticketFilter.agent;
                            name = this.ticketFilter.agentName;
                        }
                        else if (type === 'poc') {
                            id = this.ticketFilter.contactPoint;
                            name = this.ticketFilter.contactPointName;
                        }
                        return [4 /*yield*/, this.modalController.create({
                                component: _pages_user_search_user_search_page__WEBPACK_IMPORTED_MODULE_4__["UserSearchPage"],
                                componentProps: {
                                    id: id,
                                    name: name
                                }
                            })];
                    case 1:
                        modal = _a.sent();
                        modal.onDidDismiss().then(function (user) {
                            if (user !== null && user.data) {
                                if (type === 'agent') {
                                    _this.ticketFilter.agentName = user.data.name;
                                    _this.ticketFilter.agent = user.data.id;
                                }
                                else if (type === 'poc') {
                                    _this.ticketFilter.contactPointName = user.data.name;
                                    _this.ticketFilter.contactPoint = user.data.id;
                                }
                                console.log(_this.ticketFilter);
                            }
                        });
                        return [4 /*yield*/, modal.present()];
                    case 2: return [2 /*return*/, _a.sent()];
                }
            });
        });
    };
    TicketFilterPage.prototype.applyFilter = function () {
        console.log(this.ticketFilter);
    };
    TicketFilterPage.prototype.closeModal = function (sendData) {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function () {
            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                switch (_a.label) {
                    case 0:
                        if (!sendData) return [3 /*break*/, 2];
                        console.log('Send data');
                        return [4 /*yield*/, this.modalController.dismiss(this.ticketFilter)];
                    case 1:
                        _a.sent();
                        return [3 /*break*/, 4];
                    case 2:
                        console.log('Dont Send data');
                        return [4 /*yield*/, this.modalController.dismiss()];
                    case 3:
                        _a.sent();
                        _a.label = 4;
                    case 4: return [2 /*return*/];
                }
            });
        });
    };
    TicketFilterPage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-ticket-filter',
            template: __webpack_require__(/*! ./ticket-filter.page.html */ "./src/app/Rentals Management/pages/ticket-filter/ticket-filter.page.html"),
            styles: [__webpack_require__(/*! ./ticket-filter.page.scss */ "./src/app/Rentals Management/pages/ticket-filter/ticket-filter.page.scss")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_ionic_angular__WEBPACK_IMPORTED_MODULE_2__["ModalController"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["NavParams"],
            src_app_common_services_translate_translate_service_service__WEBPACK_IMPORTED_MODULE_6__["translateService"],
            src_app_common_services_alert_service_service__WEBPACK_IMPORTED_MODULE_5__["AlertServiceService"],
            _services_ticket_service__WEBPACK_IMPORTED_MODULE_7__["TicketService"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["AlertController"]])
    ], TicketFilterPage);
    return TicketFilterPage;
}());



/***/ }),

/***/ "./src/app/Rentals Management/pages/ticket-sub-category-search/ticket-sub-category-search.module.ts":
/*!**********************************************************************************************************!*\
  !*** ./src/app/Rentals Management/pages/ticket-sub-category-search/ticket-sub-category-search.module.ts ***!
  \**********************************************************************************************************/
/*! exports provided: TicketSubCategorySearchPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "TicketSubCategorySearchPageModule", function() { return TicketSubCategorySearchPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _ticket_sub_category_search_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./ticket-sub-category-search.page */ "./src/app/Rentals Management/pages/ticket-sub-category-search/ticket-sub-category-search.page.ts");







var routes = [
    {
        path: '',
        component: _ticket_sub_category_search_page__WEBPACK_IMPORTED_MODULE_6__["TicketSubCategorySearchPage"]
    }
];
var TicketSubCategorySearchPageModule = /** @class */ (function () {
    function TicketSubCategorySearchPageModule() {
    }
    TicketSubCategorySearchPageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            imports: [
                _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
                _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["IonicModule"],
                _angular_router__WEBPACK_IMPORTED_MODULE_4__["RouterModule"].forChild(routes)
            ],
            declarations: [_ticket_sub_category_search_page__WEBPACK_IMPORTED_MODULE_6__["TicketSubCategorySearchPage"]]
        })
    ], TicketSubCategorySearchPageModule);
    return TicketSubCategorySearchPageModule;
}());



/***/ }),

/***/ "./src/app/Rentals Management/pages/ticket-sub-category-search/ticket-sub-category-search.page.html":
/*!**********************************************************************************************************!*\
  !*** ./src/app/Rentals Management/pages/ticket-sub-category-search/ticket-sub-category-search.page.html ***!
  \**********************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ion-header>\r\n  <ion-toolbar color=\"primary\">\r\n    <ion-buttons slot=\"end\">\r\n      <ion-button (click)=\"closeModal(false)\">\r\n        <ion-icon name=\"close\"></ion-icon>\r\n      </ion-button>\r\n    </ion-buttons>\r\n    <ion-title>{{transService.getTranslatedData('ticket-sub-category.title')}}</ion-title>\r\n  </ion-toolbar>\r\n  <!-- <ion-searchbar></ion-searchbar> -->\r\n</ion-header>\r\n\r\n<ion-content>\r\n  <!-- <div class=\"center-text margin-top-10\" [hidden]=\"!loading\">\r\n      <ion-spinner></ion-spinner>\r\n    </div> -->\r\n  <p class=\"gotham center-text\" *ngIf=\"subCategories.length==0\">\r\n    {{transService.getTranslatedData('ticket-sub-category.empty-array')}}</p>\r\n  <ion-list>\r\n    <ion-radio-group [(ngModel)]=\"selectedSubCategory.ticketSubCategory\">\r\n      <ion-item *ngFor=\"let category of subCategories\">\r\n        <ion-label>{{category.name}}</ion-label>\r\n        <ion-radio value=\"{{category._id}}\" slot=\"end\" (click)=\"selectSubCategory(category)\"></ion-radio>\r\n      </ion-item>\r\n    </ion-radio-group>\r\n  </ion-list>\r\n</ion-content>"

/***/ }),

/***/ "./src/app/Rentals Management/pages/ticket-sub-category-search/ticket-sub-category-search.page.scss":
/*!**********************************************************************************************************!*\
  !*** ./src/app/Rentals Management/pages/ticket-sub-category-search/ticket-sub-category-search.page.scss ***!
  \**********************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL1JlbnRhbHMgTWFuYWdlbWVudC9wYWdlcy90aWNrZXQtc3ViLWNhdGVnb3J5LXNlYXJjaC90aWNrZXQtc3ViLWNhdGVnb3J5LXNlYXJjaC5wYWdlLnNjc3MifQ== */"

/***/ }),

/***/ "./src/app/Rentals Management/pages/ticket-sub-category-search/ticket-sub-category-search.page.ts":
/*!********************************************************************************************************!*\
  !*** ./src/app/Rentals Management/pages/ticket-sub-category-search/ticket-sub-category-search.page.ts ***!
  \********************************************************************************************************/
/*! exports provided: TicketSubCategorySearchPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "TicketSubCategorySearchPage", function() { return TicketSubCategorySearchPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var src_app_common_services_translate_translate_service_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/common-services/translate/translate-service.service */ "./src/app/common-services/translate/translate-service.service.ts");




var TicketSubCategorySearchPage = /** @class */ (function () {
    function TicketSubCategorySearchPage(modalController, navParams, transService) {
        this.modalController = modalController;
        this.navParams = navParams;
        this.transService = transService;
        this.subCategories = [];
        this.selectedSubCategory = {};
        this.selectedSubCategory.name = this.navParams.get('name');
        this.selectedSubCategory.ticketSubCategory = this.navParams.get('ticketSubCategory');
        this.subCategories = this.navParams.get('subCategories');
    }
    TicketSubCategorySearchPage.prototype.ngOnInit = function () {
    };
    TicketSubCategorySearchPage.prototype.selectSubCategory = function (subCategory) {
        this.selectedSubCategory.name = subCategory.name;
        this.selectedSubCategory.ticketSubCategory = subCategory._id;
        this.closeModal(true);
    };
    TicketSubCategorySearchPage.prototype.closeModal = function (sendData) {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function () {
            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                switch (_a.label) {
                    case 0:
                        if (!sendData) return [3 /*break*/, 2];
                        console.log('Send data');
                        return [4 /*yield*/, this.modalController.dismiss(this.selectedSubCategory)];
                    case 1:
                        _a.sent();
                        return [3 /*break*/, 4];
                    case 2:
                        console.log('Dont Send data');
                        return [4 /*yield*/, this.modalController.dismiss()];
                    case 3:
                        _a.sent();
                        _a.label = 4;
                    case 4: return [2 /*return*/];
                }
            });
        });
    };
    TicketSubCategorySearchPage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-ticket-sub-category-search',
            template: __webpack_require__(/*! ./ticket-sub-category-search.page.html */ "./src/app/Rentals Management/pages/ticket-sub-category-search/ticket-sub-category-search.page.html"),
            styles: [__webpack_require__(/*! ./ticket-sub-category-search.page.scss */ "./src/app/Rentals Management/pages/ticket-sub-category-search/ticket-sub-category-search.page.scss")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_ionic_angular__WEBPACK_IMPORTED_MODULE_2__["ModalController"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["NavParams"],
            src_app_common_services_translate_translate_service_service__WEBPACK_IMPORTED_MODULE_3__["translateService"]])
    ], TicketSubCategorySearchPage);
    return TicketSubCategorySearchPage;
}());



/***/ }),

/***/ "./src/app/Rentals Management/pages/unit-search/unit-search.module.ts":
/*!****************************************************************************!*\
  !*** ./src/app/Rentals Management/pages/unit-search/unit-search.module.ts ***!
  \****************************************************************************/
/*! exports provided: UnitSearchPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "UnitSearchPageModule", function() { return UnitSearchPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _unit_search_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./unit-search.page */ "./src/app/Rentals Management/pages/unit-search/unit-search.page.ts");







var routes = [
    {
        path: '',
        component: _unit_search_page__WEBPACK_IMPORTED_MODULE_6__["UnitSearchPage"]
    }
];
var UnitSearchPageModule = /** @class */ (function () {
    function UnitSearchPageModule() {
    }
    UnitSearchPageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            imports: [
                _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
                _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["IonicModule"],
                _angular_router__WEBPACK_IMPORTED_MODULE_4__["RouterModule"].forChild(routes)
            ],
            declarations: [_unit_search_page__WEBPACK_IMPORTED_MODULE_6__["UnitSearchPage"]]
        })
    ], UnitSearchPageModule);
    return UnitSearchPageModule;
}());



/***/ }),

/***/ "./src/app/Rentals Management/pages/unit-search/unit-search.page.html":
/*!****************************************************************************!*\
  !*** ./src/app/Rentals Management/pages/unit-search/unit-search.page.html ***!
  \****************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ion-header>\r\n  <ion-toolbar color=\"primary\">\r\n    <ion-buttons slot=\"end\">\r\n      <ion-button (click)=\"closeModal(false)\">\r\n        <ion-icon name=\"close\"></ion-icon>\r\n      </ion-button>\r\n    </ion-buttons>\r\n    <ion-title>{{transService.getTranslatedData('unit-search.title')}}</ion-title>\r\n  </ion-toolbar>\r\n  <ion-searchbar [(ngModel)]=\"filterData.searchText\"\r\n    placeholder=\"{{transService.getTranslatedData('search-placeholder')}}\" (ngModelChange)=\"resetFilterAndSearch()\">\r\n  </ion-searchbar>\r\n</ion-header>\r\n\r\n<ion-content>\r\n\r\n  <div class=\"center-text margin-top-10\" [hidden]=\"!loading\">\r\n    <ion-spinner></ion-spinner>\r\n  </div>\r\n\r\n  <!-- <ion-list>\r\n  \r\n      <ion-radio-group>\r\n        <ion-item *ngFor=\"let project of projects\">\r\n          <ion-label>{{project.name}} {{selectedProject}}</ion-label>\r\n          <ion-radio value=\"project._id\" slot=\"end\" [(ngModel)]=\"selectedProject\"></ion-radio>\r\n        </ion-item>\r\n      </ion-radio-group>\r\n  \r\n    </ion-list> -->\r\n\r\n  <p class=\"center-text\" *ngIf=\"!loading && units.length==0\">No Unit Available</p>\r\n  <ion-list>\r\n    <ion-radio-group [(ngModel)]=\"selectedUnit.ticketBelongsToRefId\">\r\n      <ion-item *ngFor=\"let unit of units\">\r\n        <ion-label>{{unit.block}}{{unit.door}}, {{unit.name}}</ion-label>\r\n        <ion-radio value=\"{{unit._id}}\" slot=\"end\" (click)=\"selectUnit(unit)\"></ion-radio>\r\n      </ion-item>\r\n    </ion-radio-group>\r\n  </ion-list>\r\n\r\n  <ion-infinite-scroll [hidden]=\"disableInfiniteScroll\" threshold=\"5px\" (ionInfinite)=\"searchUnit($event)\">\r\n    <ion-infinite-scroll-content loadingSpinner=\"bubbles\"\r\n      loadingText=\"{{transService.getTranslatedData('infinite-scroll')}}\">\r\n    </ion-infinite-scroll-content>\r\n  </ion-infinite-scroll>\r\n\r\n</ion-content>\r\n<!-- <ion-button size=\"large\" (click)=\"closeModal(true)\" color=\"success\">Submit</ion-button> -->"

/***/ }),

/***/ "./src/app/Rentals Management/pages/unit-search/unit-search.page.scss":
/*!****************************************************************************!*\
  !*** ./src/app/Rentals Management/pages/unit-search/unit-search.page.scss ***!
  \****************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "ion-searchbar {\n  padding: 0px; }\n\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvUmVudGFscyBNYW5hZ2VtZW50L3BhZ2VzL3VuaXQtc2VhcmNoL0Q6XFxuYXZqb3RcXHZlcmlmeS9zcmNcXGFwcFxcUmVudGFscyBNYW5hZ2VtZW50XFxwYWdlc1xcdW5pdC1zZWFyY2hcXHVuaXQtc2VhcmNoLnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNFLFlBQVksRUFBQSIsImZpbGUiOiJzcmMvYXBwL1JlbnRhbHMgTWFuYWdlbWVudC9wYWdlcy91bml0LXNlYXJjaC91bml0LXNlYXJjaC5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyJpb24tc2VhcmNoYmFyIHtcclxuICBwYWRkaW5nOiAwcHg7XHJcbn1cclxuIl19 */"

/***/ }),

/***/ "./src/app/Rentals Management/pages/unit-search/unit-search.page.ts":
/*!**************************************************************************!*\
  !*** ./src/app/Rentals Management/pages/unit-search/unit-search.page.ts ***!
  \**************************************************************************/
/*! exports provided: UnitSearchPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "UnitSearchPage", function() { return UnitSearchPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _services_unit_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../services/unit.service */ "./src/app/Rentals Management/services/unit.service.ts");
/* harmony import */ var src_app_common_services_alert_service_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/common-services/alert-service.service */ "./src/app/common-services/alert-service.service.ts");
/* harmony import */ var src_app_common_services_translate_translate_service_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! src/app/common-services/translate/translate-service.service */ "./src/app/common-services/translate/translate-service.service.ts");






var UnitSearchPage = /** @class */ (function () {
    function UnitSearchPage(unitService, modalController, navParams, alertService, transService) {
        this.unitService = unitService;
        this.modalController = modalController;
        this.navParams = navParams;
        this.alertService = alertService;
        this.transService = transService;
        this.units = [];
        this.loading = false;
        this.disableInfiniteScroll = false;
        this.selectedUnit = {};
        this.filterData = {
            skip: 0,
            searchText: ''
        };
        if (this.navParams.get('id')) {
            this.selectedUnit.ticketBelongsToRefId = this.navParams.get('id');
            this.selectedUnit.ticketBelongsToName = this.navParams.get('name');
        }
        this.searchUnit('');
    }
    UnitSearchPage.prototype.ngOnInit = function () {
    };
    UnitSearchPage.prototype.closeModal = function (sendData) {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function () {
            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                switch (_a.label) {
                    case 0:
                        if (!sendData) return [3 /*break*/, 2];
                        console.log('Send data');
                        return [4 /*yield*/, this.modalController.dismiss(this.selectedUnit)];
                    case 1:
                        _a.sent();
                        return [3 /*break*/, 4];
                    case 2:
                        console.log('Dont Send data');
                        return [4 /*yield*/, this.modalController.dismiss()];
                    case 3:
                        _a.sent();
                        _a.label = 4;
                    case 4: return [2 /*return*/];
                }
            });
        });
    };
    UnitSearchPage.prototype.selectUnit = function (unit) {
        this.selectedUnit.ticketBelongsToName = '';
        if (unit.block) {
            this.selectedUnit.ticketBelongsToName = unit.block;
        }
        if (unit.door) {
            this.selectedUnit.ticketBelongsToName = this.selectedUnit.ticketBelongsToName + unit.door;
        }
        if (unit.name) {
            this.selectedUnit.ticketBelongsToName = this.selectedUnit.ticketBelongsToName + ', ' + unit.name;
        }
        this.selectedUnit.ticketBelongsToRefId = unit._id;
        this.closeModal(true);
    };
    UnitSearchPage.prototype.searchUnit = function (event) {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function () {
            var _this = this;
            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                if (!event) {
                    this.loading = true;
                }
                this.unitService.getUnits(this.filterData)
                    .subscribe(function (data) {
                    _this.units = _this.units.concat(data.data.data);
                    _this.filterData.skip = data.data.query.skip + 10;
                    console.log(_this.units);
                    event ? event.target.complete() : _this.loading = false;
                    console.log('loading should dismiss');
                    if (data.data.query.current >= data.data.query.total) {
                        _this.disableInfiniteScroll = true;
                    }
                }, function (err) {
                    _this.loading = false;
                    _this.alertService.presentAlert(_this.transService.getTranslatedData('alert-title'), err.error.error);
                });
                return [2 /*return*/];
            });
        });
    };
    UnitSearchPage.prototype.resetFilterAndSearch = function () {
        this.units = [];
        this.filterData.skip = 0;
        this.disableInfiniteScroll = false;
        this.searchUnit('');
    };
    UnitSearchPage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-unit-search',
            template: __webpack_require__(/*! ./unit-search.page.html */ "./src/app/Rentals Management/pages/unit-search/unit-search.page.html"),
            styles: [__webpack_require__(/*! ./unit-search.page.scss */ "./src/app/Rentals Management/pages/unit-search/unit-search.page.scss")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_services_unit_service__WEBPACK_IMPORTED_MODULE_3__["UnitService"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["ModalController"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["NavParams"],
            src_app_common_services_alert_service_service__WEBPACK_IMPORTED_MODULE_4__["AlertServiceService"],
            src_app_common_services_translate_translate_service_service__WEBPACK_IMPORTED_MODULE_5__["translateService"]])
    ], UnitSearchPage);
    return UnitSearchPage;
}());



/***/ }),

/***/ "./src/app/Rentals Management/pages/user-search/user-search.module.ts":
/*!****************************************************************************!*\
  !*** ./src/app/Rentals Management/pages/user-search/user-search.module.ts ***!
  \****************************************************************************/
/*! exports provided: UserSearchPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "UserSearchPageModule", function() { return UserSearchPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _user_search_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./user-search.page */ "./src/app/Rentals Management/pages/user-search/user-search.page.ts");
/* harmony import */ var _pipes_pointOfContectFilter__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../../pipes/pointOfContectFilter */ "./src/app/Rentals Management/pipes/pointOfContectFilter.ts");








var routes = [
    {
        path: '',
        component: _user_search_page__WEBPACK_IMPORTED_MODULE_6__["UserSearchPage"]
    }
];
var UserSearchPageModule = /** @class */ (function () {
    function UserSearchPageModule() {
    }
    UserSearchPageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            imports: [
                _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
                _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["IonicModule"],
                _angular_router__WEBPACK_IMPORTED_MODULE_4__["RouterModule"].forChild(routes)
            ],
            declarations: [_user_search_page__WEBPACK_IMPORTED_MODULE_6__["UserSearchPage"], _pipes_pointOfContectFilter__WEBPACK_IMPORTED_MODULE_7__["PointOfContact"]]
        })
    ], UserSearchPageModule);
    return UserSearchPageModule;
}());



/***/ }),

/***/ "./src/app/Rentals Management/pages/user-search/user-search.page.html":
/*!****************************************************************************!*\
  !*** ./src/app/Rentals Management/pages/user-search/user-search.page.html ***!
  \****************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ion-header>\r\n  <ion-toolbar color=\"primary\">\r\n    <ion-buttons slot=\"end\">\r\n      <ion-button (click)=\"closeModal(false)\">\r\n        <ion-icon name=\"close\"></ion-icon>\r\n      </ion-button>\r\n    </ion-buttons>\r\n    <ion-title>{{transService.getTranslatedData('user-search.title')}}</ion-title>\r\n  </ion-toolbar>\r\n  <ion-searchbar [(ngModel)]=\"searchTerm\" placeholder=\"{{transService.getTranslatedData('search-placeholder')}}\">\r\n  </ion-searchbar>\r\n</ion-header>\r\n\r\n<ion-content>\r\n  <div class=\"center-text margin-top-10\" [hidden]=\"!loading\">\r\n    <ion-spinner></ion-spinner>\r\n  </div>\r\n  <ion-list>\r\n    <ion-radio-group [(ngModel)]=\"selectedUser.id\">\r\n      <ion-item *ngFor=\"let user of users |PointOfContactFilter:searchTerm\">\r\n        <ion-label>{{user.firstName}} {{user.lastName}}</ion-label>\r\n        <ion-radio value=\"{{user._id}}\" slot=\"end\" (click)=\"selectUser(user)\"></ion-radio>\r\n      </ion-item>\r\n    </ion-radio-group>\r\n  </ion-list>\r\n</ion-content>"

/***/ }),

/***/ "./src/app/Rentals Management/pages/user-search/user-search.page.scss":
/*!****************************************************************************!*\
  !*** ./src/app/Rentals Management/pages/user-search/user-search.page.scss ***!
  \****************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "ion-searchbar {\n  padding: 0px; }\n\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvUmVudGFscyBNYW5hZ2VtZW50L3BhZ2VzL3VzZXItc2VhcmNoL0Q6XFxuYXZqb3RcXHZlcmlmeS9zcmNcXGFwcFxcUmVudGFscyBNYW5hZ2VtZW50XFxwYWdlc1xcdXNlci1zZWFyY2hcXHVzZXItc2VhcmNoLnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNFLFlBQVksRUFBQSIsImZpbGUiOiJzcmMvYXBwL1JlbnRhbHMgTWFuYWdlbWVudC9wYWdlcy91c2VyLXNlYXJjaC91c2VyLXNlYXJjaC5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyJpb24tc2VhcmNoYmFyIHtcclxuICBwYWRkaW5nOiAwcHg7XHJcbn1cclxuIl19 */"

/***/ }),

/***/ "./src/app/Rentals Management/pages/user-search/user-search.page.ts":
/*!**************************************************************************!*\
  !*** ./src/app/Rentals Management/pages/user-search/user-search.page.ts ***!
  \**************************************************************************/
/*! exports provided: UserSearchPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "UserSearchPage", function() { return UserSearchPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var src_app_common_services_alert_service_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/common-services/alert-service.service */ "./src/app/common-services/alert-service.service.ts");
/* harmony import */ var src_app_common_services_translate_translate_service_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/common-services/translate/translate-service.service */ "./src/app/common-services/translate/translate-service.service.ts");
/* harmony import */ var _services_rentals_user_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../services/rentals-user.service */ "./src/app/Rentals Management/services/rentals-user.service.ts");






var UserSearchPage = /** @class */ (function () {
    function UserSearchPage(
    // private loading: LoadingController,
    userService, modalController, navParams, alertService, transService) {
        this.userService = userService;
        this.modalController = modalController;
        this.navParams = navParams;
        this.alertService = alertService;
        this.transService = transService;
        this.users = [];
        this.loading = false;
        this.selectedUser = {};
        this.disableInfiniteScroll = false;
        if (this.navParams.get('id')) {
            this.selectedUser.id = this.navParams.get('id');
            this.selectedUser.name = this.navParams.get('name');
        }
        this.searchUsers();
    }
    UserSearchPage.prototype.ngOnInit = function () {
    };
    // async presentLoading() {
    //   const loading = await this.loading.create({
    //   });
    //   await loading.present();
    // }
    UserSearchPage.prototype.selectUser = function (user) {
        this.selectedUser.name = '';
        if (user.firstName) {
            this.selectedUser.name = user.firstName;
        }
        if (user.lastName) {
            this.selectedUser.name = this.selectedUser.name + ' ' + user.lastName;
        }
        this.selectedUser.id = user._id;
        this.closeModal(true);
    };
    UserSearchPage.prototype.searchUsers = function () {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function () {
            var _this = this;
            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                this.loading = true;
                this.userService.getUsers()
                    .subscribe(function (data) {
                    _this.loading = false;
                    _this.users = data;
                }, function (err) {
                    _this.loading = false;
                    _this.alertService.presentAlert(_this.transService.getTranslatedData('alert-title'), err.error.error);
                });
                return [2 /*return*/];
            });
        });
    };
    UserSearchPage.prototype.closeModal = function (sendData) {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function () {
            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                switch (_a.label) {
                    case 0:
                        if (!sendData) return [3 /*break*/, 2];
                        return [4 /*yield*/, this.modalController.dismiss(this.selectedUser)];
                    case 1:
                        _a.sent();
                        return [3 /*break*/, 4];
                    case 2: return [4 /*yield*/, this.modalController.dismiss()];
                    case 3:
                        _a.sent();
                        _a.label = 4;
                    case 4: return [2 /*return*/];
                }
            });
        });
    };
    UserSearchPage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-user-search',
            template: __webpack_require__(/*! ./user-search.page.html */ "./src/app/Rentals Management/pages/user-search/user-search.page.html"),
            styles: [__webpack_require__(/*! ./user-search.page.scss */ "./src/app/Rentals Management/pages/user-search/user-search.page.scss")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_services_rentals_user_service__WEBPACK_IMPORTED_MODULE_5__["RentalsUserService"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["ModalController"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["NavParams"],
            src_app_common_services_alert_service_service__WEBPACK_IMPORTED_MODULE_3__["AlertServiceService"],
            src_app_common_services_translate_translate_service_service__WEBPACK_IMPORTED_MODULE_4__["translateService"]])
    ], UserSearchPage);
    return UserSearchPage;
}());



/***/ }),

/***/ "./src/app/Rentals Management/pipes/agofilter.ts":
/*!*******************************************************!*\
  !*** ./src/app/Rentals Management/pipes/agofilter.ts ***!
  \*******************************************************/
/*! exports provided: AgoFilter */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AgoFilter", function() { return AgoFilter; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var moment__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! moment */ "./node_modules/moment/moment.js");
/* harmony import */ var moment__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(moment__WEBPACK_IMPORTED_MODULE_2__);



var AgoFilter = /** @class */ (function () {
    function AgoFilter() {
    }
    AgoFilter.prototype.transform = function (conCode) {
        console.log("ago Filter", conCode);
        var m = moment__WEBPACK_IMPORTED_MODULE_2__(conCode).fromNow();
        return m;
    };
    AgoFilter = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Pipe"])({
            name: 'agoFilter'
        })
    ], AgoFilter);
    return AgoFilter;
}());



/***/ }),

/***/ "./src/app/Rentals Management/pipes/pointOfContectFilter.ts":
/*!******************************************************************!*\
  !*** ./src/app/Rentals Management/pipes/pointOfContectFilter.ts ***!
  \******************************************************************/
/*! exports provided: PointOfContact */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "PointOfContact", function() { return PointOfContact; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");


var PointOfContact = /** @class */ (function () {
    function PointOfContact() {
    }
    PointOfContact.prototype.transform = function (conCode, searchTerm) {
        if (!conCode)
            return [];
        if (!searchTerm)
            return conCode;
        searchTerm = searchTerm.toLowerCase();
        return conCode.filter(function (it) {
            // let name:string;
            // if (it.lastName) {
            // return it.lastName.toLowerCase().includes(searchTerm);
            // } else if (it.firstName) {
            return it.firstName.toLowerCase().includes(searchTerm);
            // }
        });
    };
    PointOfContact = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Pipe"])({
            name: 'PointOfContactFilter'
        })
    ], PointOfContact);
    return PointOfContact;
}());



/***/ }),

/***/ "./src/app/Rentals Management/pipes/user-search-pipe.ts":
/*!**************************************************************!*\
  !*** ./src/app/Rentals Management/pipes/user-search-pipe.ts ***!
  \**************************************************************/
/*! exports provided: UserSearchPipe */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "UserSearchPipe", function() { return UserSearchPipe; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");


var UserSearchPipe = /** @class */ (function () {
    function UserSearchPipe() {
    }
    UserSearchPipe.prototype.transform = function (users, searchText) {
        if (searchText == null) {
            return users;
        }
        return users.filter(function (user) {
            return user.firstName + ' ' + user.lastName;
        });
    };
    UserSearchPipe = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Pipe"])({
            name: 'userSearch'
        })
    ], UserSearchPipe);
    return UserSearchPipe;
}());



/***/ }),

/***/ "./src/app/Rentals Management/rental-management-routing.module.ts":
/*!************************************************************************!*\
  !*** ./src/app/Rentals Management/rental-management-routing.module.ts ***!
  \************************************************************************/
/*! exports provided: RentalsRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "RentalsRoutingModule", function() { return RentalsRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");



var routes = [
    {
        path: '',
        redirectTo: 'rentals-naila-search-page',
        pathMatch: 'full'
    },
    { path: 'rentals-home', loadChildren: '../Rentals Management/pages/home/home.module#HomePageModule' },
    { path: 'rentals-profile', loadChildren: '../Rentals Management/pages/profile/profile.module#ProfilePageModule' },
    { path: 'rentals-tickets', loadChildren: '../Rentals Management/pages/tickets/tickets.module#TicketsPageModule' },
    { path: 'rentals-calendar', loadChildren: '../Rentals Management/pages/calendar/calendar.module#CalendarPageModule' },
    { path: 'rentals-create-ticket', loadChildren: '../Rentals Management/pages/create-ticket/create-ticket.module#CreateTicketPageModule' },
    { path: 'rentals-ticket-filter', loadChildren: '../Rentals Management/pages/ticket-filter/ticket-filter.module#TicketFilterPageModule' },
    { path: 'rentals-user-search', loadChildren: '../Rentals Management/pages/user-search/user-search.module#UserSearchPageModule' },
    { path: 'rentals-project-search', loadChildren: '../Rentals Management/pages/project-search/project-search.module#ProjectSearchPageModule' },
    { path: 'rentals-unit-search', loadChildren: '../Rentals Management/pages/unit-search/unit-search.module#UnitSearchPageModule' },
    { path: 'rentals-ticket-category-search', loadChildren: '../Rentals Management/pages/ticket-category-search/ticket-category-search.module#TicketCategorySearchPageModule' },
    { path: 'rentals-ticket-sub-category-search', loadChildren: '../Rentals Management/pages/ticket-sub-category-search/ticket-sub-category-search.module#TicketSubCategorySearchPageModule' },
    { path: 'rentals-ticket-details', loadChildren: '../Rentals Management/pages/ticket-details/ticket-details.module#TicketDetailsPageModule', runGuardsAndResolvers: 'always' },
    { path: 'rentals-material-search', loadChildren: '../Rentals Management/pages/material-search/material-search.module#MaterialSearchPageModule' },
    { path: 'rentals-notice-board', loadChildren: '../Rentals Management/pages/notice-board/notice-board.module#NoticeBoardPageModule' },
    { path: 'rentals-notice-details', loadChildren: '../Rentals Management/pages/notice-details/notice-details.module#NoticeDetailsPageModule' },
    { path: 'rentals-user-approval', loadChildren: '../Rentals Management/pages/user-approval/user-approval.module#UserApprovalPageModule' },
    { path: 'rentals-contact-us', loadChildren: '../Rentals Management/pages/contact-us/contact-us.module#ContactUsPageModule' },
    { path: 'rentals-estimate', loadChildren: '../Rentals Management/pages/estimate/estimate.module#EstimatePageModule' },
    { path: 'rentals-naila-search-page', loadChildren: '../Rentals Management/pages/nailasearchpage/nailasearchpage.module#NailasearchPageModule' },
    { path: 'rentals-naila-service-page', loadChildren: '../Rentals Management/pages/nailaservicepage/nailaservicepage.module#NailaservicePageModule' },
    { path: 'rentals-naila-offers-page', loadChildren: '../Rentals Management/pages/nailaofferspage/nailaofferspage.module#NailaOffersPageModule' },
    { path: 'rentals-naila-offers-listing-page', loadChildren: '../Rentals Management/pages/nailaofferslisting/nailaofferslisting.module#NailaoffersListingPageModule' },
    { path: 'rentals-naila-account-page', loadChildren: '../Rentals Management/pages/nailaaccountpage/nailaaccountpage.module#NailaAccountPageModule' },
    { path: 'rentals-naila-booking-page', loadChildren: '../Rentals Management/pages/nailabooking/nailabooking.module#NailabookingPageModule' },
    { path: 'rentals-naila-cart-page', loadChildren: '../Rentals Management/pages/nailacart/nailacart.module#NailaCartPageModule' },
    { path: 'rentals-naila-ticket-page', loadChildren: '../Rentals Management/pages/nailaticket/nailaticket.module#NailaticketPageModule' },
    { path: 'rentals-naila-beaut-booking-page', loadChildren: '../Rentals Management/pages/beauticianbooking/beauticianbooking.module#NailaBeauticianBookingPageModule' },
    { path: 'rentals-naila-beaut-attendance-page', loadChildren: '../Rentals Management/pages/nailabeauticianattendance/nailabeauticianattendance.module#NailabeauticianAttendanceModule' },
    { path: 'verifyit-dashboard', loadChildren: '../Rentals Management/pages/verifyitdashboard/verifyitdashboard.module#VerifyitDashboardPageModule' },
    { path: 'verifyit-product-info', loadChildren: '../Rentals Management/pages/verifyitProductinfo/verifyitProductinfo.module#VerifyitProductInfoPageModule' },
    { path: 'verifyit-store-product-info', loadChildren: '../Rentals Management/pages/verifyitstoreproductinfo/verifyitstoreproductinfo.module#VerifyitStoreProductInfoPageModule' },
    { path: 'verifyit-message', loadChildren: '../Rentals Management/pages/verifyitsuccessmessage/verifyitsuccessmessage.module#VerifyItSuccessMessageModule' },
    { path: 'verifyit-account', loadChildren: '../Rentals Management/pages/verifyitaccountspage/verifyitaccountspage.module#VerifyitAccountsPageModule' },
    { path: 'verifyit-product-catalog-info', loadChildren: '../Rentals Management/pages/verifyitproductcataloginfo/verifyitproductcataloginfo.module#VerifyitProductCatalogInfoPageModule' },
    { path: 'verifyit-product-catalog', loadChildren: '../Rentals Management/pages/verifyitproductcatalog/verifyitproductcatalog.module#VerifyitProductCatalogPageModule' },
];
var RentalsRoutingModule = /** @class */ (function () {
    function RentalsRoutingModule() {
    }
    RentalsRoutingModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_2__["NgModule"])({
            imports: [
                _angular_router__WEBPACK_IMPORTED_MODULE_1__["RouterModule"].forChild(routes)
            ],
            exports: [_angular_router__WEBPACK_IMPORTED_MODULE_1__["RouterModule"]]
        })
    ], RentalsRoutingModule);
    return RentalsRoutingModule;
}());



/***/ }),

/***/ "./src/app/Rentals Management/rental-management.component.html":
/*!*********************************************************************!*\
  !*** ./src/app/Rentals Management/rental-management.component.html ***!
  \*********************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ""

/***/ }),

/***/ "./src/app/Rentals Management/rental-management.component.ts":
/*!*******************************************************************!*\
  !*** ./src/app/Rentals Management/rental-management.component.ts ***!
  \*******************************************************************/
/*! exports provided: RentalsComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "RentalsComponent", function() { return RentalsComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _pages_profile_profile_page__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./pages/profile/profile.page */ "./src/app/Rentals Management/pages/profile/profile.page.ts");



var RentalsComponent = /** @class */ (function () {
    function RentalsComponent(profile) {
        this.profile = profile;
        this.appPages = {
            name: '',
            phoneNumber: localStorage.getItem('phoneNumber'),
            pages: [
                {
                    title: 'Home',
                    url: '/home',
                    src: '/assets/icon/my-home.png'
                }, {
                    title: 'Calendar',
                    url: '/calendar',
                    src: '/assets/icon/calendar.png'
                }, {
                    title: 'Tickets',
                    url: '/tickets',
                    src: '/assets/icon/ticket-history.png'
                }, {
                    title: 'Notice board',
                    url: '/notice-board',
                    src: '/assets/icon/communications.png'
                },
                {
                    title: 'Approvals',
                    url: '/user-approval',
                    src: '/assets/icon/approval.png'
                },
                {
                    title: 'Contact us',
                    url: '/contact-us',
                    src: '/assets/icon/phone.png'
                },
                {
                    title: 'Profile',
                    url: '/profile',
                    src: '/assets/icon/profile.png'
                }
            ],
            logout: {
                title: 'Logout',
                src: '/assets/icon/log-out.png',
            }
        };
    }
    RentalsComponent.prototype.logOut = function () {
        this.profile.logOut();
        // this.userService.getUserById(localStorage.getItem('user_id')).subscribe((data) => {
        //   data.businessAppDevice = {};
        //   this.userService.updateUser(data).subscribe(() => {
        //     localStorage.clear();
        //     this.router.navigateByUrl('/login');
        //   });
        // })
    };
    RentalsComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'rentals-root',
            template: __webpack_require__(/*! ./rental-management.component.html */ "./src/app/Rentals Management/rental-management.component.html")
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_pages_profile_profile_page__WEBPACK_IMPORTED_MODULE_2__["ProfilePage"]])
    ], RentalsComponent);
    return RentalsComponent;
}());



/***/ }),

/***/ "./src/app/Rentals Management/rental-management.module.ts":
/*!****************************************************************!*\
  !*** ./src/app/Rentals Management/rental-management.module.ts ***!
  \****************************************************************/
/*! exports provided: RentalsManagementModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "RentalsManagementModule", function() { return RentalsManagementModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _rental_management_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./rental-management.component */ "./src/app/Rentals Management/rental-management.component.ts");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/fesm5/http.js");
/* harmony import */ var _rental_management_routing_module__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./rental-management-routing.module */ "./src/app/Rentals Management/rental-management-routing.module.ts");
/* harmony import */ var _pages_ticket_filter_ticket_filter_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./pages/ticket-filter/ticket-filter.module */ "./src/app/Rentals Management/pages/ticket-filter/ticket-filter.module.ts");
/* harmony import */ var _pages_unit_search_unit_search_module__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./pages/unit-search/unit-search.module */ "./src/app/Rentals Management/pages/unit-search/unit-search.module.ts");
/* harmony import */ var _pages_project_search_project_search_module__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./pages/project-search/project-search.module */ "./src/app/Rentals Management/pages/project-search/project-search.module.ts");
/* harmony import */ var _pages_user_search_user_search_module__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./pages/user-search/user-search.module */ "./src/app/Rentals Management/pages/user-search/user-search.module.ts");
/* harmony import */ var _pages_ticket_category_search_ticket_category_search_module__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ./pages/ticket-category-search/ticket-category-search.module */ "./src/app/Rentals Management/pages/ticket-category-search/ticket-category-search.module.ts");
/* harmony import */ var _pages_ticket_sub_category_search_ticket_sub_category_search_module__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ./pages/ticket-sub-category-search/ticket-sub-category-search.module */ "./src/app/Rentals Management/pages/ticket-sub-category-search/ticket-sub-category-search.module.ts");
/* harmony import */ var _pages_material_search_material_search_module__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ./pages/material-search/material-search.module */ "./src/app/Rentals Management/pages/material-search/material-search.module.ts");
/* harmony import */ var _pages_notice_create_notice_create_module__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ./pages/notice-create/notice-create.module */ "./src/app/Rentals Management/pages/notice-create/notice-create.module.ts");
/* harmony import */ var _ApplicationPageModule__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! ./ApplicationPageModule */ "./src/app/Rentals Management/ApplicationPageModule.ts");
/* harmony import */ var _pipes_user_search_pipe__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! ./pipes/user-search-pipe */ "./src/app/Rentals Management/pipes/user-search-pipe.ts");
/* harmony import */ var _ionic_native_file_transfer_ngx__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! @ionic-native/file-transfer/ngx */ "./node_modules/@ionic-native/file-transfer/ngx/index.js");
/* harmony import */ var _ionic_native_push_ngx__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! @ionic-native/push/ngx */ "./node_modules/@ionic-native/push/ngx/index.js");
/* harmony import */ var _pages_profile_profile_page__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! ./pages/profile/profile.page */ "./src/app/Rentals Management/pages/profile/profile.page.ts");















// import { Camera } from '@ionic-native/camera/ngx';



var RentalsManagementModule = /** @class */ (function () {
    function RentalsManagementModule() {
    }
    RentalsManagementModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            declarations: [
                _rental_management_component__WEBPACK_IMPORTED_MODULE_2__["RentalsComponent"],
                _pipes_user_search_pipe__WEBPACK_IMPORTED_MODULE_14__["UserSearchPipe"],
            ],
            imports: [
                _rental_management_routing_module__WEBPACK_IMPORTED_MODULE_4__["RentalsRoutingModule"],
                _angular_common_http__WEBPACK_IMPORTED_MODULE_3__["HttpClientModule"],
                _pages_ticket_filter_ticket_filter_module__WEBPACK_IMPORTED_MODULE_5__["TicketFilterPageModule"],
                _pages_unit_search_unit_search_module__WEBPACK_IMPORTED_MODULE_6__["UnitSearchPageModule"],
                _pages_project_search_project_search_module__WEBPACK_IMPORTED_MODULE_7__["ProjectSearchPageModule"],
                _pages_user_search_user_search_module__WEBPACK_IMPORTED_MODULE_8__["UserSearchPageModule"],
                _pages_ticket_category_search_ticket_category_search_module__WEBPACK_IMPORTED_MODULE_9__["TicketCategorySearchPageModule"],
                _pages_ticket_sub_category_search_ticket_sub_category_search_module__WEBPACK_IMPORTED_MODULE_10__["TicketSubCategorySearchPageModule"],
                _pages_material_search_material_search_module__WEBPACK_IMPORTED_MODULE_11__["MaterialSearchPageModule"],
                _pages_notice_create_notice_create_module__WEBPACK_IMPORTED_MODULE_12__["NoticeCreatePageModule"],
                _ApplicationPageModule__WEBPACK_IMPORTED_MODULE_13__["ApplicationPageModule"]
            ],
            providers: [
                // Camera,
                _ionic_native_file_transfer_ngx__WEBPACK_IMPORTED_MODULE_15__["FileTransfer"],
                _ionic_native_push_ngx__WEBPACK_IMPORTED_MODULE_16__["Push"],
                _ionic_native_file_transfer_ngx__WEBPACK_IMPORTED_MODULE_15__["FileTransferObject"],
                _pages_profile_profile_page__WEBPACK_IMPORTED_MODULE_17__["ProfilePage"],
            ],
            bootstrap: [_rental_management_component__WEBPACK_IMPORTED_MODULE_2__["RentalsComponent"]]
        })
    ], RentalsManagementModule);
    return RentalsManagementModule;
}());



/***/ }),

/***/ "./src/app/Rentals Management/services/naila.service.ts":
/*!**************************************************************!*\
  !*** ./src/app/Rentals Management/services/naila.service.ts ***!
  \**************************************************************/
/*! exports provided: NailaService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "NailaService", function() { return NailaService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/fesm5/http.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var src_app_conatants_MainAppSetting__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/conatants/MainAppSetting */ "./src/app/conatants/MainAppSetting.ts");




var NailaService = /** @class */ (function () {
    function NailaService(http, appSettings) {
        this.http = http;
        this.appSettings = appSettings;
    }
    NailaService.prototype.getEstimateById = function (id) {
        return this.http.get(this.appSettings.getApi() + "/api/estimate/" + id + "?populate=statusChangedBy", {
            headers: new _angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpHeaders"]({
                'Content-Type': 'application/json',
                Authorization: localStorage.getItem('token')
            })
        });
    };
    NailaService.prototype.updateEstimate = function (data) {
        return this.http.post(this.appSettings.getApi() + "/api/estimate/" + data._id, data, {
            headers: new _angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpHeaders"]({
                'Content-Type': 'application/json',
                Authorization: localStorage.getItem('token')
            })
        });
    };
    NailaService.prototype.listBanners = function () {
        return this.http.get(this.appSettings.getApi() + "/products/getRelatedProductD", {
            headers: new _angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpHeaders"]({
                'Content-Type': 'application/json',
                //   Authorization: localStorage.getItem('token')
                credentials: 'include',
            }),
            withCredentials: true,
        });
    };
    NailaService.prototype.apartmentList = function () {
        return this.http.get(this.appSettings.getApi() + "/api/v1/apartments/active", {
            headers: new _angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpHeaders"]({
                'Content-Type': 'application/json',
            })
        });
    };
    NailaService.prototype.browseBycategory = function () {
        return this.http.get(this.appSettings.getApi() + "/api/v1/categories/active", {
            headers: new _angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpHeaders"]({
                'Content-Type': 'application/json',
            })
        });
    };
    NailaService.prototype.selectedCategory = function (data) {
        return this.http.get(this.appSettings.getApi() + "/api/v1/categories/" + data + "/services", {
            headers: new _angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpHeaders"]({
                'Content-Type': 'application/json',
            })
        });
    };
    // 
    NailaService.prototype.listAllBookings = function (data) {
        return this.http.get(this.appSettings.getApi() + "/api/v1/bookings/users/" + data, {
            headers: new _angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpHeaders"]({
                'Content-Type': 'application/json',
            })
        });
    };
    NailaService.prototype.listAllTickets = function (data) {
        return this.http.get(this.appSettings.getApi() + "/api/v1/tickets/" + data, {
            headers: new _angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpHeaders"]({
                'Content-Type': 'application/json',
            })
        });
    };
    NailaService.prototype.listserviceByid = function (id) {
        return this.http.get(this.appSettings.getApi() + "/api/v1/services/" + id, {
            headers: new _angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpHeaders"]({
                'Content-Type': 'application/json',
            })
        });
    };
    NailaService.prototype.applyCoupon = function (data) {
        return this.http.get(this.appSettings.getApi() + "/api/v1/bookings/coupons/" + data, {
            headers: new _angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpHeaders"]({
                'Content-Type': 'application/json',
            })
        });
    };
    NailaService.prototype.getAvailbleSlots = function (data) {
        return this.http.post(this.appSettings.getApi() + "/api/v1/bookings/get_slots", data, {
            headers: new _angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpHeaders"]({
                'Content-Type': 'application/json',
            })
        });
    };
    NailaService.prototype.createBooking = function (data) {
        return this.http.post(this.appSettings.getApi() + "/api/v1/bookings", data, {
            headers: new _angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpHeaders"]({
                'Content-Type': 'application/json',
            })
        });
    };
    NailaService.prototype.createTicket = function (data) {
        return this.http.post(this.appSettings.getApi() + "/api/v1/tickets", data, {
            headers: new _angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpHeaders"]({
                'Content-Type': 'application/json',
            })
        });
    };
    NailaService.prototype.markAttendance = function (data) {
        return this.http.post(this.appSettings.getApi() + "/api/v1/attendances/punch_in", data, {
            headers: new _angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpHeaders"]({
                'Content-Type': 'application/json',
            })
        });
    };
    NailaService.prototype.updateAttendance = function (data, punchin_id) {
        return this.http.put(this.appSettings.getApi() + "/api/v1/attendances/ " + punchin_id + "/punch_out", data, {
            headers: new _angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpHeaders"]({
                'Content-Type': 'application/json',
            })
        });
    };
    NailaService.prototype.getBookingForBeautician = function (data) {
        return this.http.get(this.appSettings.getApi() + "/api/v1/bookings/beauticians/" + data, {
            headers: new _angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpHeaders"]({
                'Content-Type': 'application/json',
            })
        });
    };
    NailaService.prototype.updatepaymentStatus = function (paymentdata, data) {
        return this.http.put(this.appSettings.getApi() + "/api/v1/bookings/" + data.id, paymentdata, {
            headers: new _angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpHeaders"]({
                'Content-Type': 'application/json',
            })
        });
    };
    //nowverifyit api
    NailaService.prototype.callGetTag = function (id) {
        // nfc/get
        return this.http.get(this.appSettings.getApi() + "/nfc/get/" + id + "/2", {
            headers: new _angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpHeaders"]({
                'Content-Type': 'application/json',
                Authorization: localStorage.getItem('token'),
                credentials: 'include',
            })
        });
    };
    NailaService.prototype.callRecordScan = function (data) {
        return this.http.get(this.appSettings.getApi() + "/nfc/recordscan/" + data.tagId + "?location=" + data.location + "&lat=" + data.lat + "&long=" + data.long + "&pincode=" + data.pincode + "&city=" + data.city + "&state=" + data.state + "&country=" + data.country, {
            headers: new _angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpHeaders"]({
                'Content-Type': 'application/json',
                'Access-Control-Allow-Credentials': 'true',
                Authorization: localStorage.getItem('token'),
                credentials: 'include',
            }),
            withCredentials: true,
        });
    };
    NailaService.prototype.callPostBoughtIt = function (tagId) {
        return this.http.post(this.appSettings.getApi() + "/nfc/bought", tagId, {
            headers: new _angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpHeaders"]({
                'Content-Type': 'application/json',
                Authorization: localStorage.getItem('token'),
            })
        });
    };
    NailaService.prototype.writeNFCQRcodedata = function (data) {
        return this.http.post(this.appSettings.getApi() + "/nfc/post/" + data.name + "/" + data.place, {
            headers: new _angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpHeaders"]({
                'Content-Type': 'application/json',
                Authorization: localStorage.getItem('token'),
            })
        });
    };
    NailaService.prototype.genetateOTP = function (data) {
        return this.http.get(this.appSettings.getApi() + "/nfc/sendsms/" + data, {
            headers: new _angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpHeaders"]({
                'Content-Type': 'application/json',
                Authorization: localStorage.getItem('token'),
                credentials: 'include',
            }),
            withCredentials: true,
        });
    };
    NailaService.prototype.submitOTP = function (data) {
        return this.http.get(this.appSettings.getApi() + "/nfc/authPurchase/" + data.tagId + "/" + data.otp, {
            headers: new _angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpHeaders"]({
                'Content-Type': 'application/json',
                Authorization: localStorage.getItem('token'),
                credentials: 'include',
            }),
            withCredentials: true,
        });
    };
    NailaService.prototype.listRelatedProducts = function (data) {
        return this.http.get(this.appSettings.getApi() + "/products/getRelatedProductDetails/" + data, {
            headers: new _angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpHeaders"]({
                'Content-Type': 'application/json',
                Authorization: localStorage.getItem('token'),
                credentials: 'include',
            }),
            withCredentials: true,
        });
    };
    NailaService.prototype.genToken = function () {
        return this.http.get(this.appSettings.getApi() + "/login/gentoken", {
            headers: new _angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpHeaders"]({
                'Content-Type': 'application/json',
                // Authorization: localStorage.getItem('token'),
                credentials: 'include',
            }),
            withCredentials: true,
        });
    };
    NailaService.prototype.reviewTracking = function (data) {
        return this.http.post(this.appSettings.getApi() + "/tracking/review_tracking", data, {
            headers: new _angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpHeaders"]({
                'Content-Type': 'application/json',
                Authorization: localStorage.getItem('token')
            })
        });
    };
    NailaService = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_2__["Injectable"])({
            providedIn: 'root'
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpClient"],
            src_app_conatants_MainAppSetting__WEBPACK_IMPORTED_MODULE_3__["MainAppSetting"]])
    ], NailaService);
    return NailaService;
}());



/***/ }),

/***/ "./src/app/Rentals Management/services/notice.service.ts":
/*!***************************************************************!*\
  !*** ./src/app/Rentals Management/services/notice.service.ts ***!
  \***************************************************************/
/*! exports provided: NoticeService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "NoticeService", function() { return NoticeService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/fesm5/http.js");
/* harmony import */ var src_app_conatants_MainAppSetting__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/conatants/MainAppSetting */ "./src/app/conatants/MainAppSetting.ts");




var NoticeService = /** @class */ (function () {
    function NoticeService(http, appSettings) {
        this.http = http;
        this.appSettings = appSettings;
    }
    NoticeService.prototype.getNotices = function (filterData) {
        console.log(filterData);
        return this.http.get(this.appSettings.getApi() + "/api/discussion?skip=" + filterData.skip + "&limit=5&populate=files", {
            headers: new _angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpHeaders"]({
                'Content-Type': 'application/json',
                Authorization: localStorage.getItem('token')
            })
        });
    };
    NoticeService.prototype.likeNotice = function (id) {
        return this.http.get(this.appSettings.getApi() + "/api/discussion/" + id + "/like", {
            headers: new _angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpHeaders"]({
                'Content-Type': 'application/json',
                Authorization: localStorage.getItem('token')
            })
        });
    };
    NoticeService.prototype.getNoticeById = function (id) {
        console.log(id);
        return this.http.get(this.appSettings.getApi() + "/api/discussion/" + id + "?&populate=files", {
            headers: new _angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpHeaders"]({
                'Content-Type': 'application/json',
                Authorization: localStorage.getItem('token')
            })
        });
    };
    NoticeService.prototype.getAllComments = function (id) {
        console.log(id);
        return this.http.get(this.appSettings.getApi() + "/api/discussion/" + id + "/comments?sortBy=-createdAt", {
            headers: new _angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpHeaders"]({
                'Content-Type': 'application/json',
                Authorization: localStorage.getItem('token')
            })
        });
    };
    NoticeService.prototype.createComment = function (data) {
        return this.http.post(this.appSettings.getApi() + "/api/comment", data, {
            headers: new _angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpHeaders"]({
                'Content-Type': 'application/json',
                Authorization: localStorage.getItem('token')
            })
        });
    };
    NoticeService.prototype.deleteComment = function (id) {
        console.log(id);
        return this.http.delete(this.appSettings.getApi() + "/api/comment/" + id, {
            headers: new _angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpHeaders"]({
                'Content-Type': 'application/json',
                Authorization: localStorage.getItem('token')
            })
        });
    };
    NoticeService.prototype.createNotice = function (data) {
        return this.http.post(this.appSettings.getApi() + "/api/discussion", data, {
            headers: new _angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpHeaders"]({
                'Content-Type': 'application/json',
                Authorization: localStorage.getItem('token')
            })
        });
    };
    NoticeService = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
            providedIn: 'root'
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpClient"],
            src_app_conatants_MainAppSetting__WEBPACK_IMPORTED_MODULE_3__["MainAppSetting"]])
    ], NoticeService);
    return NoticeService;
}());



/***/ }),

/***/ "./src/app/Rentals Management/services/project.service.ts":
/*!****************************************************************!*\
  !*** ./src/app/Rentals Management/services/project.service.ts ***!
  \****************************************************************/
/*! exports provided: ProjectService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ProjectService", function() { return ProjectService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/fesm5/http.js");
/* harmony import */ var src_app_conatants_MainAppSetting__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/conatants/MainAppSetting */ "./src/app/conatants/MainAppSetting.ts");




var ProjectService = /** @class */ (function () {
    function ProjectService(http, appSettings) {
        this.http = http;
        this.appSettings = appSettings;
    }
    ProjectService.prototype.getProjects = function (filterData) {
        console.log(filterData);
        return this.http.get(this.appSettings.getApi() + "/api/project?limit=15&searchText=" + filterData.searchText + "&skip=" + filterData.skip + "&status=all", {
            headers: new _angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpHeaders"]({
                'Content-Type': 'application/json',
                Authorization: localStorage.getItem('token')
            })
        });
    };
    ProjectService = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
            providedIn: 'root'
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpClient"],
            src_app_conatants_MainAppSetting__WEBPACK_IMPORTED_MODULE_3__["MainAppSetting"]])
    ], ProjectService);
    return ProjectService;
}());



/***/ }),

/***/ "./src/app/Rentals Management/services/rentals-user.service.ts":
/*!*********************************************************************!*\
  !*** ./src/app/Rentals Management/services/rentals-user.service.ts ***!
  \*********************************************************************/
/*! exports provided: RentalsUserService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "RentalsUserService", function() { return RentalsUserService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/fesm5/http.js");
/* harmony import */ var src_app_conatants_MainAppSetting__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/conatants/MainAppSetting */ "./src/app/conatants/MainAppSetting.ts");




var RentalsUserService = /** @class */ (function () {
    function RentalsUserService(http, appSettings) {
        this.http = http;
        this.appSettings = appSettings;
    }
    RentalsUserService.prototype.getUsers = function () {
        return this.http.get(this.appSettings.getApi() + "/api/user/type?fields=firstName&fields=lastName&fields=types&fields=_id&status=active&types=vendor&types=employee&types=contract-employee&types=technician&types=admin&types=housekeeper", {
            headers: new _angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpHeaders"]({
                'Content-Type': 'application/json',
                Authorization: localStorage.getItem('token')
            })
        });
    };
    RentalsUserService.prototype.getUserById = function (id) {
        return this.http.get(this.appSettings.getApi() + "/api/user/" + id, {
            headers: new _angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpHeaders"]({
                'Content-Type': 'application/json',
                Authorization: localStorage.getItem('token')
            })
        });
    };
    RentalsUserService.prototype.getUserApprovals = function () {
        return this.http.get(this.appSettings.getApi() + "/api/approval", {
            headers: new _angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpHeaders"]({
                'Content-Type': 'application/json',
                Authorization: localStorage.getItem('token')
            })
        });
    };
    RentalsUserService.prototype.updateUser = function (data) {
        return this.http.put(this.appSettings.getApi() + "/api/user/" + data._id, data, {
            headers: new _angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpHeaders"]({
                'Content-Type': 'application/json',
                Authorization: localStorage.getItem('token')
            })
        });
    };
    RentalsUserService.prototype.approve = function (id) {
        return this.http.post(this.appSettings.getApi() + "/api/approval/" + id + "/approve", '', this.appSettings.getHttpHeadesWithToken());
    };
    RentalsUserService.prototype.reject = function (id, data) {
        console.log(data);
        var userData = {
            notes: data
        };
        return this.http.post(this.appSettings.getApi() + "/api/approval/" + id + "/reject", userData, this.appSettings.getHttpHeadesWithToken());
    };
    RentalsUserService = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
            providedIn: 'root'
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpClient"],
            src_app_conatants_MainAppSetting__WEBPACK_IMPORTED_MODULE_3__["MainAppSetting"]])
    ], RentalsUserService);
    return RentalsUserService;
}());



/***/ }),

/***/ "./src/app/Rentals Management/services/ticket.service.ts":
/*!***************************************************************!*\
  !*** ./src/app/Rentals Management/services/ticket.service.ts ***!
  \***************************************************************/
/*! exports provided: TicketService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "TicketService", function() { return TicketService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/fesm5/http.js");
/* harmony import */ var src_app_conatants_MainAppSetting__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/conatants/MainAppSetting */ "./src/app/conatants/MainAppSetting.ts");




var TicketService = /** @class */ (function () {
    function TicketService(http, appSettings) {
        this.http = http;
        this.appSettings = appSettings;
        this.apiUrl = 'https://admin.grexter.in';
    }
    TicketService.prototype.getTicketStats = function () {
        return this.http.get(this.appSettings.getApi() + "/api/stats/business-app", {
            headers: new _angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpHeaders"]({
                'Content-Type': 'application/json',
                Authorization: localStorage.getItem('token')
            })
        });
    };
    TicketService.prototype.getTickets = function (skip, status, ticketBelongsTo, type, projects, priority, startDate, endDate, contactPoint, agent, asset) {
        console.log(asset);
        return this.http.get(this.appSettings.getApi() + "/api/ticket?" + status + "&limit=10&sortBy=-createdAt&skip=" + skip + "&ticketBelongsTo=" + ticketBelongsTo + "&type=" + type + "&projects=" + projects + "&priority=" + priority + "&startDate=" + startDate + "&endDate=" + endDate + "&contactPoint=" + contactPoint + "&agent=" + agent + "&asset=" + asset, {
            headers: new _angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpHeaders"]({
                'Content-Type': 'application/json',
                Authorization: localStorage.getItem('token')
            })
        });
    };
    TicketService.prototype.getTicketCategories = function (filterData) {
        return this.http.get(this.appSettings.getApi() + "/api/category?belongsTo=" + filterData.ticketBelongsTo + "&" + filterData.ticketBelongsTo.toLowerCase() + "=" + filterData.ticketBelongsToRefId + "&status=active&status=inactive", {
            headers: new _angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpHeaders"]({
                'Content-Type': 'application/json',
                Authorization: localStorage.getItem('token')
            })
        });
    };
    TicketService.prototype.createTicket = function (data) {
        return this.http.post(this.appSettings.getApi() + "/api/ticket", data, {
            headers: new _angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpHeaders"]({
                'Content-Type': 'application/json',
                Authorization: localStorage.getItem('token')
            })
        });
    };
    TicketService.prototype.updateTicket = function (data) {
        return this.http.put(this.appSettings.getApi() + "/api/ticket/" + data._id, data, {
            headers: new _angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpHeaders"]({
                'Content-Type': 'application/json',
                Authorization: localStorage.getItem('token')
            })
        });
    };
    TicketService.prototype.getTicketById = function (ticketId) {
        return this.http.get(this.appSettings.getApi() + "/api/ticket/" + ticketId + "?populate=estimates&populate=assets&populate=contactPoint&populate=raisedBy&populate=agent&populate=itemDetails.product", {
            headers: new _angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpHeaders"]({
                'Content-Type': 'application/json',
                Authorization: localStorage.getItem('token')
            })
        });
    };
    TicketService.prototype.getTicketComments = function (ticketId) {
        return this.http.get(this.appSettings.getApi() + "/api/ticket/" + ticketId + "/comments?sortBy=-createdAt", {
            headers: new _angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpHeaders"]({
                'Content-Type': 'application/json',
                Authorization: localStorage.getItem('token')
            })
        });
    };
    TicketService.prototype.createComment = function (data) {
        return this.http.post(this.appSettings.getApi() + "/api/comment", data, {
            headers: new _angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpHeaders"]({
                'Content-Type': 'application/json',
                Authorization: localStorage.getItem('token')
            })
        });
    };
    TicketService.prototype.searchMaterials = function (filterData) {
        return this.http.get(this.appSettings.getApi() + "/api/product-and-service?type=inventory&searchText=" + filterData.searchText + "&skip=" + filterData.skip + "&limit=10&status=active", {
            headers: new _angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpHeaders"]({
                'Content-Type': 'application/json',
                Authorization: localStorage.getItem('token')
            })
        });
    };
    TicketService.prototype.searchAssert = function (data) {
        return this.http.get(this.appSettings.getApi() + "/api/asset/" + data, {
            headers: new _angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpHeaders"]({
                'Content-Type': 'application/json',
                Authorization: localStorage.getItem('token')
            })
        });
    };
    TicketService = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
            providedIn: 'root'
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpClient"],
            src_app_conatants_MainAppSetting__WEBPACK_IMPORTED_MODULE_3__["MainAppSetting"]])
    ], TicketService);
    return TicketService;
}());



/***/ }),

/***/ "./src/app/Rentals Management/services/unit.service.ts":
/*!*************************************************************!*\
  !*** ./src/app/Rentals Management/services/unit.service.ts ***!
  \*************************************************************/
/*! exports provided: UnitService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "UnitService", function() { return UnitService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/fesm5/http.js");
/* harmony import */ var src_app_conatants_MainAppSetting__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/conatants/MainAppSetting */ "./src/app/conatants/MainAppSetting.ts");




var UnitService = /** @class */ (function () {
    function UnitService(http, appSettings) {
        this.http = http;
        this.appSettings = appSettings;
    }
    UnitService.prototype.getUnits = function (filterData) {
        console.log(filterData);
        return this.http.get(this.appSettings.getApi() + "/api/home?limit=10&searchText=" + filterData.searchText + "&skip=" + filterData.skip + "&status=active", {
            headers: new _angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpHeaders"]({
                'Content-Type': 'application/json',
                Authorization: localStorage.getItem('token')
            })
        });
    };
    UnitService = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
            providedIn: 'root'
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpClient"],
            src_app_conatants_MainAppSetting__WEBPACK_IMPORTED_MODULE_3__["MainAppSetting"]])
    ], UnitService);
    return UnitService;
}());



/***/ }),

/***/ "./src/app/Rentals Management/services/utils.service.ts":
/*!**************************************************************!*\
  !*** ./src/app/Rentals Management/services/utils.service.ts ***!
  \**************************************************************/
/*! exports provided: Utils */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "Utils", function() { return Utils; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/fesm5/http.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var src_app_conatants_MainAppSetting__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/conatants/MainAppSetting */ "./src/app/conatants/MainAppSetting.ts");




var Utils = /** @class */ (function () {
    function Utils(http, appSettings) {
        this.http = http;
        this.appSettings = appSettings;
        this.LoadPage = new _angular_core__WEBPACK_IMPORTED_MODULE_2__["EventEmitter"]();
        this.cartitem = [];
        this.cartdata = 0;
    }
    Utils.prototype.LoadPageOnrouteChange = function () {
        console.log('ios working and verifyit');
        this.LoadPage.next(true);
    };
    Utils = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_2__["Injectable"])({
            providedIn: 'root'
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpClient"],
            src_app_conatants_MainAppSetting__WEBPACK_IMPORTED_MODULE_3__["MainAppSetting"]])
    ], Utils);
    return Utils;
}());



/***/ }),

/***/ "./src/app/app-routing.module.ts":
/*!***************************************!*\
  !*** ./src/app/app-routing.module.ts ***!
  \***************************************/
/*! exports provided: AppRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AppRoutingModule", function() { return AppRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");



var routes = [
    {
        path: '',
        redirectTo: 'verifyit-dashboard',
        pathMatch: 'full'
    },
    // { path: 'building-management', loadChildren: '../app/Building-Management/building-management.module#BuildingManagementModule' },
    { path: 'login', loadChildren: '../app/login/login.module#LoginPageModule' },
    // { path: 'posts', loadChildren: '../app/login/login.module#LoginPageModule' },
    // { path: 'posts/:slug', loadChildren: '../app/login/login.module#LoginPageModule' },
    { path: 'verifyit-dashboard', loadChildren: '../app/Rentals Management/pages/verifyitdashboard/verifyitdashboard.module#VerifyitDashboardPageModule' },
    { path: 'rentals', loadChildren: '../app/Rentals Management/rental-management.module#RentalsManagementModule' },
];
var AppRoutingModule = /** @class */ (function () {
    function AppRoutingModule() {
    }
    AppRoutingModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            imports: [
                _angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forRoot(routes, { preloadingStrategy: _angular_router__WEBPACK_IMPORTED_MODULE_2__["PreloadAllModules"], onSameUrlNavigation: 'reload' })
            ],
            exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]]
        })
    ], AppRoutingModule);
    return AppRoutingModule;
}());



/***/ }),

/***/ "./src/app/app.component.html":
/*!************************************!*\
  !*** ./src/app/app.component.html ***!
  \************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ion-app color=\"primary\">\r\n  <ion-split-pane>\r\n    <ion-menu style=\"--width: 220px;\" side=\"start\">\r\n      <ion-header>\r\n        <ion-toolbar color=\"primary\">\r\n          <ion-menu-toggle>\r\n            <ion-title style=\"margin-bottom: 50px;\" class=\"\">\r\n\r\n              <ion-col size=\"4\">\r\n                <img style=\"width: 50px;\r\n              height: 50px;\r\n              margin-top: 20px;\r\n              border-radius: 50px;\" src=\"assets/imgs/nailalogo.jpg\" alt=\"assets/imgs/taps.png\">\r\n              </ion-col>\r\n              <!-- <ion-col style=\"vertical-align: super;\" size=\"8\">\r\n\r\n                <ion-label>Naila</ion-label>\r\n              </ion-col> -->\r\n\r\n              <!-- <p class=\"font-14 margin-bottom-3 font-weight-600\">{{appPages.name}}</p>\r\n              <p class=\"margin-top-0 font-14 font-weight-600\">{{appPages.phoneNumber}}</p> -->\r\n            </ion-title>\r\n          </ion-menu-toggle>\r\n        </ion-toolbar>\r\n      </ion-header>\r\n      <ion-content *ngIf=\"canNFC\" style=\"--background: black;\r\n      --color: white;\r\n      --border-width: 0 0 0px 0;\">\r\n        <ion-list style=\"background:black;\">\r\n          <ion-item style=\"--background: black;\r\n        color: white;\">\r\n            <ion-label *ngIf=\"!username\" (click)=\"navigatetologinpage()\">\r\n              Login/Signup\r\n            </ion-label>\r\n            <ion-label *ngIf=\"username\" >\r\n              Hi {{username}}!\r\n            </ion-label>\r\n          </ion-item>\r\n        </ion-list>\r\n        <ion-list *ngIf=\"userrole=='1'\" class=\"padding-bottom-0 padding-top-0 \">\r\n          <ion-menu-toggle auto-hide=\"false\" *ngFor=\"let p of appPages.pages\">\r\n            <ion-item *ngIf=\"(p.userrole!='2' || p.userrole=='default') && userrole=='1' \" style=\"--background: black;\r\n            --color: white;\r\n            --border-width: 0 0 0px 0;\" lines=\"full\" (click)=\"routeForword(p.url)\"\r\n              (click)=\"toggleRole(p.userrole,p.title)\">\r\n              <img class=\"icon-25 margin-bottom-10\" *ngIf=\"p.src\" [src]=\"p.src\">\r\n              <ion-label [ngClass]=\"{marginTop5: p.src?true:false}\">\r\n                {{translate.instant(p.title)}}\r\n              </ion-label>\r\n            </ion-item>\r\n\r\n\r\n            <!-- <ion-item *ngIf=\"p.title == 'Log Out' &&  p.userrole!=(userrole || this.utils.userType)\" style=\"--background: black;\r\n            --color: white;\r\n            --border-width: 0 0 0px 0;\" lines=\"full\" (click)=\"logOut()\">\r\n              <img class=\"icon-25 margin-bottom-10\" *ngIf=\"p.src\" [src]=\"p.src\">\r\n              <ion-label [ngClass]=\"{marginTop5: p.src?true:false}\">\r\n                {{translate.instant(p.title)}}\r\n              </ion-label>\r\n            </ion-item> -->\r\n          </ion-menu-toggle>\r\n\r\n\r\n\r\n          <!-- <ion-menu-toggle>\r\n            <ion-item style=\"--background: black;\r\n            --color: white;\r\n            --border-width: 0 0 0px 0;\" lines=\"full\" (click)=\"logOut()\">\r\n              <img class=\"icon-25 margin-bottom-10\" [src]=\"appPages.logout.src\">\r\n              <ion-label class=\"marginTop5\">\r\n                {{translate.instant(appPages.logout.title)}}\r\n              </ion-label>\r\n            </ion-item>\r\n          </ion-menu-toggle> -->\r\n        </ion-list>\r\n\r\n        <ion-list *ngIf=\"userrole=='2'\" class=\"padding-bottom-0 padding-top-0 \">\r\n          <ion-menu-toggle auto-hide=\"false\" *ngFor=\"let p of appPages.pages\">\r\n            \r\n            <ion-item *ngIf=\"p.userrole=='2' || p.userrole=='default'\" style=\"--background: black;\r\n            --color: white;\r\n            --border-width: 0 0 0px 0;\" lines=\"full\" (click)=\"routeForword(p.url)\"\r\n              (click)=\"toggleRole(p.userrole,p.title)\">\r\n              <img class=\"icon-25 margin-bottom-10\" *ngIf=\"p.src\" [src]=\"p.src\">\r\n              <ion-label [ngClass]=\"{marginTop5: p.src?true:false}\">\r\n                {{translate.instant(p.title)}} \r\n              </ion-label>\r\n            </ion-item>\r\n\r\n\r\n            <!-- <ion-item *ngIf=\"p.title == 'Log Out' &&  p.userrole!=(userrole || this.utils.userType)\" style=\"--background: black;\r\n            --color: white;\r\n            --border-width: 0 0 0px 0;\" lines=\"full\" (click)=\"logOut()\">\r\n              <img class=\"icon-25 margin-bottom-10\" *ngIf=\"p.src\" [src]=\"p.src\">\r\n              <ion-label [ngClass]=\"{marginTop5: p.src?true:false}\">\r\n                {{translate.instant(p.title)}}\r\n              </ion-label>\r\n            </ion-item> -->\r\n          </ion-menu-toggle>\r\n\r\n\r\n\r\n          <!-- <ion-menu-toggle>\r\n            <ion-item style=\"--background: black;\r\n            --color: white;\r\n            --border-width: 0 0 0px 0;\" lines=\"full\" (click)=\"logOut()\">\r\n              <img class=\"icon-25 margin-bottom-10\" [src]=\"appPages.logout.src\">\r\n              <ion-label class=\"marginTop5\">\r\n                {{translate.instant(appPages.logout.title)}}\r\n              </ion-label>\r\n            </ion-item>\r\n          </ion-menu-toggle> -->\r\n        </ion-list>\r\n      </ion-content>\r\n\r\n\r\n\r\n      <ion-content *ngIf=\"!canNFC\" style=\"--background: black;\r\n      --color: white;\r\n      --border-width: 0 0 0px 0;\">\r\n        <ion-list style=\"background:black;\">\r\n          <ion-item style=\"--background: black;\r\n        color: white;\">\r\n            <ion-label *ngIf=\"!username\" (click)=\"navigatetologinpage()\">\r\n              Login/Signup\r\n            </ion-label>\r\n            <ion-label *ngIf=\"username\" >\r\n              Hi {{username}}!\r\n            </ion-label>\r\n          </ion-item>\r\n        </ion-list>\r\n        <ion-list *ngIf=\"userrole=='1'\" class=\"padding-bottom-0 padding-top-0 \">\r\n          <ion-menu-toggle auto-hide=\"false\" *ngFor=\"let p of appPages2.pages\">\r\n            <ion-item *ngIf=\"(p.userrole!='2' || p.userrole=='default') && userrole=='1' \" style=\"--background: black;\r\n            --color: white;\r\n            --border-width: 0 0 0px 0;\" lines=\"full\" (click)=\"routeForword(p.url)\"\r\n              (click)=\"toggleRole(p.userrole,p.title)\">\r\n              <img class=\"icon-25 margin-bottom-10\" *ngIf=\"p.src\" [src]=\"p.src\">\r\n              <ion-label [ngClass]=\"{marginTop5: p.src?true:false}\">\r\n                {{translate.instant(p.title)}}\r\n              </ion-label>\r\n            </ion-item>\r\n\r\n\r\n            <!-- <ion-item *ngIf=\"p.title == 'Log Out' &&  p.userrole!=(userrole || this.utils.userType)\" style=\"--background: black;\r\n            --color: white;\r\n            --border-width: 0 0 0px 0;\" lines=\"full\" (click)=\"logOut()\">\r\n              <img class=\"icon-25 margin-bottom-10\" *ngIf=\"p.src\" [src]=\"p.src\">\r\n              <ion-label [ngClass]=\"{marginTop5: p.src?true:false}\">\r\n                {{translate.instant(p.title)}}\r\n              </ion-label>\r\n            </ion-item> -->\r\n          </ion-menu-toggle>\r\n\r\n\r\n\r\n          <!-- <ion-menu-toggle>\r\n            <ion-item style=\"--background: black;\r\n            --color: white;\r\n            --border-width: 0 0 0px 0;\" lines=\"full\" (click)=\"logOut()\">\r\n              <img class=\"icon-25 margin-bottom-10\" [src]=\"appPages.logout.src\">\r\n              <ion-label class=\"marginTop5\">\r\n                {{translate.instant(appPages.logout.title)}}\r\n              </ion-label>\r\n            </ion-item>\r\n          </ion-menu-toggle> -->\r\n        </ion-list>\r\n\r\n        <ion-list *ngIf=\"userrole=='2'\" class=\"padding-bottom-0 padding-top-0 \">\r\n          <ion-menu-toggle auto-hide=\"false\" *ngFor=\"let p of appPages2.pages\">\r\n            \r\n            <ion-item *ngIf=\"p.userrole=='2' || p.userrole=='default'\" style=\"--background: black;\r\n            --color: white;\r\n            --border-width: 0 0 0px 0;\" lines=\"full\" (click)=\"routeForword(p.url)\"\r\n              (click)=\"toggleRole(p.userrole,p.title)\">\r\n              <img class=\"icon-25 margin-bottom-10\" *ngIf=\"p.src\" [src]=\"p.src\">\r\n              <ion-label [ngClass]=\"{marginTop5: p.src?true:false}\">\r\n                {{translate.instant(p.title)}} \r\n              </ion-label>\r\n            </ion-item>\r\n\r\n\r\n            <!-- <ion-item *ngIf=\"p.title == 'Log Out' &&  p.userrole!=(userrole || this.utils.userType)\" style=\"--background: black;\r\n            --color: white;\r\n            --border-width: 0 0 0px 0;\" lines=\"full\" (click)=\"logOut()\">\r\n              <img class=\"icon-25 margin-bottom-10\" *ngIf=\"p.src\" [src]=\"p.src\">\r\n              <ion-label [ngClass]=\"{marginTop5: p.src?true:false}\">\r\n                {{translate.instant(p.title)}}\r\n              </ion-label>\r\n            </ion-item> -->\r\n          </ion-menu-toggle>\r\n\r\n\r\n\r\n          <!-- <ion-menu-toggle>\r\n            <ion-item style=\"--background: black;\r\n            --color: white;\r\n            --border-width: 0 0 0px 0;\" lines=\"full\" (click)=\"logOut()\">\r\n              <img class=\"icon-25 margin-bottom-10\" [src]=\"appPages.logout.src\">\r\n              <ion-label class=\"marginTop5\">\r\n                {{translate.instant(appPages.logout.title)}}\r\n              </ion-label>\r\n            </ion-item>\r\n          </ion-menu-toggle> -->\r\n        </ion-list>\r\n      </ion-content>\r\n\r\n\r\n    </ion-menu>\r\n    <ion-router-outlet main></ion-router-outlet>\r\n  </ion-split-pane>\r\n</ion-app>"

/***/ }),

/***/ "./src/app/app.component.ts":
/*!**********************************!*\
  !*** ./src/app/app.component.ts ***!
  \**********************************/
/*! exports provided: AppComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AppComponent", function() { return AppComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _ionic_native_splash_screen_ngx__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ionic-native/splash-screen/ngx */ "./node_modules/@ionic-native/splash-screen/ngx/index.js");
/* harmony import */ var _ionic_native_status_bar_ngx__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic-native/status-bar/ngx */ "./node_modules/@ionic-native/status-bar/ngx/index.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ngx-translate/core */ "./node_modules/@ngx-translate/core/fesm5/ngx-translate-core.js");
/* harmony import */ var _common_services_storage_service_service__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./common-services/storage-service.service */ "./src/app/common-services/storage-service.service.ts");
/* harmony import */ var _ionic_storage__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @ionic/storage */ "./node_modules/@ionic/storage/fesm5/ionic-storage.js");
/* harmony import */ var _Rentals_Management_services_rentals_user_service__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ./Rentals Management/services/rentals-user.service */ "./src/app/Rentals Management/services/rentals-user.service.ts");
/* harmony import */ var _common_services_alert_service_service__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ./common-services/alert-service.service */ "./src/app/common-services/alert-service.service.ts");
/* harmony import */ var _Building_Management_services_building_user_service__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ./Building-Management/services/building-user.service */ "./src/app/Building-Management/services/building-user.service.ts");
/* harmony import */ var _Rentals_Management_services_utils_service__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ./Rentals Management/services/utils.service */ "./src/app/Rentals Management/services/utils.service.ts");
/* harmony import */ var _ionic_native_nfc_ngx__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! @ionic-native/nfc/ngx */ "./node_modules/@ionic-native/nfc/ngx/index.js");
/* harmony import */ var _ionic_native_deeplinks_ngx__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! @ionic-native/deeplinks/ngx */ "./node_modules/@ionic-native/deeplinks/ngx/index.js");
/* harmony import */ var _Rentals_Management_services_naila_service__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! ./Rentals Management/services/naila.service */ "./src/app/Rentals Management/services/naila.service.ts");
















var AppComponent = /** @class */ (function () {
    // options: PushOptions = {
    //   android: {},
    //   ios: {
    //   },
    // }
    // pushObject: PushObject = this.push.init(this.options);
    function AppComponent(zone, deeplinks, nfc, ndef, platform, splashScreen, statusBar, router, navCtrl, translate, storageService, storage, loadingCtrl, rentalsUserService, alertService, buildingUserService, utils, verifyitservice) {
        this.zone = zone;
        this.deeplinks = deeplinks;
        this.nfc = nfc;
        this.ndef = ndef;
        this.platform = platform;
        this.splashScreen = splashScreen;
        this.statusBar = statusBar;
        this.router = router;
        this.navCtrl = navCtrl;
        this.translate = translate;
        this.storageService = storageService;
        this.storage = storage;
        this.loadingCtrl = loadingCtrl;
        this.rentalsUserService = rentalsUserService;
        this.alertService = alertService;
        this.buildingUserService = buildingUserService;
        this.utils = utils;
        this.verifyitservice = verifyitservice;
        this.appPages = {
            name: "",
            phoneNumber: localStorage.getItem("phoneNumber"),
            pages: [
                //     {
                //   title: "Home",
                //   url: `verifyit-dashboard`,
                //   src: "/assets/imgs/home.svg",
                //   userrole: 'default'
                // },
                {
                    title: "Read NFC/QR",
                    url: "verifyit-dashboard",
                    src: "/assets/imgs/whitenfc.png",
                    userrole: 'default'
                },
                {
                    title: "Write NFC/QR",
                    url: "verifyit-dashboard",
                    src: "/assets/imgs/whitenfc.png",
                    userrole: '2'
                },
                // {
                //   title: "Read QR",
                //   url: `verifyit-dashboard`,
                //   src: "/assets/imgs/whiteqrcode.jpg",
                //   userrole: window.localStorage.getItem("userType")
                // },
                // {
                //   title: "Write QR",
                //   url: `verifyit-dashboard`,
                //   src: "/assets/imgs/whiteqrcode.jpg",
                //   userrole: window.localStorage.getItem("userType")
                // },
                {
                    title: "Account",
                    url: "verifyit-account",
                    src: "assets/imgs/profile1.svg",
                    userrole: "default"
                }
                // {
                //   title: 'Tickets',
                // url: `rentals-naila-ticket-page`,
                //   src: '/assets/imgs/business.svg'
                // },
                // {
                //   title: 'app-component.contact-us',
                // url: `-contact-us`,
                //   src: '/assets/icon/phone.png'
                // },
                // {
                //   title: 'Project ',
                // url: `-my-data-project`,
                //   src: '/assets/icon/phone.png'
                // },
                // {
                //   title: 'Bookings',
                //   url: `rentals-naila-beaut-booking-page`,
                //   src: '/assets/imgs/bookings.svg',
                //   userrole:'Beautician'
                // },
                // {
                //   title: 'Attendance',
                //   url: `rentals-naila-beaut-attendance-page`,
                //   src: '/assets/imgs/business.svg',
                //   userrole:'Beautician'
                // },
                // {
                //   title: 'Log Out',
                //   // url: `rentals-naila-cart-page`,
                //   src: '/assets/imgs/logoutsearch.svg'
                // }
            ]
        };
        this.appPages2 = {
            name: "",
            phoneNumber: localStorage.getItem("phoneNumber"),
            pages: [
                //     {
                //   title: "Home",
                //   url: `verifyit-dashboard`,
                //   src: "/assets/imgs/home.svg",
                //   userrole: 'default'
                // },
                {
                    title: "Read QR",
                    url: "verifyit-dashboard",
                    src: "/assets/imgs/whiteqrcode.png",
                    userrole: 'default'
                },
                {
                    title: "Write QR",
                    url: "verifyit-dashboard",
                    src: "/assets/imgs/whiteqrcode.png",
                    userrole: '2'
                },
                // {
                //   title: "Read QR",
                //   url: `verifyit-dashboard`,
                //   src: "/assets/imgs/whiteqrcode.jpg",
                //   userrole: window.localStorage.getItem("userType")
                // },
                // {
                //   title: "Write QR",
                //   url: `verifyit-dashboard`,
                //   src: "/assets/imgs/whiteqrcode.jpg",
                //   userrole: window.localStorage.getItem("userType")
                // },
                {
                    title: "Account",
                    url: "verifyit-account",
                    src: "assets/imgs/profile1.svg",
                    userrole: "default"
                }
                // {
                //   title: 'Tickets',
                // url: `rentals-naila-ticket-page`,
                //   src: '/assets/imgs/business.svg'
                // },
                // {
                //   title: 'app-component.contact-us',
                // url: `-contact-us`,
                //   src: '/assets/icon/phone.png'
                // },
                // {
                //   title: 'Project ',
                // url: `-my-data-project`,
                //   src: '/assets/icon/phone.png'
                // },
                // {
                //   title: 'Bookings',
                //   url: `rentals-naila-beaut-booking-page`,
                //   src: '/assets/imgs/bookings.svg',
                //   userrole:'Beautician'
                // },
                // {
                //   title: 'Attendance',
                //   url: `rentals-naila-beaut-attendance-page`,
                //   src: '/assets/imgs/business.svg',
                //   userrole:'Beautician'
                // },
                // {
                //   title: 'Log Out',
                //   // url: `rentals-naila-cart-page`,
                //   src: '/assets/imgs/logoutsearch.svg'
                // }
            ]
        };
        this.username = '';
        // ionViewWillEnter(){
        //   this.toggleRole('');
        // }
        this.populatemenu = true;
        this.p = {
            userrole: ""
        };
        this.canNFC = false;
    }
    AppComponent.prototype.ngOnInit = function () {
        var _this = this;
        this.utils.LoadPage.subscribe(function (data) {
            if (window.localStorage.getItem("userType")) {
                _this.userrole = window.localStorage.getItem("userType");
                _this.username = window.localStorage.getItem("name");
                _this.showMenulist = true;
                _this.ionViewDidLoad();
            }
            else {
                _this.showMenulist = false;
                _this.ionViewDidLoad();
            }
        });
        if (!window.localStorage.getItem("userType")) {
            this.userrole = window.localStorage.setItem("userType", "1");
        }
        this.username = window.localStorage.getItem("name");
        this.userrole = window.localStorage.getItem("userType");
        this.initializeApp();
    };
    AppComponent.prototype.toggleRole = function (role, title) {
        // this.populatemenu=!this.populatemenu
        if (role == "2") {
            this.p.userrole = "1";
        }
        else if (role == "1") {
            this.p.userrole = "2";
        }
        // if (title != "Account") {
        //   this.utils.LoadPageOnrouteChange();
        // }else
        if (title == 'Read NFC/QR') {
            debugger;
            this.utils.menuTitle = 'Read NFC/QR';
            this.utils.LoadPageOnrouteChange();
        }
        else if (title == 'Write NFC/QR') {
            this.utils.menuTitle = 'Write NFC/QR';
            this.utils.LoadPageOnrouteChange();
        }
        else if (title == 'Write QR') {
            this.utils.menuTitle = 'Write NFC/QR';
            this.utils.LoadPageOnrouteChange();
        }
        else if (title == 'Read QR') {
            debugger;
            this.utils.menuTitle = 'Read NFC/QR';
            this.utils.LoadPageOnrouteChange();
        }
    };
    AppComponent.prototype.ionViewDidLoad = function () {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function () {
            var _this = this;
            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                this.platform.ready().then(function () {
                    _this.nfc
                        .enabled()
                        .then(function (resolve) {
                        _this.canNFC = true;
                    })
                        .catch(function (reject) {
                        _this.canNFC = false;
                    });
                });
                return [2 /*return*/];
            });
        });
    };
    AppComponent.prototype.presentLoading = function () {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function () {
            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.loadingCtrl
                            .create({
                            spinner: "lines"
                        })
                            .then(function (loading) {
                            loading.present();
                        })];
                    case 1:
                        _a.sent();
                        return [2 /*return*/];
                }
            });
        });
    };
    AppComponent.prototype.routeForword = function (url) {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function () {
            var _this = this;
            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.storageService.getDatafromIonicStorage("appSrc").then(function (val) {
                            _this.appSrc = val;
                            console.log("-----------------", val);
                            _this.router.navigateByUrl("" + url);
                            // this.router.navigateByUrl(`${this.appSrc}${url}`)
                        })];
                    case 1:
                        _a.sent();
                        return [2 /*return*/];
                }
            });
        });
    };
    AppComponent.prototype.initializeApp = function () {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function () {
            var isLoggedIn;
            var _this = this;
            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                switch (_a.label) {
                    case 0:
                        if (!window.localStorage.getItem('token')) {
                            window.localStorage.setItem('token', '');
                            this.storageService.storeDataToIonicStorage('token', '');
                        }
                        return [4 /*yield*/, this.ionViewDidLoad()];
                    case 1:
                        _a.sent();
                        this.platform.ready().then(function () { return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](_this, void 0, void 0, function () {
                            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                                this.setupDeeplinks();
                                this.generateToken();
                                // this.setupDeeplinks();
                                // if (this.platform.is('ios')) {
                                //   console.log('trueeeeeeeeeeeeeee====================================')
                                //   wkWebView.injectCookie('http://www.nowverifyit.com/');
                                //   console.log('trueeeeeeeeeeeeeee====================================')
                                // }
                                this.statusBar.styleLightContent();
                                this.statusBar.backgroundColorByHexString("#ffffff");
                                this._initTranslate();
                                this.splashScreen.hide();
                                this.statusBar.styleDefault();
                                this.redirectToHomeOrLogin(isLoggedIn);
                                return [2 /*return*/];
                            });
                        }); });
                        return [2 /*return*/];
                }
            });
        });
    };
    AppComponent.prototype.redirectToHomeOrLogin = function (isLoggedIn) {
        window.localStorage.getItem("uid");
        var registereduser = window.localStorage.getItem("registereduser");
        if (window.localStorage.getItem("user_type") == "Beautician") {
            registereduser == "true"
                ? this.navCtrl.navigateRoot("/rentals-naila-beaut-booking-page")
                : this.navCtrl.navigateRoot("/login");
        }
        else if (window.localStorage.getItem("user_type") == "Customer") {
            registereduser == "true"
                ? this.navCtrl.navigateRoot("/rentals-naila-search-page")
                : this.navCtrl.navigateRoot("/login");
        }
        if (window.localStorage.getItem("cartitem") &&
            window.localStorage.getItem("cartitemcount")) {
            this.utils.cartitem = JSON.parse(window.localStorage.getItem("cartitem"));
            this.utils.cartdata = window.localStorage.getItem("cartitemcount");
        }
    };
    // logout() {
    //   window.localStorage.clear()
    //   this.storage.clear()
    //   this.router.navigateByUrl('/login')
    // }
    AppComponent.prototype.logOut = function () {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function () {
            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.presentLoading()];
                    case 1:
                        _a.sent();
                        window.localStorage.clear();
                        this.router.navigateByUrl("/login");
                        return [4 /*yield*/, this.loadingCtrl.dismiss()];
                    case 2:
                        _a.sent();
                        return [2 /*return*/];
                }
            });
        });
    };
    AppComponent.prototype.updateUser = function (val, data) {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function () {
            var _this = this;
            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                if (val == "rentals") {
                    this.rentalsUserService.updateUser(data).subscribe(function (data) { return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](_this, void 0, void 0, function () {
                        return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                            switch (_a.label) {
                                case 0: return [4 /*yield*/, this.loadingCtrl.dismiss()];
                                case 1:
                                    _a.sent();
                                    window.localStorage.clear();
                                    return [4 /*yield*/, this.storage.clear()];
                                case 2:
                                    _a.sent();
                                    this.navCtrl.navigateRoot("/login");
                                    return [2 /*return*/];
                            }
                        });
                    }); }, function (err) { return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](_this, void 0, void 0, function () {
                        return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                            switch (_a.label) {
                                case 0: return [4 /*yield*/, this.loadingCtrl.dismiss()];
                                case 1:
                                    _a.sent();
                                    this.alertService.presentAlert("", "Error while logging out");
                                    return [2 /*return*/];
                            }
                        });
                    }); });
                }
                else if (val == "building-management") {
                    this.buildingUserService.updateUser(data).subscribe(function (data) { return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](_this, void 0, void 0, function () {
                        return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                            switch (_a.label) {
                                case 0: return [4 /*yield*/, this.loadingCtrl.dismiss()];
                                case 1:
                                    _a.sent();
                                    window.localStorage.clear();
                                    return [4 /*yield*/, this.storage.clear()];
                                case 2:
                                    _a.sent();
                                    this.navCtrl.navigateRoot("/login");
                                    return [2 /*return*/];
                            }
                        });
                    }); }, function (err) { return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](_this, void 0, void 0, function () {
                        return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                            switch (_a.label) {
                                case 0: return [4 /*yield*/, this.loadingCtrl.dismiss()];
                                case 1:
                                    _a.sent();
                                    this.alertService.presentAlert("", "Error while logging out");
                                    return [2 /*return*/];
                            }
                        });
                    }); });
                }
                return [2 /*return*/];
            });
        });
    };
    AppComponent.prototype._initTranslate = function () {
        this.translate.setDefaultLang("en");
        this.translate.use("en"); // Set your language here
    };
    AppComponent.prototype.navigatetologinpage = function () {
        this.router.navigateByUrl("/login");
    };
    AppComponent.prototype.setupDeeplinks = function () {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function () {
            var _this = this;
            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                this.deeplinks.route('/').subscribe(function (match) {
                    console.log('Successfully matched route', JSON.stringify(match));
                    console.log("=======================>");
                    console.log(match.$args);
                    console.log("=======================>");
                    // Create our internal Router path by hand
                    var internalPath = "/" + match.$route + "/" + match.$args['slug'];
                    // Run the navigation in the Angular zone
                    _this.zone.run(function () {
                        _this.router.navigateByUrl(internalPath);
                    });
                }, function (nomatch) {
                    // nomatch.$link - the full link data
                    console.error("Got a deeplink that didn't match", JSON.stringify(nomatch));
                });
                return [2 /*return*/];
            });
        });
    };
    AppComponent.prototype.ngAfterViewInit = function () {
        var _this = this;
        this.platform.ready().then(function () { return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](_this, void 0, void 0, function () {
            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                return [2 /*return*/];
            });
        }); });
    };
    // private async initDeepLinking(): Promise<void> {
    //   if (this.platform.is('cordova')) {
    //     await this.initDeepLinkingBranchio();
    //   } else {
    //     await this.initDeepLinkingWeb();
    //   }
    // }
    // private async initDeepLinkingWeb(): Promise<void> {
    //   const myparam: string =
    //     this.platform.getQueryParam('$myparam') ||
    //     this.platform.getQueryParam('myparam') ||
    //     this.platform.getQueryParam('%24myparam');
    //   console.log('Parameter', myparam);
    // }
    // private async initDeepLinkingBranchio(): Promise<void> {
    //   try {
    //     const branchIo = window['Branch'];
    //     if (branchIo) {
    //       const data: DeeplinkMatch =
    //         await branchIo.initSession();
    //       if (data.$myparam !== undefined) {
    //         console.log('Parameter', data.$myparam);
    //         this.router.navigateByUrl('/verifyit-account')
    //       }
    //     }
    //   } catch (err) {
    //     console.error(err);
    //   }
    // }
    AppComponent.prototype.generateToken = function () {
        var _this = this;
        var token = (window.localStorage.getItem('token'));
        this.verifyitservice.genToken().subscribe(function (data) { return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](_this, void 0, void 0, function () {
            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                debugger;
                if (!token.length) {
                    window.localStorage.setItem('token', data.data.token);
                }
                return [2 /*return*/];
            });
        }); }, function (err) { return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](_this, void 0, void 0, function () {
            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.loadingCtrl.dismiss()];
                    case 1:
                        _a.sent();
                        this.alertService.presentAlert("", "Error while logging out");
                        return [2 /*return*/];
                }
            });
        }); });
    };
    AppComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: "app-root",
            template: __webpack_require__(/*! ./app.component.html */ "./src/app/app.component.html")
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgZone"],
            _ionic_native_deeplinks_ngx__WEBPACK_IMPORTED_MODULE_14__["Deeplinks"],
            _ionic_native_nfc_ngx__WEBPACK_IMPORTED_MODULE_13__["NFC"],
            _ionic_native_nfc_ngx__WEBPACK_IMPORTED_MODULE_13__["Ndef"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["Platform"],
            _ionic_native_splash_screen_ngx__WEBPACK_IMPORTED_MODULE_3__["SplashScreen"],
            _ionic_native_status_bar_ngx__WEBPACK_IMPORTED_MODULE_4__["StatusBar"],
            _angular_router__WEBPACK_IMPORTED_MODULE_5__["Router"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["NavController"],
            _ngx_translate_core__WEBPACK_IMPORTED_MODULE_6__["TranslateService"],
            _common_services_storage_service_service__WEBPACK_IMPORTED_MODULE_7__["StorageService"],
            _ionic_storage__WEBPACK_IMPORTED_MODULE_8__["Storage"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["LoadingController"],
            _Rentals_Management_services_rentals_user_service__WEBPACK_IMPORTED_MODULE_9__["RentalsUserService"],
            _common_services_alert_service_service__WEBPACK_IMPORTED_MODULE_10__["AlertServiceService"],
            _Building_Management_services_building_user_service__WEBPACK_IMPORTED_MODULE_11__["BuildingUserService"],
            _Rentals_Management_services_utils_service__WEBPACK_IMPORTED_MODULE_12__["Utils"],
            _Rentals_Management_services_naila_service__WEBPACK_IMPORTED_MODULE_15__["NailaService"]])
    ], AppComponent);
    return AppComponent;
}());



/***/ }),

/***/ "./src/app/app.module.ts":
/*!*******************************!*\
  !*** ./src/app/app.module.ts ***!
  \*******************************/
/*! exports provided: AppModule, HttpLoaderFactory */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AppModule", function() { return AppModule; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "HttpLoaderFactory", function() { return HttpLoaderFactory; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_platform_browser__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/platform-browser */ "./node_modules/@angular/platform-browser/fesm5/platform-browser.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _ionic_native_splash_screen_ngx__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic-native/splash-screen/ngx */ "./node_modules/@ionic-native/splash-screen/ngx/index.js");
/* harmony import */ var _ionic_native_status_bar_ngx__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic-native/status-bar/ngx */ "./node_modules/@ionic-native/status-bar/ngx/index.js");
/* harmony import */ var _app_component__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./app.component */ "./src/app/app.component.ts");
/* harmony import */ var _app_routing_module__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./app-routing.module */ "./src/app/app-routing.module.ts");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/fesm5/http.js");
/* harmony import */ var _ionic_native_social_sharing_ngx__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @ionic-native/social-sharing/ngx */ "./node_modules/@ionic-native/social-sharing/ngx/index.js");
/* harmony import */ var _ionic_native_file_transfer_ngx__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @ionic-native/file-transfer/ngx */ "./node_modules/@ionic-native/file-transfer/ngx/index.js");
/* harmony import */ var _ionic_native_push_ngx__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! @ionic-native/push/ngx */ "./node_modules/@ionic-native/push/ngx/index.js");
/* harmony import */ var _conatants_MainAppSetting__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! ./conatants/MainAppSetting */ "./src/app/conatants/MainAppSetting.ts");
/* harmony import */ var _Rentals_Management_rental_management_module__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! ./Rentals Management/rental-management.module */ "./src/app/Rentals Management/rental-management.module.ts");
/* harmony import */ var _ionic_native_ionic_webview_ngx__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! @ionic-native/ionic-webview/ngx */ "./node_modules/@ionic-native/ionic-webview/ngx/index.js");
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! @ngx-translate/core */ "./node_modules/@ngx-translate/core/fesm5/ngx-translate-core.js");
/* harmony import */ var _ngx_translate_http_loader__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! @ngx-translate/http-loader */ "./node_modules/@ngx-translate/http-loader/fesm5/ngx-translate-http-loader.js");
/* harmony import */ var _common_services_storage_service_service__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! ./common-services/storage-service.service */ "./src/app/common-services/storage-service.service.ts");
/* harmony import */ var _ionic_storage__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! @ionic/storage */ "./node_modules/@ionic/storage/fesm5/ionic-storage.js");
/* harmony import */ var _ionic_native_http_ngx__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(/*! @ionic-native/http/ngx */ "./node_modules/@ionic-native/http/ngx/index.js");
/* harmony import */ var _common_components_org_modal_org_modal_component__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(/*! ./common-components/org-modal/org-modal.component */ "./src/app/common-components/org-modal/org-modal.component.ts");
/* harmony import */ var _login_countrycodemodal_countrycodemodal_component__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(/*! ./login/countrycodemodal/countrycodemodal.component */ "./src/app/login/countrycodemodal/countrycodemodal.component.ts");
/* harmony import */ var _login_countrycodemodal_Filter_pipe__WEBPACK_IMPORTED_MODULE_23__ = __webpack_require__(/*! ./login/countrycodemodal/Filter.pipe */ "./src/app/login/countrycodemodal/Filter.pipe.ts");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_24__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var ngx_avatar__WEBPACK_IMPORTED_MODULE_25__ = __webpack_require__(/*! ngx-avatar */ "./node_modules/ngx-avatar/fesm5/ngx-avatar.js");
/* harmony import */ var _ionic_native_device_ngx__WEBPACK_IMPORTED_MODULE_26__ = __webpack_require__(/*! @ionic-native/device/ngx */ "./node_modules/@ionic-native/device/ngx/index.js");
/* harmony import */ var ngx_order_pipe__WEBPACK_IMPORTED_MODULE_27__ = __webpack_require__(/*! ngx-order-pipe */ "./node_modules/ngx-order-pipe/fesm2015/ngx-order-pipe.js");
/* harmony import */ var _common_components_picture_picture_component__WEBPACK_IMPORTED_MODULE_28__ = __webpack_require__(/*! ./common-components/picture/picture.component */ "./src/app/common-components/picture/picture.component.ts");
/* harmony import */ var _ionic_native_file_path_ngx__WEBPACK_IMPORTED_MODULE_29__ = __webpack_require__(/*! @ionic-native/file-path/ngx */ "./node_modules/@ionic-native/file-path/ngx/index.js");
/* harmony import */ var _Rentals_Management_modals_approvalpopup_approvalpopup_component__WEBPACK_IMPORTED_MODULE_30__ = __webpack_require__(/*! ./Rentals Management/modals/approvalpopup/approvalpopup.component */ "./src/app/Rentals Management/modals/approvalpopup/approvalpopup.component.ts");
/* harmony import */ var _ionic_native_nfc_ngx__WEBPACK_IMPORTED_MODULE_31__ = __webpack_require__(/*! @ionic-native/nfc/ngx */ "./node_modules/@ionic-native/nfc/ngx/index.js");
/* harmony import */ var _ionic_native_qr_scanner_ngx__WEBPACK_IMPORTED_MODULE_32__ = __webpack_require__(/*! @ionic-native/qr-scanner/ngx */ "./node_modules/@ionic-native/qr-scanner/ngx/index.js");
/* harmony import */ var _ionic_native_screenshot_ngx__WEBPACK_IMPORTED_MODULE_33__ = __webpack_require__(/*! @ionic-native/screenshot/ngx */ "./node_modules/@ionic-native/screenshot/ngx/index.js");
/* harmony import */ var _ionic_native_barcode_scanner_ngx__WEBPACK_IMPORTED_MODULE_34__ = __webpack_require__(/*! @ionic-native/barcode-scanner/ngx */ "./node_modules/@ionic-native/barcode-scanner/ngx/index.js");
/* harmony import */ var _ionic_native_deeplinks_ngx__WEBPACK_IMPORTED_MODULE_35__ = __webpack_require__(/*! @ionic-native/deeplinks/ngx */ "./node_modules/@ionic-native/deeplinks/ngx/index.js");
/* harmony import */ var _ionic_native_in_app_browser_ngx__WEBPACK_IMPORTED_MODULE_36__ = __webpack_require__(/*! @ionic-native/in-app-browser/ngx */ "./node_modules/@ionic-native/in-app-browser/ngx/index.js");
/* harmony import */ var _techiediaries_ngx_qrcode__WEBPACK_IMPORTED_MODULE_37__ = __webpack_require__(/*! @techiediaries/ngx-qrcode */ "./node_modules/@techiediaries/ngx-qrcode/fesm5/techiediaries-ngx-qrcode.js");
/* harmony import */ var _ionic_native_geolocation_ngx__WEBPACK_IMPORTED_MODULE_38__ = __webpack_require__(/*! @ionic-native/geolocation/ngx */ "./node_modules/@ionic-native/geolocation/ngx/index.js");
/* harmony import */ var _angular_service_worker__WEBPACK_IMPORTED_MODULE_39__ = __webpack_require__(/*! @angular/service-worker */ "./node_modules/@angular/service-worker/fesm5/service-worker.js");











// import { Camera } from '@ionic-native/camera/ngx';



// import { BuildingManagementModule } from './Building-Management/building-management.module';























// import { ApprovalpopupComponent } from '../../modals/approvalpopup/approvalpopup.component';



var AppModule = /** @class */ (function () {
    function AppModule() {
    }
    AppModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            declarations: [
                _app_component__WEBPACK_IMPORTED_MODULE_7__["AppComponent"],
                _common_components_org_modal_org_modal_component__WEBPACK_IMPORTED_MODULE_21__["OrgModalComponent"],
                _login_countrycodemodal_countrycodemodal_component__WEBPACK_IMPORTED_MODULE_22__["CountrycodemodalComponent"],
                _common_components_picture_picture_component__WEBPACK_IMPORTED_MODULE_28__["PictureComponent"],
                _login_countrycodemodal_Filter_pipe__WEBPACK_IMPORTED_MODULE_23__["FilterPipe"],
                _Rentals_Management_modals_approvalpopup_approvalpopup_component__WEBPACK_IMPORTED_MODULE_30__["ApprovalpopupComponent"]
            ],
            entryComponents: [_common_components_org_modal_org_modal_component__WEBPACK_IMPORTED_MODULE_21__["OrgModalComponent"], _login_countrycodemodal_countrycodemodal_component__WEBPACK_IMPORTED_MODULE_22__["CountrycodemodalComponent"], _common_components_picture_picture_component__WEBPACK_IMPORTED_MODULE_28__["PictureComponent"], _Rentals_Management_modals_approvalpopup_approvalpopup_component__WEBPACK_IMPORTED_MODULE_30__["ApprovalpopupComponent"]],
            imports: [
                _techiediaries_ngx_qrcode__WEBPACK_IMPORTED_MODULE_37__["NgxQRCodeModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_24__["FormsModule"],
                _angular_platform_browser__WEBPACK_IMPORTED_MODULE_2__["BrowserModule"],
                _angular_common_http__WEBPACK_IMPORTED_MODULE_9__["HttpClientModule"],
                ngx_avatar__WEBPACK_IMPORTED_MODULE_25__["AvatarModule"],
                _ionic_storage__WEBPACK_IMPORTED_MODULE_19__["IonicStorageModule"].forRoot(),
                _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"].forRoot({
                    rippleEffect: false,
                    mode: 'md'
                }),
                ngx_order_pipe__WEBPACK_IMPORTED_MODULE_27__["OrderModule"],
                _app_routing_module__WEBPACK_IMPORTED_MODULE_8__["AppRoutingModule"],
                // BuildingManagementModule,
                _Rentals_Management_rental_management_module__WEBPACK_IMPORTED_MODULE_14__["RentalsManagementModule"],
                _ionic_storage__WEBPACK_IMPORTED_MODULE_19__["IonicStorageModule"].forRoot(),
                _ngx_translate_core__WEBPACK_IMPORTED_MODULE_16__["TranslateModule"].forRoot({
                    loader: {
                        provide: _ngx_translate_core__WEBPACK_IMPORTED_MODULE_16__["TranslateLoader"],
                        useFactory: HttpLoaderFactory,
                        deps: [_angular_common_http__WEBPACK_IMPORTED_MODULE_9__["HttpClient"]]
                    }
                }),
                _angular_service_worker__WEBPACK_IMPORTED_MODULE_39__["ServiceWorkerModule"].register('ngsw-worker.js', { enabled: true })
            ],
            providers: [
                _ionic_native_in_app_browser_ngx__WEBPACK_IMPORTED_MODULE_36__["InAppBrowser"],
                _ionic_native_social_sharing_ngx__WEBPACK_IMPORTED_MODULE_10__["SocialSharing"],
                _ionic_native_deeplinks_ngx__WEBPACK_IMPORTED_MODULE_35__["Deeplinks"],
                _ionic_native_qr_scanner_ngx__WEBPACK_IMPORTED_MODULE_32__["QRScanner"],
                _ionic_native_screenshot_ngx__WEBPACK_IMPORTED_MODULE_33__["Screenshot"],
                _ionic_native_geolocation_ngx__WEBPACK_IMPORTED_MODULE_38__["Geolocation"],
                _ionic_native_barcode_scanner_ngx__WEBPACK_IMPORTED_MODULE_34__["BarcodeScanner"],
                _ionic_native_nfc_ngx__WEBPACK_IMPORTED_MODULE_31__["Ndef"],
                _ionic_native_status_bar_ngx__WEBPACK_IMPORTED_MODULE_6__["StatusBar"],
                _ionic_native_splash_screen_ngx__WEBPACK_IMPORTED_MODULE_5__["SplashScreen"],
                _conatants_MainAppSetting__WEBPACK_IMPORTED_MODULE_13__["MainAppSetting"],
                _ionic_native_file_transfer_ngx__WEBPACK_IMPORTED_MODULE_11__["FileTransfer"],
                _ionic_native_file_transfer_ngx__WEBPACK_IMPORTED_MODULE_11__["FileTransferObject"],
                _ionic_native_http_ngx__WEBPACK_IMPORTED_MODULE_20__["HTTP"],
                _ionic_native_nfc_ngx__WEBPACK_IMPORTED_MODULE_31__["NFC"],
                _common_services_storage_service_service__WEBPACK_IMPORTED_MODULE_18__["StorageService"],
                _ionic_native_push_ngx__WEBPACK_IMPORTED_MODULE_12__["Push"],
                _ionic_native_device_ngx__WEBPACK_IMPORTED_MODULE_26__["Device"],
                _ionic_native_ionic_webview_ngx__WEBPACK_IMPORTED_MODULE_15__["WebView"],
                _ionic_native_file_path_ngx__WEBPACK_IMPORTED_MODULE_29__["FilePath"],
                { provide: _angular_router__WEBPACK_IMPORTED_MODULE_3__["RouteReuseStrategy"], useClass: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicRouteStrategy"] }
            ],
            bootstrap: [_app_component__WEBPACK_IMPORTED_MODULE_7__["AppComponent"]]
        })
    ], AppModule);
    return AppModule;
}());

function HttpLoaderFactory(http) {
    return new _ngx_translate_http_loader__WEBPACK_IMPORTED_MODULE_17__["TranslateHttpLoader"](http, "./assets/i18n/", ".json");
}


/***/ }),

/***/ "./src/app/common-components/org-modal/org-modal.component.html":
/*!**********************************************************************!*\
  !*** ./src/app/common-components/org-modal/org-modal.component.html ***!
  \**********************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ion-header>\r\n  <ion-toolbar color=\"primary\">\r\n    <ion-title>Select {{title}}</ion-title>\r\n    <ion-buttons slot=\"end\">\r\n      <ion-button (click)=\"close('')\" class=\"font-weight-600 font-19\">\r\n        <ion-icon name=\"close\"></ion-icon>\r\n      </ion-button>\r\n    </ion-buttons>\r\n  </ion-toolbar>\r\n</ion-header>\r\n<ion-content class=\"grey-back\">\r\n  <div class=\"full-width grey-back max-available-height\">\r\n\r\n    <!-- <p class=\"grey-back font-weight-500 margin-top-0 margin-bottom-0 margin-left-10 padding-top-10\">\r\n      CHOOSE A MAINTENANCE ACTIVITY <sup style=\"font-size : 18px !important;\"> * </sup></p> -->\r\n    <ion-list class=\"margin-top-10 padding-bottom-0 grey-back padding-top-0\" *ngIf=\"modalType==='org'\">\r\n      <ion-radio-group>\r\n        <ion-item class=\"item-border\">\r\n          <ion-label>{{org.bm.organization.name}}</ion-label>\r\n          <ion-radio mode=\"ios\" value=\"org.bm.organization._id\" (click)=\"close(org.bm)\"></ion-radio>\r\n        </ion-item>\r\n        <ion-item class=\"item-border\">\r\n          <ion-label>{{org.rm.organization.name}}</ion-label>\r\n          <ion-radio mode=\"ios\" value=\"org.rm.organization._id\" (click)=\"close(org.rm)\"></ion-radio>\r\n        </ion-item>\r\n      </ion-radio-group>\r\n    </ion-list>\r\n\r\n    <ion-list class=\"margin-top-10 padding-bottom-0 padding-top-0 grey-back\" *ngIf=\"modalType=='project'\">\r\n\r\n      <ion-searchbar placeholder=\"Search\" [(ngModel)]=\"searchText\" class=\"padding-0 padding-bottom-10 grey-back\"\r\n        inputmode=\"text\" type=\"decimal\" (ionChange)=\"searchProject()\" [debounce]=\"250\"></ion-searchbar>\r\n      <p *ngIf=\"projects.length==0\" class=\"center-text margin-0 padding-top-20 grey-back\">No Projects Available</p>\r\n      <ion-radio-group *ngIf=\"projects.length>0\">\r\n        <div>\r\n          <ion-item class=\"item-border\" *ngFor=\"let project of projects\">\r\n            <ion-label>{{project.name}}</ion-label>\r\n            <ion-radio mode=\"ios\" (click)=\"close(project)\"></ion-radio>\r\n          </ion-item>\r\n        </div>\r\n      </ion-radio-group>\r\n    </ion-list>\r\n    <ion-list class=\"margin-top-10 padding-bottom-0 padding-top-0\" *ngIf=\"modalType=='door'\">\r\n      <ion-searchbar placeholder=\"Search\" [(ngModel)]=\"searchText\" class=\"padding-0 padding-bottom-10\" inputmode=\"text\"\r\n        type=\"decimal\" (ionChange)=\"searchDoor()\" [debounce]=\"250\"></ion-searchbar>\r\n      <p *ngIf=\"doors.length==0\" class=\"center-text margin-0 padding-top-20 grey-back\">No Doors Available</p>\r\n      <ion-radio-group *ngIf=\"doors.length>0\">\r\n        <div>\r\n          <ion-item class=\"item-border\" *ngFor=\"let door of doors\">\r\n            <ion-label>{{door.block}} - {{door.floor}} - {{door.door}}</ion-label>\r\n            <ion-radio mode=\"ios\" (click)=\"close(door)\"></ion-radio>\r\n          </ion-item>\r\n        </div>\r\n      </ion-radio-group>\r\n    </ion-list>\r\n  </div>\r\n</ion-content>"

/***/ }),

/***/ "./src/app/common-components/org-modal/org-modal.component.scss":
/*!**********************************************************************!*\
  !*** ./src/app/common-components/org-modal/org-modal.component.scss ***!
  \**********************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL2NvbW1vbi1jb21wb25lbnRzL29yZy1tb2RhbC9vcmctbW9kYWwuY29tcG9uZW50LnNjc3MifQ== */"

/***/ }),

/***/ "./src/app/common-components/org-modal/org-modal.component.ts":
/*!********************************************************************!*\
  !*** ./src/app/common-components/org-modal/org-modal.component.ts ***!
  \********************************************************************/
/*! exports provided: OrgModalComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "OrgModalComponent", function() { return OrgModalComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var src_app_common_services_search_properties_search_project_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/common-services/search-properties/search-project.service */ "./src/app/common-services/search-properties/search-project.service.ts");
/* harmony import */ var src_app_common_services_alert_service_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/common-services/alert-service.service */ "./src/app/common-services/alert-service.service.ts");





// import { AlertserviceService } from 'src/app/common-services/alert/alertservice.service';
// import { Mixpanel } from '@ionic-native/mixpanel/ngx';
var OrgModalComponent = /** @class */ (function () {
    function OrgModalComponent(modalCtrl, searchProjectService, alertService, loading) {
        this.modalCtrl = modalCtrl;
        this.searchProjectService = searchProjectService;
        this.alertService = alertService;
        this.loading = loading;
        this.searchText = '';
        this.isloggedin = 'false';
        this.searchType = 'project';
        this.doors = [];
        this.org = {
            type: "multi",
            bm: {
                organization: {
                    _id: "5943d4efa3d24b443f4008a2",
                    name: "Monk Realty Solutions Pvt Ltd",
                    status: "active",
                    logo: { "thumbnail": "https://thehousemonk-saas-ramaniyam.s3-ap-southeast-1.amazonaws.com/demoAccount/S3C/documents/bc9af9b4-905c-434a-8121-35201db9a0ab-VnV-TE4F_fiSyYRJSdDzPVyd_c.png" }
                },
                action: "register",
                moduleName: "BM"
            },
            // rm: {
            //   organization: {
            //     _id: "5943d4efa3d24b443f4008a2",
            //     name: "Monk Realty Solutions Pvt Ltd",
            //     status: "active",
            //     logo: { "thumbnail": "https://thehousemonk-saas-ramaniyam.s3-ap-southeast-1.amazonaws.com/demoAccount/S3C/documents/bc9af9b4-905c-434a-8121-35201db9a0ab-VnV-TE4F_fiSyYRJSdDzPVyd_c.png" }
            //   },
            //   action: "register",
            //   moduleName: "RM"
            // },
            rm: {
                types: ["tenant"],
                organization: {
                    _id: "5d67abae2fca1d4059d940cb",
                    name: "Grexter Living",
                    status: "active",
                    logo: { "thumbnail": "https://thehousemonk-saas-ramaniyam.s3-ap-southeast-1.amazonaws.com/GrexterLiving-5d67abae2fca1d4059d940cb/S3C/documents/a8485ad4-75b8-43b3-8b91-4690a97e6b11-prrmYkcRf9MhoxJKZ9z3y6kV_c.png" }
                },
                action: "login",
                moduleName: "RM"
            }
        };
        this.projects = [];
    }
    OrgModalComponent.prototype.ngOnInit = function () {
        if (this.modalType == 'org') {
            this.searchOrg();
            this.title = 'an organization';
        }
        else if (this.modalType == "project") {
            this.searchProject();
            this.title = 'a project';
        }
        else if (this.modalType == 'door') {
            this.title = 'a unit';
            this.searchDoor();
        }
    };
    OrgModalComponent.prototype.presentLoading = function () {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function () {
            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.loading.create({
                            spinner: 'lines'
                        }).then(function (loading) {
                            loading.present();
                        })];
                    case 1:
                        _a.sent();
                        return [2 /*return*/];
                }
            });
        });
    };
    OrgModalComponent.prototype.close = function (data) {
        if (data) {
            this.modalCtrl.dismiss(data, this.modalType);
        }
        else {
            this.modalCtrl.dismiss(null, null);
        }
    };
    OrgModalComponent.prototype.searchOrg = function () {
    };
    OrgModalComponent.prototype.searchDoor = function () {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function () {
            var _this = this;
            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.presentLoading()];
                    case 1:
                        _a.sent();
                        console.log('====================================');
                        console.log(this.searchText);
                        console.log('====================================');
                        this.searchProjectService.searchProject('listings', this.searchText, 0, 'project', this.id).subscribe(function (data) { return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](_this, void 0, void 0, function () {
                            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                                switch (_a.label) {
                                    case 0: return [4 /*yield*/, this.loading.dismiss()];
                                    case 1:
                                        _a.sent();
                                        this.doors = data.listingsWithHomes;
                                        return [2 /*return*/];
                                }
                            });
                        }); }, function (err) { return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](_this, void 0, void 0, function () {
                            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                                switch (_a.label) {
                                    case 0: return [4 /*yield*/, this.loading.dismiss()];
                                    case 1:
                                        _a.sent();
                                        // this.mixpanel.track('error while calling searchproject service', {
                                        //   type: 'listings',
                                        //   org: 'project',
                                        //   id: this.id
                                        // })
                                        this.alertService.presentAlert("", 'Something went wrong, Please try again later');
                                        return [2 /*return*/];
                                }
                            });
                        }); });
                        return [2 /*return*/];
                }
            });
        });
    };
    OrgModalComponent.prototype.searchProject = function () {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function () {
            var type, skip, org;
            var _this = this;
            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.presentLoading()];
                    case 1:
                        _a.sent();
                        console.log('====================================');
                        console.log(this.id);
                        console.log('====================================');
                        type = '';
                        skip = 0;
                        this.searchText;
                        this.searchProjectService.searchProject('projects', this.searchText, skip, 'organization', this.id).subscribe(function (data) { return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](_this, void 0, void 0, function () {
                            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                                switch (_a.label) {
                                    case 0: return [4 /*yield*/, this.loading.dismiss()];
                                    case 1:
                                        _a.sent();
                                        this.projects = data.data;
                                        return [2 /*return*/];
                                }
                            });
                        }); }, function (err) { return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](_this, void 0, void 0, function () {
                            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                                switch (_a.label) {
                                    case 0: return [4 /*yield*/, this.loading.dismiss()];
                                    case 1:
                                        _a.sent();
                                        this.alertService.presentAlert("", 'Something went wrong, Please try again later');
                                        return [2 /*return*/];
                                }
                            });
                        }); });
                        return [2 /*return*/];
                }
            });
        });
    };
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])(),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Object)
    ], OrgModalComponent.prototype, "modalType", void 0);
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])(),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Object)
    ], OrgModalComponent.prototype, "id", void 0);
    OrgModalComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-org-modal',
            template: __webpack_require__(/*! ./org-modal.component.html */ "./src/app/common-components/org-modal/org-modal.component.html"),
            styles: [__webpack_require__(/*! ./org-modal.component.scss */ "./src/app/common-components/org-modal/org-modal.component.scss")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_ionic_angular__WEBPACK_IMPORTED_MODULE_2__["ModalController"],
            src_app_common_services_search_properties_search_project_service__WEBPACK_IMPORTED_MODULE_3__["SearchProjectService"],
            src_app_common_services_alert_service_service__WEBPACK_IMPORTED_MODULE_4__["AlertServiceService"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["LoadingController"]])
    ], OrgModalComponent);
    return OrgModalComponent;
}());



/***/ }),

/***/ "./src/app/common-components/picture/picture.component.css":
/*!*****************************************************************!*\
  !*** ./src/app/common-components/picture/picture.component.css ***!
  \*****************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL2NvbW1vbi1jb21wb25lbnRzL3BpY3R1cmUvcGljdHVyZS5jb21wb25lbnQuY3NzIn0= */"

/***/ }),

/***/ "./src/app/common-components/picture/picture.component.html":
/*!******************************************************************!*\
  !*** ./src/app/common-components/picture/picture.component.html ***!
  \******************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ion-header>\r\n  <ion-toolbar color=\"primary\">\r\n    <ion-title>Picture</ion-title>\r\n    <ion-buttons slot=\"end\">\r\n      <ion-button (click)=\"dismiss()\">\r\n        <ion-icon slot=\"icon-only\" name=\"close\"></ion-icon>\r\n      </ion-button>\r\n    </ion-buttons>\r\n  </ion-toolbar>\r\n\r\n\r\n  <!-- <ion-item lines=\"none\" color=\"primary\" class=\"margin-padding-zero \">\r\n    <span class=\"font-weight-600 font-19  padding-left-10\">Picture</span>\r\n    <ion-buttons slot=\"end\">\r\n      <ion-button (click)=\"dismiss()\">\r\n        <ion-icon slot=\"icon-only\" name=\"close\"></ion-icon>\r\n      </ion-button>\r\n    </ion-buttons>\r\n  </ion-item> -->\r\n\r\n</ion-header>\r\n\r\n<ion-content>\r\n  <div class=\"padding-30\">\r\n    <img [src]=\"image\" style=\"max-width:100%;\r\n      max-height:10%;\r\n      width:auto;\r\n      height:auto;\">\r\n  </div>\r\n</ion-content>"

/***/ }),

/***/ "./src/app/common-components/picture/picture.component.ts":
/*!****************************************************************!*\
  !*** ./src/app/common-components/picture/picture.component.ts ***!
  \****************************************************************/
/*! exports provided: PictureComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "PictureComponent", function() { return PictureComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");



var PictureComponent = /** @class */ (function () {
    function PictureComponent(_modalCtrl) {
        this._modalCtrl = _modalCtrl;
    }
    PictureComponent.prototype.ngOnInit = function () {
        console.log(this.image);
    };
    PictureComponent.prototype.dismiss = function () {
        this._modalCtrl.dismiss();
    };
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])(),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Object)
    ], PictureComponent.prototype, "image", void 0);
    PictureComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-picture',
            template: __webpack_require__(/*! ./picture.component.html */ "./src/app/common-components/picture/picture.component.html"),
            styles: [__webpack_require__(/*! ./picture.component.css */ "./src/app/common-components/picture/picture.component.css")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_ionic_angular__WEBPACK_IMPORTED_MODULE_2__["ModalController"]])
    ], PictureComponent);
    return PictureComponent;
}());



/***/ }),

/***/ "./src/app/common-services/alert-service.service.ts":
/*!**********************************************************!*\
  !*** ./src/app/common-services/alert-service.service.ts ***!
  \**********************************************************/
/*! exports provided: AlertServiceService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AlertServiceService", function() { return AlertServiceService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _ionic_native_file_transfer_ngx__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ionic-native/file-transfer/ngx */ "./node_modules/@ionic-native/file-transfer/ngx/index.js");
/* harmony import */ var _conatants_MainAppSetting__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../conatants/MainAppSetting */ "./src/app/conatants/MainAppSetting.ts");
/* harmony import */ var _ionic_storage__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/storage */ "./node_modules/@ionic/storage/fesm5/ionic-storage.js");
/* harmony import */ var _ionic_native_file_path_ngx__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic-native/file-path/ngx */ "./node_modules/@ionic-native/file-path/ngx/index.js");



// import { Camera, CameraOptions } from '@ionic-native/camera/ngx';




var AlertServiceService = /** @class */ (function () {
    function AlertServiceService(alrtCtrl, 
    // private camera: Camera,
    transfer, appSetting, actionSheet, storage, filePath) {
        this.alrtCtrl = alrtCtrl;
        this.transfer = transfer;
        this.appSetting = appSetting;
        this.actionSheet = actionSheet;
        this.storage = storage;
        this.filePath = filePath;
        this.data = {};
        this.respData = {};
    }
    // private options: CameraOptions = {
    //   quality: 15,
    //   destinationType: this.camera.DestinationType.FILE_URI,
    //   encodingType: this.camera.EncodingType.JPEG,
    //   mediaType: this.camera.MediaType.PICTURE,
    //   sourceType: this.camera.PictureSourceType.CAMERA
    // }
    AlertServiceService.prototype.saveToLocalStorage = function (key, value) {
        this.storage.set(key, value);
    };
    AlertServiceService.prototype.getDataFromLoaclStorage = function (key) {
        return this.storage.get(key);
    };
    // async capturePhoto(sourcetype) {
    //   this.options.sourceType = sourcetype=='camera'?this.camera.PictureSourceType.CAMERA:sourcetype=='library'?this.camera.PictureSourceType.PHOTOLIBRARY:null
    //   console.log(this.options);
    //     await this.camera.getPicture(this.options).then((imageData) => {
    //       console.log("image data by camera", imageData);
    //       this.fileURL = this.filePath.resolveNativePath(imageData);
    //     }, (error) => {
    //       console.error(error);
    //     });
    //     return this.fileURL;
    // }
    AlertServiceService.prototype.onCaptureImage = function (fileURI) {
        console.log("from on capture image", fileURI);
        return fileURI.substring(7);
    };
    AlertServiceService.prototype.presentAlert = function (header, subheader) {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function () {
            var alert;
            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.alrtCtrl.create({
                            header: header,
                            subHeader: subheader,
                            cssClass: 'alert-header',
                            buttons: [{
                                    text: 'OK',
                                    cssClass: 'alert-button'
                                }]
                        })];
                    case 1:
                        alert = _a.sent();
                        return [4 /*yield*/, alert.present()];
                    case 2:
                        _a.sent();
                        return [2 /*return*/];
                }
            });
        });
    };
    AlertServiceService.prototype.upload = function (fileURI1, data, type) {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function () {
            var fileTransfer, uploadOpts;
            var _this = this;
            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                switch (_a.label) {
                    case 0:
                        fileTransfer = this.transfer.create();
                        console.log(fileURI1);
                        uploadOpts = {
                            fileKey: "Display Picture",
                            params: {
                                data: JSON.stringify(data)
                            },
                            fileName: fileURI1.substr(fileURI1.lastIndexOf('/') + 1),
                            headers: {
                                'authorization': window.localStorage.getItem('token'),
                            },
                        };
                        if (type == 'RAISETICKET') {
                            this.apiUrl = this.appSetting.getApi() + "/api/ticket";
                            uploadOpts.httpMethod = 'post';
                        }
                        else if (type == 'UPDATETICKET') {
                            uploadOpts.httpMethod = 'put';
                            this.apiUrl = this.appSetting.getApi() + "/api/ticket/" + data._id;
                        }
                        else if (type == 'CREATENOTICE') {
                            uploadOpts.httpMethod = 'post';
                            console.log(uploadOpts);
                            this.apiUrl = this.appSetting.getApi() + "/api/discussion";
                        }
                        else if (type == 'ADDTOTICKETDETAIL') {
                            this.apiUrl = this.appSetting.getApi() + "/api/ticket/" + data._id;
                            uploadOpts.httpMethod = 'put';
                        }
                        return [4 /*yield*/, fileTransfer.upload(fileURI1, this.apiUrl, uploadOpts).then(function (data) {
                                _this.respData = JSON.parse(data.response);
                                console.log(_this.respData);
                                _this.fileURL = _this.respData.fileUrl;
                                return data;
                            }, function (err) {
                                console.log("*******************Error*******************");
                                console.log(err);
                            })];
                    case 1:
                        _a.sent();
                        console.log("Before Returning data", this.respData);
                        return [2 /*return*/, this.respData];
                }
            });
        });
    };
    AlertServiceService = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_2__["Injectable"])({
            providedIn: 'root'
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_ionic_angular__WEBPACK_IMPORTED_MODULE_1__["AlertController"],
            _ionic_native_file_transfer_ngx__WEBPACK_IMPORTED_MODULE_3__["FileTransfer"],
            _conatants_MainAppSetting__WEBPACK_IMPORTED_MODULE_4__["MainAppSetting"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_1__["ActionSheetController"],
            _ionic_storage__WEBPACK_IMPORTED_MODULE_5__["Storage"],
            _ionic_native_file_path_ngx__WEBPACK_IMPORTED_MODULE_6__["FilePath"]])
    ], AlertServiceService);
    return AlertServiceService;
}());



/***/ }),

/***/ "./src/app/common-services/search-properties/search-project.service.ts":
/*!*****************************************************************************!*\
  !*** ./src/app/common-services/search-properties/search-project.service.ts ***!
  \*****************************************************************************/
/*! exports provided: SearchProjectService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SearchProjectService", function() { return SearchProjectService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/fesm5/http.js");
/* harmony import */ var src_app_conatants_MainAppSetting__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/conatants/MainAppSetting */ "./src/app/conatants/MainAppSetting.ts");




var SearchProjectService = /** @class */ (function () {
    function SearchProjectService(http, appSetting) {
        this.http = http;
        this.appSetting = appSetting;
    }
    SearchProjectService.prototype.searchProject = function (type, searchtext, skip, org, id) {
        //projects?limit=5&skip=0&searchText=&organization=5943d4efa3d24b443f4008a2
        return this.http.get("http://localhost:3020/shared-resource/onboarding/" + type + "?limit=10&searchText=" + searchtext + "&skip=" + skip + "&" + org + "=" + id, this.appSetting.getHttpHeades());
    };
    SearchProjectService.prototype.createUserApproval = function (data) {
        return this.http.post("http://localhost:3020/api/approval", data, this.appSetting.getHttpHeades());
    };
    SearchProjectService = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
            providedIn: 'root'
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpClient"],
            src_app_conatants_MainAppSetting__WEBPACK_IMPORTED_MODULE_3__["MainAppSetting"]])
    ], SearchProjectService);
    return SearchProjectService;
}());



/***/ }),

/***/ "./src/app/common-services/storage-service.service.js":
/*!************************************************************!*\
  !*** ./src/app/common-services/storage-service.service.js ***!
  \************************************************************/
/*! exports provided: StorageService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "StorageService", function() { return StorageService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _ionic_storage__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ionic/storage */ "./node_modules/@ionic/storage/fesm5/ionic-storage.js");



var StorageService = /** @class */ (function () {
    function StorageService(storage) {
        var _this = this;
        this.storage = storage;
        this.storage.get('appSrc').then(function (val) {
            _this.appSrc = val;
        });
    }
    StorageService.prototype.gettoken = function () {
        var _this = this;
        this.storage.get('token').then(function (data) {
            _this.token = data;
        });
        return this.token;
    };
    StorageService.prototype.storeDataToIonicStorage = function (key, value) {
        this.storage.set(key, value);
    };
    StorageService.prototype.getDatafromIonicStorage = function (key) {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function () {
            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                return [2 /*return*/, this.storage.get(key)];
            });
        });
    };
    StorageService.prototype.emptyStorage = function () {
        this.storage.clear();
    };
    StorageService.prototype.removeItem = function (item) {
        return this.storage.remove(item);
    };
    StorageService = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
            providedIn: 'root'
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_ionic_storage__WEBPACK_IMPORTED_MODULE_2__["Storage"]])
    ], StorageService);
    return StorageService;
}());

//# sourceMappingURL=storage-service.service.js.map

/***/ }),

/***/ "./src/app/common-services/storage-service.service.ts":
/*!************************************************************!*\
  !*** ./src/app/common-services/storage-service.service.ts ***!
  \************************************************************/
/*! exports provided: StorageService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "StorageService", function() { return StorageService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _ionic_storage__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ionic/storage */ "./node_modules/@ionic/storage/fesm5/ionic-storage.js");



var StorageService = /** @class */ (function () {
    function StorageService(storage) {
        var _this = this;
        this.storage = storage;
        this.storage.get('appSrc').then(function (val) {
            _this.appSrc = val;
        });
    }
    StorageService.prototype.gettoken = function () {
        var _this = this;
        this.storage.get('token').then(function (data) {
            _this.token = data;
        });
        return this.token;
    };
    StorageService.prototype.storeDataToIonicStorage = function (key, value) {
        this.storage.set(key, value);
    };
    StorageService.prototype.getDatafromIonicStorage = function (key) {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function () {
            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                return [2 /*return*/, this.storage.get(key)];
            });
        });
    };
    StorageService.prototype.emptyStorage = function () {
        this.storage.clear();
    };
    StorageService.prototype.removeItem = function (item) {
        return this.storage.remove(item);
    };
    StorageService = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
            providedIn: 'root'
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_ionic_storage__WEBPACK_IMPORTED_MODULE_2__["Storage"]])
    ], StorageService);
    return StorageService;
}());



/***/ }),

/***/ "./src/app/common-services/translate/translate-service.service.ts":
/*!************************************************************************!*\
  !*** ./src/app/common-services/translate/translate-service.service.ts ***!
  \************************************************************************/
/*! exports provided: translateService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "translateService", function() { return translateService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ngx-translate/core */ "./node_modules/@ngx-translate/core/fesm5/ngx-translate-core.js");



var translateService = /** @class */ (function () {
    function translateService(translate) {
        this.translate = translate;
    }
    translateService.prototype.getTranslatedData = function (key) {
        return this.translate.instant(key);
    };
    translateService = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
            providedIn: 'root'
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_ngx_translate_core__WEBPACK_IMPORTED_MODULE_2__["TranslateService"]])
    ], translateService);
    return translateService;
}());



/***/ }),

/***/ "./src/app/conatants/MainAppSetting.ts":
/*!*********************************************!*\
  !*** ./src/app/conatants/MainAppSetting.ts ***!
  \*********************************************/
/*! exports provided: MainAppSetting */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "MainAppSetting", function() { return MainAppSetting; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/fesm5/http.js");
/* harmony import */ var _conatants_organization_json__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../conatants/organization.json */ "./src/app/conatants/organization.json");
var _conatants_organization_json__WEBPACK_IMPORTED_MODULE_2___namespace = /*#__PURE__*/__webpack_require__.t(/*! ../conatants/organization.json */ "./src/app/conatants/organization.json", 1);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _common_services_storage_service_service_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../common-services/storage-service.service.js */ "./src/app/common-services/storage-service.service.js");





var ORG = _conatants_organization_json__WEBPACK_IMPORTED_MODULE_2__["buildFor"];
var appFor = _conatants_organization_json__WEBPACK_IMPORTED_MODULE_2__["connectTo"];
var MainAppSetting = /** @class */ (function () {
    function MainAppSetting(storageService) {
        var _this = this;
        this.storageService = storageService;
        this.ORG = ORG;
        this.appFor = appFor;
        this.platform = '';
        // public API = API;
        this.HTTPHEADER = this.getHttpHeades();
        this.storageService.getDatafromIonicStorage('token').then(function (data) {
            _this.token = data;
        });
        this.storageService.getDatafromIonicStorage('user_id').then(function (data) {
            _this.userId = data;
        });
        // this.storageService.getDatafromIonicStorage('platform').then(data => {
        //     this.platform = data
        // })
    }
    MainAppSetting.prototype.getPlatform = function () {
        var _this = this;
        this.storageService.getDatafromIonicStorage('platform').then(function (data) {
            _this.platform = data;
        });
    };
    MainAppSetting.prototype.getHttpHeades = function () {
        var httpHeades = {
            // withCredentials : true,
            // Credentials:'include',
            headers: new _angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpHeaders"]({
                'Content-Type': 'application/json',
                'Access-Control-Allow-Credentials': 'true'
            }),
        };
        return httpHeades;
    };
    MainAppSetting.prototype.setTokenAferLogin = function (token) {
        this.token = token;
    };
    MainAppSetting.prototype.setPlatformAfterLogin = function (data) {
        console.log('Step 3 -------------received platform data', data);
        this.platform = data;
        console.log('Step 3 ------------- setting platform', this.platform);
    };
    MainAppSetting.prototype.getHttpHeadesWithToken = function () {
        var httpHeadesWithToken = {
            headers: new _angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpHeaders"]({
                credentials: 'include',
                'Content-Type': 'application/json',
                'authorization': window.localStorage.getItem('token'),
                'Access-Control-Allow-Credentials': 'true'
                // 'Access-Control-Allow-Origin': '*',
                // 'Access-Control-Allow-Credentials': 'true'
            }),
            withCredentials: true,
        };
        return httpHeadesWithToken;
    };
    MainAppSetting.prototype.getApi = function () {
        var _this = this;
        console.log("Get api service called - step pre 7-------");
        this.storageService.getDatafromIonicStorage('platform').then(function (data) {
            console.log("value recieved in step 7 from storage", data);
            _this.platform = data;
        });
        var API = '';
        // console.log("pltform inapp setting " + this.platform);
        console.log("platform value in step post 7", this.platform);
        if (this.ORG == "Both") {
            if (window.localStorage.getItem('platform') == "rm") {
                if (this.appFor == 'alpha') {
                    API = 'https://admin.grexter.in';
                }
                else if (this.appFor == 'production') {
                    API = 'https://rentals.thehousemonk.com';
                }
            }
            else {
                if (this.appFor == 'alpha') {
                    API = 'https://alpha.thehousemonk.com';
                }
                else if (this.appFor == 'production') {
                    API = 'https://thehousemonk.com';
                }
            }
        }
        else if (this.ORG == "RM") {
            // window.localStorage.setItem('appSrc', 'rentals');
            this.storageService.storeDataToIonicStorage('appSrc', 'rentals');
            if (this.appFor == 'alpha') {
                API = 'https://www.nowverifyit.com';
            }
            else if (this.appFor == 'production') {
                API = 'https://www.nowverifyit.com';
            }
        }
        else if (this.ORG == "BM") {
            window.localStorage.setItem('appSrc', 'building-management');
            this.storageService.storeDataToIonicStorage('appSrc', 'building-management');
            if (this.appFor == 'alpha') {
                API = 'https://alpha.thehousemonk.com';
            }
            else if (this.appFor == 'production') {
                API = 'https://thehousemonk.com';
            }
            else {
                API = 'http://localhost:3020';
            }
        }
        console.log('-------MAIN APP', API);
        return API;
    };
    MainAppSetting = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["Injectable"])({
            providedIn: "root"
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_common_services_storage_service_service_js__WEBPACK_IMPORTED_MODULE_4__["StorageService"]])
    ], MainAppSetting);
    return MainAppSetting;
}());



/***/ }),

/***/ "./src/app/conatants/organization.json":
/*!*********************************************!*\
  !*** ./src/app/conatants/organization.json ***!
  \*********************************************/
/*! exports provided: appName, connectTo, buildFor, appBundleId, mixpanel-token, orgName, default */
/***/ (function(module) {

module.exports = {"appName":"Business - TheHouseMonk","connectTo":"production","buildFor":"RM","appBundleId":"com.grexterBusiness.coliving","mixpanel-token":"1350cf4808c3adbdd9ef79625d091dc7","orgName":"The house monk"};

/***/ }),

/***/ "./src/app/login/countrycodemodal/Filter.pipe.ts":
/*!*******************************************************!*\
  !*** ./src/app/login/countrycodemodal/Filter.pipe.ts ***!
  \*******************************************************/
/*! exports provided: FilterPipe */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "FilterPipe", function() { return FilterPipe; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");


var FilterPipe = /** @class */ (function () {
    function FilterPipe() {
    }
    FilterPipe.prototype.transform = function (conCode, searchTerm) {
        if (!conCode)
            return [];
        if (!searchTerm)
            return conCode;
        searchTerm = searchTerm.toLowerCase();
        return conCode.filter(function (it) {
            return it.country.toLowerCase().includes(searchTerm);
        });
    };
    FilterPipe = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Pipe"])({
            name: 'Filter'
        })
    ], FilterPipe);
    return FilterPipe;
}());



/***/ }),

/***/ "./src/app/login/countrycodemodal/countrycodemodal.component.html":
/*!************************************************************************!*\
  !*** ./src/app/login/countrycodemodal/countrycodemodal.component.html ***!
  \************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ion-list style=\"overflow: auto\" class=\"padding-bottom-0\">\r\n  <ion-radio-group [(ngModel)]=\"value\">\r\n    <ion-list-header class=\"center-text gotham\">{{transService.getTranslatedData('country-code-modal.title')}}\r\n    </ion-list-header>\r\n    <ion-item *ngFor=\"let code of countryCode |Filter :searchTerm\" (click)=\"dismissModal(code.code)\">\r\n      <ion-label class=\"gotham\">{{code.country}}</ion-label>\r\n      <ion-radio mode=\"ios\" value=\"{{code.code}}\"></ion-radio>\r\n    </ion-item>\r\n    <ion-button *ngIf=\"!hideButton\" expand=\"full\" class=\"margin-0 gotham\" (click)=\"showMore()\">\r\n      {{transService.getTranslatedData('country-code-modal.button')}}\r\n    </ion-button>\r\n  </ion-radio-group>\r\n</ion-list>"

/***/ }),

/***/ "./src/app/login/countrycodemodal/countrycodemodal.component.scss":
/*!************************************************************************!*\
  !*** ./src/app/login/countrycodemodal/countrycodemodal.component.scss ***!
  \************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL2xvZ2luL2NvdW50cnljb2RlbW9kYWwvY291bnRyeWNvZGVtb2RhbC5jb21wb25lbnQuc2NzcyJ9 */"

/***/ }),

/***/ "./src/app/login/countrycodemodal/countrycodemodal.component.ts":
/*!**********************************************************************!*\
  !*** ./src/app/login/countrycodemodal/countrycodemodal.component.ts ***!
  \**********************************************************************/
/*! exports provided: CountrycodemodalComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CountrycodemodalComponent", function() { return CountrycodemodalComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var src_app_common_services_translate_translate_service_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/common-services/translate/translate-service.service */ "./src/app/common-services/translate/translate-service.service.ts");




var CountrycodemodalComponent = /** @class */ (function () {
    function CountrycodemodalComponent(_modalCtrl, transService) {
        this._modalCtrl = _modalCtrl;
        this.transService = transService;
        this.hideButton = false;
        this.showLoading = false;
        this.start = 0;
        this.end = 10;
        this.countryCode = [{ country: "India (+91)", code: "+91" }, { country: "United States (+1)", code: "+1" }, { country: "Canada (+1)", code: "+1" }, { country: "United Kingdom (+44)", code: "+44" }, { country: "Singapore (+65)", code: "+65" }, { country: "Australia (+61)", code: "+61" }, { country: "Indonesia (+62)", code: "+62" }, { country: "Malaysia (+60)", code: "+60" }, { country: "United Arab Emirates (+971)", code: "+971" }, { country: "Qatar (+974)", code: "+974" }, { country: "Oman (+968)", code: "+968" }, { country: "New Zealand (+64)", code: "+64" }, { country: "Kuwait (+965)", code: "+965" }, { country: "Saudi Arabia (+966)", code: "+966" }, { country: "Nigeria (+234)", code: "+234" }, { country: "Bahrain (+973)", code: "+973" }, { country: "Maldives (+960)", code: "+960" }];
        this.moreCountryCode = [{ country: "Afghanistan (+93)", code: "+93" }, { country: "Albania (+355)", code: "+355" }, { country: "Algeria (+213)", code: "+213" }, { country: "AmericanSamoa (+1 684)", code: "+1684" }, { country: "Andorra (+376)", code: "+376" }, { country: "Angola (+244)", code: "+244" }, { country: "Anguilla (+1 264)", code: "+1264" }, { country: "Antigua and Barbuda (+1268)", code: "+1268" }, { country: "Argentina (+54)", code: "+54" }, { country: "Armenia (+374)", code: "+374" }, { country: "Aruba (+297)", code: "+297" }, { country: "Austria (+43)", code: "+43" }, { country: "Azerbaijan (+994)", code: "+994" }, { country: "Bahamas (+1 242)", code: "+1242" }, { country: "Bangladesh (+880)", code: "+880" }, { country: "Barbados (+1 246)", code: "+1246" }, { country: "Belarus (+375)", code: "+375" }, { country: "Belgium (+32)", code: "+32" }, { country: "Belize (+501)", code: "+501" }, { country: "Benin (+229)", code: "+229" }, { country: "Bermuda (+1 441)", code: "+1441" }, { country: "Bhutan (+975)", code: "+975" }, { country: "Bosnia and Herzegovina (+387)", code: "+387" }, { country: "Botswana (+267)", code: "+267" }, { country: "Brazil (+55)", code: "+55" }, { country: "British Indian Ocean Territory (+246)", code: "+246" }, { country: "Bulgaria (+359)", code: "+359" }, { country: "Burkina Faso (+226)", code: "+226" }, { country: "Burundi (+257)", code: "+257" }, { country: "Cambodia (+855)", code: "+855" }, { country: "Cameroon (+237)", code: "+237" }, { country: "Cape Verde (+238)", code: "+238" }, { country: "Cayman Islands (+ 345)", code: "+ 345" }, { country: "Central African Republic (+236)", code: "+236" }, { country: "Chad (+235)", code: "+235" }, { country: "Chile (+56)", code: "+56" }, { country: "China (+86)", code: "+86" }, { country: "Colombia (+57)", code: "+57" }, { country: "Christmas Island (+61)", code: "+61" }, { country: "Comoros (+269)", code: "+269" }, { country: "Congo (+242)", code: "+242" }, { country: "Cook Islands (+682)", code: "+682" }, { country: "Costa Rica (+506)", code: "+506" }, { country: "Croatia (+385)", code: "+385" }, { country: "Cuba (+53)", code: "+53" }, { country: "Cyprus (+537)", code: "+537" }, { country: "Czech Republic (+420)", code: "+420" }, { country: "Denmark (+45)", code: "+45" }, { country: "Djibouti (+253)", code: "+253" }, { country: "Dominica (+1 767)", code: "+1767" }, { country: "Dominican Republic (+1 849)", code: "+1849" }, { country: "Ecuador (+593)", code: "+593" }, { country: "Egypt (+20)", code: "+20" }, { country: "El Salvador (+503)", code: "+503" }, { country: "Equatorial Guinea (+240)", code: "+240" }, { country: "Eritrea (+291)", code: "+291" }, { country: "Estonia (+372)", code: "+372" }, { country: "Ethiopia (+251)", code: "+251" }, { country: "Faroe Islands (+298)", code: "+298" }, { country: "Fiji (+679)", code: "+679" }, { country: "Finland (+358)", code: "+358" }, { country: "France (+33)", code: "+33" }, { country: "French Guiana (+594)", code: "+594" }, { country: "French Polynesia (+689)", code: "+689" }, { country: "Gabon (+241)", code: "+241" }, { country: "Gambia (+220)", code: "+220" }, { country: "Georgia (+995)", code: "+995" }, { country: "Germany (+49)", code: "+49" }, { country: "Ghana (+233)", code: "+233" }, { country: "Gibraltar (+350)", code: "+350" }, { country: "Greece (+30)", code: "+30" }, { country: "Greenland (+299)", code: "+299" }, { country: "Grenada (+1 473)", code: "+1473" }, { country: "Guadeloupe (+590)", code: "+590" }, { country: "Guam (+1 671)", code: "+1671" }, { country: "Guatemala (+502)", code: "+502" }, { country: "Guinea (+224)", code: "+224" }, { country: "Guinea-Bissau (+245)", code: "+245" }, { country: "Guyana (+595)", code: "+595" }, { country: "Haiti (+509)", code: "+509" }, { country: "Honduras (+504)", code: "+504" }, { country: "Hungary (+36)", code: "+36" }, { country: "Iceland (+354)", code: "+354" }, { country: "Iraq (+964)", code: "+964" }, { country: "Ireland (+353)", code: "+353" }, { country: "Israel (+972)", code: "+972" }, { country: "Italy (+39)", code: "+39" }, { country: "Jamaica (+1 876)", code: "+1876" }, { country: "Japan (+81)", code: "+81" }, { country: "Jordan (+962)", code: "+962" }, { country: "Kazakhstan (+7 7)", code: "+77" }, { country: "Kenya (+254)", code: "+254" }, { country: "Kiribati (+686)", code: "+686" }, { country: "Kyrgyzstan (+996)", code: "+996" }, { country: "Latvia (+371)", code: "+371" }, { country: "Lebanon (+961)", code: "+961" }, { country: "Lesotho (+266)", code: "+266" }, { country: "Liberia (+231)", code: "+231" }, { country: "Liechtenstein (+423)", code: "+423" }, { country: "Lithuania (+370)", code: "+370" }, { country: "Luxembourg (+352)", code: "+352" }, { country: "Madagascar (+261)", code: "+261" }, { country: "Malawi (+265)", code: "+265" }, { country: "Mali (+223)", code: "+223" }, { country: "Malta (+356)", code: "+356" }, { country: "Marshall Islands (+692)", code: "+692" }, { country: "Martinique (+596)", code: "+596" }, { country: "Mauritania (+222)", code: "+222" }, { country: "Mauritius (+230)", code: "+230" }, { country: "Mayotte (+262)", code: "+262" }, { country: "Mexico (+52)", code: "+52" }, { country: "Monaco (+377)", code: "+377" }, { country: "Mongolia (+976)", code: "+976" }, { country: "Montenegro (+382)", code: "+382" }, { country: "Montserrat (+1664)", code: "+1664" }, { country: "Morocco (+212)", code: "+212" }, { country: "Myanmar (+95)", code: "+95" }, { country: "Namibia (+264)", code: "+264" }, { country: "Nauru (+674)", code: "+674" }, { country: "Nepal (+977)", code: "+977" }, { country: "Netherlands (+31)", code: "+31" }, { country: "Netherlands Antilles (+599)", code: "+599" }, { country: "New Caledonia (+687)", code: "+687" }, { country: "Nicaragua (+505)", code: "+505" }, { country: "Niger (+227)", code: "+227" }, { country: "Niue (+683)", code: "+683" }, { country: "Norfolk Island (+672)", code: "+672" }, { country: "Northern Mariana Islands (+1 670)", code: "+1670" }, { country: "Norway (+47)", code: "+47" }, { country: "Pakistan (+92)", code: "+92" }, { country: "Palau (+680)", code: "+680" }, { country: "Panama (+507)", code: "+507" }, { country: "Papua New Guinea (+675)", code: "+675" }, { country: "Paraguay (+595)", code: "+595" }, { country: "Peru (+51)", code: "+51" }, { country: "Philippines (+63)", code: "+63" }, { country: "Poland (+48)", code: "+48" }, { country: "Portugal (+351)", code: "+351" }, { country: "Puerto Rico (+1 939)", code: "+1939" }, { country: "Romania (+40)", code: "+40" }, { country: "Rwanda (+250)", code: "+250" }, { country: "Samoa (+685)", code: "+685" }, { country: "San Marino (+378)", code: "+378" }, { country: "Senegal (+221)", code: "+221" }, { country: "Serbia (+381)", code: "+381" }, { country: "Seychelles (+248)", code: "+248" }, { country: "Sierra Leone (+232)", code: "+232" }, { country: "Slovakia (+421)", code: "+421" }, { country: "Slovenia (+386)", code: "+386" }, { country: "Solomon Islands (+677)", code: "+677" }, { country: "South Africa (+27)", code: "+27" }, { country: "South Georgia and the South Sandwich Islands (+500)", code: "+500" }, { country: "Spain (+34)", code: "+34" }, { country: "Sri Lanka (+94)", code: "+94" }, { country: "Sudan (+249)", code: "+249" }, { country: "Suriname (+597)", code: "+597" }, { country: "Swaziland (+268)", code: "+268" }, { country: "Sweden (+46)", code: "+46" }, { country: "Switzerland (+41)", code: "+41" }, { country: "Tajikistan (+992)", code: "+992" }, { country: "Thailand (+66)", code: "+66" }, { country: "Togo (+228)", code: "+228" }, { country: "Tokelau (+690)", code: "+690" }, { country: "Tonga (+676)", code: "+676" }, { country: "Trinidad and Tobago (+1 868)", code: "+1868" }, { country: "Tunisia (+216)", code: "+216" }, { country: "Turkey (+90)", code: "+90" }, { country: "Turkmenistan (+993)", code: "+993" }, { country: "Turks and Caicos Islands (+1 649)", code: "+1649" }, { country: "Tuvalu (+688)", code: "+688" }, { country: "Uganda (+256)", code: "+256" }, { country: "Ukraine (+380)", code: "+380" }, { country: "Uruguay (+598)", code: "+598" }, { country: "Uzbekistan (+998)", code: "+998" }, { country: "Vanuatu (+678)", code: "+678" }, { country: "Wallis and Futuna (+681)", code: "+681" }, { country: "Yemen (+967)", code: "+967" }, { country: "Zambia (+260)", code: "+260" }, { country: "Zimbabwe (+263)", code: "+263" }, { country: "land Islands ()", code: "" }, { country: "Bolivia, Plurinational State of (+591)", code: "+591" }, { country: "Brunei Darussalam (+673)", code: "+673" }, { country: "Cocos (Keeling) Islands (+61)", code: "+61" }, { country: "Congo, The Democratic Republic of the (+243)", code: "+243" }, { country: "Cote d'Ivoire (+225)", code: "+225" }, { country: "Falkland Islands (Malvinas) (+500)", code: "+500" }, { country: "Guernsey (+44)", code: "+44" }, { country: "Holy See (Vatican City State) (+379)", code: "+379" }, { country: "Hong Kong (+852)", code: "+852" }, { country: "Iran, Islamic Republic of (+98)", code: "+98" }, { country: "Isle of Man (+44)", code: "+44" }, { country: "Jersey (+44)", code: "+44" }, { country: "Korea, Democratic People's Republic of (+850)", code: "+850" }, { country: "Korea, Republic of (+82)", code: "+82" }, { country: "Lao People's Democratic Republic (+856)", code: "+856" }, { country: "Libyan Arab Jamahiriya (+218)", code: "+218" }, { country: "Macao (+853)", code: "+853" }, { country: "Macedonia, The Former Yugoslav Republic of (+389)", code: "+389" }, { country: "Micronesia, Federated States of (+691)", code: "+691" }, { country: "Moldova, Republic of (+373)", code: "+373" }, { country: "Mozambique (+258)", code: "+258" }, { country: "Palestinian Territory, Occupied (+970)", code: "+970" }, { country: "Pitcairn (+872)", code: "+872" }, { country: "Réunion (+262)", code: "+262" }, { country: "Russia (+7)", code: "+7" }, { country: "Saint Barthélemy (+590)", code: "+590" }, { country: "Saint Helena, Ascension and Tristan Da Cunha (+290)", code: "+290" }, { country: "Saint Kitts and Nevis (+1 869)", code: "+1869" }, { country: "Saint Lucia (+1 758)", code: "+1758" }, { country: "Saint Martin (+590)", code: "+590" }, { country: "Saint Pierre and Miquelon (+508)", code: "+508" }, { country: "Saint Vincent and the Grenadines (+1 784)", code: "+1784" }, { country: "Sao Tome and Principe (+239)", code: "+239" }, { country: "Somalia (+252)", code: "+252" }, { country: "Svalbard and Jan Mayen (+47)", code: "+47" }, { country: "Syrian Arab Republic (+963)", code: "+963" }, { country: "Taiwan, Province of China (+886)", code: "+886" }, { country: "Tanzania, United Republic of (+255)", code: "+255" }, { country: "Timor-Leste (+670)", code: "+670" }, { country: "Venezuela, Bolivarian Republic of (+58)", code: "+58" }, { country: "Viet Nam (+84)", code: "+84" }, { country: "Virgin Islands, British (+1 284)", code: "+1284" }, { country: "Virgin Islands, U.S. (+1 340)", code: "+1340" }];
    }
    CountrycodemodalComponent.prototype.ngOnInit = function () {
        console.log(this.value);
    };
    CountrycodemodalComponent.prototype.dismissModal = function (value) {
        this._modalCtrl.dismiss(value);
    };
    CountrycodemodalComponent.prototype.showMore = function () {
        this.hideButton = true;
        this.countryCode = this.countryCode.concat(this.moreCountryCode);
    };
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])(),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Number)
    ], CountrycodemodalComponent.prototype, "value", void 0);
    CountrycodemodalComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-countrycodemodal',
            template: __webpack_require__(/*! ./countrycodemodal.component.html */ "./src/app/login/countrycodemodal/countrycodemodal.component.html"),
            styles: [__webpack_require__(/*! ./countrycodemodal.component.scss */ "./src/app/login/countrycodemodal/countrycodemodal.component.scss")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_ionic_angular__WEBPACK_IMPORTED_MODULE_2__["ModalController"],
            src_app_common_services_translate_translate_service_service__WEBPACK_IMPORTED_MODULE_3__["translateService"]])
    ], CountrycodemodalComponent);
    return CountrycodemodalComponent;
}());



/***/ }),

/***/ "./src/environments/environment.ts":
/*!*****************************************!*\
  !*** ./src/environments/environment.ts ***!
  \*****************************************/
/*! exports provided: environment */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "environment", function() { return environment; });
// This file can be replaced during build by using the `fileReplacements` array.
// `ng build --prod` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.
var environment = {
    production: false
};
/*
 * For easier debugging in development mode, you can import the following file
 * to ignore zone related error stack frames such as `zone.run`, `zoneDelegate.invokeTask`.
 *
 * This import should be commented out in production mode because it will have a negative impact
 * on performance if an error is thrown.
 */
// import 'zone.js/dist/zone-error';  // Included with Angular CLI.


/***/ }),

/***/ "./src/main.ts":
/*!*********************!*\
  !*** ./src/main.ts ***!
  \*********************/
/*! no exports provided */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_platform_browser_dynamic__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/platform-browser-dynamic */ "./node_modules/@angular/platform-browser-dynamic/fesm5/platform-browser-dynamic.js");
/* harmony import */ var _app_app_module__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./app/app.module */ "./src/app/app.module.ts");
/* harmony import */ var _environments_environment__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./environments/environment */ "./src/environments/environment.ts");




if (_environments_environment__WEBPACK_IMPORTED_MODULE_3__["environment"].production) {
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["enableProdMode"])();
}
Object(_angular_platform_browser_dynamic__WEBPACK_IMPORTED_MODULE_1__["platformBrowserDynamic"])().bootstrapModule(_app_app_module__WEBPACK_IMPORTED_MODULE_2__["AppModule"])
    .catch(function (err) { return console.log(err); });


/***/ }),

/***/ 0:
/*!***************************!*\
  !*** multi ./src/main.ts ***!
  \***************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__(/*! D:\navjot\verify\src\main.ts */"./src/main.ts");


/***/ })

},[[0,"runtime","vendor"]]]);
//# sourceMappingURL=main.js.map