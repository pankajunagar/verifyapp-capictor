(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["Rentals-Management-pages-home-home-module"],{

/***/ "./src/app/Rentals Management/pages/home/home.module.ts":
/*!**************************************************************!*\
  !*** ./src/app/Rentals Management/pages/home/home.module.ts ***!
  \**************************************************************/
/*! exports provided: HomePageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "HomePageModule", function() { return HomePageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _ApplicationPageModule__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./../../ApplicationPageModule */ "./src/app/Rentals Management/ApplicationPageModule.ts");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _home_page__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./home.page */ "./src/app/Rentals Management/pages/home/home.page.ts");
/* harmony import */ var _modals_create_notice_create_notice_component__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../../modals/create-notice/create-notice.component */ "./src/app/Rentals Management/modals/create-notice/create-notice.component.ts");









// import { BarcodeScanner } from '@ionic-native/barcode-scanner/ngx';
var routes = [
    {
        path: '',
        component: _home_page__WEBPACK_IMPORTED_MODULE_7__["HomePage"]
    }
];
var HomePageModule = /** @class */ (function () {
    function HomePageModule() {
    }
    HomePageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_2__["NgModule"])({
            entryComponents: [_modals_create_notice_create_notice_component__WEBPACK_IMPORTED_MODULE_8__["CreateNoticeComponent"]],
            imports: [
                _angular_common__WEBPACK_IMPORTED_MODULE_3__["CommonModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormsModule"],
                _ApplicationPageModule__WEBPACK_IMPORTED_MODULE_1__["ApplicationPageModule"],
                _ionic_angular__WEBPACK_IMPORTED_MODULE_6__["IonicModule"],
                _angular_router__WEBPACK_IMPORTED_MODULE_5__["RouterModule"].forChild(routes)
            ],
            providers: [
            // BarcodeScanner
            ],
            declarations: [_home_page__WEBPACK_IMPORTED_MODULE_7__["HomePage"]]
        })
    ], HomePageModule);
    return HomePageModule;
}());



/***/ }),

/***/ "./src/app/Rentals Management/pages/home/home.page.html":
/*!**************************************************************!*\
  !*** ./src/app/Rentals Management/pages/home/home.page.html ***!
  \**************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ion-header no-border>\r\n  <ion-toolbar>\r\n    <ion-buttons slot=\"start\">\r\n      <ion-menu-button></ion-menu-button>\r\n    </ion-buttons>\r\n    <!-- <ion-buttons slot=\"end\" expand=\"full\" class=\"ion-button\" (click)=\"openScanner()\">\r\n      <ion-button style=\"color: black\">\r\n          <img src=\"../../../../assets/icons.png\" width=\"30px\" height=\"30px\"/>\r\n      </ion-button>\r\n    </ion-buttons> -->\r\n  </ion-toolbar>\r\n</ion-header>\r\n<ion-content>\r\n  <div class=\"background-yellow home-top-container\">\r\n    <span class=\"font-22 gotham\">{{transService.getTranslatedData('home.string1')}} {{userDetails?.firstName}}\r\n      {{userDetails?.lastName}}</span>\r\n    <br>\r\n    <span class=\"font-14 gotham\" style=\"margin-top:5px\">{{transService.getTranslatedData('home.string2')}}</span>\r\n  </div>\r\n  <ion-card style=\"margin-top: -45px\">\r\n    <ion-card-content class=\"padding-6\">\r\n      <ion-grid>\r\n        <ion-row>\r\n          <ion-col>\r\n            <p class=\"gotham font-weight-600 txt-grey\">{{transService.getTranslatedData('home.open')}}</p>\r\n            <p class=\"font-18 gotham\">{{ticketStats?.ticket['open']||0}}</p>\r\n          </ion-col>\r\n          <ion-col>\r\n            <p class=\"gotham font-weight-600 txt-grey\">{{transService.getTranslatedData('home.in-progress')}}</p>\r\n            <p class=\"font-18 gotham\">{{ticketStats?.ticket['in-progress']||0}}</p>\r\n          </ion-col>\r\n          <!-- <ion-col>\r\n            <p class=\"gotham font-weight-600 txt-grey\">{{transService.getTranslatedData('home.resolved')}}</p>\r\n            <p class=\"font-18 gotham\">20</p>\r\n          </ion-col> -->\r\n        </ion-row>\r\n      </ion-grid>\r\n    </ion-card-content>\r\n  </ion-card>\r\n\r\n  <!-- <ion-grid>\r\n    <br>\r\n    <span class=\"font-18 gotham\" style=\"margin-top:5px; padding-left:15px\">Add/Approve</span>\r\n    <br>\r\n    <br>\r\n    <ion-row class=\"border-top border-bottom\">\r\n      <ion-col class=\"center-text \" (click)=\"navigate('create-ticket')\">\r\n        <img class=\"tile-option margin-bottom-10 \" src=\"/assets/icon/raise-ticket.png\">\r\n        <p class=\"font-14 gotham margin-bottom-20\">Raise ticket</p>\r\n      </ion-col>\r\n      <ion-col class=\"center-text border-right border-left \" (click)=\"openCreateNoticeModal()\">\r\n        <img class=\"tile-option margin-bottom-10 \" src=\"/assets/icon/create-notice.png\">\r\n        <p class=\"font-14 gotham margin-bottom-20\">Create notice</p>\r\n      </ion-col>\r\n\r\n      <ion-col class=\"center-text \" (click)=\"navigate('user-approval')\">\r\n        <img class=\"tile-option margin-bottom-10 \" src=\"/assets/icon/approval.png\">\r\n        <p class=\"font-14 gotham margin-bottom-20\">User</p>\r\n      </ion-col>\r\n    </ion-row>\r\n    <br>\r\n    <span class=\"font-18 gotham\" style=\"margin-top:5px; padding-left:15px\">View</span>\r\n    <br>\r\n    <br>\r\n    <ion-row class=\"border-top border-bottom\">\r\n      <ion-col class=\"center-text  \" (click)=\"navigate('tickets')\">\r\n        <img class=\"tile-option margin-bottom-10 \" src=\"/assets/icon/ticket-history.png\">\r\n        <p class=\"font-14 gotham margin-bottom-20\">Tickets</p>\r\n      </ion-col>\r\n      <ion-col class=\"center-text border-right border-left\" (click)=\"navigate('notice-board')\">\r\n        <img class=\"tile-option margin-bottom-10 \" src=\"/assets/icon/communications.png\">\r\n        <p class=\"font-14 gotham margin-bottom-20\">Discussion</p>\r\n      </ion-col>\r\n      <ion-col class=\"center-text\" (click)=\"navigate('calendar')\">\r\n        <img class=\"tile-option margin-bottom-10 \" src=\"/assets/icon/calendar.png\">\r\n        <p class=\"font-14 gotham margin-bottom-20\">Calendar</p>\r\n      </ion-col>\r\n    </ion-row>\r\n  </ion-grid> -->\r\n\r\n  <ion-grid>\r\n    <!-- <br>\r\n    <span class=\"font-18 gotham\" style=\"margin-top:5px; padding-left:15px\">Add/Approve</span>\r\n    <br> -->\r\n    <br>\r\n    <ion-row class=\"border-top\">\r\n      <ion-col class=\"center-text \" (click)=\"navigate('create-ticket')\">\r\n        <img class=\"tile-option margin-bottom-10 \" src=\"/assets/icon/raise-ticket.png\">\r\n        <p class=\"font-14 gotham margin-bottom-20\">{{transService.getTranslatedData('home.raise-ticket')}}</p>\r\n      </ion-col>\r\n      <ion-col class=\"center-text border-right border-left \" (click)=\"openCreateNoticeModal()\">\r\n        <img class=\"tile-option margin-bottom-10 \" src=\"/assets/icon/create-notice.png\">\r\n        <p class=\"font-14 gotham margin-bottom-20\">{{transService.getTranslatedData('home.create-notice')}}</p>\r\n      </ion-col>\r\n\r\n      <ion-col class=\"center-text \" (click)=\"navigate('user-approval')\">\r\n        <img class=\"tile-option margin-bottom-10 \" src=\"/assets/icon/approval.png\">\r\n        <p class=\"font-14 gotham margin-bottom-20\">{{transService.getTranslatedData('home.user')}}</p>\r\n      </ion-col>\r\n    </ion-row>\r\n    <ion-row class=\"border-top border-bottom\">\r\n      <ion-col class=\"center-text  \" (click)=\"navigate('tickets')\">\r\n        <img class=\"tile-option margin-bottom-10 \" src=\"/assets/icon/ticket-history.png\">\r\n        <p class=\"font-14 gotham margin-bottom-20\">{{transService.getTranslatedData('home.tickets')}}</p>\r\n      </ion-col>\r\n      <ion-col class=\"center-text border-right border-left\" (click)=\"navigate('notice-board')\">\r\n        <img class=\"tile-option margin-bottom-10 \" src=\"/assets/icon/communications.png\">\r\n        <p class=\"font-14 gotham margin-bottom-20\">{{transService.getTranslatedData('home.discussion')}}</p>\r\n      </ion-col>\r\n      <ion-col class=\"center-text\" (click)=\"navigate('calendar')\">\r\n        <img class=\"tile-option margin-bottom-10 \" src=\"/assets/icon/calendar.png\">\r\n        <p class=\"font-14 gotham margin-bottom-20\">{{transService.getTranslatedData('home.calendar')}}</p>\r\n      </ion-col>\r\n    </ion-row>\r\n  </ion-grid>\r\n\r\n  <!-- <ion-grid>\r\n    <br>\r\n    <span class=\"font-18 gotham\" style=\"margin-top:5px; padding-left:15px\">Add/Approve</span>\r\n    <br>\r\n    <br>\r\n    <ion-row>\r\n      <ion-col size=\"4\" class=\"padding-0\">\r\n        <ion-card class=\"center-text margin-5\" (click)=\"navigate('create-ticket')\" style=\"display: grid\">\r\n          <img class=\"tile-option margin-bottom-10 \" style=\"justify-self: center\" src=\"/assets/icon/raise-ticket.png\">\r\n          <p class=\"font-14 gotham margin-bottom-20\">Raise ticket</p>\r\n          <img src=\"assets/icon/add-green.png\" class=\"icon-20 border-radius-10\"\r\n            style=\"position: absolute; right: 2px; bottom: 2px;\" />\r\n\r\n        </ion-card>\r\n      </ion-col>\r\n      <ion-col size=\"4\" class=\"padding-0\">\r\n        <ion-card class=\"center-text margin-5\" style=\"display: grid\" (click)=\"openCreateNoticeModal()\">\r\n          <img class=\"tile-option margin-bottom-10 \" style=\"justify-self: center\" src=\"/assets/icon/create-notice.png\">\r\n          <p class=\"font-14 gotham margin-bottom-20\">Create notice</p>\r\n          <img src=\"assets/icon/add-green.png\" class=\"icon-20 border-radius-10\"\r\n            style=\"position: absolute; right: 2px; bottom: 2px;\" />\r\n        </ion-card>\r\n      </ion-col>\r\n\r\n      <ion-col size=\"4\" class=\"padding-0\">\r\n        <ion-card class=\"center-text margin-5\" style=\"display: grid\" (click)=\"navigate('user-approval')\">\r\n          <img class=\"tile-option margin-bottom-10 \" style=\"justify-self: center\" src=\"/assets/icon/approval.png\">\r\n          <p class=\"font-14 gotham margin-bottom-20\">User</p>\r\n          <img src=\"assets/icon/add-green.png\" class=\"icon-20 border-radius-10\"\r\n            style=\"position: absolute; right: 2px; bottom: 2px;\" />\r\n        </ion-card>\r\n\r\n      </ion-col>\r\n    </ion-row>\r\n    <br>\r\n    <span class=\"font-18 gotham\" style=\"margin-top:5px; padding-left:15px\">View</span>\r\n    <br>\r\n    <br>\r\n    <ion-row>\r\n      <ion-col size=\"4\" class=\"padding-0\">\r\n        <ion-card class=\"center-text margin-5\" style=\"display: grid\" (click)=\"openCreateNoticeModal()\">\r\n          <img class=\"tile-option margin-bottom-10 \" style=\"justify-self: center\" src=\"/assets/icon/ticket-history.png\">\r\n          <p class=\"font-14 gotham margin-bottom-20\">Tickets</p>\r\n        </ion-card>\r\n      </ion-col>\r\n      <ion-col size=\"4\" class=\"padding-0\">\r\n        <ion-card class=\"center-text margin-5\" style=\"display: grid\" (click)=\"openCreateNoticeModal()\">\r\n          <img class=\"tile-option margin-bottom-10 \" style=\"justify-self: center\" src=\"/assets/icon/communications.png\">\r\n          <p class=\"font-14 gotham margin-bottom-20\">Discussion</p>\r\n        </ion-card>\r\n\r\n      </ion-col>\r\n      <ion-col size=\"4\" class=\"padding-0\">\r\n        <ion-card class=\"center-text margin-5\" style=\"display: grid\" (click)=\"openCreateNoticeModal()\">\r\n          <img class=\"tile-option margin-bottom-10 \" style=\"justify-self: center\" src=\"/assets/icon/calendar.png\">\r\n          <p class=\"font-14 gotham margin-bottom-20\">Calendar</p>\r\n        </ion-card>\r\n\r\n      </ion-col>\r\n    </ion-row>\r\n  </ion-grid> -->\r\n\r\n  <br>\r\n  <span class=\"font-18 gotham\"\r\n    style=\"margin-top:5px; padding-left:15px\">{{transService.getTranslatedData('home.tasks-for-today')}}<span\r\n      class=\"gotham font-weight-600 txt-grey\" *ngIf=\"ticketStats\">{{ticketStats.todo.length}}</span></span>\r\n  <br>\r\n  <br>\r\n\r\n  <ion-list class=\"border-top padding-bottom-0\">\r\n    <ion-item *ngFor=\"let ticket of ticketStats?.todo\" [routerLink]=\"['/rentals-ticket-details']\"\r\n      [queryParams]=\"{ticketId: ticket._id}\" detail=\"true\" lines=\"none\">\r\n      <ion-label class=\"margin-0\">\r\n        <p class=\"gotham-bold txt-grey margin-bottom-8 padding-top-2\" text-wrap>\r\n          <span class=\"float-left\">#{{ticket.uid}} - </span>\r\n          <span class=\"center-text\"> {{ticket.ticketCategory}}</span>\r\n          <span class=\"float-right\">{{ticket.createdAt | agoFilter}}</span>\r\n        </p>\r\n        <p id=\"margin-top-bottom-5\" class=\"gotham margin-bottom-8 font-weight-600 margin-bottom-5 txt-grey\">For -\r\n          {{ticket.ticketBelongsTo == 'Home' ? 'Unit' : ticket.ticketBelongsTo}}</p>\r\n        <p>\r\n          <ion-badge class=\"gotham font-weight-600 padding-top-7 date-bedge-color\" mode=\"md\">\r\n            {{ticket.jobDate | date:'dd MMM yyyy'}} {{ticket.jobStartTime | date:'hh:mm a'}}\r\n          </ion-badge>\r\n          <ion-badge class=\"gotham font-weight-600 margin-left-20 padding-top-6\" color=\"{{ticket.status}}\" mode=\"md\">\r\n            {{ticket.status == 'in-progress' ? 'In Progress' : ticket.status}}\r\n          </ion-badge>\r\n        </p>\r\n      </ion-label>\r\n    </ion-item>\r\n  </ion-list>\r\n\r\n  <span class=\"font-14 gotham center-text display-block margin-top-10\" *ngIf=\"ticketStats?.todo.length == 0\">\r\n    {{transService.getTranslatedData('home.no-task-found')}}\r\n  </span>\r\n\r\n</ion-content>"

/***/ }),

/***/ "./src/app/Rentals Management/pages/home/home.page.scss":
/*!**************************************************************!*\
  !*** ./src/app/Rentals Management/pages/home/home.page.scss ***!
  \**************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ".welcome-card ion-img {\n  max-height: 35vh;\n  overflow: hidden; }\n\nion-toolbar {\n  background-color: #feb900 !important; }\n\n.background-yellow {\n  background-color: #feb900 !important; }\n\n.home-top-container {\n  height: 100px;\n  padding-left: 15px !important; }\n\n.font-22 {\n  font-size: 22px !important; }\n\nion-item {\n  border-bottom: 1px solid lightgray; }\n\nion-label {\n  padding-top: 10px !important;\n  padding-bottom: 10px !important; }\n\nion-list {\n  padding-top: 0px !important; }\n\n.margin-bottom-20 {\n  margin-bottom: 20px !important; }\n\n.margin-bottom-10 {\n  margin-top: 20px !important; }\n\nion-menu-button {\n  color: black !important; }\n\nion-card-content {\n  background-color: white !important; }\n\nion-toolbar {\n  --background: transparent;\n  --ion-color-base: transparent !important; }\n\nion-badge {\n  --padding: 4px !important;\n  --padding-top: 5px !important; }\n\np {\n  margin: 0px !important;\n  padding: 0px !important; }\n\n#margin-top-bottom-5 {\n  margin-top: 5px !important;\n  margin-bottom: 5px !important; }\n\n.border-top {\n  border-top: 1px solid lightgray; }\n\n.border-bottom {\n  border-bottom: 1px solid lightgray; }\n\n.border-right {\n  border-right: 1px solid lightgray !important; }\n\n.border-left {\n  border-left: 1px solid lightgray !important; }\n\n.border-1 {\n  border: 1px solid lightgray !important; }\n\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvUmVudGFscyBNYW5hZ2VtZW50L3BhZ2VzL2hvbWUvRDpcXG5hdmpvdFxcdmVyaWZ5L3NyY1xcYXBwXFxSZW50YWxzIE1hbmFnZW1lbnRcXHBhZ2VzXFxob21lXFxob21lLnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNFLGdCQUFnQjtFQUNoQixnQkFBZ0IsRUFBQTs7QUFHbEI7RUFDRSxvQ0FBb0MsRUFBQTs7QUFHdEM7RUFDRSxvQ0FBb0MsRUFBQTs7QUFHdEM7RUFDRSxhQUFhO0VBQ2IsNkJBQTZCLEVBQUE7O0FBRy9CO0VBQ0UsMEJBQTBCLEVBQUE7O0FBRzVCO0VBRUUsa0NBQWtDLEVBQUE7O0FBR3BDO0VBQ0UsNEJBQTRCO0VBQzVCLCtCQUErQixFQUFBOztBQUdqQztFQUNFLDJCQUEyQixFQUFBOztBQUc3QjtFQUNFLDhCQUE4QixFQUFBOztBQUVoQztFQUNFLDJCQUEyQixFQUFBOztBQUc3QjtFQUNFLHVCQUF1QixFQUFBOztBQUd6QjtFQUNFLGtDQUFrQyxFQUFBOztBQUdwQztFQUNFLHlCQUFhO0VBQ2Isd0NBQWlCLEVBQUE7O0FBRW5CO0VBQ0UseUJBQVU7RUFDViw2QkFBYyxFQUFBOztBQUdoQjtFQUNFLHNCQUFzQjtFQUN0Qix1QkFBdUIsRUFBQTs7QUFHekI7RUFDRSwwQkFBMEI7RUFDMUIsNkJBQTZCLEVBQUE7O0FBRS9CO0VBQ0UsK0JBQStCLEVBQUE7O0FBR2pDO0VBQ0Usa0NBQWtDLEVBQUE7O0FBR3BDO0VBQ0UsNENBQTRDLEVBQUE7O0FBRzlDO0VBQ0UsMkNBQTJDLEVBQUE7O0FBRzdDO0VBQ0Usc0NBQXNDLEVBQUEiLCJmaWxlIjoic3JjL2FwcC9SZW50YWxzIE1hbmFnZW1lbnQvcGFnZXMvaG9tZS9ob21lLnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIi53ZWxjb21lLWNhcmQgaW9uLWltZyB7XHJcbiAgbWF4LWhlaWdodDogMzV2aDtcclxuICBvdmVyZmxvdzogaGlkZGVuO1xyXG59XHJcblxyXG5pb24tdG9vbGJhciB7XHJcbiAgYmFja2dyb3VuZC1jb2xvcjogI2ZlYjkwMCAhaW1wb3J0YW50O1xyXG59XHJcblxyXG4uYmFja2dyb3VuZC15ZWxsb3cge1xyXG4gIGJhY2tncm91bmQtY29sb3I6ICNmZWI5MDAgIWltcG9ydGFudDtcclxufVxyXG5cclxuLmhvbWUtdG9wLWNvbnRhaW5lciB7XHJcbiAgaGVpZ2h0OiAxMDBweDtcclxuICBwYWRkaW5nLWxlZnQ6IDE1cHggIWltcG9ydGFudDtcclxufVxyXG5cclxuLmZvbnQtMjIge1xyXG4gIGZvbnQtc2l6ZTogMjJweCAhaW1wb3J0YW50O1xyXG59XHJcblxyXG5pb24taXRlbSB7XHJcbiAgLy8gYm9yZGVyLXRvcDogMXB4IHNvbGlkIGxpZ2h0Z3JheTtcclxuICBib3JkZXItYm90dG9tOiAxcHggc29saWQgbGlnaHRncmF5O1xyXG59XHJcblxyXG5pb24tbGFiZWwge1xyXG4gIHBhZGRpbmctdG9wOiAxMHB4ICFpbXBvcnRhbnQ7XHJcbiAgcGFkZGluZy1ib3R0b206IDEwcHggIWltcG9ydGFudDtcclxufVxyXG5cclxuaW9uLWxpc3Qge1xyXG4gIHBhZGRpbmctdG9wOiAwcHggIWltcG9ydGFudDtcclxufVxyXG5cclxuLm1hcmdpbi1ib3R0b20tMjAge1xyXG4gIG1hcmdpbi1ib3R0b206IDIwcHggIWltcG9ydGFudDtcclxufVxyXG4ubWFyZ2luLWJvdHRvbS0xMCB7XHJcbiAgbWFyZ2luLXRvcDogMjBweCAhaW1wb3J0YW50O1xyXG59XHJcblxyXG5pb24tbWVudS1idXR0b24ge1xyXG4gIGNvbG9yOiBibGFjayAhaW1wb3J0YW50O1xyXG59XHJcblxyXG5pb24tY2FyZC1jb250ZW50IHtcclxuICBiYWNrZ3JvdW5kLWNvbG9yOiB3aGl0ZSAhaW1wb3J0YW50O1xyXG59XHJcblxyXG5pb24tdG9vbGJhciB7XHJcbiAgLS1iYWNrZ3JvdW5kOiB0cmFuc3BhcmVudDtcclxuICAtLWlvbi1jb2xvci1iYXNlOiB0cmFuc3BhcmVudCAhaW1wb3J0YW50O1xyXG59XHJcbmlvbi1iYWRnZSB7XHJcbiAgLS1wYWRkaW5nOiA0cHggIWltcG9ydGFudDtcclxuICAtLXBhZGRpbmctdG9wOiA1cHggIWltcG9ydGFudDtcclxufVxyXG5cclxucCB7XHJcbiAgbWFyZ2luOiAwcHggIWltcG9ydGFudDtcclxuICBwYWRkaW5nOiAwcHggIWltcG9ydGFudDtcclxufVxyXG5cclxuI21hcmdpbi10b3AtYm90dG9tLTUge1xyXG4gIG1hcmdpbi10b3A6IDVweCAhaW1wb3J0YW50O1xyXG4gIG1hcmdpbi1ib3R0b206IDVweCAhaW1wb3J0YW50O1xyXG59XHJcbi5ib3JkZXItdG9wIHtcclxuICBib3JkZXItdG9wOiAxcHggc29saWQgbGlnaHRncmF5O1xyXG59XHJcblxyXG4uYm9yZGVyLWJvdHRvbSB7XHJcbiAgYm9yZGVyLWJvdHRvbTogMXB4IHNvbGlkIGxpZ2h0Z3JheTtcclxufVxyXG5cclxuLmJvcmRlci1yaWdodCB7XHJcbiAgYm9yZGVyLXJpZ2h0OiAxcHggc29saWQgbGlnaHRncmF5ICFpbXBvcnRhbnQ7XHJcbn1cclxuXHJcbi5ib3JkZXItbGVmdCB7XHJcbiAgYm9yZGVyLWxlZnQ6IDFweCBzb2xpZCBsaWdodGdyYXkgIWltcG9ydGFudDtcclxufVxyXG5cclxuLmJvcmRlci0xIHtcclxuICBib3JkZXI6IDFweCBzb2xpZCBsaWdodGdyYXkgIWltcG9ydGFudDtcclxufVxyXG4iXX0= */"

/***/ }),

/***/ "./src/app/Rentals Management/pages/home/home.page.ts":
/*!************************************************************!*\
  !*** ./src/app/Rentals Management/pages/home/home.page.ts ***!
  \************************************************************/
/*! exports provided: HomePage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "HomePage", function() { return HomePage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _services_ticket_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../services/ticket.service */ "./src/app/Rentals Management/services/ticket.service.ts");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _ionic_native_push_ngx__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic-native/push/ngx */ "./node_modules/@ionic-native/push/ngx/index.js");
/* harmony import */ var src_app_common_services_alert_service_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! src/app/common-services/alert-service.service */ "./src/app/common-services/alert-service.service.ts");
/* harmony import */ var _modals_create_notice_create_notice_component__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../../modals/create-notice/create-notice.component */ "./src/app/Rentals Management/modals/create-notice/create-notice.component.ts");
/* harmony import */ var src_app_common_services_translate_translate_service_service__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! src/app/common-services/translate/translate-service.service */ "./src/app/common-services/translate/translate-service.service.ts");
/* harmony import */ var _ionic_storage__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @ionic/storage */ "./node_modules/@ionic/storage/fesm5/ionic-storage.js");
/* harmony import */ var _services_rentals_user_service__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ../../services/rentals-user.service */ "./src/app/Rentals Management/services/rentals-user.service.ts");
/* harmony import */ var _ionic_native_device_ngx__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @ionic-native/device/ngx */ "./node_modules/@ionic-native/device/ngx/index.js");












// import { BarcodeScanner } from '@ionic-native/barcode-scanner/ngx';
var HomePage = /** @class */ (function () {
    function HomePage(ticketService, 
    // private barcodeScanner: BarcodeScanner,
    loadingCtrl, router, modalController, userService, alertService, push, transService, storage, device, alertCtrl, _navCtrl) {
        var _this = this;
        this.ticketService = ticketService;
        this.loadingCtrl = loadingCtrl;
        this.router = router;
        this.modalController = modalController;
        this.userService = userService;
        this.alertService = alertService;
        this.push = push;
        this.transService = transService;
        this.storage = storage;
        this.device = device;
        this.alertCtrl = alertCtrl;
        this._navCtrl = _navCtrl;
        this.loading = true;
        this.options = {
            android: {},
            ios: {},
        };
        this.pushObject = this.push.init(this.options);
        this.pushObject.on('registration')
            .subscribe(function (registration) {
            _this.registrationId = registration.registrationId;
        }, function (err) {
            // this.alertService.presentAlert('Error from push', err);
        });
        this.pushObject.on('notification').subscribe(function (notification) {
            _this.loading = false;
            console.log(JSON.stringify(notification));
            // alert(JSON.stringify(notification.additionalData.id));
            if (notification.additionalData.type == 'discussion') {
                _this.presentAlert(notification.title + " " + notification.message);
                console.log('discussion');
                if (notification.additionalData.id) {
                    console.log('discussion with id');
                    _this._navCtrl.navigateForward("/rentals-notice-details", {
                        queryParams: {
                            did: notification.additionalData.id
                        }
                    });
                }
                else {
                    console.log('discussion without id');
                    _this._navCtrl.navigateForward("/rentals-notice-board");
                }
            }
            else if (notification.additionalData.type == 'ticket') {
                _this.presentAlert(notification.title);
                if (notification.additionalData.id) {
                    _this._navCtrl.navigateForward("/rentals-ticket-details", {
                        queryParams: {
                            ticketId: notification.additionalData.id
                        }
                    });
                }
                else {
                    _this._navCtrl.navigateForward('/rentals-tickets');
                }
            }
            // else if (notification.additionalData.type == 'approval') {
            //   this.router.navigateByUrl(`/rentals-user-approval`);
            // } else if (notification.additionalData.type == 'estimate') {
            //   this.router.navigateByUrl(`/rentals-ticket-details?eid=${notification.additionalData.id}`);
            // }
        }, function (err) {
            // alert(JSON.stringify(err))
        });
    }
    HomePage.prototype.presentLoading = function () {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function () {
            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.loadingCtrl.create({
                            spinner: 'crescent'
                        }).then(function (loading) {
                            loading.present();
                        })];
                    case 1:
                        _a.sent();
                        return [2 /*return*/];
                }
            });
        });
    };
    HomePage.prototype.ionViewDidEnter = function () {
        this.loading == true ? this.presentLoading() : '';
        this.getTicketStats();
    };
    HomePage.prototype.ngOnInit = function () {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function () {
            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                this.getUserDetails();
                return [2 /*return*/];
            });
        });
    };
    HomePage.prototype.openCreateNoticeModal = function () {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function () {
            var modal;
            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.modalController.create({
                            component: _modals_create_notice_create_notice_component__WEBPACK_IMPORTED_MODULE_7__["CreateNoticeComponent"],
                        })];
                    case 1:
                        modal = _a.sent();
                        return [4 /*yield*/, modal.present()];
                    case 2: return [2 /*return*/, _a.sent()];
                }
            });
        });
    };
    HomePage.prototype.presentAlert = function (header) {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function () {
            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.alertCtrl.create({
                            header: header,
                            // message: message,
                            cssClass: 'notifivation-alert',
                            buttons: [{
                                    text: 'OK',
                                    cssClass: 'width-100-percent alert-button-inner.sc-ion-alert-md',
                                }]
                        }).then(function (alert) {
                            alert.present();
                        })];
                    case 1:
                        _a.sent();
                        return [2 /*return*/];
                }
            });
        });
    };
    HomePage.prototype.getRoundedTime = function () {
        var d = new Date();
        // alert(d)
        var ratio = d.getMinutes() / 60;
        // alert(ratio)
        // Past 30 min mark, return epoch at +1 hours and 0 minutes
        if (ratio > 0.5) {
            // alert((d.getHours() + 1) * 3600)
            return (d.getHours() + 1) * 3600;
        }
        // Return epoch at 30 minutes past current hour
        // alert((d.getHours() * 3600) + 1800)
        return (d.getHours() * 3600) + 1800;
    };
    HomePage.prototype.getUserDetails = function () {
        var _this = this;
        this.userService.getUserById(window.localStorage.getItem('user_id'))
            .subscribe(function (data) {
            _this.userDetails = data;
            console.log(_this.userDetails);
            _this.userDetails.businessAppDevice = {
                id: '',
                pushToken: _this.registrationId,
                fcmToken: true,
                deviceId: _this.device.uuid,
                platform: _this.device.platform ? _this.device.platform.toLowerCase() : '',
                newApp: true
            };
            console.log('After', _this.userDetails);
            _this.pushNotifications();
            if (_this.userDetails.firstName) {
                window.localStorage.setItem('firstName', _this.userDetails.firstName);
                _this.storage.set('firstName', _this.userDetails.firstName);
            }
            if (_this.userDetails.lastName) {
                window.localStorage.setItem('lastName', _this.userDetails.lastName);
                _this.storage.set('lastName', _this.userDetails.lastName);
            }
        }, function (err) {
            console.log('error getting user details');
        });
    };
    HomePage.prototype.navigate = function (path) {
        this.router.navigateByUrl("/" + window.localStorage.getItem('appSrc') + "-" + path);
    };
    HomePage.prototype.getTicketStats = function () {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function () {
            var _this = this;
            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                this.ticketService.getTicketStats()
                    .subscribe(function (data) {
                    _this.loading == true ? _this.loadingCtrl.dismiss() : '';
                    _this.loading = false;
                    _this.ticketStats = data;
                    console.log(_this.ticketStats);
                }, function (err) {
                    _this.loading == true ? _this.loadingCtrl.dismiss() : '';
                    _this.alertService.presentAlert(_this.transService.getTranslatedData('alert-title'), err.error.error);
                });
                return [2 /*return*/];
            });
        });
    };
    HomePage.prototype.pushNotifications = function () {
        if (this.registrationId) {
            this.userService.updateUser(this.userDetails).subscribe(function (data) {
                // console.log(data);
                // alert('success');
            }, function (err) {
                // alert('Error')
                console.log(err);
            });
        }
    };
    HomePage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-home',
            template: __webpack_require__(/*! ./home.page.html */ "./src/app/Rentals Management/pages/home/home.page.html"),
            styles: [__webpack_require__(/*! ./home.page.scss */ "./src/app/Rentals Management/pages/home/home.page.scss")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_services_ticket_service__WEBPACK_IMPORTED_MODULE_2__["TicketService"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["LoadingController"],
            _angular_router__WEBPACK_IMPORTED_MODULE_4__["Router"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["ModalController"],
            _services_rentals_user_service__WEBPACK_IMPORTED_MODULE_10__["RentalsUserService"],
            src_app_common_services_alert_service_service__WEBPACK_IMPORTED_MODULE_6__["AlertServiceService"],
            _ionic_native_push_ngx__WEBPACK_IMPORTED_MODULE_5__["Push"],
            src_app_common_services_translate_translate_service_service__WEBPACK_IMPORTED_MODULE_8__["translateService"],
            _ionic_storage__WEBPACK_IMPORTED_MODULE_9__["Storage"],
            _ionic_native_device_ngx__WEBPACK_IMPORTED_MODULE_11__["Device"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["AlertController"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["NavController"]])
    ], HomePage);
    return HomePage;
}());



/***/ })

}]);
//# sourceMappingURL=Rentals-Management-pages-home-home-module.js.map