(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["Rentals-Management-pages-verifyitaccountspage-verifyitaccountspage-module"],{

/***/ "./src/app/Rentals Management/pages/verifyitaccountspage/verifyitaccountspage.html":
/*!*****************************************************************************************!*\
  !*** ./src/app/Rentals Management/pages/verifyitaccountspage/verifyitaccountspage.html ***!
  \*****************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ion-header no-border>\r\n  <ion-toolbar color=\"primary\">\r\n    <ion-buttons slot=\"start\">\r\n      <ion-menu-button></ion-menu-button>\r\n    </ion-buttons>\r\n    <!-- <ion-buttons slot=\"end\" expand=\"full\" class=\"ion-button\" (click)=\"openScanner()\">\r\n      <ion-button style=\"color: black\">\r\n          <img style=\"width: 15px;\r\n            height: 15px;\" src=\"../../../../assets/icons.png\" width=\"30px\" height=\"30px\"/>\r\n      </ion-button>\r\n    </ion-buttons> -->\r\n\r\n    <ion-title>Account</ion-title>\r\n  </ion-toolbar>\r\n\r\n</ion-header>\r\n\r\n\r\n<ion-content *ngIf=\"this.accountdetail.name && this.accountdetail.email\" style=\"top: 3vh;\" fullscreen>\r\n<ion-row>\r\n  <!-- <ion-col>\r\n\r\n  \r\n \r\n        <ion-card class=\"myCard\">\r\n          <div class=\"myOverlay\">\r\n        div class=\"card-title\">{{item.title}}</div> \r\n          </div>\r\n        </ion-card>\r\n    \r\n\r\n\r\n   \r\n\r\n  </ion-col> -->\r\n</ion-row>\r\n  <ion-row>\r\n    <ion-col size=\"3\">\r\n      Name:\r\n    </ion-col>\r\n    <ion-col style=\"text-align: left;\">\r\n      {{this.accountdetail.name}}\r\n    </ion-col>\r\n  </ion-row>\r\n  <ion-row>\r\n    <ion-col size=\"3\">\r\n      Email:\r\n    </ion-col>\r\n    <ion-col style=\"text-align: left;\">\r\n      {{this.accountdetail.email}}\r\n    </ion-col>\r\n  </ion-row>\r\n  <ion-row>\r\n    <ion-col size=\"3\">\r\n      Mobile:\r\n    </ion-col>\r\n    <ion-col style=\"text-align: left;\">\r\n      {{this.accountdetail.mobile}}\r\n    </ion-col>\r\n  </ion-row>\r\n\r\n</ion-content>\r\n<ion-content *ngIf=\"!(this.accountdetail.name && this.accountdetail.email)\">\r\n  <p style=\"    text-align: center;\r\n  margin-top: 10vh;\">\r\n\r\n    Please Sign in to see your account details.\r\n  </p>\r\n</ion-content>"

/***/ }),

/***/ "./src/app/Rentals Management/pages/verifyitaccountspage/verifyitaccountspage.module.ts":
/*!**********************************************************************************************!*\
  !*** ./src/app/Rentals Management/pages/verifyitaccountspage/verifyitaccountspage.module.ts ***!
  \**********************************************************************************************/
/*! exports provided: VerifyitAccountsPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "VerifyitAccountsPageModule", function() { return VerifyitAccountsPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _ApplicationPageModule__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../ApplicationPageModule */ "./src/app/Rentals Management/ApplicationPageModule.ts");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _modals_refundmodal_refundmodal_component__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../../modals/refundmodal/refundmodal.component */ "./src/app/Rentals Management/modals/refundmodal/refundmodal.component.ts");
/* harmony import */ var _modals_privacypolicy_privacypolicy_component__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../../modals/privacypolicy/privacypolicy.component */ "./src/app/Rentals Management/modals/privacypolicy/privacypolicy.component.ts");
/* harmony import */ var _modals_termsandcondition_termsandcondition_component__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ../../modals/termsandcondition/termsandcondition.component */ "./src/app/Rentals Management/modals/termsandcondition/termsandcondition.component.ts");
/* harmony import */ var _verifyitaccountspage__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ./verifyitaccountspage */ "./src/app/Rentals Management/pages/verifyitaccountspage/verifyitaccountspage.ts");







// import { BarcodeScanner } from '@ionic-native/barcode-scanner/ngx';
// import { NailaAccountPage } from './nailaaccountpage';




var routes = [
    {
        path: '',
        component: _verifyitaccountspage__WEBPACK_IMPORTED_MODULE_10__["VerifyitAccountsPage"]
    }
];
var VerifyitAccountsPageModule = /** @class */ (function () {
    function VerifyitAccountsPageModule() {
    }
    VerifyitAccountsPageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_2__["NgModule"])({
            entryComponents: [],
            imports: [
                _angular_common__WEBPACK_IMPORTED_MODULE_3__["CommonModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormsModule"],
                _ApplicationPageModule__WEBPACK_IMPORTED_MODULE_1__["ApplicationPageModule"],
                _ionic_angular__WEBPACK_IMPORTED_MODULE_6__["IonicModule"],
                _angular_router__WEBPACK_IMPORTED_MODULE_5__["RouterModule"].forChild(routes)
            ],
            providers: [
                // BarcodeScanner,
                _modals_refundmodal_refundmodal_component__WEBPACK_IMPORTED_MODULE_7__["RefundModalComponent"],
                _modals_privacypolicy_privacypolicy_component__WEBPACK_IMPORTED_MODULE_8__["PrivacyPolicyModalComponent"],
                _modals_termsandcondition_termsandcondition_component__WEBPACK_IMPORTED_MODULE_9__["TermsModalComponent"]
            ],
            declarations: [_verifyitaccountspage__WEBPACK_IMPORTED_MODULE_10__["VerifyitAccountsPage"],]
        })
    ], VerifyitAccountsPageModule);
    return VerifyitAccountsPageModule;
}());



/***/ }),

/***/ "./src/app/Rentals Management/pages/verifyitaccountspage/verifyitaccountspage.scss":
/*!*****************************************************************************************!*\
  !*** ./src/app/Rentals Management/pages/verifyitaccountspage/verifyitaccountspage.scss ***!
  \*****************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "img {\n  width: 100%;\n  height: 100%; }\n\n.myCard {\n  position: relative; }\n\n.myOverlay {\n  width: 100%;\n  height: 22px;\n  position: absolute;\n  z-index: 99;\n  bottom: 0px;\n  opacity: 0.5;\n  background: #000;\n  color: #fff; }\n\nion-avatar {\n  --border-radius: unset !important; }\n\nion-item {\n  --border-width: 0px 0px 0.1px 0px !important;\n  --border-color: #F0F0F0 !important; }\n\n.myCard {\n  position: relative;\n  height: 20vh;\n  width: 100%;\n  margin-left: 0px;\n  margin-top: 0px;\n  z-index: 0; }\n\n.myOverlay {\n  width: 100%;\n  height: 22px;\n  position: absolute;\n  z-index: 99;\n  bottom: 0px;\n  background: #000;\n  background: linear-gradient(to bottom, transparent, black);\n  color: #fff; }\n\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvUmVudGFscyBNYW5hZ2VtZW50L3BhZ2VzL3ZlcmlmeWl0YWNjb3VudHNwYWdlL0Q6XFxuYXZqb3RcXHZlcmlmeS9zcmNcXGFwcFxcUmVudGFscyBNYW5hZ2VtZW50XFxwYWdlc1xcdmVyaWZ5aXRhY2NvdW50c3BhZ2VcXHZlcmlmeWl0YWNjb3VudHNwYWdlLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDRSxXQUFVO0VBQ1YsWUFBVyxFQUFBOztBQUdiO0VBQ0Usa0JBQWlCLEVBQUE7O0FBSW5CO0VBQ0UsV0FBVztFQUNYLFlBQVk7RUFDWixrQkFBa0I7RUFDbEIsV0FBVztFQUNYLFdBQVc7RUFDWCxZQUFZO0VBQ1osZ0JBQWdCO0VBQ2hCLFdBQVcsRUFBQTs7QUFHYjtFQUNFLGlDQUFnQixFQUFBOztBQUdsQjtFQUNFLDRDQUFlO0VBQ2Ysa0NBQWUsRUFBQTs7QUFTakI7RUFDRSxrQkFBaUI7RUFDakIsWUFBWTtFQUNaLFdBQVc7RUFDWCxnQkFBZ0I7RUFDaEIsZUFBZTtFQUNmLFVBQVUsRUFBQTs7QUFJWjtFQUNFLFdBQVc7RUFDWCxZQUFZO0VBQ1osa0JBQWtCO0VBQ2xCLFdBQVc7RUFDWCxXQUFXO0VBQ1gsZ0JBQWdCO0VBQ2hCLDBEQUF5RDtFQUN6RCxXQUFXLEVBQUEiLCJmaWxlIjoic3JjL2FwcC9SZW50YWxzIE1hbmFnZW1lbnQvcGFnZXMvdmVyaWZ5aXRhY2NvdW50c3BhZ2UvdmVyaWZ5aXRhY2NvdW50c3BhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbImltZ3tcclxuICB3aWR0aDoxMDAlO1xyXG4gIGhlaWdodDoxMDAlO1xyXG59XHJcblxyXG4ubXlDYXJke1xyXG4gIHBvc2l0aW9uOnJlbGF0aXZlO1xyXG5cclxufVxyXG5cclxuLm15T3ZlcmxheXtcclxuICB3aWR0aDogMTAwJTtcclxuICBoZWlnaHQ6IDIycHg7XHJcbiAgcG9zaXRpb246IGFic29sdXRlO1xyXG4gIHotaW5kZXg6IDk5O1xyXG4gIGJvdHRvbTogMHB4O1xyXG4gIG9wYWNpdHk6IDAuNTtcclxuICBiYWNrZ3JvdW5kOiAjMDAwO1xyXG4gIGNvbG9yOiAjZmZmO1xyXG5cclxufVxyXG5pb24tYXZhdGFye1xyXG4gIC0tYm9yZGVyLXJhZGl1czogdW5zZXQgIWltcG9ydGFudDtcclxufVxyXG5cclxuaW9uLWl0ZW17XHJcbiAgLS1ib3JkZXItd2lkdGg6IDBweCAwcHggMC4xcHggMHB4ICFpbXBvcnRhbnQ7XHJcbiAgLS1ib3JkZXItY29sb3I6ICNGMEYwRjAgIWltcG9ydGFudDtcclxufVxyXG5cclxuXHJcbi8vIGlvbi10b29sYmFye1xyXG4vLyAgIGJvcmRlci1ib3R0b20tbGVmdC1yYWRpdXM6IDI1cHg7XHJcbi8vICAgICBib3JkZXItYm90dG9tLXJpZ2h0LXJhZGl1czogMjVweDtcclxuLy8gfVxyXG5cclxuLm15Q2FyZHtcclxuICBwb3NpdGlvbjpyZWxhdGl2ZTtcclxuICBoZWlnaHQ6IDIwdmg7XHJcbiAgd2lkdGg6IDEwMCU7XHJcbiAgbWFyZ2luLWxlZnQ6IDBweDtcclxuICBtYXJnaW4tdG9wOiAwcHg7XHJcbiAgei1pbmRleDogMDtcclxuXHJcbn1cclxuXHJcbi5teU92ZXJsYXl7XHJcbiAgd2lkdGg6IDEwMCU7XHJcbiAgaGVpZ2h0OiAyMnB4O1xyXG4gIHBvc2l0aW9uOiBhYnNvbHV0ZTtcclxuICB6LWluZGV4OiA5OTtcclxuICBib3R0b206IDBweDtcclxuICBiYWNrZ3JvdW5kOiAjMDAwO1xyXG4gIGJhY2tncm91bmQ6IGxpbmVhci1ncmFkaWVudCh0byBib3R0b20sdHJhbnNwYXJlbnQsIGJsYWNrKTtcclxuICBjb2xvcjogI2ZmZjtcclxuXHJcbn0iXX0= */"

/***/ }),

/***/ "./src/app/Rentals Management/pages/verifyitaccountspage/verifyitaccountspage.ts":
/*!***************************************************************************************!*\
  !*** ./src/app/Rentals Management/pages/verifyitaccountspage/verifyitaccountspage.ts ***!
  \***************************************************************************************/
/*! exports provided: VerifyitAccountsPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "VerifyitAccountsPage", function() { return VerifyitAccountsPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _modals_refundmodal_refundmodal_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../modals/refundmodal/refundmodal.component */ "./src/app/Rentals Management/modals/refundmodal/refundmodal.component.ts");
/* harmony import */ var _modals_privacypolicy_privacypolicy_component__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../modals/privacypolicy/privacypolicy.component */ "./src/app/Rentals Management/modals/privacypolicy/privacypolicy.component.ts");
/* harmony import */ var _modals_termsandcondition_termsandcondition_component__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../../modals/termsandcondition/termsandcondition.component */ "./src/app/Rentals Management/modals/termsandcondition/termsandcondition.component.ts");







// import { Slides } from 'ionic-angular';
var VerifyitAccountsPage = /** @class */ (function () {
    // sliderConfig = {
    //   slidesPerView: 1.2,
    //   spaceBetween: 5,
    //   // centeredSlides: true
    // };
    // sliderConfig2 = {
    //   slidesPerView: 3.2,
    //   spaceBetween: 5,
    //   // centeredSlides: true
    // };
    // public searchTerm: string = "";
    // public items: any;
    function VerifyitAccountsPage(alertController, refundmodal, modalController, route) {
        this.alertController = alertController;
        this.refundmodal = refundmodal;
        this.modalController = modalController;
        this.route = route;
        this.accountdetail = {
            name: '',
            email: '',
            mobile: ''
        };
        // this.items = [
        //   { title: "one" },
        //   { title: "two" },
        //   { title: "three" },
        //   { title: "four" },
        //   { title: "five" },
        //   { title: "six" }
        // ];
    }
    VerifyitAccountsPage.prototype.ngOnInit = function () {
        var slug = this.route.snapshot.paramMap.get('slug');
        var url = "https://devdactic.com/wp-json/wp/v2/posts?slug=" + slug + "&_embed";
        this.accountdetail.name = window.localStorage.getItem('name');
        this.accountdetail.email = window.localStorage.getItem('email');
        this.accountdetail.mobile = window.localStorage.getItem('mobile');
        // this.setFilteredItems();
    };
    //   setFilteredItems() {
    //     this.items = this.filterItems(this.searchTerm);
    //   }
    //   filterItems(searchTerm) {
    //     return this.items.filter(item => {
    //       return item.title.toLowerCase().indexOf(searchTerm.toLowerCase()) > -1;
    //     });
    //   }
    // a=false;
    VerifyitAccountsPage.prototype.presentAlert = function () {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function () {
            var alert;
            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.alertController.create({
                            subHeader: 'Whatsapp',
                            message: 'You can contact Naila Support Team on 7624943335 number.',
                            buttons: ['OK']
                        })];
                    case 1:
                        alert = _a.sent();
                        return [4 /*yield*/, alert.present()];
                    case 2:
                        _a.sent();
                        return [2 /*return*/];
                }
            });
        });
    };
    // async presentRefudAlert() {
    //   const alert = await this.alertController.create({
    //     cssClass: 'custom-refund-alert',
    //     message: 'You can contact Naila Support Team on 7624943335 number.',
    //     buttons: ['OK']
    //   });
    //   await alert.present();
    // }
    VerifyitAccountsPage.prototype.openCreateRefundModal = function () {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function () {
            var modal;
            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.modalController.create({
                            component: _modals_refundmodal_refundmodal_component__WEBPACK_IMPORTED_MODULE_4__["RefundModalComponent"],
                        })];
                    case 1:
                        modal = _a.sent();
                        return [4 /*yield*/, modal.present()];
                    case 2: return [2 /*return*/, _a.sent()];
                }
            });
        });
    };
    VerifyitAccountsPage.prototype.openPrivacyPolicyModal = function () {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function () {
            var modal;
            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.modalController.create({
                            component: _modals_privacypolicy_privacypolicy_component__WEBPACK_IMPORTED_MODULE_5__["PrivacyPolicyModalComponent"],
                        })];
                    case 1:
                        modal = _a.sent();
                        return [4 /*yield*/, modal.present()];
                    case 2: return [2 /*return*/, _a.sent()];
                }
            });
        });
    };
    VerifyitAccountsPage.prototype.TandCModal = function () {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function () {
            var modal;
            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.modalController.create({
                            component: _modals_termsandcondition_termsandcondition_component__WEBPACK_IMPORTED_MODULE_6__["TermsModalComponent"],
                        })];
                    case 1:
                        modal = _a.sent();
                        return [4 /*yield*/, modal.present()];
                    case 2: return [2 /*return*/, _a.sent()];
                }
            });
        });
    };
    // popOver.onDidDismiss().then(data => {
    //   // if (data.data) {
    //   //   if (data.data.val == 'approve') {
    //   //     // this.approvalUser(id)
    //   //   } else if (data.data.val == 'reject') {
    //   //     // this.rejectUser(id, data.data.notes)
    //   //   }
    //   // }
    // })
    // return await popOver.present()
    VerifyitAccountsPage.prototype.dismiss = function () {
        // using the injected ModalController this page
        // can "dismiss" itself and optionally pass back data
        this.modalController.dismiss({
            'dismissed': true
        });
    };
    VerifyitAccountsPage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-verifyitaccountspage',
            template: __webpack_require__(/*! ./verifyitaccountspage.html */ "./src/app/Rentals Management/pages/verifyitaccountspage/verifyitaccountspage.html"),
            styles: [__webpack_require__(/*! ./verifyitaccountspage.scss */ "./src/app/Rentals Management/pages/verifyitaccountspage/verifyitaccountspage.scss")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_ionic_angular__WEBPACK_IMPORTED_MODULE_2__["AlertController"],
            _modals_refundmodal_refundmodal_component__WEBPACK_IMPORTED_MODULE_4__["RefundModalComponent"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["ModalController"],
            _angular_router__WEBPACK_IMPORTED_MODULE_3__["ActivatedRoute"]])
    ], VerifyitAccountsPage);
    return VerifyitAccountsPage;
}());



/***/ })

}]);
//# sourceMappingURL=Rentals-Management-pages-verifyitaccountspage-verifyitaccountspage-module.js.map