(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["Rentals-Management-pages-nailaaccountpage-nailaaccountpage-module"],{

/***/ "./src/app/Rentals Management/pages/nailaaccountpage/nailaaccountpage.html":
/*!*********************************************************************************!*\
  !*** ./src/app/Rentals Management/pages/nailaaccountpage/nailaaccountpage.html ***!
  \*********************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ion-header no-border>\r\n  <ion-toolbar color=\"primary\">\r\n    <ion-buttons slot=\"start\">\r\n      <ion-menu-button></ion-menu-button>\r\n    </ion-buttons>\r\n    <!-- <ion-buttons slot=\"end\" expand=\"full\" class=\"ion-button\" (click)=\"openScanner()\">\r\n      <ion-button style=\"color: black\">\r\n          <img style=\"width: 15px;\r\n            height: 15px;\" src=\"../../../../assets/icons.png\" width=\"30px\" height=\"30px\"/>\r\n      </ion-button>\r\n    </ion-buttons> -->\r\n\r\n    <ion-title>Account</ion-title>\r\n  </ion-toolbar>\r\n\r\n</ion-header>\r\n\r\n\r\n<ion-content fullscreen>\r\n  <ion-list>\r\n    <!-- <ion-item lines=\"none\">\r\n      <ion-avatar style=\"    width: 15px;\r\n          height: 18px;\r\n          margin-right: 10px;\" slot=\"start\">\r\n        <img style=\"width: 13px;\r\n            height: auto;\" src=\"assets/imgs/social.svg\">\r\n      </ion-avatar>\r\n      <ion-label class=\"margin-top-0 margin-bottom-0\">\r\n\r\n        <p  class=\"margin-bottom-0 font-12 text-black\">Profile</p>\r\n      </ion-label>\r\n    </ion-item> -->\r\n\r\n    <ion-item (click)=\"presentAlert()\" lines=\"none\">\r\n      <ion-avatar style=\"width: 15px;\r\n            height: 18px;\r\n            margin-right: 10px;\" slot=\"start\">\r\n        <img style=\"width: 13px;\r\n              height: auto;\" src=\"assets/imgs/what.svg\">\r\n      </ion-avatar>\r\n      <ion-label>\r\n        <p class=\"margin-bottom-0 font-12 text-black\">Whatsapp</p>\r\n      </ion-label>\r\n    </ion-item>\r\n    <ion-item (click)=\"TandCModal()\" lines=\"none\">\r\n      <ion-avatar style=\"    width: 15px;\r\n          height: 18px;\r\n          margin-right: 10px;\" slot=\"start\">\r\n        <img style=\"width: 13px;\r\n            height: auto;\" src=\"assets/imgs/tandc.svg\">\r\n      </ion-avatar>\r\n      <ion-label>\r\n        <p class=\"margin-bottom-0 font-12 text-black\">Terms & conditions</p>\r\n      </ion-label>\r\n    </ion-item>\r\n\r\n\r\n     \r\n\r\n    <ion-item (click)=\"openPrivacyPolicyModal()\" lines=\"none\">\r\n      <ion-avatar style=\"    width: 15px;\r\n          height: 18px;\r\n          margin-right: 10px;\" slot=\"start\">\r\n        <img style=\"width: 13px;\r\n            height: auto;\" src=\"assets/imgs/prohibition.svg\">\r\n      </ion-avatar>\r\n      <ion-label>\r\n        <p class=\"margin-bottom-0 font-12 text-black\">Privacy Policy</p>\r\n      </ion-label>\r\n    </ion-item>\r\n\r\n    <!-- <ion-item lines=\"none\">\r\n      <ion-avatar style=\"    width: 15px;\r\n          height: 18px;\r\n          margin-right: 10px;\" slot=\"start\">\r\n        <img style=\"width: 13px;\r\n            height: auto;\" src=\"assets/imgs/party.svg\">\r\n      </ion-avatar>\r\n      <ion-label>\r\n        <p class=\"margin-bottom-0 font-12 text-black\">Invite a friend</p>\r\n      </ion-label>\r\n    </ion-item> -->\r\n\r\n    <ion-item (click)=\"openCreateRefundModal()\" lines=\"none\">\r\n      <ion-avatar style=\"    width: 15px;\r\n          height: 18px;\r\n          margin-right: 10px;\" slot=\"start\">\r\n        <img style=\"width: 13px;\r\n            height: auto;\" src=\"assets/imgs/customerservice.svg\">\r\n      </ion-avatar>\r\n      <ion-label>\r\n        <p class=\"margin-bottom-0 font-12 text-black\">Refund policy</p>\r\n      </ion-label>\r\n    </ion-item>\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n    <!-- <ion-item lines=\"none\">\r\n      <ion-avatar style=\"    width: 15px;\r\n          height: 18px;\r\n          margin-right: 10px;\" slot=\"start\">\r\n        <img style=\"width: 13px;\r\n            height: auto;\" src=\"assets/imgs/logout.png\">\r\n      </ion-avatar>\r\n      <ion-label>\r\n        <p class=\"margin-bottom-0 font-12 text-black\">Logout</p>\r\n      </ion-label>\r\n    </ion-item> -->\r\n  </ion-list>\r\n\r\n\r\n</ion-content>"

/***/ }),

/***/ "./src/app/Rentals Management/pages/nailaaccountpage/nailaaccountpage.module.ts":
/*!**************************************************************************************!*\
  !*** ./src/app/Rentals Management/pages/nailaaccountpage/nailaaccountpage.module.ts ***!
  \**************************************************************************************/
/*! exports provided: NailaAccountPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "NailaAccountPageModule", function() { return NailaAccountPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _ApplicationPageModule__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../ApplicationPageModule */ "./src/app/Rentals Management/ApplicationPageModule.ts");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _modals_create_notice_create_notice_component__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../../modals/create-notice/create-notice.component */ "./src/app/Rentals Management/modals/create-notice/create-notice.component.ts");
/* harmony import */ var _nailaaccountpage__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./nailaaccountpage */ "./src/app/Rentals Management/pages/nailaaccountpage/nailaaccountpage.ts");
/* harmony import */ var _modals_refundmodal_refundmodal_component__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ../../modals/refundmodal/refundmodal.component */ "./src/app/Rentals Management/modals/refundmodal/refundmodal.component.ts");
/* harmony import */ var _modals_privacypolicy_privacypolicy_component__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ../../modals/privacypolicy/privacypolicy.component */ "./src/app/Rentals Management/modals/privacypolicy/privacypolicy.component.ts");
/* harmony import */ var _modals_termsandcondition_termsandcondition_component__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ../../modals/termsandcondition/termsandcondition.component */ "./src/app/Rentals Management/modals/termsandcondition/termsandcondition.component.ts");








// import { BarcodeScanner } from '@ionic-native/barcode-scanner/ngx';




var routes = [
    {
        path: '',
        component: _nailaaccountpage__WEBPACK_IMPORTED_MODULE_8__["NailaAccountPage"]
    }
];
var NailaAccountPageModule = /** @class */ (function () {
    function NailaAccountPageModule() {
    }
    NailaAccountPageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_2__["NgModule"])({
            entryComponents: [_modals_create_notice_create_notice_component__WEBPACK_IMPORTED_MODULE_7__["CreateNoticeComponent"], _modals_refundmodal_refundmodal_component__WEBPACK_IMPORTED_MODULE_9__["RefundModalComponent"], _modals_privacypolicy_privacypolicy_component__WEBPACK_IMPORTED_MODULE_10__["PrivacyPolicyModalComponent"], _modals_termsandcondition_termsandcondition_component__WEBPACK_IMPORTED_MODULE_11__["TermsModalComponent"]],
            imports: [
                _angular_common__WEBPACK_IMPORTED_MODULE_3__["CommonModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormsModule"],
                _ApplicationPageModule__WEBPACK_IMPORTED_MODULE_1__["ApplicationPageModule"],
                _ionic_angular__WEBPACK_IMPORTED_MODULE_6__["IonicModule"],
                _angular_router__WEBPACK_IMPORTED_MODULE_5__["RouterModule"].forChild(routes)
            ],
            providers: [
                // BarcodeScanner,
                _modals_refundmodal_refundmodal_component__WEBPACK_IMPORTED_MODULE_9__["RefundModalComponent"],
                _modals_privacypolicy_privacypolicy_component__WEBPACK_IMPORTED_MODULE_10__["PrivacyPolicyModalComponent"],
                _modals_termsandcondition_termsandcondition_component__WEBPACK_IMPORTED_MODULE_11__["TermsModalComponent"]
            ],
            declarations: [_nailaaccountpage__WEBPACK_IMPORTED_MODULE_8__["NailaAccountPage"], _modals_refundmodal_refundmodal_component__WEBPACK_IMPORTED_MODULE_9__["RefundModalComponent"], _modals_privacypolicy_privacypolicy_component__WEBPACK_IMPORTED_MODULE_10__["PrivacyPolicyModalComponent"], _modals_termsandcondition_termsandcondition_component__WEBPACK_IMPORTED_MODULE_11__["TermsModalComponent"]]
        })
    ], NailaAccountPageModule);
    return NailaAccountPageModule;
}());



/***/ }),

/***/ "./src/app/Rentals Management/pages/nailaaccountpage/nailaaccountpage.scss":
/*!*********************************************************************************!*\
  !*** ./src/app/Rentals Management/pages/nailaaccountpage/nailaaccountpage.scss ***!
  \*********************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "img {\n  width: 100%;\n  height: 100%; }\n\n.myCard {\n  position: relative; }\n\n.myOverlay {\n  width: 100%;\n  height: 22px;\n  position: absolute;\n  z-index: 99;\n  bottom: 0px;\n  opacity: 0.5;\n  background: #000;\n  color: #fff; }\n\nion-avatar {\n  --border-radius: unset !important; }\n\nion-item {\n  --border-width: 0px 0px 0.1px 0px !important;\n  --border-color: #F0F0F0 !important; }\n\nion-toolbar {\n  border-bottom-left-radius: 25px;\n  border-bottom-right-radius: 25px; }\n\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvUmVudGFscyBNYW5hZ2VtZW50L3BhZ2VzL25haWxhYWNjb3VudHBhZ2UvRDpcXG5hdmpvdFxcdmVyaWZ5L3NyY1xcYXBwXFxSZW50YWxzIE1hbmFnZW1lbnRcXHBhZ2VzXFxuYWlsYWFjY291bnRwYWdlXFxuYWlsYWFjY291bnRwYWdlLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDRSxXQUFVO0VBQ1YsWUFBVyxFQUFBOztBQUdiO0VBQ0Usa0JBQWlCLEVBQUE7O0FBSW5CO0VBQ0UsV0FBVztFQUNYLFlBQVk7RUFDWixrQkFBa0I7RUFDbEIsV0FBVztFQUNYLFdBQVc7RUFDWCxZQUFZO0VBQ1osZ0JBQWdCO0VBQ2hCLFdBQVcsRUFBQTs7QUFHYjtFQUNFLGlDQUFnQixFQUFBOztBQUdsQjtFQUNFLDRDQUFlO0VBQ2Ysa0NBQWUsRUFBQTs7QUFHakI7RUFDRSwrQkFBK0I7RUFDN0IsZ0NBQWdDLEVBQUEiLCJmaWxlIjoic3JjL2FwcC9SZW50YWxzIE1hbmFnZW1lbnQvcGFnZXMvbmFpbGFhY2NvdW50cGFnZS9uYWlsYWFjY291bnRwYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyJpbWd7XHJcbiAgd2lkdGg6MTAwJTtcclxuICBoZWlnaHQ6MTAwJTtcclxufVxyXG5cclxuLm15Q2FyZHtcclxuICBwb3NpdGlvbjpyZWxhdGl2ZTtcclxuXHJcbn1cclxuXHJcbi5teU92ZXJsYXl7XHJcbiAgd2lkdGg6IDEwMCU7XHJcbiAgaGVpZ2h0OiAyMnB4O1xyXG4gIHBvc2l0aW9uOiBhYnNvbHV0ZTtcclxuICB6LWluZGV4OiA5OTtcclxuICBib3R0b206IDBweDtcclxuICBvcGFjaXR5OiAwLjU7XHJcbiAgYmFja2dyb3VuZDogIzAwMDtcclxuICBjb2xvcjogI2ZmZjtcclxuXHJcbn1cclxuaW9uLWF2YXRhcntcclxuICAtLWJvcmRlci1yYWRpdXM6IHVuc2V0ICFpbXBvcnRhbnQ7XHJcbn1cclxuXHJcbmlvbi1pdGVte1xyXG4gIC0tYm9yZGVyLXdpZHRoOiAwcHggMHB4IDAuMXB4IDBweCAhaW1wb3J0YW50O1xyXG4gIC0tYm9yZGVyLWNvbG9yOiAjRjBGMEYwICFpbXBvcnRhbnQ7XHJcbn1cclxuXHJcbmlvbi10b29sYmFye1xyXG4gIGJvcmRlci1ib3R0b20tbGVmdC1yYWRpdXM6IDI1cHg7XHJcbiAgICBib3JkZXItYm90dG9tLXJpZ2h0LXJhZGl1czogMjVweDtcclxufSJdfQ== */"

/***/ }),

/***/ "./src/app/Rentals Management/pages/nailaaccountpage/nailaaccountpage.ts":
/*!*******************************************************************************!*\
  !*** ./src/app/Rentals Management/pages/nailaaccountpage/nailaaccountpage.ts ***!
  \*******************************************************************************/
/*! exports provided: NailaAccountPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "NailaAccountPage", function() { return NailaAccountPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _modals_refundmodal_refundmodal_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../modals/refundmodal/refundmodal.component */ "./src/app/Rentals Management/modals/refundmodal/refundmodal.component.ts");
/* harmony import */ var _modals_privacypolicy_privacypolicy_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../modals/privacypolicy/privacypolicy.component */ "./src/app/Rentals Management/modals/privacypolicy/privacypolicy.component.ts");
/* harmony import */ var _modals_termsandcondition_termsandcondition_component__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../modals/termsandcondition/termsandcondition.component */ "./src/app/Rentals Management/modals/termsandcondition/termsandcondition.component.ts");






// import { Slides } from 'ionic-angular';
var NailaAccountPage = /** @class */ (function () {
    // sliderConfig = {
    //   slidesPerView: 1.2,
    //   spaceBetween: 5,
    //   // centeredSlides: true
    // };
    // sliderConfig2 = {
    //   slidesPerView: 3.2,
    //   spaceBetween: 5,
    //   // centeredSlides: true
    // };
    // public searchTerm: string = "";
    // public items: any;
    function NailaAccountPage(alertController, refundmodal, modalController) {
        this.alertController = alertController;
        this.refundmodal = refundmodal;
        this.modalController = modalController;
        // this.items = [
        //   { title: "one" },
        //   { title: "two" },
        //   { title: "three" },
        //   { title: "four" },
        //   { title: "five" },
        //   { title: "six" }
        // ];
    }
    NailaAccountPage.prototype.ngOnInit = function () {
        // this.setFilteredItems();
    };
    //   setFilteredItems() {
    //     this.items = this.filterItems(this.searchTerm);
    //   }
    //   filterItems(searchTerm) {
    //     return this.items.filter(item => {
    //       return item.title.toLowerCase().indexOf(searchTerm.toLowerCase()) > -1;
    //     });
    //   }
    // a=false;
    NailaAccountPage.prototype.presentAlert = function () {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function () {
            var alert;
            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.alertController.create({
                            subHeader: 'Whatsapp',
                            message: 'You can contact Naila Support Team on 7624943335 number.',
                            buttons: ['OK']
                        })];
                    case 1:
                        alert = _a.sent();
                        return [4 /*yield*/, alert.present()];
                    case 2:
                        _a.sent();
                        return [2 /*return*/];
                }
            });
        });
    };
    // async presentRefudAlert() {
    //   const alert = await this.alertController.create({
    //     cssClass: 'custom-refund-alert',
    //     message: 'You can contact Naila Support Team on 7624943335 number.',
    //     buttons: ['OK']
    //   });
    //   await alert.present();
    // }
    NailaAccountPage.prototype.openCreateRefundModal = function () {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function () {
            var modal;
            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.modalController.create({
                            component: _modals_refundmodal_refundmodal_component__WEBPACK_IMPORTED_MODULE_3__["RefundModalComponent"],
                        })];
                    case 1:
                        modal = _a.sent();
                        return [4 /*yield*/, modal.present()];
                    case 2: return [2 /*return*/, _a.sent()];
                }
            });
        });
    };
    NailaAccountPage.prototype.openPrivacyPolicyModal = function () {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function () {
            var modal;
            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.modalController.create({
                            component: _modals_privacypolicy_privacypolicy_component__WEBPACK_IMPORTED_MODULE_4__["PrivacyPolicyModalComponent"],
                        })];
                    case 1:
                        modal = _a.sent();
                        return [4 /*yield*/, modal.present()];
                    case 2: return [2 /*return*/, _a.sent()];
                }
            });
        });
    };
    NailaAccountPage.prototype.TandCModal = function () {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function () {
            var modal;
            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.modalController.create({
                            component: _modals_termsandcondition_termsandcondition_component__WEBPACK_IMPORTED_MODULE_5__["TermsModalComponent"],
                        })];
                    case 1:
                        modal = _a.sent();
                        return [4 /*yield*/, modal.present()];
                    case 2: return [2 /*return*/, _a.sent()];
                }
            });
        });
    };
    // popOver.onDidDismiss().then(data => {
    //   // if (data.data) {
    //   //   if (data.data.val == 'approve') {
    //   //     // this.approvalUser(id)
    //   //   } else if (data.data.val == 'reject') {
    //   //     // this.rejectUser(id, data.data.notes)
    //   //   }
    //   // }
    // })
    // return await popOver.present()
    NailaAccountPage.prototype.dismiss = function () {
        // using the injected ModalController this page
        // can "dismiss" itself and optionally pass back data
        this.modalController.dismiss({
            'dismissed': true
        });
    };
    NailaAccountPage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-nailaaccountpage',
            template: __webpack_require__(/*! ./nailaaccountpage.html */ "./src/app/Rentals Management/pages/nailaaccountpage/nailaaccountpage.html"),
            styles: [__webpack_require__(/*! ./nailaaccountpage.scss */ "./src/app/Rentals Management/pages/nailaaccountpage/nailaaccountpage.scss")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_ionic_angular__WEBPACK_IMPORTED_MODULE_2__["AlertController"], _modals_refundmodal_refundmodal_component__WEBPACK_IMPORTED_MODULE_3__["RefundModalComponent"], _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["ModalController"]])
    ], NailaAccountPage);
    return NailaAccountPage;
}());



/***/ })

}]);
//# sourceMappingURL=Rentals-Management-pages-nailaaccountpage-nailaaccountpage-module.js.map