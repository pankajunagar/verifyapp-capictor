(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["Rentals-Management-pages-beauticianbooking-beauticianbooking-module"],{

/***/ "./src/app/Rentals Management/pages/beauticianbooking/beauticianbooking.html":
/*!***********************************************************************************!*\
  !*** ./src/app/Rentals Management/pages/beauticianbooking/beauticianbooking.html ***!
  \***********************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ion-header no-border>\r\n  <ion-toolbar color=\"primary\">\r\n    <ion-buttons slot=\"start\">\r\n      <ion-menu-button></ion-menu-button>\r\n    </ion-buttons>\r\n    <!-- <ion-buttons slot=\"end\" expand=\"full\" class=\"ion-button\" (click)=\"openScanner()\">\r\n      <ion-button style=\"color: black\">\r\n          <img src=\"../../../../assets/icons.png\" width=\"30px\" height=\"30px\"/>\r\n      </ion-button>\r\n    </ion-buttons> -->\r\n\r\n    <ion-title>Bookings</ion-title>\r\n  </ion-toolbar>\r\n\r\n  <ion-segment value=\"all\">\r\n    <ion-segment-button (click)=\"listAllBookings('past')\">\r\n      <ion-label style=\"text-decoration: unset\">Todays booking</ion-label>\r\n    </ion-segment-button>\r\n    <ion-segment-button (click)=\"listAllBookings('upcoming')\">\r\n      <ion-label style=\"text-decoration: unset\">Tomorrow booking</ion-label>\r\n    </ion-segment-button>\r\n  </ion-segment>\r\n</ion-header>\r\n\r\n<ion-content padding>\r\n\r\n  <ion-card>\r\n    <ng-container *ngIf=\"listbooking.length\">\r\n      <ng-container *ngFor=\"let bookingdata of listbooking\">\r\n        <ion-item lines=\"none\">\r\n          <ion-label class=\"font-15\" style=\"float:left\">\r\n            Booking Info:\r\n          </ion-label>\r\n        </ion-item>\r\n        <!-- <ion-col size=\"3\">\r\n        <img class=\"float-left\" style=\"width: 70px;\r\n      height: 43px;\r\n      margin-top: 5px;\r\n      position: absolute;\r\n      border-radius: 5px;\" src={{item.service.image.url}} alt=\"\">\r\n      </ion-col> -->\r\n        <ion-item *ngFor=\"let item of bookingdata.booking_services_details; let i=index\" lines=\"none\" size=\"12\">\r\n\r\n\r\n\r\n\r\n\r\n          <ol start={{i+1}}>\r\n            <li class=\"font-12\">{{item.service.name}}-Rs. {{item.service.offer_price}} X Quantity {{item.quantity}}</li>\r\n          </ol>\r\n\r\n\r\n        </ion-item>\r\n\r\n\r\n        <!-- <ion-col size=\"3\"></ion-col>\r\n\r\n      <ion-col size=\"9\">\r\n\r\n\r\n        <ion-list class=\"padding-bottom-0\">\r\n          <ion-item style=\"--min-height: 10px;\" lines=\"none\">\r\n            <ion-label style=\"text-align: start;\" class=\"margin-0\">\r\n              <p class=\"\" text-wrap>\r\n                <small class=\"float-left text-nunderline font-12 text-ncolor\">View Invoice</small>\r\n                <span class=\"center-text\"> hello</span>\r\n              </p>\r\n\r\n            </ion-label>\r\n            <small class=\"float-right \">Rs.900</small> \r\n            <ion-label style=\"text-align: end; padding-right: 10px;\" class=\"margin-0 \">\r\n              <p class=\"\" text-wrap>\r\n                <small (click)=\"presentAlert(item)\" class=\"font-12 text-ncolor text-nunderline\">Raise Ticket</small>\r\n                <span class=\"center-text\"> hello</span>\r\n              </p>\r\n\r\n            </ion-label>\r\n            <small class=\"float-right \">Details</small> \r\n\r\n          </ion-item>\r\n        </ion-list>\r\n\r\n      </ion-col> -->\r\n\r\n\r\n        <!-- <hr> -->\r\n\r\n\r\n\r\n        <ion-item lines=\"none\">\r\n          <small class=\"float-left font-12 text-black\">Payment mode</small>-\r\n          <small *ngIf=\"bookingdata.payment_mode=='by_cash'\" class=\" float-right font-12 txt-black\">\r\n            Cash\r\n          </small>\r\n          <small *ngIf=\"bookingdata.payment_mode=='online'\" class=\" float-right font-12 txt-black\">\r\n            Online\r\n          </small>\r\n        </ion-item>\r\n        <ion-item lines=\"none\">\r\n          <small class=\"float-left text-black\">Total amount</small>-\r\n          <small class=\" float-right font-12 txt-black\">\r\n            Rs. {{bookingdata.total_amount}}\r\n          </small>\r\n        </ion-item>\r\n        <ion-item lines=\"none\">\r\n          <ion-label class=\"font-15\" style=\"float:left\">\r\n            User Info:\r\n          </ion-label>\r\n        </ion-item>\r\n        <ion-item lines=\"none\">\r\n          <small class=\"float-left font-12 text-black\">Customer Name</small>-\r\n          <small class=\" float-right font-12 txt-black\">\r\n            {{bookingdata.user.name}}\r\n          </small>\r\n        </ion-item>\r\n        <ion-item lines=\"none\">\r\n          <small class=\"float-left font-12 text-black\">Contact Number</small>-\r\n          <small class=\" float-right font-12 txt-black\">\r\n            {{bookingdata.user.contact}}\r\n          </small>\r\n        </ion-item>\r\n        <ion-item *ngIf=\"bookingdata.flat_no && bookingdata.address\" lines=\"none\">\r\n          <small class=\"float-left font-12 text-black\">Address-</small><br>\r\n          <small class=\" float-right font-12 txt-black\">\r\n\r\n            {{bookingdata.flat_no}}, {{bookingdata.address}}\r\n          </small>\r\n        </ion-item>\r\n        <br>\r\n        <ion-item lines=\"none\">\r\n          <label (click)=\"bookingdata.payment_status='collected_cash';collectedCash(bookingdata)\" style=\"width: 100%;\r\n        display: inline-flex;\r\n        /* height: 35px; */\r\n        justify-content: center;\r\n        border: 1px solid red;\r\n        padding: 10px;\r\n        margin-top: 5px;\r\n        color: white;\r\n        background: red;\"\r\n            *ngIf=\"bookingdata.payment_mode=='by_cash' && bookingdata.payment_status !='collected_cash' && bookingdata.payment_status !='online_paid' && !bookingdata.service_status \">Collect\r\n            Cash</label>\r\n\r\n          <label\r\n            *ngIf=\"( bookingdata.payment_status =='collected_cash') && bookingdata.service_status!='Service Done' \"\r\n            (click)=\"bookingdata.service_status='Service Done';collectedCash(bookingdata)\" style=\"width: 100%;\r\n        display: inline-flex;\r\n        /* height: 35px; */\r\n        justify-content: center;\r\n        border: 1px solid yellow;\r\n        padding: 10px;\r\n        margin-top: 5px;\r\n        color: black;\r\n        background: yellow;\">Update Service</label>\r\n\r\n          <label (click)=\"collectedCash(bookingdata)\" style=\"width: 100%;\r\n        display: inline-flex;\r\n        /* height: 35px; */\r\n        justify-content: center;\r\n        border: 1px solid green;\r\n        padding: 10px;\r\n        margin-top: 5px;\r\n        color: white;\r\n        background: green;\" *ngIf=\"bookingdata.service_status=='Service Done'\">Service Done</label>\r\n          <label style=\"width: 100%;\r\n        display: inline-flex;\r\n        /* height: 35px; */\r\n        margin-top: 5px;\r\n        justify-content: center;\r\n        border: 1px solid yellow;\r\n        padding: 10px;\r\n        color: black;\r\n        background: yellow;\"\r\n            *ngIf=\"bookingdata.payment_mode=='online' && bookingdata.payment_status =='online_paid' && !bookingdata.service_status \"\r\n            (click)=\"bookingdata.service_status='Service Done';collectedCash(bookingdata)\">Paid</label>\r\n        </ion-item>\r\n        <br>\r\n        <br>\r\n      </ng-container>\r\n    </ng-container>\r\n  </ion-card>\r\n\r\n\r\n  <ng-container *ngIf=\"!listbooking.length\">\r\n    <ion-row>\r\n      <p style=\"display: inline-flex;\r\n        justify-content: center;\r\n        text-align: center;\r\n        width: 100%;\r\n        margin-top: 25vh;\">No {{bookingname}} Bookings!</p>\r\n    </ion-row>\r\n  </ng-container>\r\n\r\n  <br>\r\n  <!-- \r\n  <ion-infinite-scroll [hidden]=\"disableInfiniteScroll\" threshold=\"5px\" (ionInfinite)=\"searchTicket($event)\">\r\n    <ion-infinite-scroll-content loadingSpinner=\"bubbles\"\r\n      loadingText=\"{{transService.getTranslatedbookingdata('infinite-scroll')}}\">\r\n    </ion-infinite-scroll-content>\r\n  </ion-infinite-scroll> -->\r\n  <!-- <ion-button>Collect cash</ion-button> -->\r\n\r\n\r\n\r\n\r\n</ion-content>"

/***/ }),

/***/ "./src/app/Rentals Management/pages/beauticianbooking/beauticianbooking.module.ts":
/*!****************************************************************************************!*\
  !*** ./src/app/Rentals Management/pages/beauticianbooking/beauticianbooking.module.ts ***!
  \****************************************************************************************/
/*! exports provided: NailaBeauticianBookingPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "NailaBeauticianBookingPageModule", function() { return NailaBeauticianBookingPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _ApplicationPageModule__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../ApplicationPageModule */ "./src/app/Rentals Management/ApplicationPageModule.ts");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _modals_create_notice_create_notice_component__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../../modals/create-notice/create-notice.component */ "./src/app/Rentals Management/modals/create-notice/create-notice.component.ts");
/* harmony import */ var _beauticianbooking__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./beauticianbooking */ "./src/app/Rentals Management/pages/beauticianbooking/beauticianbooking.ts");








// import { BarcodeScanner } from '@ionic-native/barcode-scanner/ngx';

// import { NailaBeauticianBookingPage } from './nailabooking';
// import { NailaBeauticianBookingPage } from './nailaofferslisting';
var routes = [
    {
        path: '',
        component: _beauticianbooking__WEBPACK_IMPORTED_MODULE_8__["NailaBeauticianBookingPage"]
    }
];
var NailaBeauticianBookingPageModule = /** @class */ (function () {
    function NailaBeauticianBookingPageModule() {
    }
    NailaBeauticianBookingPageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_2__["NgModule"])({
            entryComponents: [_modals_create_notice_create_notice_component__WEBPACK_IMPORTED_MODULE_7__["CreateNoticeComponent"]],
            imports: [
                _angular_common__WEBPACK_IMPORTED_MODULE_3__["CommonModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormsModule"],
                _ApplicationPageModule__WEBPACK_IMPORTED_MODULE_1__["ApplicationPageModule"],
                _ionic_angular__WEBPACK_IMPORTED_MODULE_6__["IonicModule"],
                _angular_router__WEBPACK_IMPORTED_MODULE_5__["RouterModule"].forChild(routes)
            ],
            providers: [
            // BarcodeScanner
            ],
            declarations: [_beauticianbooking__WEBPACK_IMPORTED_MODULE_8__["NailaBeauticianBookingPage"]]
        })
    ], NailaBeauticianBookingPageModule);
    return NailaBeauticianBookingPageModule;
}());



/***/ }),

/***/ "./src/app/Rentals Management/pages/beauticianbooking/beauticianbooking.scss":
/*!***********************************************************************************!*\
  !*** ./src/app/Rentals Management/pages/beauticianbooking/beauticianbooking.scss ***!
  \***********************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "ion-navbar {\n  border-bottom-right-radius: 15px;\n  border-bottom-left-radius: 15px;\n  background-color: black; }\n\nion-card {\n  position: relative;\n  text-align: center;\n  border-radius: 20px !important; }\n\n.card-title {\n  position: absolute;\n  top: 20vh;\n  background-color: yellow;\n  font-size: 2.0em;\n  height: 15vh;\n  width: 100%;\n  font-weight: bold;\n  color: #fff; }\n\nion-card-content {\n  text-align: left;\n  background: red;\n  line-height: 1.5;\n  width: 100%;\n  padding-top: 7px;\n  padding-bottom: 7px; }\n\nlabel {\n  padding-left: 3vw; }\n\n.service ion-card-content {\n  text-align: center;\n  line-height: 1.5;\n  width: 100%;\n  font-size: 6px;\n  background: transparent;\n  padding: 5px 1px 3px; }\n\n.service ion-card {\n  position: relative;\n  text-align: center;\n  border-radius: 10px !important; }\n\nion-list {\n  padding-top: 0px !important; }\n\nion-toolbar {\n  border-bottom-left-radius: 25px;\n  border-bottom-right-radius: 25px; }\n\n.list-offers {\n  margin-right: 5px; }\n\nh6 {\n  padding-left: 4vw;\n  font-weight: 500; }\n\nhr {\n  border-width: 0.2px !important;\n  height: 0px !important; }\n\nion-item {\n  --detail-icon-color: goldenrod;\n  --detail-icon-opacity:1;\n  margin-bottom: -9px; }\n\nion-col {\n  padding-bottom: 0px;\n  padding-top: 0px; }\n\nli {\n  margin-bottom: 0vw !important;\n  float: left; }\n\nol {\n  -webkit-padding-start: 15px;\n          padding-inline-start: 15px; }\n\nion-label {\n  text-decoration: underline; }\n\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvUmVudGFscyBNYW5hZ2VtZW50L3BhZ2VzL2JlYXV0aWNpYW5ib29raW5nL0Q6XFxuYXZqb3RcXHZlcmlmeS9zcmNcXGFwcFxcUmVudGFscyBNYW5hZ2VtZW50XFxwYWdlc1xcYmVhdXRpY2lhbmJvb2tpbmdcXGJlYXV0aWNpYW5ib29raW5nLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDRSxnQ0FBZ0M7RUFDaEMsK0JBQStCO0VBQy9CLHVCQUF1QixFQUFBOztBQU9uQjtFQUNFLGtCQUFrQjtFQUNsQixrQkFBa0I7RUFDbEIsOEJBQThCLEVBQUE7O0FBR2hDO0VBQ0ksa0JBQWtCO0VBQ2xCLFNBQVM7RUFDVCx3QkFBd0I7RUFDeEIsZ0JBQWdCO0VBQ2hCLFlBQVk7RUFDWixXQUFXO0VBQ1gsaUJBQWlCO0VBQ2pCLFdBQVcsRUFBQTs7QUFRbkI7RUFDSSxnQkFBZ0I7RUFDUixlQUFlO0VBQ3ZCLGdCQUFnQjtFQUNoQixXQUFXO0VBQ1gsZ0JBQWdCO0VBQ2hCLG1CQUFtQixFQUFBOztBQUd2QjtFQUNJLGlCQUFpQixFQUFBOztBQUVyQjtFQUVRLGtCQUFrQjtFQUNsQixnQkFBZ0I7RUFDaEIsV0FBVztFQUNYLGNBQWM7RUFDZCx1QkFBdUI7RUFDdkIsb0JBQW9CLEVBQUE7O0FBUDVCO0VBVVEsa0JBQWtCO0VBQ2xCLGtCQUFrQjtFQUNsQiw4QkFBOEIsRUFBQTs7QUFtQnRDO0VBQ0UsMkJBQTJCLEVBQUE7O0FBSTdCO0VBQ0UsK0JBQStCO0VBQy9CLGdDQUFnQyxFQUFBOztBQUdsQztFQUNFLGlCQUFpQixFQUFBOztBQUduQjtFQUNFLGlCQUFpQjtFQUNqQixnQkFBZ0IsRUFBQTs7QUFHbkI7RUFDRSw4QkFBOEI7RUFDOUIsc0JBQXNCLEVBQUE7O0FBR3hCO0VBRUMsOEJBQW9CO0VBQ3BCLHVCQUFzQjtFQUN0QixtQkFBbUIsRUFBQTs7QUFLckI7RUFDRSxtQkFBbUI7RUFDbkIsZ0JBQWdCLEVBQUE7O0FBR2xCO0VBQ0UsNkJBQTZCO0VBQzdCLFdBQVcsRUFBQTs7QUFFYjtFQUNFLDJCQUEwQjtVQUExQiwwQkFBMEIsRUFBQTs7QUFHNUI7RUFDRSwwQkFDRixFQUFBIiwiZmlsZSI6InNyYy9hcHAvUmVudGFscyBNYW5hZ2VtZW50L3BhZ2VzL2JlYXV0aWNpYW5ib29raW5nL2JlYXV0aWNpYW5ib29raW5nLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyJpb24tbmF2YmFye1xyXG4gIGJvcmRlci1ib3R0b20tcmlnaHQtcmFkaXVzOiAxNXB4O1xyXG4gIGJvcmRlci1ib3R0b20tbGVmdC1yYWRpdXM6IDE1cHg7XHJcbiAgYmFja2dyb3VuZC1jb2xvcjogYmxhY2s7XHJcbn1cclxuXHJcblxyXG5cclxuXHJcblxyXG4gICAgICBpb24tY2FyZCB7XHJcbiAgICAgICAgcG9zaXRpb246IHJlbGF0aXZlO1xyXG4gICAgICAgIHRleHQtYWxpZ246IGNlbnRlcjtcclxuICAgICAgICBib3JkZXItcmFkaXVzOiAyMHB4ICFpbXBvcnRhbnQ7XHJcbiAgICAgIH1cclxuXHJcbiAgICAgIC5jYXJkLXRpdGxlIHtcclxuICAgICAgICAgIHBvc2l0aW9uOiBhYnNvbHV0ZTtcclxuICAgICAgICAgIHRvcDogMjB2aDtcclxuICAgICAgICAgIGJhY2tncm91bmQtY29sb3I6IHllbGxvdztcclxuICAgICAgICAgIGZvbnQtc2l6ZTogMi4wZW07XHJcbiAgICAgICAgICBoZWlnaHQ6IDE1dmg7XHJcbiAgICAgICAgICB3aWR0aDogMTAwJTtcclxuICAgICAgICAgIGZvbnQtd2VpZ2h0OiBib2xkO1xyXG4gICAgICAgICAgY29sb3I6ICNmZmY7XHJcbiAgICAgIH1cclxuXHJcbiAgICAgXHJcbiAgICAgIC8vIGlvbi1zbGlkZXtcclxuICAgICAgLy8gICAgIHdpZHRoOiAyNDVweCAhaW1wb3J0YW50O1xyXG4gICAgICAvLyB9XHJcblxyXG4gIGlvbi1jYXJkLWNvbnRlbnR7XHJcbiAgICAgIHRleHQtYWxpZ246IGxlZnQ7XHJcbiAgICAgICAgICAgICAgYmFja2dyb3VuZDogcmVkO1xyXG4gICAgICBsaW5lLWhlaWdodDogMS41O1xyXG4gICAgICB3aWR0aDogMTAwJTtcclxuICAgICAgcGFkZGluZy10b3A6IDdweDtcclxuICAgICAgcGFkZGluZy1ib3R0b206IDdweDtcclxuICB9XHJcblxyXG4gIGxhYmVse1xyXG4gICAgICBwYWRkaW5nLWxlZnQ6IDN2dztcclxuICB9XHJcbiAgLnNlcnZpY2V7XHJcbiAgICAgIGlvbi1jYXJkLWNvbnRlbnR7XHJcbiAgICAgICAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XHJcbiAgICAgICAgICBsaW5lLWhlaWdodDogMS41O1xyXG4gICAgICAgICAgd2lkdGg6IDEwMCU7XHJcbiAgICAgICAgICBmb250LXNpemU6IDZweDtcclxuICAgICAgICAgIGJhY2tncm91bmQ6IHRyYW5zcGFyZW50O1xyXG4gICAgICAgICAgcGFkZGluZzogNXB4IDFweCAzcHg7XHJcbiAgICAgIH1cclxuICAgICAgaW9uLWNhcmR7XHJcbiAgICAgICAgICBwb3NpdGlvbjogcmVsYXRpdmU7XHJcbiAgICAgICAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XHJcbiAgICAgICAgICBib3JkZXItcmFkaXVzOiAxMHB4ICFpbXBvcnRhbnQ7ICBcclxuICAgICAgICAgIFxyXG4gICAgICB9XHJcbiAgfVxyXG5cclxuICAvLyAuYm9yZGVyLXRvcCB7XHJcbiAgLy8gICBib3JkZXItdG9wOiAxcHggc29saWQgbGlnaHRncmF5O1xyXG4gIC8vIH1cclxuICBcclxuICBpb24taXRlbSB7XHJcbiAgICAvLyBib3JkZXItdG9wOiAxcHggc29saWQgbGlnaHRncmF5O1xyXG4gICAgLy8gYm9yZGVyLWJvdHRvbTogMXB4IHNvbGlkIGxpZ2h0Z3JheTtcclxuICB9XHJcbiAgXHJcbiAgLy8gaW9uLWxhYmVsIHtcclxuICAvLyAgIHBhZGRpbmctdG9wOiAxMHB4ICFpbXBvcnRhbnQ7XHJcbiAgLy8gICBwYWRkaW5nLWJvdHRvbTogMTBweCAhaW1wb3J0YW50O1xyXG4gIC8vIH1cclxuICBcclxuICBpb24tbGlzdCB7XHJcbiAgICBwYWRkaW5nLXRvcDogMHB4ICFpbXBvcnRhbnQ7XHJcbiAgfVxyXG4gIFxyXG5cclxuICBpb24tdG9vbGJhcntcclxuICAgIGJvcmRlci1ib3R0b20tbGVmdC1yYWRpdXM6IDI1cHg7XHJcbiAgICBib3JkZXItYm90dG9tLXJpZ2h0LXJhZGl1czogMjVweDtcclxuICB9XHJcblxyXG4gIC5saXN0LW9mZmVyc3tcclxuICAgIG1hcmdpbi1yaWdodDogNXB4O1xyXG4gIH1cclxuXHJcbiAgaDZ7XHJcbiAgICBwYWRkaW5nLWxlZnQ6IDR2dztcclxuICAgIGZvbnQtd2VpZ2h0OiA1MDA7XHJcbiAgICB9XHJcblxyXG4gaHJ7XHJcbiAgIGJvcmRlci13aWR0aDogMC4ycHggIWltcG9ydGFudDtcclxuICAgaGVpZ2h0OiAwcHggIWltcG9ydGFudDtcclxuIH1cclxuXHJcbiBpb24taXRlbSB7XHJcbiAgLy8gYm9yZGVyLXRvcDogMXB4IHNvbGlkIGxpZ2h0Z3JheTtcclxuICAtLWRldGFpbC1pY29uLWNvbG9yOiBnb2xkZW5yb2Q7XHJcbiAgLS1kZXRhaWwtaWNvbi1vcGFjaXR5OjE7XHJcbiAgbWFyZ2luLWJvdHRvbTogLTlweDtcclxuICAvLyAtLWJvcmRlci13aWR0aDogMHB4IDBweCAwLjFweCAwcHggIWltcG9ydGFudDtcclxuICAvLyAtLWJvcmRlci1jb2xvcjogI0YwRjBGMCAhaW1wb3J0YW50O1xyXG59XHJcblxyXG5pb24tY29se1xyXG4gIHBhZGRpbmctYm90dG9tOiAwcHg7XHJcbiAgcGFkZGluZy10b3A6IDBweDtcclxufVxyXG5cclxubGl7XHJcbiAgbWFyZ2luLWJvdHRvbTogMHZ3ICFpbXBvcnRhbnQ7XHJcbiAgZmxvYXQ6IGxlZnQ7XHJcbn1cclxub2x7XHJcbiAgcGFkZGluZy1pbmxpbmUtc3RhcnQ6IDE1cHg7XHJcbn1cclxuXHJcbmlvbi1sYWJlbHtcclxuICB0ZXh0LWRlY29yYXRpb246IHVuZGVybGluZVxyXG59Il19 */"

/***/ }),

/***/ "./src/app/Rentals Management/pages/beauticianbooking/beauticianbooking.ts":
/*!*********************************************************************************!*\
  !*** ./src/app/Rentals Management/pages/beauticianbooking/beauticianbooking.ts ***!
  \*********************************************************************************/
/*! exports provided: NailaBeauticianBookingPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "NailaBeauticianBookingPage", function() { return NailaBeauticianBookingPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _services_naila_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../services/naila.service */ "./src/app/Rentals Management/services/naila.service.ts");




// import { ApprovalpopupComponent } from '../../modals/approvalpopup/approvalpopup.component';
var NailaBeauticianBookingPage = /** @class */ (function () {
    function NailaBeauticianBookingPage(nailaservice, alertController) {
        this.nailaservice = nailaservice;
        this.alertController = alertController;
        this.sliderConfig = {
            slidesPerView: 1.2,
            spaceBetween: 5,
        };
        this.sliderConfig2 = {
            slidesPerView: 3.2,
            spaceBetween: 5,
        };
        this.searchTerm = "";
        this.a = false;
        this.upcomingbooking = [];
        this.pastbooking = [];
        this.listbooking = [];
        this.bookingList = [];
        this.items = [
            { title: "one" },
            { title: "two" },
            { title: "three" },
            { title: "four" },
            { title: "five" },
            { title: "six" }
        ];
        // this.bookingname="Loading"
    }
    NailaBeauticianBookingPage.prototype.ngOnInit = function () {
        this.setFilteredItems();
        this.listAllBookings('past');
    };
    NailaBeauticianBookingPage.prototype.listAllBookings = function (data) {
        var _this = this;
        var tomorrow = new Date();
        tomorrow.setDate(tomorrow.getDate() + 1);
        this.starttimeoftomorrow = tomorrow;
        this.starttimeoftomorrow.setHours(0, 0, 0, 0);
        this.endtimeoftomorrow = tomorrow;
        this.endtimeoftomorrow.setHours(23, 59, 59, 999);
        this.starttimeofday = new Date();
        this.starttimeofday.setHours(0, 0, 0, 0);
        this.endtimeofday = new Date();
        this.endtimeofday.setHours(23, 59, 59, 999);
        // element.schedule_on).getTime()
        this.listbooking.splice(0, this.listbooking.length);
        var date = new Date();
        console.log(date);
        var id = window.localStorage.getItem('beautician_id');
        this.nailaservice.getBookingForBeautician(id).subscribe(function (bookingList) {
            _this.bookingList = bookingList;
            _this.upcomingbooking = [];
            _this.bookingList.forEach(function (element) {
                debugger;
                if (new Date(element.schedule_on).getTime() >= _this.starttimeofday.getTime() && new Date(element.schedule_on).getTime() < _this.endtimeofday.getTime()) {
                    _this.pastbooking.push(element);
                }
                else if (new Date(element.schedule_on).getTime() >= _this.endtimeofday.getTime() && new Date(element.schedule_on).getTime() < _this.endtimeoftomorrow.getTime()) {
                    _this.upcomingbooking.push(element);
                }
            });
            if (data == 'past') {
                // this.listbooking = []
                _this.listbooking.splice(0, _this.listbooking.length);
                _this.listbooking = _this.pastbooking;
                if (_this.listbooking)
                    _this.bookingname = "Todays";
            }
            else {
                _this.listbooking.splice(0, _this.listbooking.length);
                _this.listbooking = _this.upcomingbooking;
                if (_this.listbooking)
                    _this.bookingname = "Tomorrow";
            }
            console.log(_this.listbooking);
        });
    };
    // upcomingdata(data){
    //   this.listbooking=[];
    //   this.
    // }
    NailaBeauticianBookingPage.prototype.setFilteredItems = function () {
        this.items = this.filterItems(this.searchTerm);
    };
    NailaBeauticianBookingPage.prototype.filterItems = function (searchTerm) {
        return this.items.filter(function (item) {
            return item.title.toLowerCase().indexOf(searchTerm.toLowerCase()) > -1;
        });
    };
    NailaBeauticianBookingPage.prototype.presentAlert = function (item) {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function () {
            var alert;
            var _this = this;
            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.alertController.create({
                            // message: 'Enter your issue.',
                            inputs: [
                                {
                                    name: 'description',
                                    placeholder: 'Description'
                                },
                            ],
                            buttons: [
                                {
                                    text: 'Submit',
                                    handler: function (data) {
                                        var ticketdata = {
                                            "title": item.service.name,
                                            "description": data.description,
                                            "booking_id": item.service_id
                                        };
                                        _this.nailaservice.createTicket(ticketdata).subscribe(function (data) {
                                        });
                                        // let validateObj = (data);
                                        console.log("==================", data, "========================");
                                    }
                                }
                            ]
                        })];
                    case 1:
                        alert = _a.sent();
                        return [4 /*yield*/, alert.present()];
                    case 2:
                        _a.sent();
                        return [2 /*return*/];
                }
            });
        });
    };
    NailaBeauticianBookingPage.prototype.collectedCash = function (bookingdata) {
        debugger;
        var paymentdata = {
            "apartment_id": bookingdata.apartment_id,
            "user_id": bookingdata.user_id,
            "beautician_id": bookingdata.beautician_id,
            "total_amount": bookingdata.total_amount,
            "c_gst": 9,
            "s_gst": 9,
            "service_status": bookingdata.service_status,
            "address": bookingdata.address,
            "schedule_on": bookingdata.schedule_on,
            "schedule_till": bookingdata.schedule_till,
            "total_no_of_minutes": bookingdata.total_no_of_minutes,
            "payment_status": bookingdata.payment_status,
            "payment_mode": bookingdata.payment_mode,
            "payment_id": bookingdata.payment_id,
            "transaction_id": "21342387732424",
            "coupon_id": 1
        };
        this.nailaservice.updatepaymentStatus(paymentdata, bookingdata).subscribe(function (data) {
            bookingdata = data;
            alert('Successfully status updated.');
            // if(bookingdata.payment_status='Paid'){
            //   bookingdata.payment_status='Paid'
            // }
            // if(bookingdata.service_status=='Service Done'){
            //   bookingdata.service_status='Service Done'
            // }
        });
    };
    NailaBeauticianBookingPage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-beauticianbooking',
            template: __webpack_require__(/*! ./beauticianbooking.html */ "./src/app/Rentals Management/pages/beauticianbooking/beauticianbooking.html"),
            styles: [__webpack_require__(/*! ./beauticianbooking.scss */ "./src/app/Rentals Management/pages/beauticianbooking/beauticianbooking.scss")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_services_naila_service__WEBPACK_IMPORTED_MODULE_3__["NailaService"], _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["AlertController"]])
    ], NailaBeauticianBookingPage);
    return NailaBeauticianBookingPage;
}());



/***/ })

}]);
//# sourceMappingURL=Rentals-Management-pages-beauticianbooking-beauticianbooking-module.js.map