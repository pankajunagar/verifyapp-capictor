(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["Rentals-Management-pages-nailaservicepage-nailaservicepage-module"],{

/***/ "./src/app/Rentals Management/pages/nailaservicepage/nailaservicepage.html":
/*!*********************************************************************************!*\
  !*** ./src/app/Rentals Management/pages/nailaservicepage/nailaservicepage.html ***!
  \*********************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ion-header no-border>\r\n  <ion-toolbar color=\"primary\">\r\n    <ion-buttons slot=\"start\">\r\n      <ion-menu-button></ion-menu-button>\r\n    </ion-buttons>\r\n    <!-- <ion-buttons slot=\"end\" expand=\"full\" class=\"ion-button\" (click)=\"openScanner()\">\r\n      <ion-button style=\"color: black\">\r\n          <img src=\"../../../../assets/icons.png\" width=\"30px\" height=\"30px\"/>\r\n      </ion-button>\r\n    </ion-buttons> -->\r\n\r\n    <ion-title style=\"display: inline-table;\" class=\"\">Service</ion-title>\r\n\r\n    <ion-buttons routerLink=\"/rentals-naila-cart-page\" style=\"float: right;outline: none;\r\n    zoom: 2;\" end>\r\n      <ion-icon ios=\"ios-cart\" md=\"md-cart\"></ion-icon>\r\n      <p *ngIf=\"this.utils.cartdata.length\" class=\"cart-number\">{{this.utils.cartdata}}</p>\r\n    </ion-buttons>\r\n  </ion-toolbar>\r\n</ion-header>\r\n\r\n\r\n<ion-content padding>\r\n  <ion-card>\r\n    <ion-card-header>\r\n      <ion-card-title style=\"display: inline-flex;\r\n          align-items: center;\r\n          width: 100%;\r\n          justify-content: center;\r\n          font-size: 20px;\r\n          \r\n          \" class=\"text-black font-weight-500\">\r\n\r\n        <!-- Hair color <ion-icon style=\"vertical-align: middle;\" name=\"compass\"></ion-icon> 20% -->\r\n\r\n\r\n        <small class=\"text-black\">{{this.utils.storage.name}}\r\n        </small>\r\n\r\n        <img style=\"height: 15px;\r\n        width: 15px;\r\n        margin-top: 1px;\r\n        margin-left: 5px;\r\n        margin-right: 5px;\" src=\"assets/imgs/discount2.svg\" alt=\"\">\r\n\r\n\r\n        <small class=\"text-black font-weight-500\">{{100-percentagediscount}} </small>\r\n\r\n      </ion-card-title>\r\n\r\n      <ion-card-subtitle style=\"display: inline-flex;\r\n          align-items: center;\r\n          width: 100%;\r\n          justify-content: center;\r\n          font-size: 15px;\r\n          \r\n          \" class=\"text-black \">\r\n        <small class=\"text-black margin-right-10\">Price <span class=\"font-weight-600 \" style=\"text-decoration: line-through;\r\n            text-decoration-color: goldenrod; \"> Rs.{{this.utils.storage.price}}</span> </small>\r\n        <small\r\n          class=\" margin-right-10 font-weight-600 center-text text-black\">Rs.{{this.utils.storage.offer_price}}</small>\r\n\r\n        <small class=\" margin-right-10 text-black\">Duration <span\r\n            class=\"font-weight-600\">{{this.utils.storage.no_of_minuties}} min</span> </small>\r\n        <!-- <small class=\"float-right gotham\">20%</small>  -->\r\n\r\n      </ion-card-subtitle>\r\n      <hr>\r\n\r\n      <!-- \r\n            <p class=\"gotham-medium\" text-wrap>\r\n                <span class=\"float-left\">Blow Dry</span>\r\n                <span class=\"center-text\"> hello</span>\r\n              </p> -->\r\n\r\n      <!-- <ul class=\"my-nav text-black\">\r\n                    <li>Loreal color</li>\r\n                    <li>Include streaks</li>\r\n                    <li>14 shades to choose from</li>\r\n                    <li>List item for sold folder drama</li>\r\n                  </ul> -->\r\n\r\n      <p class=\"ion-text-justify\">{{this.utils.storage.description}}</p>\r\n      <!-- <ion-item class=\"center-text\" lines=\"none\">\r\n                  <ion-icon (click)=\"itemCounter('plus')\" name=\"add-circle\" style=\"zoom: 1.1; color: black;\"></ion-icon>\r\n                    <p class=\"add-sub\">{{itemcounter}}</p>                   \r\n                    <ion-icon (click)=\"itemCounter('minus')\" name=\"remove-circle\" style=\"zoom: 1.1;color: black;\"></ion-icon>\r\n                 </ion-item>\r\n                 <br> -->\r\n      <!-- <ion-button [disabled]=\"disablebutton\" (click)=\"disabledButton()\" class=\"btn\">Add to cart</ion-button> -->\r\n      <ion-button  *ngIf=\"!disablebutton\" size=\"12\" [disabled]=\"disablebutton\" routerLink=\"/rentals-naila-search-page\"\r\n      (click)=\"addTocart(this.utils.storage)\" class=\"btn\">Add to cart</ion-button>\r\n      <ion-button size=\"12\" routerLink=\"/rentals-naila-search-page\" class=\"btn\">Continue shopping</ion-button>\r\n        <ion-button *ngIf=\"disablebutton\"  size=\"12\" size=\"12\"  routerLink=\"/rentals-naila-cart-page\"\r\n         class=\"btn\">Go to cart</ion-button>\r\n    </ion-card-header>\r\n    <!-- <ion-card-content>\r\n            <ion-item no-lines>\r\n                <button ion-button (click)=\"minus()\">-</button>\r\n                <p>{{number}}</p>                   \r\n                <button ion-button (click)=\"plus()\">+</button>\r\n                <button ion-button (click)=\"addCart()\">Add to cart</button>\r\n             </ion-item>\r\n        </ion-card-content> -->\r\n  </ion-card>\r\n</ion-content>"

/***/ }),

/***/ "./src/app/Rentals Management/pages/nailaservicepage/nailaservicepage.module.ts":
/*!**************************************************************************************!*\
  !*** ./src/app/Rentals Management/pages/nailaservicepage/nailaservicepage.module.ts ***!
  \**************************************************************************************/
/*! exports provided: NailaservicePageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "NailaservicePageModule", function() { return NailaservicePageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _ApplicationPageModule__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../ApplicationPageModule */ "./src/app/Rentals Management/ApplicationPageModule.ts");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _modals_create_notice_create_notice_component__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../../modals/create-notice/create-notice.component */ "./src/app/Rentals Management/modals/create-notice/create-notice.component.ts");
/* harmony import */ var _nailaservicepage__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./nailaservicepage */ "./src/app/Rentals Management/pages/nailaservicepage/nailaservicepage.ts");








// import { BarcodeScanner } from '@ionic-native/barcode-scanner/ngx';
// import { NailasearchPage } from './nailasearchpage';

var routes = [
    {
        path: '',
        component: _nailaservicepage__WEBPACK_IMPORTED_MODULE_8__["NailaservicePage"]
    }
];
var NailaservicePageModule = /** @class */ (function () {
    function NailaservicePageModule() {
    }
    NailaservicePageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_2__["NgModule"])({
            entryComponents: [_modals_create_notice_create_notice_component__WEBPACK_IMPORTED_MODULE_7__["CreateNoticeComponent"]],
            imports: [
                _angular_common__WEBPACK_IMPORTED_MODULE_3__["CommonModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormsModule"],
                _ApplicationPageModule__WEBPACK_IMPORTED_MODULE_1__["ApplicationPageModule"],
                _ionic_angular__WEBPACK_IMPORTED_MODULE_6__["IonicModule"],
                _angular_router__WEBPACK_IMPORTED_MODULE_5__["RouterModule"].forChild(routes)
            ],
            providers: [
            // BarcodeScanner
            ],
            declarations: [_nailaservicepage__WEBPACK_IMPORTED_MODULE_8__["NailaservicePage"]]
        })
    ], NailaservicePageModule);
    return NailaservicePageModule;
}());



/***/ }),

/***/ "./src/app/Rentals Management/pages/nailaservicepage/nailaservicepage.scss":
/*!*********************************************************************************!*\
  !*** ./src/app/Rentals Management/pages/nailaservicepage/nailaservicepage.scss ***!
  \*********************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "ion-card {\n  position: relative;\n  text-align: center;\n  border-radius: 20px !important; }\n\nhr {\n  border: 0.5px solid #F0F0F0;\n  height: 0px; }\n\nion-card {\n  background: white;\n  position: absolute;\n  left: 50%;\n  bottom: -15vw;\n  transform: translate(-50%, -50%);\n  margin: 0 auto;\n  width: 300px; }\n\nion-card-title {\n  padding-bottom: 5px;\n  font-size: 12px; }\n\n.my-nav {\n  list-style-type: disc;\n  text-align: start;\n  padding-left: 15px;\n  font-size: 13px; }\n\nion-item {\n  display: inline-table; }\n\nion-content {\n  --background: url('/assets/imgs/serviceimage.png');\n  background-repeat: no-repeat;\n  background-size: cover; }\n\n.add-sub {\n  margin-left: 1vh;\n  margin-right: 1vh; }\n\n.btn {\n  width: 60%;\n  margin-top: 5px;\n  font-size: 10px;\n  height: 25px; }\n\nimg {\n  width: 100%;\n  height: 100%; }\n\n.myCard {\n  position: relative; }\n\n.myOverlay {\n  width: 100%;\n  height: 22px;\n  position: absolute;\n  z-index: 99;\n  bottom: 0px;\n  opacity: 0.5;\n  background: #000;\n  color: #fff; }\n\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvUmVudGFscyBNYW5hZ2VtZW50L3BhZ2VzL25haWxhc2VydmljZXBhZ2UvRDpcXG5hdmpvdFxcdmVyaWZ5L3NyY1xcYXBwXFxSZW50YWxzIE1hbmFnZW1lbnRcXHBhZ2VzXFxuYWlsYXNlcnZpY2VwYWdlXFxuYWlsYXNlcnZpY2VwYWdlLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBVU07RUFDRSxrQkFBa0I7RUFDbEIsa0JBQWtCO0VBQ2xCLDhCQUE4QixFQUFBOztBQUdoQztFQUNFLDJCQUE0QjtFQUM1QixXQUFXLEVBQUE7O0FBdUVuQjtFQUNFLGlCQUFpQjtFQUNqQixrQkFBa0I7RUFDbEIsU0FBUztFQUNULGFBQWE7RUFDYixnQ0FBZ0M7RUFDaEMsY0FBYztFQUNkLFlBQVksRUFBQTs7QUFJZDtFQUNFLG1CQUFtQjtFQUNqQixlQUFlLEVBQUE7O0FBR25CO0VBQ0UscUJBQXFCO0VBQ3JCLGlCQUFpQjtFQUNqQixrQkFBa0I7RUFDbEIsZUFBZSxFQUFBOztBQUVqQjtFQUNFLHFCQUFxQixFQUFBOztBQUd2QjtFQUNFLGtEQUFhO0VBQ2IsNEJBQTRCO0VBQ3pCLHNCQUFzQixFQUFBOztBQU0zQjtFQUNFLGdCQUFnQjtFQUNoQixpQkFBaUIsRUFBQTs7QUFFbkI7RUFDRSxVQUFVO0VBQ1YsZUFBZTtFQUNmLGVBQWU7RUFDZixZQUFZLEVBQUE7O0FBVWQ7RUFDRSxXQUFVO0VBQ1YsWUFBVyxFQUFBOztBQUdiO0VBQ0Usa0JBQWlCLEVBQUE7O0FBSW5CO0VBQ0UsV0FBVztFQUNYLFlBQVk7RUFDWixrQkFBa0I7RUFDbEIsV0FBVztFQUNYLFdBQVc7RUFDWCxZQUFZO0VBQ1osZ0JBQWdCO0VBQ2hCLFdBQVcsRUFBQSIsImZpbGUiOiJzcmMvYXBwL1JlbnRhbHMgTWFuYWdlbWVudC9wYWdlcy9uYWlsYXNlcnZpY2VwYWdlL25haWxhc2VydmljZXBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIi8vIGlvbi1uYXZiYXJ7XHJcbi8vICAgYm9yZGVyLWJvdHRvbS1yaWdodC1yYWRpdXM6IDE1cHg7XHJcbi8vICAgYm9yZGVyLWJvdHRvbS1sZWZ0LXJhZGl1czogMTVweDtcclxuLy8gICBiYWNrZ3JvdW5kLWNvbG9yOiBibGFjaztcclxuLy8gfVxyXG5cclxuXHJcblxyXG5cclxuXHJcbiAgICAgIGlvbi1jYXJkIHtcclxuICAgICAgICBwb3NpdGlvbjogcmVsYXRpdmU7XHJcbiAgICAgICAgdGV4dC1hbGlnbjogY2VudGVyO1xyXG4gICAgICAgIGJvcmRlci1yYWRpdXM6IDIwcHggIWltcG9ydGFudDtcclxuICAgICAgfVxyXG5cclxuICAgICAgaHJ7ICAgIFxyXG4gICAgICAgIGJvcmRlcjogMC41cHggc29saWQgI0YwRjBGMFx0O1xyXG4gICAgICAgIGhlaWdodDogMHB4O1xyXG4gICAgICB9XHJcbi8vICAgICAgIC5jYXJkLXRpdGxlIHtcclxuLy8gICAgICAgICAgIHBvc2l0aW9uOiBhYnNvbHV0ZTtcclxuLy8gICAgICAgICAgIHRvcDogMjB2aDtcclxuLy8gICAgICAgICAgIGJhY2tncm91bmQtY29sb3I6IHllbGxvdztcclxuLy8gICAgICAgICAgIGZvbnQtc2l6ZTogMi4wZW07XHJcbi8vICAgICAgICAgICBoZWlnaHQ6IDE1dmg7XHJcbi8vICAgICAgICAgICB3aWR0aDogMTAwJTtcclxuLy8gICAgICAgICAgIGZvbnQtd2VpZ2h0OiBib2xkO1xyXG4vLyAgICAgICAgICAgY29sb3I6ICNmZmY7XHJcbi8vICAgICAgIH1cclxuXHJcbiAgICAgXHJcbi8vICAgICAgIC8vIGlvbi1zbGlkZXtcclxuLy8gICAgICAgLy8gICAgIHdpZHRoOiAyNDVweCAhaW1wb3J0YW50O1xyXG4vLyAgICAgICAvLyB9XHJcblxyXG4vLyAgIGlvbi1jYXJkLWNvbnRlbnR7XHJcbi8vICAgICAgIHRleHQtYWxpZ246IGxlZnQ7XHJcbi8vICAgICAgICAgICAgICAgYmFja2dyb3VuZDogcmVkO1xyXG4vLyAgICAgICBsaW5lLWhlaWdodDogMS41O1xyXG4vLyAgICAgICB3aWR0aDogMTAwJTtcclxuLy8gICAgICAgcGFkZGluZy10b3A6IDdweDtcclxuLy8gICAgICAgcGFkZGluZy1ib3R0b206IDdweDtcclxuLy8gICB9XHJcblxyXG4vLyAgIGxhYmVse1xyXG4vLyAgICAgICBwYWRkaW5nLWxlZnQ6IDN2dztcclxuLy8gICB9XHJcbi8vICAgLnNlcnZpY2V7XHJcbi8vICAgICAgIGlvbi1jYXJkLWNvbnRlbnR7XHJcbi8vICAgICAgICAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XHJcbi8vICAgICAgICAgICBsaW5lLWhlaWdodDogMS41O1xyXG4vLyAgICAgICAgICAgd2lkdGg6IDEwMCU7XHJcbi8vICAgICAgICAgICBmb250LXNpemU6IDZweDtcclxuLy8gICAgICAgICAgIGJhY2tncm91bmQ6IHRyYW5zcGFyZW50O1xyXG4vLyAgICAgICAgICAgcGFkZGluZzogNXB4IDFweCAzcHg7XHJcbi8vICAgICAgIH1cclxuLy8gICAgICAgaW9uLWNhcmR7XHJcbi8vICAgICAgICAgICBwb3NpdGlvbjogcmVsYXRpdmU7XHJcbi8vICAgICAgICAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XHJcbi8vICAgICAgICAgICBib3JkZXItcmFkaXVzOiAxMHB4ICFpbXBvcnRhbnQ7ICBcclxuICAgICAgICAgIFxyXG4vLyAgICAgICB9XHJcbi8vICAgfVxyXG5cclxuLy8gICAvLyAuYm9yZGVyLXRvcCB7XHJcbi8vICAgLy8gICBib3JkZXItdG9wOiAxcHggc29saWQgbGlnaHRncmF5O1xyXG4vLyAgIC8vIH1cclxuICBcclxuLy8gICBpb24taXRlbSB7XHJcbi8vICAgICAvLyBib3JkZXItdG9wOiAxcHggc29saWQgbGlnaHRncmF5O1xyXG4vLyAgICAgYm9yZGVyLWJvdHRvbTogMXB4IHNvbGlkIGxpZ2h0Z3JheTtcclxuLy8gICB9XHJcbiAgXHJcbi8vICAgaW9uLWxhYmVsIHtcclxuLy8gICAgIHBhZGRpbmctdG9wOiAxMHB4ICFpbXBvcnRhbnQ7XHJcbi8vICAgICBwYWRkaW5nLWJvdHRvbTogMTBweCAhaW1wb3J0YW50O1xyXG4vLyAgIH1cclxuICBcclxuLy8gICBpb24tbGlzdCB7XHJcbi8vICAgICBwYWRkaW5nLXRvcDogMHB4ICFpbXBvcnRhbnQ7XHJcbi8vICAgfVxyXG4gIFxyXG5cclxuLy8gICBpb24tdG9vbGJhcntcclxuLy8gICAgIGJvcmRlci1ib3R0b20tbGVmdC1yYWRpdXM6IDI1cHg7XHJcbi8vICAgICBib3JkZXItYm90dG9tLXJpZ2h0LXJhZGl1czogMjVweDtcclxuLy8gICB9XHJcblxyXG5pb24tY2FyZHtcclxuICBiYWNrZ3JvdW5kOiB3aGl0ZTtcclxuICBwb3NpdGlvbjogYWJzb2x1dGU7XHJcbiAgbGVmdDogNTAlO1xyXG4gIGJvdHRvbTogLTE1dnc7XHJcbiAgdHJhbnNmb3JtOiB0cmFuc2xhdGUoLTUwJSwgLTUwJSk7XHJcbiAgbWFyZ2luOiAwIGF1dG87XHJcbiAgd2lkdGg6IDMwMHB4O1xyXG59XHJcblxyXG5cclxuaW9uLWNhcmQtdGl0bGV7XHJcbiAgcGFkZGluZy1ib3R0b206IDVweDtcclxuICAgIGZvbnQtc2l6ZTogMTJweDtcclxufVxyXG5cclxuLm15LW5hdiB7XHJcbiAgbGlzdC1zdHlsZS10eXBlOiBkaXNjO1xyXG4gIHRleHQtYWxpZ246IHN0YXJ0O1xyXG4gIHBhZGRpbmctbGVmdDogMTVweDtcclxuICBmb250LXNpemU6IDEzcHg7XHJcbn1cclxuaW9uLWl0ZW17XHJcbiAgZGlzcGxheTogaW5saW5lLXRhYmxlO1xyXG59XHJcblxyXG5pb24tY29udGVudHtcclxuICAtLWJhY2tncm91bmQ6IHVybCgnL2Fzc2V0cy9pbWdzL3NlcnZpY2VpbWFnZS5wbmcnKTtcclxuICBiYWNrZ3JvdW5kLXJlcGVhdDogbm8tcmVwZWF0O1xyXG4gICAgIGJhY2tncm91bmQtc2l6ZTogY292ZXI7XHJcbn1cclxuXHJcbi5iYWNrZ3JvdW5kLWltYWdle1xyXG4gXHJcbn1cclxuLmFkZC1zdWJ7XHJcbiAgbWFyZ2luLWxlZnQ6IDF2aDtcclxuICBtYXJnaW4tcmlnaHQ6IDF2aDtcclxufVxyXG4uYnRue1xyXG4gIHdpZHRoOiA2MCU7XHJcbiAgbWFyZ2luLXRvcDogNXB4O1xyXG4gIGZvbnQtc2l6ZTogMTBweDtcclxuICBoZWlnaHQ6IDI1cHg7XHJcblxyXG59XHJcbi8vIGlvbi1idXR0b257XHJcbi8vICAgLS1iYWNrZ3JvdW5kOiBnb2xkZW5yb2Q7XHJcbi8vIH1cclxuXHJcblxyXG5cclxuLy8gc2Vjb25kIHBhZ2VcclxuaW1ne1xyXG4gIHdpZHRoOjEwMCU7XHJcbiAgaGVpZ2h0OjEwMCU7XHJcbn1cclxuXHJcbi5teUNhcmR7XHJcbiAgcG9zaXRpb246cmVsYXRpdmU7XHJcblxyXG59XHJcblxyXG4ubXlPdmVybGF5e1xyXG4gIHdpZHRoOiAxMDAlO1xyXG4gIGhlaWdodDogMjJweDtcclxuICBwb3NpdGlvbjogYWJzb2x1dGU7XHJcbiAgei1pbmRleDogOTk7XHJcbiAgYm90dG9tOiAwcHg7XHJcbiAgb3BhY2l0eTogMC41O1xyXG4gIGJhY2tncm91bmQ6ICMwMDA7XHJcbiAgY29sb3I6ICNmZmY7XHJcblxyXG59Il19 */"

/***/ }),

/***/ "./src/app/Rentals Management/pages/nailaservicepage/nailaservicepage.ts":
/*!*******************************************************************************!*\
  !*** ./src/app/Rentals Management/pages/nailaservicepage/nailaservicepage.ts ***!
  \*******************************************************************************/
/*! exports provided: NailaservicePage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "NailaservicePage", function() { return NailaservicePage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _services_utils_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../services/utils.service */ "./src/app/Rentals Management/services/utils.service.ts");





// import { Slides } from 'ionic-angular';
var NailaservicePage = /** @class */ (function () {
    // sliderConfig = {
    //   slidesPerView: 1.2,
    //   spaceBetween: 5,
    //   // centeredSlides: true
    // };
    // sliderConfig2 = {
    //   slidesPerView: 3.2,
    //   spaceBetween: 5,
    //   // centeredSlides: true
    // };
    // public searchTerm: string = "";
    // public items: any;
    function NailaservicePage(utils, router, alertController) {
        this.utils = utils;
        this.router = router;
        this.alertController = alertController;
        this.disablebutton = false;
        // this.items = [
        //   { title: "one" },
        //   { title: "two" },
        //   { title: "three" },
        //   { title: "four" },
        //   { title: "five" },
        //   { title: "six" }
        // ];
        this.restrictproductadd = [];
        this.itemcounter = 0;
    }
    NailaservicePage.prototype.ngOnInit = function () {
        var _this = this;
        if (window.localStorage.getItem('cartitem')) {
            this.utils.cartdata = window.localStorage.getItem('cartitemcount');
            this.utils.cartitem = JSON.parse(window.localStorage.getItem('cartitem'));
        }
        else {
            this.utils.cartitem = [];
            this.utils.cartdata = [];
        }
        // this.setFilteredItems();
        console.log(this.utils.storage);
        // this.addTocart(this.utils.storage)
        if (window.localStorage.getItem('cartitem')) {
            this.restrictproductadd = JSON.parse(window.localStorage.getItem('cartitem'));
            this.restrictproductadd.forEach(function (element) {
                if (_this.utils.storage.name === element.service.name && element.servicecount > 0) {
                    _this.disablebutton = true;
                    _this.disabledButton();
                    // this.router.navigateByUrl('/rentals-naila-search-page')
                    // alert("Product already added")
                }
            });
        }
        this.percentagediscount = Math.trunc(this.percentage(this.utils.storage.offer_price, this.utils.storage.price));
    };
    NailaservicePage.prototype.percentage = function (partialValue, totalValue) {
        return (100 * partialValue) / totalValue;
    };
    //   setFilteredItems() {
    //     this.items = this.filterItems(this.searchTerm);
    //   }
    //   filterItems(searchTerm) {
    //     return this.items.filter(item => {
    //       return item.title.toLowerCase().indexOf(searchTerm.toLowerCase()) > -1;
    //     });
    //   }
    // a=false;
    NailaservicePage.prototype.itemCounter = function (plusminus) {
        if (plusminus == "plus" && this.itemcounter >= 0) {
            this.itemcounter = this.itemcounter + 1;
        }
        else if (plusminus == "minus" && this.itemcounter > 0) {
            this.itemcounter = this.itemcounter - 1;
        }
    };
    NailaservicePage.prototype.addTocart = function (data) {
        this.utils.cartitem.push({
            'service': data,
            'servicecount': 1
        });
        this.utils.cartdata = this.utils.cartitem.length;
        window.localStorage.setItem('cartitem', JSON.stringify(this.utils.cartitem));
        window.localStorage.setItem('cartitemcount', JSON.stringify(this.utils.cartitem.length));
        // this.utils.cartdata= this.utils.cartdata.reduce((a, b) => a + b, 0) 
    };
    // disabledButton(){
    //     alert("Product already added.If you want to increase the quantity please go to cart.")
    // }
    NailaservicePage.prototype.disabledButton = function () {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function () {
            var alert;
            var _this = this;
            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.alertController.create({
                            cssClass: 'my-custom-class',
                            message: 'Product already added.If you want to increase the quantity please go to cart.',
                            buttons: [
                                {
                                    text: 'Continue Shopping',
                                    // role: 'cancel',
                                    cssClass: 'secondary',
                                    handler: function (blah) {
                                        // console.log('Confirm Cancel: blah');
                                        _this.router.navigateByUrl('/rentals-naila-search-page');
                                    }
                                }, {
                                    text: 'Go to Cart',
                                    handler: function () {
                                        _this.router.navigateByUrl('/rentals-naila-cart-page');
                                    }
                                }
                            ]
                        })];
                    case 1:
                        alert = _a.sent();
                        return [4 /*yield*/, alert.present()];
                    case 2:
                        _a.sent();
                        return [2 /*return*/];
                }
            });
        });
    };
    NailaservicePage.prototype.ionViewWillLeave = function () {
        var _this = this;
        window.localStorage.removeItem('coupon_id');
        this.cartitemcounter = 0;
        this.utils.cartitem = JSON.parse(window.localStorage.getItem('cartitem'));
        this.locatemp = this.utils.cartitem;
        if (!this.utils.cartitem) {
            this.utils.cartitem = [];
        }
        var filtercartitem = this.utils.cartitem.filter(function (element) {
            return (element.servicecount > 0);
        });
        if (filtercartitem.length) {
            filtercartitem.forEach(function (element) {
                _this.cartitemcounter = element.servicecount + _this.cartitemcounter;
            });
            window.localStorage.setItem('cartitem', JSON.stringify(filtercartitem));
            window.localStorage.setItem('cartitemcount', this.cartitemcounter);
        }
    };
    NailaservicePage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-nailaservicepage',
            template: __webpack_require__(/*! ./nailaservicepage.html */ "./src/app/Rentals Management/pages/nailaservicepage/nailaservicepage.html"),
            styles: [__webpack_require__(/*! ./nailaservicepage.scss */ "./src/app/Rentals Management/pages/nailaservicepage/nailaservicepage.scss")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_services_utils_service__WEBPACK_IMPORTED_MODULE_4__["Utils"], _angular_router__WEBPACK_IMPORTED_MODULE_3__["Router"], _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["AlertController"]])
    ], NailaservicePage);
    return NailaservicePage;
}());



/***/ })

}]);
//# sourceMappingURL=Rentals-Management-pages-nailaservicepage-nailaservicepage-module.js.map