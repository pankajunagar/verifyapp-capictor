(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["Rentals-Management-pages-verifyitproductcatalog-verifyitproductcatalog-module"],{

/***/ "./src/app/Rentals Management/pages/verifyitproductcatalog/verifyitproductcatalog.html":
/*!*********************************************************************************************!*\
  !*** ./src/app/Rentals Management/pages/verifyitproductcatalog/verifyitproductcatalog.html ***!
  \*********************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ion-header no-border>\r\n  <ion-toolbar color=\"primary\">\r\n    <ion-buttons slot=\"start\">\r\n      <ion-menu-button></ion-menu-button>\r\n    </ion-buttons>\r\n    <!-- <ion-buttons slot=\"end\" expand=\"full\" class=\"ion-button\" (click)=\"openScanner()\">\r\n      <ion-button style=\"color: black\">\r\n          <img src=\"../../../../assets/icons.png\" width=\"30px\" height=\"30px\"/>\r\n      </ion-button>\r\n    </ion-buttons> -->\r\n\r\n    <ion-title>Product catalog</ion-title>\r\n  </ion-toolbar>\r\n\r\n</ion-header>\r\n\r\n\r\n<ion-content *ngIf=\"listbanner && this.listbanner.data[0].meta_data.category\" padding>\r\n\r\n    <!-- <ion-searchbar placeholder=\"Browse products\" mode=\"ios\"\r\n    [(ngModel)]=\"searchTerm\" (ionChange)=\"setFilteredItems()\"\r\n  ></ion-searchbar> -->\r\n\r\n  <ion-toolbar *ngIf=\"listGroupedProduct.length\">\r\n    <ion-title (click)=\"listGroupedProduct=[]\">  <ion-icon  ios=\"ios-arrow-round-back\" md=\"md-arrow-round-back\"></ion-icon>\r\n       </ion-title>\r\n  </ion-toolbar>\r\n  <ion-row *ngIf=\"listGroupedProduct.length\" class=\"center-text\">\r\n    <ion-col  *ngFor=\"let item of listGroupedProduct\" size=\"6\">\r\n\r\n      <ion-card  class=\"myCard\">\r\n        <img (click)=\"showProductInfo(item)\"\r\n          src={{item.img1}} />\r\n        <div class=\"myOverlay\">\r\n          <div class=\"card-title\">{{item.product_name}}</div>\r\n        </div>\r\n      </ion-card>\r\n\r\n    </ion-col>\r\n  </ion-row>\r\n  <ion-row *ngIf=\"!listGroupedProduct.length\" class=\"center-text\">\r\n    <ion-col  *ngFor=\"let item of jsonToBeUsed\" size=\"6\">\r\n\r\n      <ion-card (click)=\"showProductFromGroup(item.value)\"  class=\"myCard\">\r\n        <!-- <img (click)=\"showProductInfo(item)\"\r\n          src={{item.img1}} /> -->\r\n          <div class=\"card-title-group\">{{item.key}}</div>\r\n\r\n      \r\n      </ion-card>\r\n\r\n    </ion-col>\r\n    <!-- <ion-col>\r\n\r\n      <ion-card class=\"myCard\">\r\n        <img style=\"    height: 155px;\"\r\n          src=\"assets/imgs/dryer.jpg\" />\r\n        <div class=\"myOverlay\">\r\n          <div class=\"card-title\">Styling</div>\r\n        </div>\r\n      </ion-card>\r\n    </ion-col> -->\r\n\r\n  </ion-row>\r\n</ion-content>\r\n\r\n\r\n<ion-content *ngIf=\"listbanner  && !this.listbanner.data[0].meta_data.category\" padding>\r\n\r\n  <ion-searchbar placeholder=\"Browse products\" mode=\"ios\"\r\n  [(ngModel)]=\"searchTerm\" (ionChange)=\"setFilteredItems()\"\r\n></ion-searchbar>\r\n<ion-row class=\"center-text\">\r\n  <ion-col  *ngFor=\"let item of items\" size=\"6\">\r\n\r\n    <ion-card  class=\"myCard\">\r\n      <img *ngIf=\"item.img1\" (click)=\"showProductInfo(item)\"\r\n        src={{item.img1}} />\r\n      <div class=\"myOverlay\">\r\n        <div class=\"card-title\">{{item.product_name}}</div>\r\n      </div>\r\n    </ion-card>\r\n\r\n  </ion-col>\r\n  <!-- <ion-col>\r\n\r\n    <ion-card class=\"myCard\">\r\n      <img style=\"    height: 155px;\"\r\n        src=\"assets/imgs/dryer.jpg\" />\r\n      <div class=\"myOverlay\">\r\n        <div class=\"card-title\">Styling</div>\r\n      </div>\r\n    </ion-card>\r\n  </ion-col> -->\r\n\r\n</ion-row>\r\n</ion-content>"

/***/ }),

/***/ "./src/app/Rentals Management/pages/verifyitproductcatalog/verifyitproductcatalog.module.ts":
/*!**************************************************************************************************!*\
  !*** ./src/app/Rentals Management/pages/verifyitproductcatalog/verifyitproductcatalog.module.ts ***!
  \**************************************************************************************************/
/*! exports provided: VerifyitProductCatalogPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "VerifyitProductCatalogPageModule", function() { return VerifyitProductCatalogPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _ApplicationPageModule__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../ApplicationPageModule */ "./src/app/Rentals Management/ApplicationPageModule.ts");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _modals_create_notice_create_notice_component__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../../modals/create-notice/create-notice.component */ "./src/app/Rentals Management/modals/create-notice/create-notice.component.ts");
/* harmony import */ var _verifyitproductcatalog__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./verifyitproductcatalog */ "./src/app/Rentals Management/pages/verifyitproductcatalog/verifyitproductcatalog.ts");









// import { BarcodeScanner } from '@ionic-native/barcode-scanner/ngx';
// import { NailasearchPage } from './nailasearchpage';
// import { VerifyitProductCatalogPage } from './VerifyitProductCatalogPage';
var routes = [
    {
        path: '',
        component: _verifyitproductcatalog__WEBPACK_IMPORTED_MODULE_8__["VerifyitProductCatalogPage"]
    }
];
var VerifyitProductCatalogPageModule = /** @class */ (function () {
    function VerifyitProductCatalogPageModule() {
    }
    VerifyitProductCatalogPageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_2__["NgModule"])({
            entryComponents: [_modals_create_notice_create_notice_component__WEBPACK_IMPORTED_MODULE_7__["CreateNoticeComponent"]],
            imports: [
                _angular_common__WEBPACK_IMPORTED_MODULE_3__["CommonModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormsModule"],
                _ApplicationPageModule__WEBPACK_IMPORTED_MODULE_1__["ApplicationPageModule"],
                _ionic_angular__WEBPACK_IMPORTED_MODULE_6__["IonicModule"],
                _angular_router__WEBPACK_IMPORTED_MODULE_5__["RouterModule"].forChild(routes)
            ],
            providers: [
            // BarcodeScanner
            ],
            declarations: [_verifyitproductcatalog__WEBPACK_IMPORTED_MODULE_8__["VerifyitProductCatalogPage"]]
        })
    ], VerifyitProductCatalogPageModule);
    return VerifyitProductCatalogPageModule;
}());



/***/ }),

/***/ "./src/app/Rentals Management/pages/verifyitproductcatalog/verifyitproductcatalog.scss":
/*!*********************************************************************************************!*\
  !*** ./src/app/Rentals Management/pages/verifyitproductcatalog/verifyitproductcatalog.scss ***!
  \*********************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "img {\n  width: 100%;\n  height: 100%; }\n\n.myCard {\n  position: relative;\n  height: 165px;\n  width: 42vw !important;\n  background: black;\n  color: white;\n  font-size: 27px;\n  font-family: cursive; }\n\n.myOverlay {\n  width: 100%;\n  height: 45px;\n  position: absolute;\n  z-index: 99;\n  font-size: 12px;\n  bottom: 0px;\n  color: #fff;\n  background: linear-gradient(to bottom, transparent, black); }\n\nion-col {\n  margin-left: -2vw; }\n\n.card-title {\n  margin-top: 2vw; }\n\n.card-title-group {\n  margin-top: 2vw;\n  margin-top: 16vw;\n  font-weight: 500;\n  vertical-align: middle; }\n\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvUmVudGFscyBNYW5hZ2VtZW50L3BhZ2VzL3ZlcmlmeWl0cHJvZHVjdGNhdGFsb2cvRDpcXG5hdmpvdFxcdmVyaWZ5L3NyY1xcYXBwXFxSZW50YWxzIE1hbmFnZW1lbnRcXHBhZ2VzXFx2ZXJpZnlpdHByb2R1Y3RjYXRhbG9nXFx2ZXJpZnlpdHByb2R1Y3RjYXRhbG9nLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDRSxXQUFVO0VBQ1YsWUFBVyxFQUFBOztBQUdiO0VBQ0Usa0JBQWlCO0VBQ2pCLGFBQWE7RUFDWCxzQkFBc0I7RUFDdEIsaUJBQWlCO0VBQ2pCLFlBQVk7RUFDWixlQUFlO0VBQ2Ysb0JBRUosRUFBQTs7QUFFQTtFQUNFLFdBQVc7RUFDWCxZQUFZO0VBQ1osa0JBQWtCO0VBQ2xCLFdBQVc7RUFDWCxlQUFlO0VBQ2YsV0FBVztFQUdYLFdBQVc7RUFDWCwwREFBeUQsRUFBQTs7QUFJM0Q7RUFDRSxpQkFBaUIsRUFBQTs7QUFHbkI7RUFDRSxlQUFlLEVBQUE7O0FBRWpCO0VBQ0UsZUFBZTtFQUNmLGdCQUFnQjtFQUNoQixnQkFBZ0I7RUFFaEIsc0JBQXNCLEVBQUEiLCJmaWxlIjoic3JjL2FwcC9SZW50YWxzIE1hbmFnZW1lbnQvcGFnZXMvdmVyaWZ5aXRwcm9kdWN0Y2F0YWxvZy92ZXJpZnlpdHByb2R1Y3RjYXRhbG9nLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyJpbWd7XHJcbiAgd2lkdGg6MTAwJTtcclxuICBoZWlnaHQ6MTAwJTtcclxufVxyXG5cclxuLm15Q2FyZHtcclxuICBwb3NpdGlvbjpyZWxhdGl2ZTtcclxuICBoZWlnaHQ6IDE2NXB4O1xyXG4gICAgd2lkdGg6IDQydncgIWltcG9ydGFudDtcclxuICAgIGJhY2tncm91bmQ6IGJsYWNrO1xyXG4gICAgY29sb3I6IHdoaXRlO1xyXG4gICAgZm9udC1zaXplOiAyN3B4O1xyXG4gICAgZm9udC1mYW1pbHk6IGN1cnNpdmVcclxuXHJcbn1cclxuXHJcbi5teU92ZXJsYXl7XHJcbiAgd2lkdGg6IDEwMCU7XHJcbiAgaGVpZ2h0OiA0NXB4O1xyXG4gIHBvc2l0aW9uOiBhYnNvbHV0ZTtcclxuICB6LWluZGV4OiA5OTtcclxuICBmb250LXNpemU6IDEycHg7XHJcbiAgYm90dG9tOiAwcHg7XHJcbiAgLy8gb3BhY2l0eTogMC41O1xyXG4gIC8vIGJhY2tncm91bmQ6ICMwMDA7XHJcbiAgY29sb3I6ICNmZmY7XHJcbiAgYmFja2dyb3VuZDogbGluZWFyLWdyYWRpZW50KHRvIGJvdHRvbSx0cmFuc3BhcmVudCwgYmxhY2spO1xyXG5cclxuXHJcbn1cclxuaW9uLWNvbHtcclxuICBtYXJnaW4tbGVmdDogLTJ2dztcclxufVxyXG5cclxuLmNhcmQtdGl0bGV7XHJcbiAgbWFyZ2luLXRvcDogMnZ3O1xyXG59XHJcbi5jYXJkLXRpdGxlLWdyb3Vwe1xyXG4gIG1hcmdpbi10b3A6IDJ2dztcclxuICBtYXJnaW4tdG9wOiAxNnZ3O1xyXG4gIGZvbnQtd2VpZ2h0OiA1MDA7XHJcbiAgLy8gY29sb3I6IGJsYWNrO1xyXG4gIHZlcnRpY2FsLWFsaWduOiBtaWRkbGU7XHJcbn1cclxuIl19 */"

/***/ }),

/***/ "./src/app/Rentals Management/pages/verifyitproductcatalog/verifyitproductcatalog.ts":
/*!*******************************************************************************************!*\
  !*** ./src/app/Rentals Management/pages/verifyitproductcatalog/verifyitproductcatalog.ts ***!
  \*******************************************************************************************/
/*! exports provided: VerifyitProductCatalogPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "VerifyitProductCatalogPage", function() { return VerifyitProductCatalogPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _services_naila_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../services/naila.service */ "./src/app/Rentals Management/services/naila.service.ts");
/* harmony import */ var _services_utils_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../services/utils.service */ "./src/app/Rentals Management/services/utils.service.ts");





// import { Slides } from 'ionic-angular';
var VerifyitProductCatalogPage = /** @class */ (function () {
    function VerifyitProductCatalogPage(nailaservice, utils, router) {
        this.nailaservice = nailaservice;
        this.utils = utils;
        this.router = router;
        this.groupedProducts = [];
        this.jsonToBeUsed = [];
        this.values = [];
        this.result = [];
        this.listGroupedProduct = [];
    }
    VerifyitProductCatalogPage.prototype.ngOnInit = function () {
        var _this = this;
        // 
        this.nailaservice.listRelatedProducts(this.utils.productId).subscribe(function (data) {
            _this.listbanner = data;
            if (_this.listbanner.data[0].meta_data.category) {
                _this.groupBy(_this.listbanner.data, "category");
                console.log('=================================>===============');
                _this.groupedProducts.push(_this.result);
                Object.keys(_this.result).forEach(function (e) { return _this.jsonToBeUsed.push({ key: e, value: _this.result[e] }); });
                console.log(_this.jsonToBeUsed);
                console.log('=================================>===============');
            }
            _this.items = _this.listbanner.data;
            _this.listbanner.data.forEach(function (element) {
                element.name = element.product_name;
            });
            console.log(_this.listbanner);
        });
    };
    VerifyitProductCatalogPage.prototype.setFilteredItems = function () {
        this.items = this.listbanner.data;
        this.items = this.filterItems(this.searchTerm);
    };
    VerifyitProductCatalogPage.prototype.filterItems = function (searchTerm) {
        return this.items.filter(function (item) {
            return item.name.toLowerCase().indexOf(searchTerm.toLowerCase()) > -1;
        });
    };
    VerifyitProductCatalogPage.prototype.showProductInfo = function (item) {
        this.utils.productCatalogInfo = '';
        this.utils.productCatalogInfo = item;
        this.router.navigateByUrl('/verifyit-product-catalog-info');
    };
    VerifyitProductCatalogPage.prototype.groupBy = function (collection, property) {
        var _this = this;
        debugger;
        // var i = 0, val, index
        // for (; i < collection.length; i++) {
        //     val = collection[i].meta_data.category;
        //     index = this.values.indexOf(val);
        //     if (index > -1)
        //         this.result[index].push(collection[i]);
        //     else {
        //         this.values.push(val);
        //         this.result.push([collection[i]]);
        //     }
        // }
        collection.reduce(function (acc, d) {
            if (Object.keys(acc).includes(d.meta_data.category))
                return acc;
            acc[d.meta_data.category] = collection.filter(function (g) { return g.meta_data.category === d.meta_data.category; });
            return _this.result = acc;
            // this.result.push(acc);
        }, {});
    };
    VerifyitProductCatalogPage.prototype.showProductFromGroup = function (value) {
        this.listGroupedProduct = value;
    };
    VerifyitProductCatalogPage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-verifyitproductcatalog',
            template: __webpack_require__(/*! ./verifyitproductcatalog.html */ "./src/app/Rentals Management/pages/verifyitproductcatalog/verifyitproductcatalog.html"),
            styles: [__webpack_require__(/*! ./verifyitproductcatalog.scss */ "./src/app/Rentals Management/pages/verifyitproductcatalog/verifyitproductcatalog.scss")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_services_naila_service__WEBPACK_IMPORTED_MODULE_3__["NailaService"], _services_utils_service__WEBPACK_IMPORTED_MODULE_4__["Utils"], _angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"]])
    ], VerifyitProductCatalogPage);
    return VerifyitProductCatalogPage;
}());



/***/ })

}]);
//# sourceMappingURL=Rentals-Management-pages-verifyitproductcatalog-verifyitproductcatalog-module.js.map