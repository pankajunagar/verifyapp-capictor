(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["Rentals-Management-pages-calendar-calendar-module"],{

/***/ "./src/app/Rentals Management/pages/calendar/calendar.module.ts":
/*!**********************************************************************!*\
  !*** ./src/app/Rentals Management/pages/calendar/calendar.module.ts ***!
  \**********************************************************************/
/*! exports provided: CalendarPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CalendarPageModule", function() { return CalendarPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _ApplicationPageModule__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./../../ApplicationPageModule */ "./src/app/Rentals Management/ApplicationPageModule.ts");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _calendar_page__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./calendar.page */ "./src/app/Rentals Management/pages/calendar/calendar.page.ts");








var routes = [
    {
        path: '',
        component: _calendar_page__WEBPACK_IMPORTED_MODULE_7__["CalendarPage"]
    }
];
var CalendarPageModule = /** @class */ (function () {
    function CalendarPageModule() {
    }
    CalendarPageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_2__["NgModule"])({
            imports: [
                _ApplicationPageModule__WEBPACK_IMPORTED_MODULE_1__["ApplicationPageModule"],
                _angular_common__WEBPACK_IMPORTED_MODULE_3__["CommonModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormsModule"],
                _ionic_angular__WEBPACK_IMPORTED_MODULE_6__["IonicModule"],
                _angular_router__WEBPACK_IMPORTED_MODULE_5__["RouterModule"].forChild(routes)
            ],
            declarations: [_calendar_page__WEBPACK_IMPORTED_MODULE_7__["CalendarPage"]]
        })
    ], CalendarPageModule);
    return CalendarPageModule;
}());



/***/ }),

/***/ "./src/app/Rentals Management/pages/calendar/calendar.page.html":
/*!**********************************************************************!*\
  !*** ./src/app/Rentals Management/pages/calendar/calendar.page.html ***!
  \**********************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ion-header>\r\n  <ion-toolbar color=\"primary\">\r\n    <ion-buttons slot=\"start\">\r\n      <ion-back-button></ion-back-button>\r\n    </ion-buttons>\r\n    <ion-title class=\"padding-0\" >{{transService.getTranslatedData('calendar.title')}}</ion-title>\r\n  </ion-toolbar>\r\n  <ion-segment scrollable mode=\"md\" class=\"shadow margin-padding-zero\" value=\"4\">\r\n    <ion-segment-button mode=\"md\" *ngFor=\"let date of dateList let i= index\"\r\n      class=\"margin-padding-zero min-width-37 font-12\" value=\"{{i}}\" (click)=\"resetDate(date)\">\r\n      <ion-label class=\"margin-padding-zero gotham txt-warm-grey\">{{date |\r\n        date:'EEE'}}</ion-label>\r\n      <span class=\"padding-0 margin-top-5 margin-bottom-5 gotham font-30\r\n        black-color\">{{date | date:'dd' }}</span>\r\n      <ion-label class=\"margin-padding-zero txt-warm-grey\">{{date | date:'MMM'}}</ion-label>\r\n    </ion-segment-button>\r\n  </ion-segment>\r\n</ion-header>\r\n\r\n<ion-content>\r\n\r\n  <!-- <span class=\"font-14 gotham\" *ngIf=\"tickets?.length == 0\" style=\"margin-top:5px; padding-left:15px\">No tasks\r\n    found</span> -->\r\n  <ion-list class=\"margin-top-10\">\r\n    <ion-item *ngFor=\"let ticket of tickets\" detail=\"true\" lines=\"none\" [routerLink]=\"['/rentals-ticket-details']\"\r\n      [queryParams]=\"{ticketId: ticket._id}\">\r\n      <ion-label class=\"margin-0\">\r\n        <p class=\"gotham-medium margin-bottom-8\" text-wrap>\r\n          <span class=\"float-left\">#{{ticket.uid}} - </span>\r\n          <span class=\"center-text\"> {{ticket.ticketCategory}}</span>\r\n          <span class=\"float-right\">{{ticket.createdAt | date:'dd MMM\r\n            yyyy'|agoFilter}}</span>\r\n        </p>\r\n        <!-- <p class=\"gotham font-weight-600 txt-grey\">{{d.address}}</p> -->\r\n        <p class=\"gotham font-weight-600 txt-grey margin-bottom-8\">\r\n          {{ticket.propertyName}} - {{ticket.propertyLocality}}</p>\r\n        <!-- <p class=\"gotham font-weight-600 txt-grey\">For -\r\n          {{ticket.ticketBelongsTo == 'Home' ? 'Unit' : ticket.ticketBelongsTo}}</p> -->\r\n        <p>\r\n          <ion-badge class=\"gotham font-weight-600 padding-top-5\r\n            padding-bottom-3 date-bedge-color\" mode=\"md\">\r\n            {{ticket.jobDate | date:'dd MMM yyyy'}} {{ticket.jobStartTime |\r\n            date:'hh:mm a'}}\r\n          </ion-badge>\r\n          <ion-badge class=\"gotham font-weight-600 margin-left-20 padding-top-5\" color=\"{{ticket.status}}\" mode=\"md\">\r\n            {{ticket.status == 'in-progress' ? transService.getTranslatedData('calendar.in-progress') : ticket.status}}\r\n          </ion-badge>\r\n        </p>\r\n      </ion-label>\r\n    </ion-item>\r\n  </ion-list>\r\n\r\n  <ion-infinite-scroll [hidden]=\"disableInfiniteScroll\" threshold=\"5px\" (ionInfinite)=\"searchTicket($event)\">\r\n    <ion-infinite-scroll-content loadingSpinner=\"bubbles\"\r\n      loadingText=\"{{transService.getTranslatedData('infinite-scroll')}}\">\r\n    </ion-infinite-scroll-content>\r\n  </ion-infinite-scroll>\r\n\r\n</ion-content>"

/***/ }),

/***/ "./src/app/Rentals Management/pages/calendar/calendar.page.scss":
/*!**********************************************************************!*\
  !*** ./src/app/Rentals Management/pages/calendar/calendar.page.scss ***!
  \**********************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ".border-top {\n  border-top: 1px solid lightgray; }\n\nion-item {\n  border-bottom: 1px solid lightgray; }\n\nion-label {\n  padding-top: 10px !important;\n  padding-bottom: 10px !important; }\n\nion-list {\n  padding-top: 0px !important; }\n\n.overflow-span {\n  overflow: hidden;\n  white-space: nowrap;\n  text-overflow: ellipsis; }\n\n.class1 {\n  display: flex !important;\n  margin-bottom: 8px !important; }\n\nion-badge {\n  --padding: 4px !important; }\n\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvUmVudGFscyBNYW5hZ2VtZW50L3BhZ2VzL2NhbGVuZGFyL0Q6XFxuYXZqb3RcXHZlcmlmeS9zcmNcXGFwcFxcUmVudGFscyBNYW5hZ2VtZW50XFxwYWdlc1xcY2FsZW5kYXJcXGNhbGVuZGFyLnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNFLCtCQUErQixFQUFBOztBQUdqQztFQUVFLGtDQUFrQyxFQUFBOztBQUdwQztFQUNFLDRCQUE0QjtFQUM1QiwrQkFBK0IsRUFBQTs7QUFHakM7RUFDRSwyQkFBMkIsRUFBQTs7QUFHN0I7RUFDRSxnQkFBZ0I7RUFDaEIsbUJBQW1CO0VBQ25CLHVCQUF1QixFQUFBOztBQUd6QjtFQUNFLHdCQUF3QjtFQUN4Qiw2QkFBNkIsRUFBQTs7QUFFL0I7RUFDRSx5QkFBVSxFQUFBIiwiZmlsZSI6InNyYy9hcHAvUmVudGFscyBNYW5hZ2VtZW50L3BhZ2VzL2NhbGVuZGFyL2NhbGVuZGFyLnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIi5ib3JkZXItdG9wIHtcclxuICBib3JkZXItdG9wOiAxcHggc29saWQgbGlnaHRncmF5O1xyXG59XHJcblxyXG5pb24taXRlbSB7XHJcbiAgLy8gYm9yZGVyLXRvcDogMXB4IHNvbGlkIGxpZ2h0Z3JheTtcclxuICBib3JkZXItYm90dG9tOiAxcHggc29saWQgbGlnaHRncmF5O1xyXG59XHJcblxyXG5pb24tbGFiZWwge1xyXG4gIHBhZGRpbmctdG9wOiAxMHB4ICFpbXBvcnRhbnQ7XHJcbiAgcGFkZGluZy1ib3R0b206IDEwcHggIWltcG9ydGFudDtcclxufVxyXG5cclxuaW9uLWxpc3Qge1xyXG4gIHBhZGRpbmctdG9wOiAwcHggIWltcG9ydGFudDtcclxufVxyXG5cclxuLm92ZXJmbG93LXNwYW4ge1xyXG4gIG92ZXJmbG93OiBoaWRkZW47XHJcbiAgd2hpdGUtc3BhY2U6IG5vd3JhcDtcclxuICB0ZXh0LW92ZXJmbG93OiBlbGxpcHNpcztcclxufVxyXG5cclxuLmNsYXNzMSB7XHJcbiAgZGlzcGxheTogZmxleCAhaW1wb3J0YW50O1xyXG4gIG1hcmdpbi1ib3R0b206IDhweCAhaW1wb3J0YW50O1xyXG59XHJcbmlvbi1iYWRnZSB7XHJcbiAgLS1wYWRkaW5nOiA0cHggIWltcG9ydGFudDtcclxufVxyXG4iXX0= */"

/***/ }),

/***/ "./src/app/Rentals Management/pages/calendar/calendar.page.ts":
/*!********************************************************************!*\
  !*** ./src/app/Rentals Management/pages/calendar/calendar.page.ts ***!
  \********************************************************************/
/*! exports provided: CalendarPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CalendarPage", function() { return CalendarPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _services_ticket_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../services/ticket.service */ "./src/app/Rentals Management/services/ticket.service.ts");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var src_app_common_services_alert_service_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/common-services/alert-service.service */ "./src/app/common-services/alert-service.service.ts");
/* harmony import */ var src_app_common_services_translate_translate_service_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! src/app/common-services/translate/translate-service.service */ "./src/app/common-services/translate/translate-service.service.ts");






var CalendarPage = /** @class */ (function () {
    function CalendarPage(ticketService, loading, alertService, transService) {
        this.ticketService = ticketService;
        this.loading = loading;
        this.alertService = alertService;
        this.transService = transService;
        this.dateList = [];
        this.tickets = [];
        this.disableInfiniteScroll = false;
        this.filterData = {
            skip: 0,
            ticketBelongsTo: 'all',
            type: 'all',
            priority: 'all',
            status: '&status=open&status=in-progress',
            startDate: ((new Date(new Date().setHours(0, 0, 0, 0))).toJSON()).substr(0, 10),
            endDate: ((new Date(new Date().setHours(23, 59, 59, 999))).toJSON()).substr(0, 10)
        };
        this.searchTicket('');
    }
    CalendarPage.prototype.ngOnInit = function () {
        var date = new Date();
        var startDate = new Date(date.setDate(date.getDate() - 5));
        for (var i = 0; i <= 8; i++) {
            this.dateList.push(new Date(startDate.setDate(startDate.getDate() + 1)));
        }
    };
    CalendarPage.prototype.presentLoading = function () {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function () {
            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.loading.create({
                            spinner: "lines"
                        }).then(function (loading) {
                            loading.present();
                        })];
                    case 1:
                        _a.sent();
                        return [2 /*return*/];
                }
            });
        });
    };
    CalendarPage.prototype.searchTicket = function (event) {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function () {
            var _this = this;
            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                switch (_a.label) {
                    case 0:
                        if (!!event) return [3 /*break*/, 2];
                        return [4 /*yield*/, this.presentLoading()];
                    case 1:
                        _a.sent();
                        _a.label = 2;
                    case 2:
                        this.ticketService.getTickets(this.filterData.skip, this.filterData.status, this.filterData.ticketBelongsTo, this.filterData.type, '', '', this.filterData.startDate, this.filterData.endDate, '', '', '')
                            .subscribe(function (data) {
                            _this.tickets = _this.tickets.concat(data.data.data);
                            _this.filterData.skip = data.data.query.skip + 10;
                            event ? event.target.complete() : _this.loading.dismiss();
                            if (data.data.query.current >= data.data.query.total) {
                                _this.disableInfiniteScroll = true;
                            }
                        }, function (err) {
                            // this.loading.dismiss();
                            _this.alertService.presentAlert(_this.transService.getTranslatedData('alert-title'), err.error.error);
                        });
                        return [2 /*return*/];
                }
            });
        });
    };
    CalendarPage.prototype.resetDate = function (date) {
        this.tickets = [];
        this.filterData.skip = 0;
        this.filterData.startDate = ((new Date(new Date(date).setHours(0, 0, 0, 0))).toJSON()).substr(0, 10);
        this.filterData.endDate = ((new Date(new Date(date).setHours(23, 59, 59, 999))).toJSON()).substr(0, 10);
        this.searchTicket('');
    };
    CalendarPage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-calendar',
            template: __webpack_require__(/*! ./calendar.page.html */ "./src/app/Rentals Management/pages/calendar/calendar.page.html"),
            styles: [__webpack_require__(/*! ./calendar.page.scss */ "./src/app/Rentals Management/pages/calendar/calendar.page.scss")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_services_ticket_service__WEBPACK_IMPORTED_MODULE_2__["TicketService"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["LoadingController"],
            src_app_common_services_alert_service_service__WEBPACK_IMPORTED_MODULE_4__["AlertServiceService"],
            src_app_common_services_translate_translate_service_service__WEBPACK_IMPORTED_MODULE_5__["translateService"]])
    ], CalendarPage);
    return CalendarPage;
}());



/***/ })

}]);
//# sourceMappingURL=Rentals-Management-pages-calendar-calendar-module.js.map