(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["Rentals-Management-pages-tickets-tickets-module"],{

/***/ "./src/app/Rentals Management/components/ticket/ticket.component.html":
/*!****************************************************************************!*\
  !*** ./src/app/Rentals Management/components/ticket/ticket.component.html ***!
  \****************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ion-list class=\"padding-0\">\r\n  <ion-radio-group>\r\n    <ion-list-header class=\"justify-center gotham\">Sort By</ion-list-header>\r\n    <ion-item lines=\"full\">\r\n      <ion-label class=\"gotham\">Job Date</ion-label>\r\n      <ion-radio mode=\"md\" value=\"jobDate\" checked></ion-radio>\r\n    </ion-item>\r\n    <ion-item lines=\"full\">\r\n      <ion-label class=\"gotham\">Created At</ion-label>\r\n      <ion-radio mode=\"md\" value=\"createdAt\"></ion-radio>\r\n    </ion-item>\r\n    <ion-item lines=\"full\">\r\n      <ion-label class=\"gotham\">Ascending</ion-label>\r\n      <ion-radio mode=\"md\" value=\"ascending\"></ion-radio>\r\n    </ion-item>\r\n    <ion-item lines=\"full\">\r\n      <ion-label class=\"gotham\">Descending</ion-label>\r\n      <ion-radio mode=\"md\" value=\"descinding\"></ion-radio>\r\n    </ion-item>\r\n  </ion-radio-group>\r\n</ion-list>\r\n<ion-button (click)=\"close()\" class=\"gotham margin-0\" expand=\"full\">\r\n  Filter\r\n</ion-button>"

/***/ }),

/***/ "./src/app/Rentals Management/components/ticket/ticket.component.scss":
/*!****************************************************************************!*\
  !*** ./src/app/Rentals Management/components/ticket/ticket.component.scss ***!
  \****************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ".popover-content.sc-ion-popover-ios {\n  border-radius: 0px !important; }\n\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvUmVudGFscyBNYW5hZ2VtZW50L2NvbXBvbmVudHMvdGlja2V0L0Q6XFxuYXZqb3RcXHZlcmlmeS9zcmNcXGFwcFxcUmVudGFscyBNYW5hZ2VtZW50XFxjb21wb25lbnRzXFx0aWNrZXRcXHRpY2tldC5jb21wb25lbnQuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNJLDZCQUE2QixFQUFBIiwiZmlsZSI6InNyYy9hcHAvUmVudGFscyBNYW5hZ2VtZW50L2NvbXBvbmVudHMvdGlja2V0L3RpY2tldC5jb21wb25lbnQuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIi5wb3BvdmVyLWNvbnRlbnQuc2MtaW9uLXBvcG92ZXItaW9zIHtcclxuICAgIGJvcmRlci1yYWRpdXM6IDBweCAhaW1wb3J0YW50O1xyXG4gIH0iXX0= */"

/***/ }),

/***/ "./src/app/Rentals Management/components/ticket/ticket.component.ts":
/*!**************************************************************************!*\
  !*** ./src/app/Rentals Management/components/ticket/ticket.component.ts ***!
  \**************************************************************************/
/*! exports provided: TicketComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "TicketComponent", function() { return TicketComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");



var TicketComponent = /** @class */ (function () {
    function TicketComponent(popOverCtrl) {
        this.popOverCtrl = popOverCtrl;
    }
    TicketComponent.prototype.ngOnInit = function () { };
    TicketComponent.prototype.close = function () {
        this.popOverCtrl.dismiss();
    };
    TicketComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_2__["Component"])({
            selector: 'app-ticket',
            template: __webpack_require__(/*! ./ticket.component.html */ "./src/app/Rentals Management/components/ticket/ticket.component.html"),
            styles: [__webpack_require__(/*! ./ticket.component.scss */ "./src/app/Rentals Management/components/ticket/ticket.component.scss")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_ionic_angular__WEBPACK_IMPORTED_MODULE_1__["PopoverController"]])
    ], TicketComponent);
    return TicketComponent;
}());



/***/ }),

/***/ "./src/app/Rentals Management/pages/tickets/tickets.module.ts":
/*!********************************************************************!*\
  !*** ./src/app/Rentals Management/pages/tickets/tickets.module.ts ***!
  \********************************************************************/
/*! exports provided: TicketsPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "TicketsPageModule", function() { return TicketsPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _ApplicationPageModule__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./../../ApplicationPageModule */ "./src/app/Rentals Management/ApplicationPageModule.ts");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _tickets_page__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./tickets.page */ "./src/app/Rentals Management/pages/tickets/tickets.page.ts");
/* harmony import */ var _components_ticket_ticket_component__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../../components/ticket/ticket.component */ "./src/app/Rentals Management/components/ticket/ticket.component.ts");









var routes = [
    {
        path: '',
        component: _tickets_page__WEBPACK_IMPORTED_MODULE_7__["TicketsPage"]
    }
];
var TicketsPageModule = /** @class */ (function () {
    function TicketsPageModule() {
    }
    TicketsPageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_2__["NgModule"])({
            entryComponents: [_components_ticket_ticket_component__WEBPACK_IMPORTED_MODULE_8__["TicketComponent"]],
            imports: [
                _angular_common__WEBPACK_IMPORTED_MODULE_3__["CommonModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormsModule"],
                _ionic_angular__WEBPACK_IMPORTED_MODULE_6__["IonicModule"],
                _ApplicationPageModule__WEBPACK_IMPORTED_MODULE_1__["ApplicationPageModule"],
                _angular_router__WEBPACK_IMPORTED_MODULE_5__["RouterModule"].forChild(routes),
            ],
            declarations: [_tickets_page__WEBPACK_IMPORTED_MODULE_7__["TicketsPage"], _components_ticket_ticket_component__WEBPACK_IMPORTED_MODULE_8__["TicketComponent"]]
        })
    ], TicketsPageModule);
    return TicketsPageModule;
}());



/***/ }),

/***/ "./src/app/Rentals Management/pages/tickets/tickets.page.html":
/*!********************************************************************!*\
  !*** ./src/app/Rentals Management/pages/tickets/tickets.page.html ***!
  \********************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ion-header>\r\n  <ion-toolbar color=\"primary\">\r\n    <ion-buttons slot=\"start\">\r\n      <ion-back-button></ion-back-button>\r\n    </ion-buttons>\r\n    <ion-buttons slot=\"end\">\r\n      <ion-button (click)=\"openTicketFilterModal()\">\r\n        <ion-icon name=\"funnel\" mode=\"ios\"></ion-icon>\r\n      </ion-button>\r\n    </ion-buttons>\r\n    <ion-title class=\"padding-0\" >{{transService.getTranslatedData('ticket.title')}}</ion-title>\r\n  </ion-toolbar>\r\n</ion-header>\r\n\r\n<ion-content>\r\n  <p class=\"gotham center-text\" *ngIf=\"noTicket&&tickets.length==0\">\r\n    {{transService.getTranslatedData('ticket.empty-array')}}</p>\r\n  <ion-list class=\"border-top padding-bottom-0\">\r\n    <ion-item *ngFor=\"let ticket of tickets\" [routerLink]=\"['/rentals-ticket-details']\"\r\n      [queryParams]=\"{ticketId: ticket._id}\" detail=\"true\" lines=\"none\">\r\n      <ion-label class=\"margin-0\">\r\n        <p class=\"gotham-medium margin-bottom-8 \" text-wrap>\r\n          <span class=\"float-left\">#{{ticket.uid}} - </span>\r\n          <span class=\"center-text\"> {{ticket.ticketCategory}}</span>\r\n          <span class=\"float-right gotham\">{{ticket.createdAt | agoFilter}}</span>\r\n        </p>\r\n        <p class=\"gotham font-weight-600 txt-grey margin-bottom-8\">\r\n          {{ticket.block?ticket.block+' - ':''}}{{ticket.door}} {{ticket.propertyName}} - {{ticket.propertyLocality}}\r\n        </p>\r\n\r\n        <ion-badge *ngIf=\"ticket.jobStartTime\"\r\n          class=\"gotham font-weight-600 date-bedge-color padding-bottom-3 padding-top-6\" mode=\"md\">\r\n          {{ticket.jobDate | date:'dd MMM yyyy'}} {{ticket.jobStartTime | date:'hh:mm a'}}\r\n        </ion-badge>\r\n        <ion-badge class=\"gotham font-weight-600 padding-top-5\" [ngClass]=\"{'margin-left-20': ticket.jobStartTime}\"\r\n          color=\"{{ticket.status}}\" mode=\"md\">\r\n          {{ticket.status == 'in-progress' ? transService.getTranslatedData('ticket.in-progress') : ticket.status}}\r\n        </ion-badge>\r\n      </ion-label>\r\n    </ion-item>\r\n  </ion-list>\r\n\r\n  <ion-infinite-scroll [hidden]=\"disableInfiniteScroll\" threshold=\"5px\" (ionInfinite)=\"searchTicket($event)\">\r\n    <ion-infinite-scroll-content loadingSpinner=\"bubbles\"\r\n      loadingText=\"{{transService.getTranslatedData('infinite-scroll')}}\">\r\n    </ion-infinite-scroll-content>\r\n  </ion-infinite-scroll>\r\n</ion-content>"

/***/ }),

/***/ "./src/app/Rentals Management/pages/tickets/tickets.page.scss":
/*!********************************************************************!*\
  !*** ./src/app/Rentals Management/pages/tickets/tickets.page.scss ***!
  \********************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ".border-top {\n  border-top: 1px solid lightgray; }\n\nion-item {\n  border-bottom: 1px solid lightgray; }\n\nion-label {\n  padding-top: 10px !important;\n  padding-bottom: 10px !important; }\n\nion-list {\n  padding-top: 0px !important; }\n\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvUmVudGFscyBNYW5hZ2VtZW50L3BhZ2VzL3RpY2tldHMvRDpcXG5hdmpvdFxcdmVyaWZ5L3NyY1xcYXBwXFxSZW50YWxzIE1hbmFnZW1lbnRcXHBhZ2VzXFx0aWNrZXRzXFx0aWNrZXRzLnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNFLCtCQUErQixFQUFBOztBQUdqQztFQUVFLGtDQUFrQyxFQUFBOztBQUdwQztFQUNFLDRCQUE0QjtFQUM1QiwrQkFBK0IsRUFBQTs7QUFHakM7RUFDRSwyQkFBMkIsRUFBQSIsImZpbGUiOiJzcmMvYXBwL1JlbnRhbHMgTWFuYWdlbWVudC9wYWdlcy90aWNrZXRzL3RpY2tldHMucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiLmJvcmRlci10b3Age1xyXG4gIGJvcmRlci10b3A6IDFweCBzb2xpZCBsaWdodGdyYXk7XHJcbn1cclxuXHJcbmlvbi1pdGVtIHtcclxuICAvLyBib3JkZXItdG9wOiAxcHggc29saWQgbGlnaHRncmF5O1xyXG4gIGJvcmRlci1ib3R0b206IDFweCBzb2xpZCBsaWdodGdyYXk7XHJcbn1cclxuXHJcbmlvbi1sYWJlbCB7XHJcbiAgcGFkZGluZy10b3A6IDEwcHggIWltcG9ydGFudDtcclxuICBwYWRkaW5nLWJvdHRvbTogMTBweCAhaW1wb3J0YW50O1xyXG59XHJcblxyXG5pb24tbGlzdCB7XHJcbiAgcGFkZGluZy10b3A6IDBweCAhaW1wb3J0YW50O1xyXG59XHJcbiJdfQ== */"

/***/ }),

/***/ "./src/app/Rentals Management/pages/tickets/tickets.page.ts":
/*!******************************************************************!*\
  !*** ./src/app/Rentals Management/pages/tickets/tickets.page.ts ***!
  \******************************************************************/
/*! exports provided: TicketsPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "TicketsPage", function() { return TicketsPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _services_ticket_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../services/ticket.service */ "./src/app/Rentals Management/services/ticket.service.ts");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _pages_ticket_filter_ticket_filter_page__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../pages/ticket-filter/ticket-filter.page */ "./src/app/Rentals Management/pages/ticket-filter/ticket-filter.page.ts");
/* harmony import */ var src_app_common_services_alert_service_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! src/app/common-services/alert-service.service */ "./src/app/common-services/alert-service.service.ts");
/* harmony import */ var _components_ticket_ticket_component__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../../components/ticket/ticket.component */ "./src/app/Rentals Management/components/ticket/ticket.component.ts");
/* harmony import */ var src_app_common_services_translate_translate_service_service__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! src/app/common-services/translate/translate-service.service */ "./src/app/common-services/translate/translate-service.service.ts");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");









var TicketsPage = /** @class */ (function () {
    function TicketsPage(ticketService, ref, loading, modalController, alertService, popOverCtrl, transService, route) {
        var _this = this;
        this.ticketService = ticketService;
        this.ref = ref;
        this.loading = loading;
        this.modalController = modalController;
        this.alertService = alertService;
        this.popOverCtrl = popOverCtrl;
        this.transService = transService;
        this.route = route;
        this.tickets = [];
        this.disableInfiniteScroll = false;
        this.noTicket = false;
        this.filterData = {
            skip: 0,
            status: ['open', 'in-progress'],
            ticketBelongsTo: 'all',
            type: 'on-demand',
            priority: 'all'
        };
        this.status = '';
        // this.searchTicket('');
        this.route.queryParams.subscribe(function (params) {
            if (params && params.id) {
                _this.filterData.asset = params.id;
                _this.filterData.assetId = params.name;
            }
            _this.searchTicket('');
        });
    }
    TicketsPage.prototype.ngOnInit = function () {
    };
    TicketsPage.prototype.presentLoading = function () {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function () {
            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.loading.create({
                            spinner: "lines"
                        }).then(function (loading) {
                            loading.present();
                        })];
                    case 1:
                        _a.sent();
                        return [2 /*return*/];
                }
            });
        });
    };
    TicketsPage.prototype.openTicketFilterModal = function () {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function () {
            var modal;
            var _this = this;
            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.modalController.create({
                            component: _pages_ticket_filter_ticket_filter_page__WEBPACK_IMPORTED_MODULE_4__["TicketFilterPage"],
                            componentProps: {
                                data: this.dataFromFilterPage
                            }
                        })];
                    case 1:
                        modal = _a.sent();
                        modal.onDidDismiss().then(function (ticketFilter) {
                            if (ticketFilter !== null && ticketFilter.data) {
                                _this.dataFromFilterPage = ticketFilter.data;
                                console.log("sadasdasdasdasd", ticketFilter);
                                ticketFilter.data.agent ? _this.filterData.agent = ticketFilter.data.agent : _this.filterData.agent = '';
                                ticketFilter.data.startDate ? _this.filterData.startDate = ticketFilter.data.startDate : _this.filterData.startDate = '';
                                ticketFilter.data.endDate ? _this.filterData.endDate = ticketFilter.data.endDate : _this.filterData.endDate = '';
                                ticketFilter.data.ticketBelongsToRefId ? _this.filterData.projects = ticketFilter.data.ticketBelongsToRefId : _this.filterData.projects = '';
                                ticketFilter.data.agent ? _this.filterData.agent = ticketFilter.data.agent : _this.filterData.agent = '';
                                ticketFilter.data.contactPoint ? _this.filterData.contactPoint = ticketFilter.data.contactPoint : _this.filterData.contactPoint = '';
                                if (ticketFilter.data.ticketBelongsTo) {
                                    ticketFilter.data.ticketBelongsTo.length > 1 ? _this.filterData.ticketBelongsTo = 'all' : _this.filterData.ticketBelongsTo = ticketFilter.data.ticketBelongsTo[0];
                                }
                                if (ticketFilter.data.type) {
                                    ticketFilter.data.type.length > 1 ? _this.filterData.type = 'all' : _this.filterData.type = ticketFilter.data.type[0];
                                }
                                if (ticketFilter.data.priority) {
                                    ticketFilter.data.priority.length > 1 ? _this.filterData.priority = 'all' : _this.filterData.priority = ticketFilter.data.priority[0];
                                }
                                if (ticketFilter.data.status) {
                                    _this.filterData.status = ticketFilter.data.status;
                                }
                                if (_this.filterData.startDate) {
                                    _this.filterData.startDate = new Date(_this.filterData.startDate);
                                    _this.filterData.startDate = new Date(_this.filterData.startDate.setHours(0, 0, 0, 0));
                                    _this.filterData.startDate = (_this.filterData.startDate.toJSON()).substr(0, 10);
                                }
                                if (_this.filterData.startDate && !_this.filterData.endDate) {
                                    var d = new Date(_this.filterData.startDate);
                                    var year = d.getFullYear();
                                    var month = d.getMonth();
                                    var day = d.getDate();
                                    var end = new Date(year + 1, month, day);
                                    _this.filterData.endDate = end.toJSON().substr(0, 10);
                                }
                                if (_this.filterData.endDate) {
                                    _this.filterData.endDate = new Date(_this.filterData.endDate);
                                    _this.filterData.endDate = new Date(_this.filterData.endDate.setHours(0, 0, 0, 0));
                                    _this.filterData.endDate = (_this.filterData.endDate.toJSON()).substr(0, 10);
                                }
                                _this.tickets = [];
                                _this.filterData.skip = 0;
                                _this.searchTicket('');
                                console.log(_this.filterData);
                            }
                        });
                        return [4 /*yield*/, modal.present()];
                    case 2: return [2 /*return*/, _a.sent()];
                }
            });
        });
    };
    // skip,
    // status,
    // ticketBelongsTo,
    // type,
    // projects,
    // priority,
    // startDate,
    // endDate,
    // contactPoint,
    // agent,
    // asset
    TicketsPage.prototype.searchTicket = function (event) {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function () {
            var _this = this;
            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                switch (_a.label) {
                    case 0:
                        this.status = '';
                        if (!!event) return [3 /*break*/, 2];
                        return [4 /*yield*/, this.presentLoading()];
                    case 1:
                        _a.sent();
                        this.disableInfiniteScroll = false;
                        _a.label = 2;
                    case 2: return [4 /*yield*/, this.filterData.status.forEach(function (element) {
                            _this.status = _this.status + ("&status=" + element);
                        })];
                    case 3:
                        _a.sent();
                        // alert(this.status)
                        this.ticketService.getTickets(this.filterData.skip || '', this.status || '', this.filterData.ticketBelongsTo || '', this.filterData.type || '', this.filterData.projects || '', this.filterData.priority || '', this.filterData.startDate || '', this.filterData.endDate || '', this.filterData.contactPoint || '', this.filterData.agent || '', this.filterData.asset || '')
                            .subscribe(function (data) {
                            _this.tickets = _this.tickets.concat(data.data.data);
                            _this.filterData.skip = data.data.query.skip + 10;
                            _this.noTicket = true;
                            event ? event.target.complete() : _this.loading.dismiss();
                            if (data.data.query.current >= data.data.query.total) {
                                _this.disableInfiniteScroll = true;
                            }
                        }, function (err) {
                            _this.loading.dismiss();
                            _this.alertService.presentAlert(_this.transService.getTranslatedData('alert-title'), err.error.error);
                        });
                        return [2 /*return*/];
                }
            });
        });
    };
    TicketsPage.prototype.popOverOption = function () {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function () {
            var popOver;
            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.popOverCtrl.create({
                            component: _components_ticket_ticket_component__WEBPACK_IMPORTED_MODULE_6__["TicketComponent"],
                            event: event,
                            mode: 'ios'
                        })];
                    case 1:
                        popOver = _a.sent();
                        return [4 /*yield*/, popOver.present()];
                    case 2: return [2 /*return*/, _a.sent()];
                }
            });
        });
    };
    TicketsPage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-tickets',
            template: __webpack_require__(/*! ./tickets.page.html */ "./src/app/Rentals Management/pages/tickets/tickets.page.html"),
            styles: [__webpack_require__(/*! ./tickets.page.scss */ "./src/app/Rentals Management/pages/tickets/tickets.page.scss")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_services_ticket_service__WEBPACK_IMPORTED_MODULE_2__["TicketService"],
            _angular_core__WEBPACK_IMPORTED_MODULE_1__["ChangeDetectorRef"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["LoadingController"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["ModalController"],
            src_app_common_services_alert_service_service__WEBPACK_IMPORTED_MODULE_5__["AlertServiceService"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["PopoverController"],
            src_app_common_services_translate_translate_service_service__WEBPACK_IMPORTED_MODULE_7__["translateService"],
            _angular_router__WEBPACK_IMPORTED_MODULE_8__["ActivatedRoute"]])
    ], TicketsPage);
    return TicketsPage;
}());



/***/ })

}]);
//# sourceMappingURL=Rentals-Management-pages-tickets-tickets-module.js.map