(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["Rentals-Management-pages-nailabeauticianattendance-nailabeauticianattendance-module"],{

/***/ "./src/app/Rentals Management/pages/nailabeauticianattendance/nailabeauticianattendance.html":
/*!***************************************************************************************************!*\
  !*** ./src/app/Rentals Management/pages/nailabeauticianattendance/nailabeauticianattendance.html ***!
  \***************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ion-header no-border>\r\n  <ion-toolbar color=\"primary\">\r\n    <ion-buttons slot=\"start\">\r\n      <ion-menu-button></ion-menu-button>\r\n    </ion-buttons>\r\n    <!-- <ion-buttons slot=\"end\" expand=\"full\" class=\"ion-button\" (click)=\"openScanner()\">\r\n      <ion-button style=\"color: black\">\r\n          <img style=\"width: 15px;\r\n            height: 15px;\" src=\"../../../../assets/icons.png\" width=\"30px\" height=\"30px\"/>\r\n      </ion-button>\r\n    </ion-buttons> -->\r\n\r\n    <ion-title>Attendance</ion-title>\r\n  </ion-toolbar>\r\n\r\n</ion-header>\r\n\r\n\r\n<ion-content class=\"ion-text-center\" fullscreen>\r\n  <ion-list>\r\n<ion-item lines=\"none\" >\r\n  <ion-button (click)=\"markAttendance()\" style=\"min-width: 120px;\r\n  margin-bottom: 15vw;\r\n  margin-top: 50vw;\">Punch in</ion-button>\r\n\r\n</ion-item>\r\n<br>\r\n<ion-item lines=\"none\">\r\n  <ion-button (click)=\"updateAttendance()\" style=\"min-width: 120px;\">Punch out</ion-button>\r\n</ion-item>\r\n  </ion-list>\r\n</ion-content>"

/***/ }),

/***/ "./src/app/Rentals Management/pages/nailabeauticianattendance/nailabeauticianattendance.module.ts":
/*!********************************************************************************************************!*\
  !*** ./src/app/Rentals Management/pages/nailabeauticianattendance/nailabeauticianattendance.module.ts ***!
  \********************************************************************************************************/
/*! exports provided: NailabeauticianAttendanceModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "NailabeauticianAttendanceModule", function() { return NailabeauticianAttendanceModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _ApplicationPageModule__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../ApplicationPageModule */ "./src/app/Rentals Management/ApplicationPageModule.ts");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _modals_create_notice_create_notice_component__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../../modals/create-notice/create-notice.component */ "./src/app/Rentals Management/modals/create-notice/create-notice.component.ts");
/* harmony import */ var _nailabeauticianattendance__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./nailabeauticianattendance */ "./src/app/Rentals Management/pages/nailabeauticianattendance/nailabeauticianattendance.ts");








// import { BarcodeScanner } from '@ionic-native/barcode-scanner/ngx';
// // import { NailabeauticianAttendance } from './NailabeauticianAttendance';
// import { RefundModalComponent } from '../../modals/refundmodal/refundmodal.component';
// import { PrivacyPolicyModalComponent } from '../../modals/privacypolicy/privacypolicy.component';
// import { TermsModalComponent } from '../../modals/termsandcondition/termsandcondition.component';

var routes = [
    {
        path: '',
        component: _nailabeauticianattendance__WEBPACK_IMPORTED_MODULE_8__["NailabeauticianAttendance"]
    }
];
var NailabeauticianAttendanceModule = /** @class */ (function () {
    function NailabeauticianAttendanceModule() {
    }
    NailabeauticianAttendanceModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_2__["NgModule"])({
            entryComponents: [_modals_create_notice_create_notice_component__WEBPACK_IMPORTED_MODULE_7__["CreateNoticeComponent"]],
            imports: [
                _angular_common__WEBPACK_IMPORTED_MODULE_3__["CommonModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormsModule"],
                _ApplicationPageModule__WEBPACK_IMPORTED_MODULE_1__["ApplicationPageModule"],
                _ionic_angular__WEBPACK_IMPORTED_MODULE_6__["IonicModule"],
                _angular_router__WEBPACK_IMPORTED_MODULE_5__["RouterModule"].forChild(routes)
            ],
            providers: [
            // BarcodeScanner,
            // RefundModalComponent,
            // PrivacyPolicyModalComponent,
            // TermsModalComponent
            ],
            declarations: [_nailabeauticianattendance__WEBPACK_IMPORTED_MODULE_8__["NailabeauticianAttendance"]]
        })
    ], NailabeauticianAttendanceModule);
    return NailabeauticianAttendanceModule;
}());



/***/ }),

/***/ "./src/app/Rentals Management/pages/nailabeauticianattendance/nailabeauticianattendance.scss":
/*!***************************************************************************************************!*\
  !*** ./src/app/Rentals Management/pages/nailabeauticianattendance/nailabeauticianattendance.scss ***!
  \***************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "ion-item {\n  display: inline-flex; }\n\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvUmVudGFscyBNYW5hZ2VtZW50L3BhZ2VzL25haWxhYmVhdXRpY2lhbmF0dGVuZGFuY2UvRDpcXG5hdmpvdFxcdmVyaWZ5L3NyY1xcYXBwXFxSZW50YWxzIE1hbmFnZW1lbnRcXHBhZ2VzXFxuYWlsYWJlYXV0aWNpYW5hdHRlbmRhbmNlXFxuYWlsYWJlYXV0aWNpYW5hdHRlbmRhbmNlLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDRSxvQkFBb0IsRUFBQSIsImZpbGUiOiJzcmMvYXBwL1JlbnRhbHMgTWFuYWdlbWVudC9wYWdlcy9uYWlsYWJlYXV0aWNpYW5hdHRlbmRhbmNlL25haWxhYmVhdXRpY2lhbmF0dGVuZGFuY2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbImlvbi1pdGVte1xyXG4gIGRpc3BsYXk6IGlubGluZS1mbGV4O1xyXG59Il19 */"

/***/ }),

/***/ "./src/app/Rentals Management/pages/nailabeauticianattendance/nailabeauticianattendance.ts":
/*!*************************************************************************************************!*\
  !*** ./src/app/Rentals Management/pages/nailabeauticianattendance/nailabeauticianattendance.ts ***!
  \*************************************************************************************************/
/*! exports provided: NailabeauticianAttendance */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "NailabeauticianAttendance", function() { return NailabeauticianAttendance; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _modals_privacypolicy_privacypolicy_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../modals/privacypolicy/privacypolicy.component */ "./src/app/Rentals Management/modals/privacypolicy/privacypolicy.component.ts");
/* harmony import */ var _modals_termsandcondition_termsandcondition_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../modals/termsandcondition/termsandcondition.component */ "./src/app/Rentals Management/modals/termsandcondition/termsandcondition.component.ts");
/* harmony import */ var _services_naila_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../services/naila.service */ "./src/app/Rentals Management/services/naila.service.ts");






// import { Slides } from 'ionic-angular';
var NailabeauticianAttendance = /** @class */ (function () {
    function NailabeauticianAttendance(nailaservice, alertController, modalController) {
        this.nailaservice = nailaservice;
        this.alertController = alertController;
        this.modalController = modalController;
    }
    NailabeauticianAttendance.prototype.ngOnInit = function () {
        this.beauticianid = window.localStorage.getItem('beautician_id');
    };
    NailabeauticianAttendance.prototype.presentAlert = function () {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function () {
            var alert;
            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.alertController.create({
                            subHeader: 'Whatsapp',
                            message: 'You can contact Naila Support Team on 7624943335 number.',
                            buttons: ['OK']
                        })];
                    case 1:
                        alert = _a.sent();
                        return [4 /*yield*/, alert.present()];
                    case 2:
                        _a.sent();
                        return [2 /*return*/];
                }
            });
        });
    };
    // async openCreateRefundModal() {
    //   let modal = await this.modalController.create({
    //     component: RefundModalComponent,
    //   })
    //   return await modal.present();
    // }
    NailabeauticianAttendance.prototype.openPrivacyPolicyModal = function () {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function () {
            var modal;
            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.modalController.create({
                            component: _modals_privacypolicy_privacypolicy_component__WEBPACK_IMPORTED_MODULE_3__["PrivacyPolicyModalComponent"],
                        })];
                    case 1:
                        modal = _a.sent();
                        return [4 /*yield*/, modal.present()];
                    case 2: return [2 /*return*/, _a.sent()];
                }
            });
        });
    };
    NailabeauticianAttendance.prototype.TandCModal = function () {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function () {
            var modal;
            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.modalController.create({
                            component: _modals_termsandcondition_termsandcondition_component__WEBPACK_IMPORTED_MODULE_4__["TermsModalComponent"],
                        })];
                    case 1:
                        modal = _a.sent();
                        return [4 /*yield*/, modal.present()];
                    case 2: return [2 /*return*/, _a.sent()];
                }
            });
        });
    };
    NailabeauticianAttendance.prototype.dismiss = function () {
        this.modalController.dismiss({
            'dismissed': true
        });
    };
    NailabeauticianAttendance.prototype.markAttendance = function () {
        var _this = this;
        var data = {
            "beautician_id": this.beauticianid
        };
        this.nailaservice.markAttendance(data).subscribe(function (data) {
            _this.punchindata = data;
            window.localStorage.setItem('punchin_id', _this.punchindata.id);
            alert('Punch In successfully');
        });
    };
    NailabeauticianAttendance.prototype.updateAttendance = function () {
        var data = {
            "beautician_id": this.beauticianid
        };
        this.punchinid = window.localStorage.getItem('punchin_id');
        this.nailaservice.updateAttendance(data, this.punchinid).subscribe(function (data) {
            alert('Punch Out successfully');
        });
    };
    NailabeauticianAttendance = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-nailabeauticianattendance',
            template: __webpack_require__(/*! ./nailabeauticianattendance.html */ "./src/app/Rentals Management/pages/nailabeauticianattendance/nailabeauticianattendance.html"),
            styles: [__webpack_require__(/*! ./nailabeauticianattendance.scss */ "./src/app/Rentals Management/pages/nailabeauticianattendance/nailabeauticianattendance.scss")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_services_naila_service__WEBPACK_IMPORTED_MODULE_5__["NailaService"], _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["AlertController"], _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["ModalController"]])
    ], NailabeauticianAttendance);
    return NailabeauticianAttendance;
}());



/***/ })

}]);
//# sourceMappingURL=Rentals-Management-pages-nailabeauticianattendance-nailabeauticianattendance-module.js.map