(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["Rentals-Management-pages-ticket-details-ticket-details-module"],{

/***/ "./src/app/Rentals Management/pages/ticket-details/ticket-details.module.ts":
/*!**********************************************************************************!*\
  !*** ./src/app/Rentals Management/pages/ticket-details/ticket-details.module.ts ***!
  \**********************************************************************************/
/*! exports provided: TicketDetailsPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "TicketDetailsPageModule", function() { return TicketDetailsPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _ApplicationPageModule__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./../../ApplicationPageModule */ "./src/app/Rentals Management/ApplicationPageModule.ts");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var ngx_avatar__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ngx-avatar */ "./node_modules/ngx-avatar/fesm5/ngx-avatar.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _ticket_details_page__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./ticket-details.page */ "./src/app/Rentals Management/pages/ticket-details/ticket-details.page.ts");









var routes = [
    {
        path: '',
        component: _ticket_details_page__WEBPACK_IMPORTED_MODULE_8__["TicketDetailsPage"]
    }
];
var TicketDetailsPageModule = /** @class */ (function () {
    function TicketDetailsPageModule() {
    }
    TicketDetailsPageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_2__["NgModule"])({
            imports: [
                _angular_common__WEBPACK_IMPORTED_MODULE_3__["CommonModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormsModule"],
                _ionic_angular__WEBPACK_IMPORTED_MODULE_7__["IonicModule"],
                ngx_avatar__WEBPACK_IMPORTED_MODULE_6__["AvatarModule"],
                _ApplicationPageModule__WEBPACK_IMPORTED_MODULE_1__["ApplicationPageModule"],
                _angular_router__WEBPACK_IMPORTED_MODULE_5__["RouterModule"].forChild(routes)
            ],
            declarations: [_ticket_details_page__WEBPACK_IMPORTED_MODULE_8__["TicketDetailsPage"]]
        })
    ], TicketDetailsPageModule);
    return TicketDetailsPageModule;
}());



/***/ }),

/***/ "./src/app/Rentals Management/pages/ticket-details/ticket-details.page.html":
/*!**********************************************************************************!*\
  !*** ./src/app/Rentals Management/pages/ticket-details/ticket-details.page.html ***!
  \**********************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ion-header no-border>\r\n  <ion-toolbar color=\"primary\">\r\n    <ion-buttons slot=\"start\">\r\n      <ion-back-button></ion-back-button>\r\n    </ion-buttons>\r\n    <ion-buttons slot=\"end\">\r\n      <ion-button [routerLink]=\"['/rentals-create-ticket']\" [queryParams]=\"{ticketId: ticket._id}\">\r\n        {{transService.getTranslatedData('ticket-details.edit')}}\r\n      </ion-button>\r\n    </ion-buttons>\r\n    <ion-title class=\"center-text\">\r\n      {{transService.getTranslatedData('ticket-details.title')}} #{{ticket.uid}}\r\n    </ion-title>\r\n  </ion-toolbar>\r\n  <div>\r\n    <ion-segment scrollable class=\" shadow margin-padding-zero \" [(ngModel)]=\"selectedTab\">\r\n      <ion-segment-button class=\"margin-padding-zero font-12\" value=\"SUMMARY\">\r\n        <ion-label class=\"margin-padding-zero\">{{transService.getTranslatedData('ticket-details.summery')}}</ion-label>\r\n      </ion-segment-button>\r\n      <ion-segment-button class=\"font-12 \" value=\"ASSETS\">\r\n        <ion-label class=\"margin-padding-zero\">{{transService.getTranslatedData('ticket-details.assets')}}</ion-label>\r\n      </ion-segment-button>\r\n      <ion-segment-button class=\"font-12\" value=\"COMMENTS\" (click)=\"getTicketComments()\">\r\n        <ion-label>{{transService.getTranslatedData('ticket-details.comments')}}</ion-label>\r\n      </ion-segment-button>\r\n      <ion-segment-button class=\"margin-padding-zero font-12\" value=\"CHECKLIST\">\r\n        <ion-label>{{transService.getTranslatedData('ticket-details.checklist')}}</ion-label>\r\n      </ion-segment-button>\r\n      <ion-segment-button class=\"font-12\" value=\"QUOTATIONS\">\r\n        <ion-label>{{transService.getTranslatedData('ticket-details.quotations')}}</ion-label>\r\n      </ion-segment-button>\r\n      <ion-segment-button class=\"font-12\" value=\"MATERIALS\">\r\n        <ion-label>{{transService.getTranslatedData('ticket-details.materials')}}</ion-label>\r\n      </ion-segment-button>\r\n    </ion-segment>\r\n  </div>\r\n</ion-header>\r\n\r\n<ion-content>\r\n\r\n  <div [ngSwitch]=\"selectedTab\">\r\n\r\n    <div *ngSwitchCase=\"'SUMMARY'\">\r\n      <div class=\"ticket-details-card\">\r\n        <ion-row>\r\n          <ion-col>\r\n            <p class=\"txt-slate-grey margin-padding-zero font-14 gotham-medium margin-bottom-3\">\r\n              {{transService.getTranslatedData('ticket-details.category')}}</p>\r\n            <P class=\"gotham-medium margin-top-10 font-14 dark-grey\">{{ticket.ticketCategory}}</P>\r\n          </ion-col>\r\n        </ion-row>\r\n        <ion-row>\r\n          <ion-col>\r\n            <p class=\"txt-slate-grey margin-padding-zero gotham-medium font-14 margin-bottom-3\">\r\n              {{transService.getTranslatedData('ticket-details.sub-category')}}</p>\r\n            <P class=\"gotham-medium margin-top-10 font-14 dark-grey\">{{ticket.ticketSubCategory}}</P>\r\n          </ion-col>\r\n        </ion-row>\r\n        <ion-row>\r\n          <ion-col>\r\n            <p class=\"txt-slate-grey margin-padding-zero font-14 gotham-medium margin-bottom-3\">\r\n              {{transService.getTranslatedData('ticket-details.created-on')}}</p>\r\n            <p class=\"gotham-medium margin-top-10 font-14 dark-grey\">\r\n              {{ticket.createdAt | date:'dd MMM yyyy' }}</p>\r\n          </ion-col>\r\n          <ion-col>\r\n            <p class=\"txt-slate-grey margin-padding-zero font-14 gotham-medium margin-bottom-3\">\r\n              {{transService.getTranslatedData('ticket-details.due-date')}}</p>\r\n            <p class=\"gotham-medium margin-top-10 font-14 dark-grey\">\r\n              {{ticket.deadlineDate | date:'dd MMM yyyy'}}</p>\r\n          </ion-col>\r\n        </ion-row>\r\n        <ion-row>\r\n          <ion-col>\r\n            <p class=\"txt-slate-grey margin-padding-zero font-14 gotham-medium margin-bottom-3\">\r\n              {{transService.getTranslatedData('ticket-details.description')}}</p>\r\n            <p class=\"gotham-medium margin-top-10 font-14 dark-grey\">\r\n              {{ticket.notes}}</p>\r\n            <p class=\"gotham-medium margin-top-10 font-14 dark-grey\" [hidden]=\"ticket.notes\">\r\n              {{transService.getTranslatedData('ticket-details.no-description')}}</p>\r\n          </ion-col>\r\n        </ion-row>\r\n        <ion-row>\r\n          <!-- <ion-col>\r\n            <p class=\"txt-slate-grey margin-padding-zero font-14 gotham-medium margin-bottom-3\">LOCATION</p>\r\n            <p class=\"gotham-medium margin-top-10 font-14 dark-grey\">\r\n              <span class=\"gotham-medium \">{{address.block}}</span>\r\n              <span class=\" gotham-medium \">{{address.door}}</span>\r\n              {{address.name}}\r\n            </p>\r\n          </ion-col> -->\r\n          <ion-col>\r\n            <p class=\"txt-slate-grey font-14 margin-padding-zero gotham-medium margin-bottom-3\">\r\n              {{transService.getTranslatedData('ticket-details.priority')}}</p>\r\n            <p class=\"gotham-medium margin-top-10 font-14 dark-grey\">{{ticket.priority}}</p>\r\n          </ion-col>\r\n        </ion-row>\r\n      </div>\r\n\r\n      <div class=\"ticket-details-card dark-grey\">\r\n        <ion-row>\r\n          <ion-col>\r\n            <p class=\"txt-slate-grey font-14 gotham-medium\">{{transService.getTranslatedData('ticket-details.people')}}\r\n            </p>\r\n          </ion-col>\r\n        </ion-row>\r\n\r\n        <ion-row class=\"margin-bottom-10\">\r\n          <ion-col size=\"2\">\r\n            <ngx-avatar initialsSize=\"2\" textSizeRatio=\"2\" name=\"{{ticket.raisedBy?.firstName}}\"></ngx-avatar>\r\n          </ion-col>\r\n          <ion-col class=\"margin-left-10\">\r\n            <p class=\"gotham-medium font-14 dark-grey margin-padding-zero\">\r\n              {{transService.getTranslatedData('ticket-details.raised-by')}}</p>\r\n            <p *ngIf=\"ticket.raisedBy\"\r\n              class=\"txt-warm-grey font-14 gotham-medium font-weight-500 margin-top-8 txt-nowrap\">\r\n              {{ticket.raisedBy.firstName}} {{ticket.raisedBy.lastName}}\r\n            </p>\r\n            <!-- <p class=\"txt-warm-grey font-14 gotham-medium font-weight-500 margin-padding-zero\">Click here to add</p> -->\r\n          </ion-col>\r\n          <ion-col class=\"center-text \">\r\n            <img class=\"float-right icon-25\" src=\"/assets/icon/phone.png\" (click)=\"call(ticket.raisedBy.phoneNumber)\" >\r\n          </ion-col>\r\n        </ion-row>\r\n\r\n        <ion-row class=\" margin-bottom-10\">\r\n          <ion-col size=\"2\">\r\n            <ngx-avatar textSizeRatio=\"2\" initialsSize=\"2\" name=\"{{ticket.contactPoint?.firstName}}\"></ngx-avatar>\r\n          </ion-col>\r\n          <ion-col class=\"margin-left-10\">\r\n            <p class=\"gotham-medium font-14 dark-grey margin-padding-zero\">\r\n              {{transService.getTranslatedData('ticket-details.poc')}}</p>\r\n            <p *ngIf=\"ticket.contactPoint\"\r\n              class=\"txt-warm-grey font-14 gotham-medium font-weight-500 margin-top-8 txt-nowrap\">\r\n              {{ticket.contactPoint.firstName}} {{ticket.contactPoint.lastName}}\r\n              <span class=\"float-right font-14 txt-warm-grey gotham-medium font-weight-500\"\r\n                (click)=\"openUserSearchModal('poc')\">{{transService.getTranslatedData('ticket-details.change')}}</span>\r\n            </p>\r\n            <p *ngIf=\"!ticket.contactPoint\"\r\n              class=\"txt-warm-grey gotham-medium font-14 font-weight-500 margin-top-8 txt-nowrap\">\r\n              {{transService.getTranslatedData('ticket-details.not-added')}}<span\r\n                class=\"float-right font-14 txt-warm-grey gotham-medium font-weight-500\"\r\n                (click)=\"openUserSearchModal('poc')\">{{transService.getTranslatedData('ticket-details.add')}}</span>\r\n            </p>\r\n          </ion-col>\r\n        </ion-row>\r\n\r\n        <ion-row class=\" margin-bottom-10\">\r\n          <ion-col size=\"2\" class=\"padding-right-20\">\r\n            <ngx-avatar initialsSize=\"2\" textSizeRatio=\"2\" class=\"margin-padding-zero font-14\"\r\n              name=\"{{ticket.agent?.firstName}}\">\r\n              <div class=\"margin-padding-zero\"></div>\r\n            </ngx-avatar>\r\n          </ion-col>\r\n          <ion-col class=\"margin-left-10\">\r\n            <p class=\"gotham-medium font-14 dark-grey margin-padding-zero\">\r\n              {{transService.getTranslatedData('ticket-details.technician')}}</p>\r\n            <p *ngIf=\"ticket.agent\" class=\"txt-warm-grey font-14 gotham-medium font-weight-500 margin-top-8 txt-nowrap\">\r\n              {{ticket.agent.firstName}} {{ticket.agent.lastName}}\r\n              <span class=\"float-right font-14 txt-warm-grey gotham-medium font-weight-500\"\r\n                (click)=\"openUserSearchModal('agent')\">{{transService.getTranslatedData('ticket-details.change')}}</span>\r\n            </p>\r\n            <p *ngIf=\"!ticket.agent\"\r\n              class=\"txt-warm-grey font-14 gotham-medium font-weight-500 margin-top-8 txt-nowrap\">\r\n              Not added\r\n              <span class=\"float-right font-14 txt-warm-grey gotham-medium font-weight-500\"\r\n                (click)=\"openUserSearchModal('agent')\">{{transService.getTranslatedData('ticket-details.add')}}</span>\r\n            </p>\r\n          </ion-col>\r\n        </ion-row>\r\n      </div>\r\n\r\n      <div class=\"ticket-details-card\">\r\n        <ion-row>\r\n          <ion-col>\r\n            <p class=\"txt-slate-grey font-14 gotham-medium margin-bottom-3\">\r\n              {{transService.getTranslatedData('ticket-details.photos')}}</p>\r\n          </ion-col>\r\n        </ion-row>\r\n        <ion-row style=\"flex-wrap: wrap;\">\r\n\r\n          <ion-col size=\"3\" style=\"position: relative;\" *ngFor=\"let file of ticket.files\">\r\n            <!-- <img src=\"assets/icon/delete.png\"\r\n              style=\"height: 25px; width: 25px; position: absolute; right: 6px; top: 6px;\"\r\n              (click)=\"removeImage(file._id)\"> -->\r\n            <img src=\"{{file.aws_url}}\" (click)=\"openImage(file.aws_url)\" class=\"img-responsive height-70 border-radius-10 \" />\r\n          </ion-col>\r\n\r\n          <ion-col size=\"3\" class=\"center-text\" (click)=\"presentActionSheet()\">\r\n            <img src=\"assets/icon/add-green.png\" class=\"height-30 width-30 border-radius-10 \" />\r\n            <p class=\"txt-slate-grey gotham-medium margin-top-10 font-weight-500 font-14\">\r\n              {{transService.getTranslatedData('ticket-details.add-photo')}}</p>\r\n          </ion-col>\r\n\r\n        </ion-row>\r\n        <div class=\"font-14 txt-brown center-text\" *ngIf=\"ticket.files?.length == 0||images.length!>1\">\r\n          {{transService.getTranslatedData('ticket-details.no-picture')}}</div>\r\n      </div>\r\n\r\n      <div class=\"ticket-details-card\">\r\n        <ion-row>\r\n          <ion-col>\r\n            <p class=\"txt-slate-grey gotham-medium font-14 margin-bottom-10  \">\r\n              {{transService.getTranslatedData('ticket-details.job-details')}}</p>\r\n          </ion-col>\r\n        </ion-row>\r\n        <ion-row>\r\n          <ion-col>\r\n            <p class=\"txt-slate-grey font-14 gotham-medium margin-padding-zero\">\r\n              {{transService.getTranslatedData('ticket-details.start-date')}}</p>\r\n            <p *ngIf=\"ticket.jobDate\" class=\"gotham-medium dark-grey font-14 margin-top-10 margin-bottom-3\">\r\n              {{ticket.jobDate | date:'dd MMM yyyy'}}</p>\r\n            <span *ngIf=\"!ticket.jobDate\"\r\n              class=\"txt-warm-grey font-14 gotham-medium font-weight-500\">{{transService.getTranslatedData('ticket-details.add')}}</span>\r\n          </ion-col>\r\n          <ion-col>\r\n            <p class=\"txt-slate-grey gotham-medium font-14 margin-padding-zero\">\r\n              {{transService.getTranslatedData('ticket-details.time')}}</p>\r\n            <p *ngIf=\"ticket.jobStartTime\" class=\"gotham-medium dark-grey margin-top-10 font-14 margin-bottom-3\">\r\n              {{ticket.jobStartTime | date:'hh:mm a'}}</p>\r\n            <span *ngIf=\"!ticket.jobStartTime\"\r\n              class=\"txt-warm-grey gotham-medium font-14 font-weight-500\">{{transService.getTranslatedData('ticket-details.add')}}</span>\r\n          </ion-col>\r\n        </ion-row>\r\n        <ion-row>\r\n          <ion-col>\r\n            <p class=\"txt-slate-grey gotham-medium font-14 margin-padding-zero\">\r\n              {{transService.getTranslatedData('ticket-details.end-date')}}</p>\r\n            <p *ngIf=\"ticket.jobEndDate\" class=\"gotham-medium dark-grey margin-top-10 font-14 margin-bottom-3\">\r\n              {{ticket.jobEndDate | date:'dd MMM yyyy'}}</p>\r\n            <span *ngIf=\"!ticket.jobEndDate\"\r\n              class=\"txt-warm-grey font-14 gotham-medium font-weight-500\">{{transService.getTranslatedData('ticket-details.add')}}</span>\r\n          </ion-col>\r\n          <ion-col>\r\n            <p class=\"txt-slate-grey gotham-medium margin-padding-zero font-14\">\r\n              {{transService.getTranslatedData('ticket-details.time')}}</p>\r\n            <p *ngIf=\"ticket.jobEndTime\" class=\"gotham-medium dark-grey margin-top-10 margin-bottom-3 font-14\">\r\n              {{ticket.jobEndTime | date:'hh:mm a'}}</p>\r\n            <span *ngIf=\"!ticket.jobEndTime\"\r\n              class=\"txt-warm-grey gotham-medium font-14 font-weight-500\">{{transService.getTranslatedData('ticket-details.add')}}</span>\r\n          </ion-col>\r\n        </ion-row>\r\n      </div>\r\n    </div>\r\n\r\n    <div *ngSwitchCase=\"'ASSETS'\" class=\"full-width max-available-height margin-top-5\">\r\n      <div class=\"ticket-assets-card\" *ngFor=\"let asset of ticket.assets\">\r\n        <ion-row>\r\n          <ion-col>\r\n            <p class=\"txt-slate-grey font-14 gotham-medium margin-bottom-0\">\r\n              {{transService.getTranslatedData('ticket-details.asset-id')}}</p>\r\n            <p class=\"margin-top-10 font-14 margin-bottom-10 gotham-medium dark-grey\">{{asset.assetId}}</p>\r\n          </ion-col>\r\n          <ion-col>\r\n            <p class=\"txt-slate-grey font-14 gotham-medium margin-bottom-0\">\r\n              {{transService.getTranslatedData('ticket-details.asset-name')}}</p>\r\n            <p class=\"margin-bottom-10 font-14 margin-top-10 gotham-medium dark-grey\">{{asset.name}}</p>\r\n          </ion-col>\r\n        </ion-row>\r\n        <ion-row>\r\n          <ion-col>\r\n            <p class=\"txt-slate-grey font-14 gotham-medium margin-padding-zero\">\r\n              {{transService.getTranslatedData('ticket-details.location')}}</p>\r\n            <p class=\"margin-bottom-10 margin-top-10 font-14 gotham-medium dark-grey \">\r\n              {{asset.location || transService.getTranslatedData('ticket-details.not-available')}}</p>\r\n          </ion-col>\r\n          <ion-col>\r\n            <p class=\"txt-slate-grey font-14 gotham-medium margin-padding-zero\">\r\n              {{transService.getTranslatedData('ticket-details.floor')}}</p>\r\n            <p class=\"margin-bottom-0 margin-top-10 font-14 gotham-medium dark-grey\">\r\n              {{asset.floor || transService.getTranslatedData('ticket-details.not-available')}}\r\n            </p>\r\n          </ion-col>\r\n        </ion-row>\r\n\r\n        <ion-row>\r\n          <ion-col>\r\n            <p class=\"txt-slate-grey font-14 gotham-medium margin-padding-zero\">\r\n              {{transService.getTranslatedData('ticket-details.description')}}</p>\r\n            <p class=\" font-14 margin-bottom-0 margin-top-10 gotham-medium dark-grey\">\r\n              {{asset.description || transService.getTranslatedData('ticket-details.not-available')}}</p>\r\n          </ion-col>\r\n        </ion-row>\r\n      </div>\r\n      <br>\r\n      <ion-row [hidden]=\"ticket.assets?.length > 0\"\r\n        class=\"txt-small txt-brown gotham-medium font-14 center-text margin-top-15\">\r\n        <ion-col>{{transService.getTranslatedData('ticket-details.no-asset')}}</ion-col>\r\n      </ion-row>\r\n\r\n    </div>\r\n\r\n    <div *ngSwitchCase=\"'COMMENTS'\" class=\"full-width max-available-height\">\r\n      <ion-row class=\"padding-10 \">\r\n        <ion-col>\r\n          <textarea rows=\"7\" class=\"border-grey-1 font-14 full-width \"\r\n            placeholder=\"{{transService.getTranslatedData('ticket-details.comment-placeholder')}}\"\r\n            [(ngModel)]=\"ticket.commentText\">\r\n          </textarea>\r\n          <ion-button class=\"float-right\" style=\"margin: 5px; padding: 0\" (click)=\"createComment()\">\r\n            <p class=\"gotham font-14 margin-padding-zero\">\r\n              {{transService.getTranslatedData('ticket-details.comment')}}</p>\r\n          </ion-button>\r\n        </ion-col>\r\n      </ion-row>\r\n      <!-- Tickets comments section -->\r\n\r\n      <ion-row [hidden]=\"comments?.length > 0\"\r\n        class=\"txt-small txt-brown gotham-medium center-text font-14 center margin-top-15\">\r\n        <ion-col>{{transService.getTranslatedData('ticket-details.no-comment')}}</ion-col>\r\n      </ion-row>\r\n\r\n      <!-- <ion-row *ngFor=\"let comment of comments\" class=\"discussion-comment padding-5\"\r\n        style=\"margin-bottom:5px !important;\">\r\n        <ion-col size=\"2\" class=\"padding-10\">\r\n          <ion-row>\r\n            <ngx-avatar class=\"gotham-medium\" name=\"{{comment.createdBy.firstName}}\"></ngx-avatar>\r\n          </ion-row>\r\n        </ion-col>\r\n        <ion-col size=\"9\" class=\"padding-10\">\r\n          <ion-row>\r\n            <ion-col class=\"  margin-bottom-0 padding-bottom-0\">\r\n              <ion-row class=\" font-14 dark-grey gotham-medium\">\r\n                {{comment.createdBy.firstName}} {{comment.createdBy.lastName}}\r\n              </ion-row>\r\n              <ion-row>\r\n                <p\r\n                  class=\"font-14 txt-align-right gotham-medium txt-warm-grey font-14 margin-bottom-0 padding-bottom-0 margin-top-8\">\r\n                  {{comment.text}}</p>\r\n              </ion-row>\r\n            </ion-col>\r\n            <ion-row\r\n              class=\"font-14 txt-align-right gotham-medium txt-warm-grey font-14 margin-bottom-0 padding-bottom-0\">\r\n              {{comment.createdAt|agoFilter}}\r\n            </ion-row>\r\n          </ion-row>\r\n        </ion-col>\r\n        <br />\r\n        <br />\r\n        <br />\r\n      </ion-row> -->\r\n\r\n      <ion-item *ngFor=\"let comment of comments\" class=\"discussion-comment padding-0\"\r\n        style=\"margin-bottom:5px !important;\" lines=\"full\">\r\n        <ngx-avatar class=\"gotham-medium\" name=\"{{comment.createdBy.firstName}}\"></ngx-avatar>\r\n        <ion-label class=\"margin-left-10\">\r\n          <p>\r\n            <span class=\" font-14 dark-grey gotham-medium\"> {{comment.createdBy.firstName}}\r\n              {{comment.createdBy.lastName}} </span>\r\n            <span class=\"font-14 float-right gotham-medium txt-warm-grey font-14 margin-bottom-0 padding-bottom-0 \">\r\n              {{comment.createdAt|agoFilter}}\r\n            </span>\r\n          </p>\r\n\r\n          <span\r\n            class=\"font-14 txt-align-right white-space-initial gotham-medium txt-warm-grey font-14 margin-bottom-0 padding-bottom-0 margin-top-8\">\r\n            {{comment.text}}\r\n          </span>\r\n        </ion-label>\r\n      </ion-item>\r\n    </div>\r\n\r\n    <div *ngSwitchCase=\"'CHECKLIST'\" class=\"full-width max-available-height margin-top-5\">\r\n      <div class=\"ticket-details-list\" *ngIf=\"ticket.checklist?.length > 0\">\r\n        <ion-list class=\"padding-bottom-0\">\r\n\r\n          <ion-item *ngFor=\"let data of ticket.checklist; let i = index\">\r\n            <ion-checkbox class=\"txt-warm-grey\" [(ngModel)]=\"data.completed\"\r\n              (ionChange)=\"updateCheckList(data.completed, i)\"></ion-checkbox>\r\n            <ion-label class=\"margin-left-20 font-14  gotham item-text-wrap\">\r\n              {{data.name}}\r\n            </ion-label>\r\n          </ion-item>\r\n\r\n        </ion-list>\r\n\r\n      </div>\r\n      <br>\r\n      <ion-row *ngIf=\"ticket.checklist?.length == 0|| !ticket.checklist\"\r\n        class=\"txt-small txt-brown gotham-medium font-14 center-text margin-top-15\">\r\n        <ion-col>{{transService.getTranslatedData('ticket-details.no-checklist')}}</ion-col>\r\n      </ion-row>\r\n    </div>\r\n\r\n    <div *ngSwitchCase=\"'QUOTATIONS'\" class=\"full-width max-available-height margin-top-5\">\r\n      <div class=\"ticket-details-list\" *ngIf=\"ticket.estimates.length > 0\">\r\n        <ion-list class=\"padding-0\" *ngFor=\"let estimate of ticket.estimates\">\r\n          <ion-item detail=\"true\" [routerLink]=\"['/rentals-estimate']\" [queryParams]=\"{estimateId: estimate._id}\">\r\n            <ion-label>\r\n              <ion-row>\r\n                <ion-col>\r\n                  <p class=\"gotham-medium font-14 dark-grey \">\r\n                    {{transService.getTranslatedData('ticket-details.quotation')}} #{{estimate.referenceNumber}}</p>\r\n                  <p class=\"gotham font-14 font-weight-600 txt-warm-grey \">\r\n                    {{estimate.createdAt | date:'dd MMM yyyy'}}\r\n                  </p>\r\n                </ion-col>\r\n                <ion-col class=\"padding-top-0\">\r\n                  <p class=\"gotham font-14 font-weight-600 float-right padding-right-10 txt-warm-grey\">\r\n                    {{estimate.totalAmount | currency:'INR'}}</p>\r\n                </ion-col>\r\n              </ion-row>\r\n            </ion-label>\r\n          </ion-item>\r\n        </ion-list>\r\n      </div>\r\n      <br>\r\n      <ion-row *ngIf=\"ticket.estimates?.length == 0\"\r\n        class=\"txt-small txt-brown gotham-medium font-14 center-text margin-top-15\">\r\n        <ion-col>\r\n          {{transService.getTranslatedData('ticket-details.no-estimate')}}\r\n        </ion-col>\r\n      </ion-row>\r\n    </div>\r\n\r\n    <div *ngSwitchCase=\"'MATERIALS'\" class=\"full-width max-available-height margin-top-5\">\r\n      <div *ngIf=\"activeMaterialSection == 'description'\" class=\"ticket-details-list full-width\">\r\n        <ion-row class=\"margin-0 padding-top-5 border-bottom-grey-1\"\r\n          *ngFor=\"let item of ticket.itemDetails let i = index\">\r\n          <ion-col size=\"1\" class=\"margin-left-8\">\r\n            <p class=\"gotham-medium font-14 dark-grey margin-padding-zero\">{{i+1}}</p>\r\n          </ion-col>\r\n          <ion-col size=\"8\" class=\"margin-left-10\">\r\n            <p class=\"gotham-medium font-14 dark-grey margin-padding-zero\">{{item.product.name}}</p>\r\n            <p *ngIf=\"item.borneByEndUser\"\r\n              class=\"txt-warm-grey font-14 gotham-medium margin-bottom-0 font-weight-500 margin-top-8 txt-nowrap\">\r\n              {{transService.getTranslatedData('ticket-details.born-by-customer')}}\r\n            </p>\r\n            <p class=\"txt-warm-grey font-14 gotham-medium margin-top-8  font-weight-500txt-nowrap\">\r\n              {{transService.getTranslatedData('ticket-details.quantity')}}{{item.quantity}}\r\n            </p>\r\n          </ion-col>\r\n          <ion-col class=\"margin-right-10 margin-top-3 padding-top-0\">\r\n            <img class=\"icon-25 float-right\" src=\"assets/icon/delete.png\" (click)=\"removeMaterial(item._id)\">\r\n          </ion-col>\r\n        </ion-row>\r\n      </div>\r\n\r\n      <div *ngIf=\"activeMaterialSection == 'materialForm'\">\r\n        <div class=\"padding-25\">\r\n          <ion-list>\r\n            <ion-list-header class=\"gotham font-16 font-weight-500\">\r\n              {{transService.getTranslatedData('ticket-details.material')}}</ion-list-header>\r\n            <ion-item>\r\n              <ion-input inputmode=\"text\" [(ngModel)]=\"materialData.name\" class=\"gotham\"\r\n                placeholder=\"{{transService.getTranslatedData('ticket-details.material-placeholder')}}\"\r\n                (click)=\"openMaterialSearchModal()\">\r\n              </ion-input>\r\n              <ion-icon class=\"float-right\" name=\"arrow-dropdown\"></ion-icon>\r\n            </ion-item>\r\n          </ion-list>\r\n          <ion-list>\r\n            <ion-list-header class=\"gotham font-16 font-weight-500\">\r\n              {{transService.getTranslatedData('ticket-details.quantity')}}</ion-list-header>\r\n            <ion-item>\r\n              <ion-input inputmode=\"number\" [(ngModel)]=\"materialData.quantity\" class=\"gotham\"\r\n                placeholder=\"{{transService.getTranslatedData('ticket-details.quantity-placeholder')}}\">\r\n              </ion-input>\r\n            </ion-item>\r\n          </ion-list>\r\n          <!-- <ion-list no-lines> -->\r\n          <ion-item lines=\"none\">\r\n            <ion-label>{{transService.getTranslatedData('ticket-details.born-by-customer-input')}}</ion-label>\r\n            <ion-checkbox slot=\"start\" [(ngModel)]=\"materialData.borneByEndUser\"></ion-checkbox>\r\n          </ion-item>\r\n          <!-- </ion-list> -->\r\n\r\n          <ion-row class=\"center-text\">\r\n            <ion-col>\r\n              <ion-button (click)=\"hideMaterialForm()\" color=\"danger\" class=\"full-width\">\r\n                {{transService.getTranslatedData('ticket-details.cancel')}}</ion-button>\r\n            </ion-col>\r\n            <ion-col>\r\n              <ion-button color=\"success\" class=\"full-width\" (click)=\"tagMaterial()\">\r\n                {{transService.getTranslatedData('ticket-details.add')}}</ion-button>\r\n            </ion-col>\r\n          </ion-row>\r\n\r\n        </div>\r\n      </div>\r\n\r\n      <br>\r\n      <ion-row *ngIf=\"ticket.itemDetails?.length == 0\"\r\n        class=\"txt-small center-text txt-brown gotham-medium font-14 margin-top-15\">\r\n        <ion-col>{{transService.getTranslatedData('ticket-details.no-material')}}</ion-col>\r\n      </ion-row>\r\n\r\n      <ion-row class=\" float-right margin-top-15\" (click)=\"showMaterialForm()\"\r\n        *ngIf=\"activeMaterialSection == 'description'\">\r\n        <img src=\"assets/icon/add-green.png\" class=\"height-30 width-30 border-radius-10 \" />\r\n        <p class=\"gotham-medium dark-grey margin-top-8 margin-left-5 margin-right-10 font-17 \">\r\n          {{transService.getTranslatedData('ticket-details.add-new')}}\r\n        </p>\r\n      </ion-row>\r\n    </div>\r\n\r\n  </div>\r\n</ion-content>\r\n<ion-footer class=\"display-flex justify-center\">\r\n  <ion-row class=\"width-80-percent margint-top-10 center-text justify-center\">\r\n    <ion-col size=\"3\">\r\n      <ion-icon name=\"checkmark-circle\" class=\"icon-40\" color=\"active-status\"></ion-icon>\r\n      <p class=\"font-12 margin-0\">{{transService.getTranslatedData('ticket-details.open')}}</p>\r\n    </ion-col>\r\n    <ion-col (click)=\"updatStatus('in-progress')\" size=\"3\">\r\n      <ion-icon name=\"checkmark-circle\" class=\"icon-40\"\r\n        [color]=\"ticket.status=='in-progress'||ticket.status=='resolved'||ticket.status=='rejected'?'active-status':'medium'\">\r\n      </ion-icon>\r\n      <p class=\"font-12 margin-0\">{{transService.getTranslatedData('ticket-details.in-progress')}}</p>\r\n    </ion-col>\r\n    <ion-col *ngIf=\"ticket.status!='rejected'\" (click)=\"updatStatus('resolved')\" size=\"3\">\r\n      <ion-icon name=\"checkmark-circle\" class=\"icon-40\" [color]=\"ticket.status=='resolved'?'active-status':'medium'\">\r\n      </ion-icon>\r\n      <p class=\"font-12 margin-0\">{{transService.getTranslatedData('ticket-details.resolved')}}</p>\r\n    </ion-col>\r\n    <ion-col *ngIf=\"ticket.status!='resolved'\" (click)=\"updatStatus('rejected')\" size=\"3\">\r\n      <ion-icon name=\"close-circle\" class=\"icon-40\"\r\n        [color]=\"ticket.status=='rejected'?'rejected-active-status':'medium'\">\r\n      </ion-icon>\r\n      <p class=\"font-12 margin-0\">{{transService.getTranslatedData('ticket-details.rejected')}}</p>\r\n    </ion-col>\r\n\r\n  </ion-row>\r\n</ion-footer>"

/***/ }),

/***/ "./src/app/Rentals Management/pages/ticket-details/ticket-details.page.scss":
/*!**********************************************************************************!*\
  !*** ./src/app/Rentals Management/pages/ticket-details/ticket-details.page.scss ***!
  \**********************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ".margin-padding-zero button .button-native {\n  padding: 0px !important; }\n\ntoolbar-container {\n  background: #17375e; }\n\n.icon-position {\n  float: right;\n  margin-top: 10px;\n  margin-bottom: 9px; }\n\n.list-md {\n  padding-bottom: 0 !important; }\n\nion-content {\n  --background: #ecebe6 !important; }\n\n.rejected-active-status {\n  color: #c4153b !important; }\n\n.disabled-status {\n  color: grey !important; }\n\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvUmVudGFscyBNYW5hZ2VtZW50L3BhZ2VzL3RpY2tldC1kZXRhaWxzL0Q6XFxuYXZqb3RcXHZlcmlmeS9zcmNcXGFwcFxcUmVudGFscyBNYW5hZ2VtZW50XFxwYWdlc1xcdGlja2V0LWRldGFpbHNcXHRpY2tldC1kZXRhaWxzLnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNFLHVCQUF1QixFQUFBOztBQUV6QjtFQUNFLG1CQUFtQixFQUFBOztBQUVyQjtFQUNFLFlBQVk7RUFDWixnQkFBZ0I7RUFDaEIsa0JBQWtCLEVBQUE7O0FBRXBCO0VBQ0UsNEJBQTRCLEVBQUE7O0FBRzlCO0VBQ0UsZ0NBQWEsRUFBQTs7QUFNZjtFQUNFLHlCQUF5QixFQUFBOztBQUUzQjtFQUNFLHNCQUFzQixFQUFBIiwiZmlsZSI6InNyYy9hcHAvUmVudGFscyBNYW5hZ2VtZW50L3BhZ2VzL3RpY2tldC1kZXRhaWxzL3RpY2tldC1kZXRhaWxzLnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIi5tYXJnaW4tcGFkZGluZy16ZXJvIGJ1dHRvbiAuYnV0dG9uLW5hdGl2ZSB7XHJcbiAgcGFkZGluZzogMHB4ICFpbXBvcnRhbnQ7XHJcbn1cclxudG9vbGJhci1jb250YWluZXIge1xyXG4gIGJhY2tncm91bmQ6ICMxNzM3NWU7XHJcbn1cclxuLmljb24tcG9zaXRpb24ge1xyXG4gIGZsb2F0OiByaWdodDtcclxuICBtYXJnaW4tdG9wOiAxMHB4O1xyXG4gIG1hcmdpbi1ib3R0b206IDlweDtcclxufVxyXG4ubGlzdC1tZCB7XHJcbiAgcGFkZGluZy1ib3R0b206IDAgIWltcG9ydGFudDtcclxufVxyXG5cclxuaW9uLWNvbnRlbnQge1xyXG4gIC0tYmFja2dyb3VuZDogI2VjZWJlNiAhaW1wb3J0YW50O1xyXG59XHJcbi8vIC5hY3RpdmUtc3RhdHVzIHtcclxuLy8gICBjb2xvcjogIzFiYjI5MyAhaW1wb3J0YW50O1xyXG4vLyB9XHJcblxyXG4ucmVqZWN0ZWQtYWN0aXZlLXN0YXR1cyB7XHJcbiAgY29sb3I6ICNjNDE1M2IgIWltcG9ydGFudDtcclxufVxyXG4uZGlzYWJsZWQtc3RhdHVzIHtcclxuICBjb2xvcjogZ3JleSAhaW1wb3J0YW50O1xyXG59XHJcbiJdfQ== */"

/***/ }),

/***/ "./src/app/Rentals Management/pages/ticket-details/ticket-details.page.ts":
/*!********************************************************************************!*\
  !*** ./src/app/Rentals Management/pages/ticket-details/ticket-details.page.ts ***!
  \********************************************************************************/
/*! exports provided: TicketDetailsPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "TicketDetailsPage", function() { return TicketDetailsPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _services_ticket_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../services/ticket.service */ "./src/app/Rentals Management/services/ticket.service.ts");
/* harmony import */ var _pages_user_search_user_search_page__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../pages/user-search/user-search.page */ "./src/app/Rentals Management/pages/user-search/user-search.page.ts");
/* harmony import */ var _pages_material_search_material_search_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../../pages/material-search/material-search.page */ "./src/app/Rentals Management/pages/material-search/material-search.page.ts");
/* harmony import */ var src_app_common_services_alert_service_service__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! src/app/common-services/alert-service.service */ "./src/app/common-services/alert-service.service.ts");
/* harmony import */ var src_app_common_services_translate_translate_service_service__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! src/app/common-services/translate/translate-service.service */ "./src/app/common-services/translate/translate-service.service.ts");
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @ngx-translate/core */ "./node_modules/@ngx-translate/core/fesm5/ngx-translate-core.js");
/* harmony import */ var src_app_common_components_picture_picture_component__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! src/app/common-components/picture/picture.component */ "./src/app/common-components/picture/picture.component.ts");











var TicketDetailsPage = /** @class */ (function () {
    function TicketDetailsPage(route, loadingCtrl, ticketService, modalController, alertService, alertCtrl, transService, trans, actionSheet) {
        var _this = this;
        this.route = route;
        this.loadingCtrl = loadingCtrl;
        this.ticketService = ticketService;
        this.modalController = modalController;
        this.alertService = alertService;
        this.alertCtrl = alertCtrl;
        this.transService = transService;
        this.trans = trans;
        this.actionSheet = actionSheet;
        this.ticket = {};
        this.comments = [];
        this.activeMaterialSection = 'description';
        this.materialData = {};
        this.images = [];
        this.flag = 'false';
        this.formData = {};
        this.route.queryParamMap.subscribe(function (params) {
            params.params.ticketId ? _this.ticketId = params.params.ticketId : '';
            params.params.flag ? _this.flag = params.params.flag : '';
            params.params.tid ? _this.ticketId = params.params.tid : '';
            console.log(_this.ticketId, _this.flag);
            _this.getTicketDetails();
        });
    }
    TicketDetailsPage.prototype.presentLoading = function () {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function () {
            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.loadingCtrl.create({
                            spinner: "lines"
                        }).then(function (loading) {
                            loading.present();
                        })];
                    case 1:
                        _a.sent();
                        return [2 /*return*/];
                }
            });
        });
    };
    TicketDetailsPage.prototype.ngOnInit = function () {
        this.selectedTab = 'SUMMARY';
        console.log(this.images.length);
    };
    TicketDetailsPage.prototype.ionViewWillEnter = function () {
        console.log('ionViewWillEnter');
        if (this.flag === 'true') {
            console.log('true', this.ticketId);
            this.flag = 'false';
            this.ticket = [];
            this.getTicketDetails();
        }
    };
    TicketDetailsPage.prototype.showMaterialForm = function () {
        this.activeMaterialSection = 'materialForm';
    };
    TicketDetailsPage.prototype.hideMaterialForm = function () {
        this.activeMaterialSection = 'description';
    };
    TicketDetailsPage.prototype.getTicketDetails = function () {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function () {
            var _this = this;
            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.presentLoading()];
                    case 1:
                        _a.sent();
                        this.ticketService.getTicketById(this.ticketId)
                            .subscribe(function (data) { return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](_this, void 0, void 0, function () {
                            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                                switch (_a.label) {
                                    case 0:
                                        this.ticket = data;
                                        return [4 /*yield*/, this.loadingCtrl.dismiss()];
                                    case 1:
                                        _a.sent();
                                        return [2 /*return*/];
                                }
                            });
                        }); }, function (err) { return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](_this, void 0, void 0, function () {
                            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                                switch (_a.label) {
                                    case 0:
                                        this.alertService.presentAlert(this.transService.getTranslatedData('alert-title'), this.transService.getTranslatedData('error-alert'));
                                        return [4 /*yield*/, this.loadingCtrl.dismiss()];
                                    case 1:
                                        _a.sent();
                                        return [2 /*return*/];
                                }
                            });
                        }); });
                        return [2 /*return*/];
                }
            });
        });
    };
    TicketDetailsPage.prototype.getTicketComments = function () {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function () {
            var _this = this;
            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.presentLoading()];
                    case 1:
                        _a.sent();
                        this.ticketService.getTicketComments(this.ticketId)
                            .subscribe(function (data) { return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](_this, void 0, void 0, function () {
                            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                                switch (_a.label) {
                                    case 0: return [4 /*yield*/, this.loadingCtrl.dismiss()];
                                    case 1:
                                        _a.sent();
                                        this.comments = data.data;
                                        return [2 /*return*/];
                                }
                            });
                        }); }, function (err) { return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](_this, void 0, void 0, function () {
                            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                                switch (_a.label) {
                                    case 0: return [4 /*yield*/, this.loadingCtrl.dismiss()];
                                    case 1:
                                        _a.sent();
                                        this.alertService.presentAlert(this.transService.getTranslatedData('alert-title'), this.transService.getTranslatedData('error-alert'));
                                        return [2 /*return*/];
                                }
                            });
                        }); });
                        return [2 /*return*/];
                }
            });
        });
    };
    TicketDetailsPage.prototype.updateTicket = function () {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function () {
            var _this = this;
            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                this.presentLoading();
                if (this.ticketToBeUpdated.ticketCategory) {
                    this.ticketToBeUpdated.ticketCategory = this.ticketToBeUpdated.ticketCategoryId;
                }
                if (this.ticketToBeUpdated.ticketSubCategory) {
                    this.ticketToBeUpdated.ticketSubCategory = this.ticketToBeUpdated.ticketSubCategoryId;
                }
                if (this.images.length > 0) {
                    console.log("With Image");
                    console.log(this.ticketToBeUpdated);
                    this.alertService.upload(this.images[0], this.ticketToBeUpdated, 'ADDTOTICKETDETAIL').then(function () { return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](_this, void 0, void 0, function () {
                        return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                            switch (_a.label) {
                                case 0: return [4 /*yield*/, this.loadingCtrl.dismiss()];
                                case 1:
                                    _a.sent();
                                    console.log(this.images);
                                    this.activeMaterialSection = 'description';
                                    this.materialData = {};
                                    this.getTicketDetails();
                                    this.alertService.presentAlert(this.transService.getTranslatedData('alert-title'), this.transService.getTranslatedData('ticket-details.ticket-updated'));
                                    return [2 /*return*/];
                            }
                        });
                    }); }, function (error) {
                        console.log(error);
                    });
                }
                else {
                    console.log("Without Image");
                    this.ticketService.updateTicket(this.ticketToBeUpdated)
                        .subscribe(function () { return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](_this, void 0, void 0, function () {
                        return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                            switch (_a.label) {
                                case 0: return [4 /*yield*/, this.loadingCtrl.dismiss()];
                                case 1:
                                    _a.sent();
                                    this.activeMaterialSection = 'description';
                                    this.materialData = {};
                                    this.getTicketDetails();
                                    this.alertService.presentAlert(this.transService.getTranslatedData('alert-title'), this.transService.getTranslatedData('ticket-details.ticket-updated'));
                                    return [2 /*return*/];
                            }
                        });
                    }); }, function (err) { return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](_this, void 0, void 0, function () {
                        return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                            switch (_a.label) {
                                case 0: return [4 /*yield*/, this.loadingCtrl.dismiss()];
                                case 1:
                                    _a.sent();
                                    this.alertService.presentAlert(this.transService.getTranslatedData('alert-title'), this.transService.getTranslatedData('error-alert'));
                                    return [2 /*return*/];
                            }
                        });
                    }); });
                }
                return [2 /*return*/];
            });
        });
    };
    TicketDetailsPage.prototype.openUserSearchModal = function (type) {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function () {
            var id, modal;
            var _this = this;
            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                switch (_a.label) {
                    case 0:
                        this.ticketToBeUpdated = Object.assign({}, this.ticket);
                        if (type === 'agent' && this.ticketToBeUpdated.agent) {
                            id = this.ticketToBeUpdated.agent._id;
                        }
                        else if (type === 'poc' && this.ticketToBeUpdated.contactPoint) {
                            id = this.ticketToBeUpdated.contactPoint._id;
                        }
                        return [4 /*yield*/, this.modalController.create({
                                component: _pages_user_search_user_search_page__WEBPACK_IMPORTED_MODULE_5__["UserSearchPage"],
                                componentProps: {
                                    id: id
                                }
                            })];
                    case 1:
                        modal = _a.sent();
                        modal.onDidDismiss().then(function (user) {
                            if (user !== null && user.data) {
                                if (type === 'agent') {
                                    console.log('selecting technician');
                                    console.log(user);
                                    _this.ticketToBeUpdated.agent = user.data.id;
                                    _this.updateTicket();
                                }
                                else if (type === 'poc') {
                                    console.log('selecting point of contact');
                                    console.log(user);
                                    _this.ticketToBeUpdated.contactPoint = user.data.id;
                                    _this.updateTicket();
                                }
                            }
                        });
                        return [4 /*yield*/, modal.present()];
                    case 2: return [2 /*return*/, _a.sent()];
                }
            });
        });
    };
    TicketDetailsPage.prototype.createComment = function () {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function () {
            var data;
            var _this = this;
            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                switch (_a.label) {
                    case 0:
                        data = {
                            text: this.ticket.commentText,
                            ticket: this.ticketId,
                            type: 'ticket',
                        };
                        return [4 /*yield*/, this.presentLoading()];
                    case 1:
                        _a.sent();
                        this.ticketService.createComment(data)
                            .subscribe(function (data) { return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](_this, void 0, void 0, function () {
                            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                                switch (_a.label) {
                                    case 0: return [4 /*yield*/, this.loadingCtrl.dismiss()];
                                    case 1:
                                        _a.sent();
                                        this.getTicketComments();
                                        this.ticket.commentText = '';
                                        return [2 /*return*/];
                                }
                            });
                        }); }, function (err) { return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](_this, void 0, void 0, function () {
                            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                                switch (_a.label) {
                                    case 0: return [4 /*yield*/, this.loadingCtrl.dismiss()];
                                    case 1:
                                        _a.sent();
                                        this.alertService.presentAlert(this.transService.getTranslatedData('alert-title'), this.transService.getTranslatedData('error-alert'));
                                        return [2 /*return*/];
                                }
                            });
                        }); });
                        return [2 /*return*/];
                }
            });
        });
    };
    TicketDetailsPage.prototype.updateCheckList = function (status, index) {
        this.ticketToBeUpdated = Object.assign({}, this.ticket);
        this.ticketToBeUpdated.checklist[index].completed = status;
        this.updateTicket();
        this.activeMaterialSection = 'description';
        this.materialData = {};
    };
    TicketDetailsPage.prototype.openMaterialSearchModal = function () {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function () {
            var modal;
            var _this = this;
            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.modalController.create({
                            component: _pages_material_search_material_search_page__WEBPACK_IMPORTED_MODULE_6__["MaterialSearchPage"],
                            componentProps: {}
                        })];
                    case 1:
                        modal = _a.sent();
                        modal.onDidDismiss().then(function (materialData) {
                            console.log(materialData);
                            _this.materialData.name = materialData.data.name;
                            _this.materialData.product = materialData.data;
                        });
                        return [4 /*yield*/, modal.present()];
                    case 2: return [2 /*return*/, _a.sent()];
                }
            });
        });
    };
    TicketDetailsPage.prototype.tagMaterial = function () {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function () {
            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                this.ticketToBeUpdated = Object.assign({}, this.ticket);
                this.ticketToBeUpdated.itemDetails.push(this.materialData);
                this.updateTicket();
                return [2 /*return*/];
            });
        });
    };
    // async fileSourceOption(type) {
    //   console.log(this.images);
    //   // if (this.images.length < 1) {
    //   let image = await this.alertService.capturePhoto(type);
    //   console.log("in add-visitor Page\n\n");
    //   console.log(image);
    //   if (image !== undefined) {
    //     this.images.push(image);
    //     this.images
    //     this.ticketToBeUpdated = Object.assign({}, this.ticket);
    //     this.updateTicket();
    //   }
    //   // } else {
    //   // this.alertService.presentAlert("Alert", "Only one picture is allowed!!")
    //   // }
    // }
    TicketDetailsPage.prototype.removeImage = function (id) {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function () {
            var alert;
            var _this = this;
            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.alertCtrl.create({
                            header: this.transService.getTranslatedData('ticket-details.remove-image'),
                            buttons: [
                                {
                                    text: this.transService.getTranslatedData('ticket-details.update.no'),
                                    role: 'cancel',
                                    cssClass: 'secondary',
                                    handler: function () {
                                        console.log('Confirm Cancel');
                                    }
                                }, {
                                    text: this.transService.getTranslatedData('ticket-details.update.yes'),
                                    handler: function () {
                                        console.log(id);
                                        _this.ticketToBeUpdated = Object.assign({}, _this.ticket);
                                        _this.ticketToBeUpdated.files = _this.ticketToBeUpdated.files.filter(function (value) { return value._id !== id; });
                                        _this.updateTicket();
                                    }
                                }
                            ]
                        })];
                    case 1:
                        alert = _a.sent();
                        return [2 /*return*/, alert.present()];
                }
            });
        });
    };
    TicketDetailsPage.prototype.removeMaterial = function (id) {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function () {
            var alert;
            var _this = this;
            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.alertCtrl.create({
                            header: this.transService.getTranslatedData('ticket-details.delete-material'),
                            buttons: [
                                {
                                    text: this.transService.getTranslatedData('ticket-details.update.no'),
                                    role: 'cancel',
                                    cssClass: 'secondary',
                                    handler: function () {
                                        console.log('Confirm Cancel');
                                    }
                                }, {
                                    text: this.transService.getTranslatedData('ticket-details.update.yes'),
                                    handler: function () {
                                        console.log(id);
                                        _this.ticketToBeUpdated = Object.assign({}, _this.ticket);
                                        _this.ticketToBeUpdated.itemDetails = _this.ticketToBeUpdated.itemDetails.filter(function (value) { return value._id !== id; });
                                        _this.updateTicket();
                                    }
                                }
                            ]
                        })];
                    case 1:
                        alert = _a.sent();
                        return [2 /*return*/, alert.present()];
                }
            });
        });
    };
    // public presentActionSheet() {
    //   this.actionSheet.create({
    //     header: 'Select image from ',
    //     buttons: [
    //       {
    //         text: 'Camera',
    //         icon: 'camera',
    //         handler: async () => {
    //           this.fileSourceOption('camera');
    //         }
    //       },
    //       {
    //         text: 'Library',
    //         icon: 'images',
    //         handler: () => {
    //           this.fileSourceOption('library');
    //         }
    //       },
    //       {
    //         text: 'Cancel',
    //         icon: 'close',
    //         handler: () => {
    //           console.log('cancel');
    //         }
    //       }
    //     ]
    //   }).then(actionsheet => {
    //     actionsheet.present()
    //   })
    // }
    TicketDetailsPage.prototype.openImage = function (image) {
        this.modalController.create({
            component: src_app_common_components_picture_picture_component__WEBPACK_IMPORTED_MODULE_10__["PictureComponent"],
            componentProps: { image: image }
        }).then(function (modal) {
            modal.present();
        });
    };
    TicketDetailsPage.prototype.updatStatus = function (status) {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function () {
            var title, ticketActionStatus, alert_1, alert_2;
            var _this = this;
            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                switch (_a.label) {
                    case 0:
                        title = '';
                        ticketActionStatus = ['resolved'];
                        this.trans.get('ticket-details.update.title', { val: status == 'in-progress' ? 'IN PROGRESS' : status.toUpperCase() }).subscribe(function (res) {
                            title = res;
                        });
                        this.ticketToBeUpdated = Object.assign({}, this.ticket);
                        if (!(this.ticketToBeUpdated.status === 'open' && ticketActionStatus.includes(status))) return [3 /*break*/, 2];
                        return [4 /*yield*/, this.alertCtrl.create({
                                header: "Please change ticket status to in-progress first",
                                buttons: [
                                    {
                                        text: 'Ok',
                                        role: 'ok',
                                    }
                                ]
                            })];
                    case 1:
                        alert_1 = _a.sent();
                        return [2 /*return*/, alert_1.present()];
                    case 2:
                        if (!(status !== this.ticketToBeUpdated.status)) return [3 /*break*/, 4];
                        if (this.ticketToBeUpdated.status === 'open'
                            && !this.ticketToBeUpdated.agent
                            && status !== 'rejected') {
                            title = 'Technician/vendor is not tagged to this ticket. Do you still want to update the ticket status?';
                        }
                        return [4 /*yield*/, this.alertCtrl.create({
                                header: title,
                                buttons: [
                                    {
                                        text: this.transService.getTranslatedData('ticket-details.update.no'),
                                        role: 'cancel',
                                        cssClass: 'secondary',
                                        handler: function () {
                                            console.log('Confirm Cancel');
                                        }
                                    }, {
                                        text: this.transService.getTranslatedData('ticket-details.update.yes'),
                                        handler: function () {
                                            _this.ticketToBeUpdated.status = status;
                                            console.log(_this.ticketToBeUpdated);
                                            _this.updateTicket();
                                        }
                                    }
                                ]
                            })];
                    case 3:
                        alert_2 = _a.sent();
                        return [2 /*return*/, alert_2.present()];
                    case 4:
                        this.alertService.presentAlert(this.transService.getTranslatedData('alert-title'), this.transService.getTranslatedData('ticket-details.update.status') + " " + status);
                        _a.label = 5;
                    case 5: return [2 /*return*/];
                }
            });
        });
    };
    TicketDetailsPage.prototype.call = function (number) {
        if (number) {
            window.location.href = 'tel:' + number;
        }
        else {
            this.alertService.presentAlert(this.transService.getTranslatedData('alert-title'), this.transService.getTranslatedData('call-alert'));
        }
    };
    TicketDetailsPage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-ticket-details',
            template: __webpack_require__(/*! ./ticket-details.page.html */ "./src/app/Rentals Management/pages/ticket-details/ticket-details.page.html"),
            styles: [__webpack_require__(/*! ./ticket-details.page.scss */ "./src/app/Rentals Management/pages/ticket-details/ticket-details.page.scss")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_router__WEBPACK_IMPORTED_MODULE_2__["ActivatedRoute"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["LoadingController"],
            _services_ticket_service__WEBPACK_IMPORTED_MODULE_4__["TicketService"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["ModalController"],
            src_app_common_services_alert_service_service__WEBPACK_IMPORTED_MODULE_7__["AlertServiceService"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["AlertController"],
            src_app_common_services_translate_translate_service_service__WEBPACK_IMPORTED_MODULE_8__["translateService"],
            _ngx_translate_core__WEBPACK_IMPORTED_MODULE_9__["TranslateService"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["ActionSheetController"]])
    ], TicketDetailsPage);
    return TicketDetailsPage;
}());



/***/ })

}]);
//# sourceMappingURL=Rentals-Management-pages-ticket-details-ticket-details-module.js.map