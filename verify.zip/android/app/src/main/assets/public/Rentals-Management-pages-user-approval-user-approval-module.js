(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["Rentals-Management-pages-user-approval-user-approval-module"],{

/***/ "./src/app/Rentals Management/pages/user-approval/user-approval.module.ts":
/*!********************************************************************************!*\
  !*** ./src/app/Rentals Management/pages/user-approval/user-approval.module.ts ***!
  \********************************************************************************/
/*! exports provided: UserApprovalPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "UserApprovalPageModule", function() { return UserApprovalPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _ApplicationPageModule__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./../../ApplicationPageModule */ "./src/app/Rentals Management/ApplicationPageModule.ts");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _user_approval_page__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./user-approval.page */ "./src/app/Rentals Management/pages/user-approval/user-approval.page.ts");








var routes = [
    {
        path: '',
        component: _user_approval_page__WEBPACK_IMPORTED_MODULE_7__["UserApprovalPage"]
    }
];
var UserApprovalPageModule = /** @class */ (function () {
    function UserApprovalPageModule() {
    }
    UserApprovalPageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_2__["NgModule"])({
            imports: [
                _angular_common__WEBPACK_IMPORTED_MODULE_3__["CommonModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormsModule"],
                _ApplicationPageModule__WEBPACK_IMPORTED_MODULE_1__["ApplicationPageModule"],
                _ionic_angular__WEBPACK_IMPORTED_MODULE_6__["IonicModule"],
                _angular_router__WEBPACK_IMPORTED_MODULE_5__["RouterModule"].forChild(routes)
            ],
            entryComponents: [],
            declarations: [_user_approval_page__WEBPACK_IMPORTED_MODULE_7__["UserApprovalPage"],]
        })
    ], UserApprovalPageModule);
    return UserApprovalPageModule;
}());



/***/ }),

/***/ "./src/app/Rentals Management/pages/user-approval/user-approval.page.html":
/*!********************************************************************************!*\
  !*** ./src/app/Rentals Management/pages/user-approval/user-approval.page.html ***!
  \********************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ion-header>\r\n  <ion-toolbar color='primary'>\r\n    <ion-buttons slot=\"start\">\r\n      <ion-back-button></ion-back-button>\r\n    </ion-buttons>\r\n    <ion-title class=\"padding-0\" >{{transService.getTranslatedData('user-approval.title')}}</ion-title>\r\n  </ion-toolbar>\r\n</ion-header>\r\n\r\n<ion-content>\r\n\r\n  <div class=\"txt-medium gotham margin-top-20 txt-brown center-text\" *ngIf=\"approvals?.length === 0\">\r\n    {{transService.getTranslatedData('user-approval.empty-array')}}\r\n  </div>\r\n\r\n  <ion-card *ngFor=\"let approval of approvals\">\r\n    <div class=\"ticket-approval-card\">\r\n      <ion-grid>\r\n        <ion-row>\r\n          <ion-col class=\" padding-0\">\r\n            <span class=\"gotham font-weight-600\">\r\n              {{approval.user?.firstName}} {{approval.user?.lastName}}\r\n            </span>\r\n          </ion-col>\r\n          <ion-col class=\"padding-right-20 padding-bottom-0\">\r\n            <ion-badge class=\"float-right\" color=\"warning border-radius-25\">\r\n              <p class=\"margin-0 gotham  \">\r\n                {{approval.user?.types[0]}}\r\n              </p>\r\n            </ion-badge>\r\n          </ion-col>\r\n        </ion-row>\r\n        <ion-row ng-if=\"approval.user.phoneNumber\">\r\n          <!-- <p style=\"font-size : 15px !important\" class=\"margin-padding-zero txt-warm-grey gotham padding-top-5\">\r\n            ({{approval.user?.countryCode}} {{approval.user?.phoneNumber}})\r\n          </p> -->\r\n        </ion-row>\r\n        <ion-row>\r\n          <p style=\"font-size : 15px !important\" class=\"margin-0 padding-top-5 gont-12 txt-warm-grey gotham\">\r\n            {{approval.user?.address}}\r\n          </p>\r\n        </ion-row>\r\n        <ion-row>\r\n          <p style=\"font-size : 15px !important\" class=\"margin-0 font-12 padding-top-5 txt-warm-grey gotham  \">\r\n            {{approval.createdAt | agoFilter }}\r\n          </p>\r\n        </ion-row>\r\n        <ion-row class=\"padding-top-10\">\r\n          <p class=\" margin-padding-zero font-12 gotham  \">\r\n            {{transService.getTranslatedData('user-approval.req-by')}}</p>\r\n        </ion-row>\r\n        <ion-row>\r\n          <p class=\"padding-top-5 font-14 gotham margin-0 mar txt-warm-grey\">\r\n            {{approval.submittedByUser?.firstName}} {{approval.submittedByUser?.lastName}}\r\n          </p>\r\n        </ion-row>\r\n      </ion-grid>\r\n    </div>\r\n    <div>\r\n      <ion-row class=\"ticket-approval-card2\">\r\n        <ion-col>\r\n          <span class=\" font-30 margin-left-10\">\r\n            <ion-icon color=\"success\" (click)=\"presentPopover('approve',approval._id)\" name=\"checkmark-circle\">\r\n            </ion-icon>\r\n          </span>\r\n          <span class=\" font-30 margin-left-30\">\r\n            <ion-icon color=\"danger\" (click)=\"presentPopover('reject',approval._id)\" name=\"close-circle\"></ion-icon>\r\n          </span>\r\n        </ion-col>\r\n        <ion-col>\r\n          <span class=\" font-30 float-right margin-right-40\">\r\n            <ion-icon name=\"call\" (click)=\"call(approval.user?.phoneNumber)\"></ion-icon>\r\n          </span>\r\n        </ion-col>\r\n      </ion-row>\r\n    </div>\r\n  </ion-card>\r\n</ion-content>"

/***/ }),

/***/ "./src/app/Rentals Management/pages/user-approval/user-approval.page.scss":
/*!********************************************************************************!*\
  !*** ./src/app/Rentals Management/pages/user-approval/user-approval.page.scss ***!
  \********************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "ion-content {\n  --ion-background-color: #ecebe6; }\n\n.ion-card {\n  padding: 5px; }\n\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvUmVudGFscyBNYW5hZ2VtZW50L3BhZ2VzL3VzZXItYXBwcm92YWwvRDpcXG5hdmpvdFxcdmVyaWZ5L3NyY1xcYXBwXFxSZW50YWxzIE1hbmFnZW1lbnRcXHBhZ2VzXFx1c2VyLWFwcHJvdmFsXFx1c2VyLWFwcHJvdmFsLnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNFLCtCQUF1QixFQUFBOztBQUV6QjtFQUNFLFlBQVksRUFBQSIsImZpbGUiOiJzcmMvYXBwL1JlbnRhbHMgTWFuYWdlbWVudC9wYWdlcy91c2VyLWFwcHJvdmFsL3VzZXItYXBwcm92YWwucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiaW9uLWNvbnRlbnQge1xyXG4gIC0taW9uLWJhY2tncm91bmQtY29sb3I6ICNlY2ViZTY7XHJcbn1cclxuLmlvbi1jYXJkIHtcclxuICBwYWRkaW5nOiA1cHg7XHJcbn1cclxuIl19 */"

/***/ }),

/***/ "./src/app/Rentals Management/pages/user-approval/user-approval.page.ts":
/*!******************************************************************************!*\
  !*** ./src/app/Rentals Management/pages/user-approval/user-approval.page.ts ***!
  \******************************************************************************/
/*! exports provided: UserApprovalPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "UserApprovalPage", function() { return UserApprovalPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var src_app_common_services_alert_service_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/common-services/alert-service.service */ "./src/app/common-services/alert-service.service.ts");
/* harmony import */ var _modals_approvalpopup_approvalpopup_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../modals/approvalpopup/approvalpopup.component */ "./src/app/Rentals Management/modals/approvalpopup/approvalpopup.component.ts");
/* harmony import */ var src_app_common_services_translate_translate_service_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! src/app/common-services/translate/translate-service.service */ "./src/app/common-services/translate/translate-service.service.ts");
/* harmony import */ var _services_rentals_user_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../../services/rentals-user.service */ "./src/app/Rentals Management/services/rentals-user.service.ts");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");








var UserApprovalPage = /** @class */ (function () {
    function UserApprovalPage(loadingCtrl, userService, modalController, alertService, popOver, transService, router) {
        this.loadingCtrl = loadingCtrl;
        this.userService = userService;
        this.modalController = modalController;
        this.alertService = alertService;
        this.popOver = popOver;
        this.transService = transService;
        this.router = router;
        this.getUserApprovals();
    }
    UserApprovalPage.prototype.ngOnInit = function () {
    };
    UserApprovalPage.prototype.presentLoading = function () {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function () {
            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.loadingCtrl.create({
                            spinner: "lines"
                        }).then(function (loading) {
                            loading.present();
                        })];
                    case 1:
                        _a.sent();
                        return [2 /*return*/];
                }
            });
        });
    };
    UserApprovalPage.prototype.getUserApprovals = function () {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function () {
            var _this = this;
            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.presentLoading()];
                    case 1:
                        _a.sent();
                        this.userService.getUserApprovals()
                            .subscribe(function (data) {
                            _this.loadingCtrl.dismiss();
                            _this.approvals = data.data.data;
                            console.log(_this.approvals);
                        }, function (err) {
                            _this.loadingCtrl.dismiss();
                            if (err.error.message == "You don't have permission for this operation!") {
                                _this.alertService.presentAlert('', "You don't have permission for this operation!");
                                _this.router.navigateByUrl('rentals-naila-search-page');
                            }
                            else {
                                _this.alertService.presentAlert(_this.transService.getTranslatedData('alert-title'), err.error.error);
                            }
                        });
                        return [2 /*return*/];
                }
            });
        });
    };
    UserApprovalPage.prototype.approvalUser = function (id) {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function () {
            var _this = this;
            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.presentLoading()];
                    case 1:
                        _a.sent();
                        this.userService.approve(id).subscribe(function (data) { return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](_this, void 0, void 0, function () {
                            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                                switch (_a.label) {
                                    case 0: return [4 /*yield*/, this.loadingCtrl.dismiss()];
                                    case 1:
                                        _a.sent();
                                        this.alertService.presentAlert(this.transService.getTranslatedData('alert-title'), this.transService.getTranslatedData('user-approval.approval-success'));
                                        this.getUserApprovals();
                                        console.log('==================DATA==================');
                                        console.log(data);
                                        console.log('==================DATA==================');
                                        return [2 /*return*/];
                                }
                            });
                        }); }, function (err) { return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](_this, void 0, void 0, function () {
                            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                                switch (_a.label) {
                                    case 0: return [4 /*yield*/, this.loadingCtrl.dismiss()];
                                    case 1:
                                        _a.sent();
                                        this.alertService.presentAlert(this.transService.getTranslatedData('alert-title'), this.transService.getTranslatedData('error-alert'));
                                        console.log('==================ERROR==================');
                                        console.log(err);
                                        console.log('==================ERROR==================');
                                        return [2 /*return*/];
                                }
                            });
                        }); });
                        return [2 /*return*/];
                }
            });
        });
    };
    UserApprovalPage.prototype.rejectUser = function (id, notes) {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function () {
            var _this = this;
            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.presentLoading()];
                    case 1:
                        _a.sent();
                        this.userService.reject(id, notes).subscribe(function (data) { return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](_this, void 0, void 0, function () {
                            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                                switch (_a.label) {
                                    case 0: return [4 /*yield*/, this.loadingCtrl.dismiss()];
                                    case 1:
                                        _a.sent();
                                        this.alertService.presentAlert(this.transService.getTranslatedData('alert-title'), this.transService.getTranslatedData('user-approval.reject-user'));
                                        this.getUserApprovals();
                                        console.log('==================DATA==================');
                                        console.log(data);
                                        console.log('==================DATA==================');
                                        return [2 /*return*/];
                                }
                            });
                        }); }, function (err) { return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](_this, void 0, void 0, function () {
                            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                                switch (_a.label) {
                                    case 0: return [4 /*yield*/, this.loadingCtrl.dismiss()];
                                    case 1:
                                        _a.sent();
                                        this.alertService.presentAlert(this.transService.getTranslatedData('alert-title'), this.transService.getTranslatedData('error-alert'));
                                        console.log('==================ERROR==================');
                                        console.log(err);
                                        console.log('==================ERROR==================');
                                        return [2 /*return*/];
                                }
                            });
                        }); });
                        return [2 /*return*/];
                }
            });
        });
    };
    UserApprovalPage.prototype.presentPopover = function (val, id) {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function () {
            var popOver;
            var _this = this;
            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.popOver.create({
                            component: _modals_approvalpopup_approvalpopup_component__WEBPACK_IMPORTED_MODULE_4__["ApprovalpopupComponent"],
                            backdropDismiss: false,
                            componentProps: {
                                val: val
                            }
                        })];
                    case 1:
                        popOver = _a.sent();
                        popOver.onDidDismiss().then(function (data) {
                            if (data.data) {
                                if (data.data.val == 'approve') {
                                    _this.approvalUser(id);
                                }
                                else if (data.data.val == 'reject') {
                                    _this.rejectUser(id, data.data.notes);
                                }
                            }
                        });
                        return [4 /*yield*/, popOver.present()];
                    case 2: return [2 /*return*/, _a.sent()];
                }
            });
        });
    };
    UserApprovalPage.prototype.call = function (number) {
        if (number) {
            window.location.href = 'tel:' + number;
        }
        else {
            this.alertService.presentAlert(this.transService.getTranslatedData('alert-title'), this.transService.getTranslatedData('call-alert'));
        }
    };
    UserApprovalPage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-user-approval',
            template: __webpack_require__(/*! ./user-approval.page.html */ "./src/app/Rentals Management/pages/user-approval/user-approval.page.html"),
            styles: [__webpack_require__(/*! ./user-approval.page.scss */ "./src/app/Rentals Management/pages/user-approval/user-approval.page.scss")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_ionic_angular__WEBPACK_IMPORTED_MODULE_2__["LoadingController"],
            _services_rentals_user_service__WEBPACK_IMPORTED_MODULE_6__["RentalsUserService"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["ModalController"],
            src_app_common_services_alert_service_service__WEBPACK_IMPORTED_MODULE_3__["AlertServiceService"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["PopoverController"],
            src_app_common_services_translate_translate_service_service__WEBPACK_IMPORTED_MODULE_5__["translateService"],
            _angular_router__WEBPACK_IMPORTED_MODULE_7__["Router"]])
    ], UserApprovalPage);
    return UserApprovalPage;
}());



/***/ })

}]);
//# sourceMappingURL=Rentals-Management-pages-user-approval-user-approval-module.js.map