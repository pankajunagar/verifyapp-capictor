(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["default~Rentals-Management-pages-nailaaccountpage-nailaaccountpage-module~Rentals-Management-pages-n~0f6f80ab"],{

/***/ "./src/app/Rentals Management/modals/privacypolicy/privacypolicy.component.html":
/*!**************************************************************************************!*\
  !*** ./src/app/Rentals Management/modals/privacypolicy/privacypolicy.component.html ***!
  \**************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ion-header>\r\n    <ion-toolbar color=\"primary\">\r\n      <ion-title>Privacy policy</ion-title>\r\n      <ion-buttons slot=\"end\">\r\n        <ion-button color=\"primary\" (click)=\"closeModal()\">\r\n          <ion-icon style=\"    color: white;\" slot=\"icon-only\" name=\"close\"></ion-icon>\r\n        </ion-button>\r\n      </ion-buttons>\r\n    </ion-toolbar>\r\n  </ion-header>\r\n\r\n\r\n  <ion-content>\r\n      <ion-list>\r\n\r\n<ion-item lines=\"none\">\r\n  <p  class=\"font-12 ion-text-justify\">These services are protected by copyright laws and international copyright treaties, as well as other intellectual property laws\r\n      and treaties. Unauthorized reproduction or distribution of the Services, or any portion of them, may result in service civil and\r\n      criminal penalties, and will be prosecuted to the maximum extent possible under the law. The services are licensed, not sold.</p>\r\n</ion-item>\r\n\r\n\r\n          <ion-item lines=\"none\">\r\n            <ion-label size=\"12\" class=\"font-14\">DEFINITIONS</ion-label>\r\n          </ion-item>\r\n          <ion-item lines=\"none\">\r\n            <p class=\"font-12\">In these terms and conditions, unless the context specifies otherwise:</p>\r\n            \r\n          </ion-item>\r\n\r\n          <ion-item class=\"font-12 ion-text-justify\" lines=\"none\">\r\n              <section>    \r\n                  <ul class=\"ion-text-justify\">\r\n                    <li>\r\n                        \"Naila, shall mean Naila - Beauty services at your door steps incorporated under the Company Act of 1956\r\n                        and having its principal place of business at No 9, 4th cross, Vidyasagar, Thanisandra Main Road, Bangalore\r\n                        560077  \r\n                    </li>\r\n                    <li> All the packages and beauty services are designed to its customers by Naila where the customers enjoy the\r\n                        salon comfort at their respective homes.\r\n                    </li>\r\n                    <li>\r\n                        Registration to the program (packages and services) is governed by these rules set by Naila for this program\r\n                        which are subject to change.\r\n\r\n                    </li>\r\n                    <li>\r\n\r\n                        \"Program” means the service, managed and operated by Naila through its beautician on payrolls, Partners,\r\n                        facilities or arrangements to its registered users/customers.\r\n                    </li>\r\n                  </ul>\r\n                </section>\r\n          </ion-item>\r\n        </ion-list>\r\n        \r\n  </ion-content>"

/***/ }),

/***/ "./src/app/Rentals Management/modals/privacypolicy/privacypolicy.component.scss":
/*!**************************************************************************************!*\
  !*** ./src/app/Rentals Management/modals/privacypolicy/privacypolicy.component.scss ***!
  \**************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL1JlbnRhbHMgTWFuYWdlbWVudC9tb2RhbHMvcHJpdmFjeXBvbGljeS9wcml2YWN5cG9saWN5LmNvbXBvbmVudC5zY3NzIn0= */"

/***/ }),

/***/ "./src/app/Rentals Management/modals/privacypolicy/privacypolicy.component.ts":
/*!************************************************************************************!*\
  !*** ./src/app/Rentals Management/modals/privacypolicy/privacypolicy.component.ts ***!
  \************************************************************************************/
/*! exports provided: PrivacyPolicyModalComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "PrivacyPolicyModalComponent", function() { return PrivacyPolicyModalComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _services_notice_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./../../services/notice.service */ "./src/app/Rentals Management/services/notice.service.ts");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var src_app_common_services_alert_service_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! src/app/common-services/alert-service.service */ "./src/app/common-services/alert-service.service.ts");
/* harmony import */ var _ionic_native_ionic_webview_ngx__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic-native/ionic-webview/ngx */ "./node_modules/@ionic-native/ionic-webview/ngx/index.js");
/* harmony import */ var src_app_common_services_translate_translate_service_service__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! src/app/common-services/translate/translate-service.service */ "./src/app/common-services/translate/translate-service.service.ts");








var PrivacyPolicyModalComponent = /** @class */ (function () {
    function PrivacyPolicyModalComponent(modalController, loadingCtrl, noticeService, router, alertService, route, webView, transService, actionSheet) {
        this.modalController = modalController;
        this.loadingCtrl = loadingCtrl;
        this.noticeService = noticeService;
        this.router = router;
        this.alertService = alertService;
        this.route = route;
        this.webView = webView;
        this.transService = transService;
        this.actionSheet = actionSheet;
        this.notice = {
            discussionBelongsTo: 'Project',
            discussionType: 'Notice',
            raisedByEmployee: true,
        };
        this.flag = false;
        this.images = [];
    }
    PrivacyPolicyModalComponent.prototype.ngOnInit = function () { };
    PrivacyPolicyModalComponent.prototype.presentLoading = function () {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function () {
            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                this.loadingCtrl.create({
                    spinner: "lines"
                }).then(function (loading) {
                    loading.present();
                });
                return [2 /*return*/];
            });
        });
    };
    PrivacyPolicyModalComponent.prototype.closeModal = function () {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function () {
            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.modalController.dismiss()];
                    case 1:
                        _a.sent();
                        return [2 /*return*/];
                }
            });
        });
    };
    PrivacyPolicyModalComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_4__["Component"])({
            selector: 'app-privacypolicy',
            template: __webpack_require__(/*! ./privacypolicy.component.html */ "./src/app/Rentals Management/modals/privacypolicy/privacypolicy.component.html"),
            styles: [__webpack_require__(/*! ./privacypolicy.component.scss */ "./src/app/Rentals Management/modals/privacypolicy/privacypolicy.component.scss")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_ionic_angular__WEBPACK_IMPORTED_MODULE_3__["ModalController"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["LoadingController"],
            _services_notice_service__WEBPACK_IMPORTED_MODULE_2__["NoticeService"],
            _angular_router__WEBPACK_IMPORTED_MODULE_1__["Router"],
            src_app_common_services_alert_service_service__WEBPACK_IMPORTED_MODULE_5__["AlertServiceService"],
            _angular_router__WEBPACK_IMPORTED_MODULE_1__["ActivatedRoute"],
            _ionic_native_ionic_webview_ngx__WEBPACK_IMPORTED_MODULE_6__["WebView"],
            src_app_common_services_translate_translate_service_service__WEBPACK_IMPORTED_MODULE_7__["translateService"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["ActionSheetController"]])
    ], PrivacyPolicyModalComponent);
    return PrivacyPolicyModalComponent;
}());



/***/ }),

/***/ "./src/app/Rentals Management/modals/termsandcondition/termsandcondition.component.html":
/*!**********************************************************************************************!*\
  !*** ./src/app/Rentals Management/modals/termsandcondition/termsandcondition.component.html ***!
  \**********************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ion-header>\r\n  <ion-toolbar color=\"primary\">\r\n    <ion-title>General Terms and Conditions</ion-title>\r\n    <ion-buttons slot=\"end\">\r\n      <ion-button color=\"primary\" (click)=\"closeModal()\">\r\n        <ion-icon style=\"    color: white;\" slot=\"icon-only\" name=\"close\"></ion-icon>\r\n      </ion-button>\r\n    </ion-buttons>\r\n  </ion-toolbar>\r\n</ion-header>\r\n\r\n\r\n<ion-content>\r\n  <ion-list>\r\n\r\n    <ion-item lines=\"none\">\r\n      <p class=\"font-12 ion-text-justify\">\r\n\r\n        The terms and conditions explain the nature and scope of “Naila beauty services at your door steps” here in\r\n        referred to as\r\n        \"Naila\" (as owner and management for the Service) and Users/Customers of Naila. The terms and conditions cover\r\n        service\r\n        usage, rules of usage, limitations and exclusions on the liability of Naila.\r\n        PLEASE READ THESE TERMS OF SERVICE CAREFULLY. THIS IS A LEGAL AGREEMENT BETWEEN Naila.com AND YOU WHICH\r\n        GOVERNS YOUR USE OF SERVICES. YOUR USE OF SERVICES CONSTITUTES YOUR ACCEPTENCE OF AND AGREEMENT TO ALL OF\r\n        THE TERMS AND CONDITIONS IN THESE TERMS OF SERVICE AND YOUR REPRESENTATION THAT YOU ARE 18 YEARS OF AGE OR\r\n        OLDER. IF YOU OBJECT TO ANYTHING IN THESE TERMS OF SERVICE, YOU ARE NOT PERMITTED TO USE THE SERVICES.\r\n        These services are protected by copyright laws and international copyright treaties, as well as other\r\n        intellectual property laws\r\n        and treaties. Unauthorized reproduction or distribution of the Services, or any portion of them, may result in\r\n        service civil and\r\n        criminal penalties, and will be prosecuted to the maximum extent possible under the law. The services are\r\n        licensed, not sold.\r\n\r\n      </p>\r\n    </ion-item>\r\n\r\n\r\n    <ion-item lines=\"none\">\r\n      <ion-label size=\"12\" class=\"font-14\">1.DEFINITIONS</ion-label>\r\n    </ion-item>\r\n    <ion-item lines=\"none\">\r\n      <p class=\"font-12\">In these terms and conditions, unless the context specifies otherwise:</p>\r\n\r\n    </ion-item>\r\n\r\n    <ion-item class=\"font-12 ion-text-justify\" lines=\"none\">\r\n      <section>\r\n        <ul class=\"ion-text-justify\">\r\n          <li>\r\n            \"Naila, shall mean Naila - Beauty services at your door steps incorporated under the Company Act of 1956\r\n            and having its principal place of business at No 9, 4th cross, Vidyasagar, Thanisandra Main Road, Bangalore\r\n            560077\r\n          </li>\r\n          <li> All the packages and beauty services are designed to its customers by Naila where the customers enjoy the\r\n            salon comfort at their respective homes.\r\n          </li>\r\n          <li>\r\n            Registration to the program (packages and services) is governed by these rules set by Naila for this program\r\n            which are subject to change.\r\n\r\n          </li>\r\n          <li>\r\n\r\n            \"Program” means the service, managed and operated by Naila through its beautician on payrolls, Partners,\r\n            facilities or arrangements to its registered users/customers.\r\n          </li>\r\n\r\n          <li>\r\n\r\n            \"Working Days” means the period from Wednesday to Monday. Timings are from 10.00 am to 7:00 pm only.\r\n            ( Tuesday Bookings on special prior request)\r\n          </li>\r\n        </ul>\r\n      </section>\r\n    </ion-item>\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n    <ion-item lines=\"none\">\r\n      <ion-label size=\"12\" class=\"font-14\">2.GENERAL CONDITIONS</ion-label>\r\n    </ion-item>\r\n\r\n\r\n    <ion-item class=\"font-12 ion-text-justify\" lines=\"none\">\r\n      <section>\r\n        <ul class=\"ion-text-justify\">\r\n          <li>\r\n            The Naila Users/customers agrees that by using the Mobile Application of Naila post login, the customer\r\n            (she) is deemed to have read and understood the these terms and conditions of the Program and confirms\r\n            that he/she is bound by these terms and conditions and any changes to it from time to time and such other\r\n            terms as specified from Naila from time to time.\r\n          </li>\r\n          <li>\r\n\r\n            o Registration into Naila Program/Service is voluntary, open to all natural persons above the age of 18\r\n            (except\r\n            only where the Partner Program is otherwise) with a correct mailing address in India\r\n          </li>\r\n          <li>\r\n            Naila is not responsible for any damage / injury / loss due to undisclosed medical records / history of the\r\n            customer.\r\n\r\n          </li>\r\n          <li>\r\n\r\n            Naila provides services to only Ladies. We don’t do cross gender service\r\n          </li>\r\n\r\n          <li>\r\n\r\n            The entire responsibility is on the customer booking the service and the residence owner to ensure that the\r\n            female therapists / beauticians visiting their premises are professionally respected and their personal,\r\n            physical or emotional safety is not breached under any circumstances. Any deliberate abuse of the\r\n            therapist's/beauticians personal and emotional safety will result in criminal prosecution of the customer in\r\n            the jurisdiction of local court.\r\n          </li>\r\n\r\n\r\n\r\n\r\n          <li>\r\n\r\n            Naila reserves the right to modify these Terms and Conditions and such changes shall be deemed effective\r\n            immediately upon posting of the modified Terms and Conditions on app following the posting of changes on\r\n            our app will indicate their acceptance of changes.\r\n          </li>\r\n\r\n          <li>\r\n\r\n\r\n            Naila Account is valid for lifetime post registration unless terminated in accordance with these terms and\r\n            conditions.\r\n          </li>\r\n\r\n\r\n          <li>\r\n\r\n            Customers will be personally liable for any and all costs, taxes, charges, claims or liabilities of whatever\r\n            nature arising from the provision or availability of benefits, facilities or arrangements provided or made\r\n            available to the customers, by Naila.\r\n          </li>\r\n\r\n\r\n          <li>\r\n\r\n            The Naila account of the customers at all times remains the property of Naila, which reserves the right at\r\n            any time in its absolute discretion and without giving notice to such users to deactivate their account.\r\n          </li>\r\n\r\n          <li>\r\n\r\n            Naila shall not be liable for any loss or damage, whether direct or indirect, resulting from service\r\n            provider or\r\n            the product sold by the service provider.\r\n          </li>\r\n\r\n\r\n\r\n          <li>\r\n\r\n            The Program on the Naila Application may be modified at the sole discretion of Nailamanagement from\r\n            time to time without intimation to the Naila customers/users\r\n          </li>\r\n\r\n\r\n          <li>\r\n\r\n            If there are any change in the contact details (mobile number/ email id/ address) of a Naila customer/users\r\n            from what has been registered with Naila the users must update the respective contact details immediately\r\n            either through the website, mobile app, contact center or any other channels to avoid any misuse of\r\n            customer’s Naila Account.\r\n          </li>\r\n\r\n\r\n          <li>\r\n\r\n            Naila shall not be liable for any loss or other relevant damages incurred by the customers/ users, if\r\n            necessary details are not updated with Naila on time.\r\n          </li>\r\n\r\n\r\n          <li>\r\n\r\n            All dispute complaints older than 45 Working Days from the date of the service availed will not be\r\n            entertained. The customer/Users must provide proof of service availed as required to register any dispute.\r\n          </li>\r\n\r\n\r\n          <li>\r\n\r\n            Each provision of the Terms is independent of each other. If any provision of the Terms is found void and\r\n            unenforceable, it will not affect the validity of the remaining provisions of Terms, which shall remain\r\n            valid\r\n            and enforceable.\r\n          </li>\r\n\r\n\r\n          <li>\r\n\r\n            Naila has the right to change your Stylist at the end moment. This might happen due to any emergency or\r\n            health issue with the already assigned Stylish stationed in your apartment.\r\n          </li>\r\n\r\n          <li>\r\n\r\n\r\n            In Case of Online Payment or Pre-Payment, Full amount will be refunded (excluding the transaction charge\r\n            of 2%) if the cancellation is done before 4 hours of the scheduled service. No refund will be give in case\r\n            of\r\n            cancellation within 4 hours of the scheduled service.\r\n          </li>\r\n\r\n          <li>Naila access your Google accounts which autofills your email/phone number in the Sign Up and Login forms.\r\n            This information is used for Login and Sign Up and calling by Naila Customer Care and Stylist.</li>\r\n\r\n        </ul>\r\n      </section>\r\n    </ion-item>\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n    <ion-item lines=\"none\">\r\n      <ion-label size=\"12\" class=\"font-14\">3.WARRANTIES / GUARANTEE</ion-label>\r\n    </ion-item>\r\n\r\n\r\n    <ion-item class=\"font-12 ion-text-justify\" lines=\"none\">\r\n      <section>\r\n        <ul class=\"ion-text-justify\">\r\n          <li>\r\n            All warranties and guarantees on the products and services are the sole responsibility of the Service\r\n            Provider/Seller(s) (except in some cases where the warranty or guarantee may be from the\r\n            manufacturer(s)) providing beauty products. Nailamanagement shall not be liable or responsible for any\r\n            defect or deficiency in the products used and service provided by the beauticians whatsoever. All\r\n            guarantees and warranties on the Naila app shall be transferred as is from the manufacturer or the Service\r\n            provider/Seller(s).\r\n          </li>\r\n          <li>\r\n\r\n            Naila Users must contact the respective Seller(s) / Manufacturer (in case of manufacturer warranty) in the\r\n            event of any defect or deficiency in the Service or product. In such event, Naila will purely act as a\r\n            complaint\r\n            routing agent. Naila gives no warranty or representation either express or implied with respect to type,\r\n            quality or fitness of goods acquired or their suitability for any purpose provided by the Supplier under\r\n            this\r\n            Program, whatsoever.\r\n          </li>\r\n\r\n\r\n\r\n\r\n        </ul>\r\n      </section>\r\n    </ion-item>\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n    <ion-item lines=\"none\">\r\n      <ion-label size=\"12\" class=\"font-14\">4.INDEMNIFICATION</ion-label>\r\n    </ion-item>\r\n\r\n\r\n    <ion-item class=\"font-12 ion-text-justify\" lines=\"none\">\r\n      <section>\r\n        <ul class=\"ion-text-justify\">\r\n          <li>\r\n            Customer/user agree to indemnify, defend and hold Naila , its affiliates, successors, assigns and licensors,\r\n            franchisees or sub-franchisees, any of their respective officers, directors, employees, agents, vendors,\r\n            licensors, representatives, advertisers, service providers and suppliers harmless from and against any and\r\n            all\r\n            claims, actions, losses, expenses, damages and costs (including reasonable attorneys' fees), resulting from\r\n            any breach or violation of Terms by you, or due to your activities related to the Naila Service, whether by\r\n            use of User Account or otherwise.\r\n          </li>\r\n\r\n\r\n\r\n\r\n\r\n        </ul>\r\n\r\n      </section>\r\n    </ion-item>\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n    <ion-item lines=\"none\">\r\n      <ion-label size=\"12\" class=\"font-14\">5.APPLICABLE LAWS</ion-label>\r\n    </ion-item>\r\n\r\n\r\n    <ion-item class=\"font-12 ion-text-justify\" lines=\"none\">\r\n      <section>\r\n        <ul class=\"ion-text-justify\">\r\n          <li>\r\n            These Terms contains the entire understanding and agreement between User and Naila and supersedes any\r\n            and all prior or inconsistent understandings relating to Naila Service and your use of Naila Service. Terms\r\n            cannot be changed or terminated orally. Any provision which must survive in order to allow us to enforce its\r\n            meaning shall survive the termination of Terms. Terms and your use of Naila Service is governed by,\r\n            construed and enforced in accordance with the laws of India applicable to contracts made, executed and\r\n            wholly performed on the Naila Service, and, for the purposes of any and all legal or equitable actions, you\r\n            specifically agree and submit to the exclusive jurisdiction and venue of the local Courts of your City and\r\n            State in India and you will not object to such jurisdiction or venue on the grounds of lack of personal\r\n            jurisdiction or otherwise.\r\n          </li>\r\n\r\n\r\n\r\n\r\n\r\n        </ul>\r\n      </section>\r\n    </ion-item>\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n    <ion-item lines=\"none\">\r\n      <ion-label size=\"12\" class=\"font-14\">6.DISCLAIMER</ion-label>\r\n    </ion-item>\r\n\r\n\r\n    <ion-item class=\"font-12 ion-text-justify\" lines=\"none\">\r\n      <section>\r\n        <ul class=\"ion-text-justify\">\r\n          <li>\r\n            Naila is a connector between the service provider and the customer. Though there is a thorough\r\n            background check and screening done on our beauticians , partner beauticians and therapists. Naila does\r\n            take partial responsibility with regards to the behavior, actions or conduct of the beautician/therapists\r\n            towards the customer. The customer/user should take care of their belongings and valuables during the\r\n            visit of the beauticians/therapists. Naila will not be responsible for any loss or damage of valuables of\r\n            Customers during or post visits of the beauticians/therapists booked through Naila.\r\n          </li>\r\n\r\n\r\n          <li>\r\n\r\n            The Naila service and all contents, materials and postings are without any representation or warranty of any\r\n            kind.\r\n          </li>\r\n\r\n\r\n          <li>\r\n\r\n            You understand the Naila Service and agree to the fullest extent and their successors and assigns, or any of\r\n            their affiliates or their respective officers, directors, employees, agents, licensors, representatives,\r\n            operational service providers, advertisers or suppliers shall not be liable for any loss or damage, of any\r\n            kind, direct or indirect, in connection with or arising from use of the Naila service or from this terms of\r\n            use,\r\n            including, but not limited to, compensatory, consequential, incidental, indirect, special or punitive\r\n            damages\r\n          </li>\r\n\r\n\r\n          <li>\r\n            Acceptance of booking amount is neither a commitment nor a guarantee by Naila to mandatorily provide a\r\n            beautician/therapist for the services.\r\n          </li>\r\n\r\n          <li>\r\n\r\n            Any need for a legal arbitration or proceedings which arises out of the service or the purchase of the\r\n            products from the beautician/therapist is to be settled between the customer and the service provider\r\n            without our involvement.\r\n          </li>\r\n\r\n        </ul>\r\n      </section>\r\n    </ion-item>\r\n  </ion-list>\r\n\r\n</ion-content>"

/***/ }),

/***/ "./src/app/Rentals Management/modals/termsandcondition/termsandcondition.component.scss":
/*!**********************************************************************************************!*\
  !*** ./src/app/Rentals Management/modals/termsandcondition/termsandcondition.component.scss ***!
  \**********************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL1JlbnRhbHMgTWFuYWdlbWVudC9tb2RhbHMvdGVybXNhbmRjb25kaXRpb24vdGVybXNhbmRjb25kaXRpb24uY29tcG9uZW50LnNjc3MifQ== */"

/***/ }),

/***/ "./src/app/Rentals Management/modals/termsandcondition/termsandcondition.component.ts":
/*!********************************************************************************************!*\
  !*** ./src/app/Rentals Management/modals/termsandcondition/termsandcondition.component.ts ***!
  \********************************************************************************************/
/*! exports provided: TermsModalComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "TermsModalComponent", function() { return TermsModalComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _services_notice_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./../../services/notice.service */ "./src/app/Rentals Management/services/notice.service.ts");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var src_app_common_services_alert_service_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! src/app/common-services/alert-service.service */ "./src/app/common-services/alert-service.service.ts");
/* harmony import */ var _ionic_native_ionic_webview_ngx__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic-native/ionic-webview/ngx */ "./node_modules/@ionic-native/ionic-webview/ngx/index.js");
/* harmony import */ var src_app_common_services_translate_translate_service_service__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! src/app/common-services/translate/translate-service.service */ "./src/app/common-services/translate/translate-service.service.ts");








var TermsModalComponent = /** @class */ (function () {
    function TermsModalComponent(modalController, loadingCtrl, noticeService, router, alertService, route, webView, transService, actionSheet) {
        this.modalController = modalController;
        this.loadingCtrl = loadingCtrl;
        this.noticeService = noticeService;
        this.router = router;
        this.alertService = alertService;
        this.route = route;
        this.webView = webView;
        this.transService = transService;
        this.actionSheet = actionSheet;
        this.notice = {
            discussionBelongsTo: 'Project',
            discussionType: 'Notice',
            raisedByEmployee: true,
        };
        this.flag = false;
        this.images = [];
    }
    TermsModalComponent.prototype.ngOnInit = function () { };
    TermsModalComponent.prototype.presentLoading = function () {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function () {
            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                this.loadingCtrl.create({
                    spinner: "lines"
                }).then(function (loading) {
                    loading.present();
                });
                return [2 /*return*/];
            });
        });
    };
    TermsModalComponent.prototype.closeModal = function () {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function () {
            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.modalController.dismiss()];
                    case 1:
                        _a.sent();
                        return [2 /*return*/];
                }
            });
        });
    };
    TermsModalComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_4__["Component"])({
            selector: 'app-termsandcondition',
            template: __webpack_require__(/*! ./termsandcondition.component.html */ "./src/app/Rentals Management/modals/termsandcondition/termsandcondition.component.html"),
            styles: [__webpack_require__(/*! ./termsandcondition.component.scss */ "./src/app/Rentals Management/modals/termsandcondition/termsandcondition.component.scss")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_ionic_angular__WEBPACK_IMPORTED_MODULE_3__["ModalController"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["LoadingController"],
            _services_notice_service__WEBPACK_IMPORTED_MODULE_2__["NoticeService"],
            _angular_router__WEBPACK_IMPORTED_MODULE_1__["Router"],
            src_app_common_services_alert_service_service__WEBPACK_IMPORTED_MODULE_5__["AlertServiceService"],
            _angular_router__WEBPACK_IMPORTED_MODULE_1__["ActivatedRoute"],
            _ionic_native_ionic_webview_ngx__WEBPACK_IMPORTED_MODULE_6__["WebView"],
            src_app_common_services_translate_translate_service_service__WEBPACK_IMPORTED_MODULE_7__["translateService"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["ActionSheetController"]])
    ], TermsModalComponent);
    return TermsModalComponent;
}());



/***/ })

}]);
//# sourceMappingURL=default~Rentals-Management-pages-nailaaccountpage-nailaaccountpage-module~Rentals-Management-pages-n~0f6f80ab.js.map