(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["Rentals-Management-pages-verifyitProductinfo-verifyitProductinfo-module"],{

/***/ "./src/app/Rentals Management/pages/verifyitProductinfo/verifyitProductinfo.module.ts":
/*!********************************************************************************************!*\
  !*** ./src/app/Rentals Management/pages/verifyitProductinfo/verifyitProductinfo.module.ts ***!
  \********************************************************************************************/
/*! exports provided: VerifyitProductInfoPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "VerifyitProductInfoPageModule", function() { return VerifyitProductInfoPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _ApplicationPageModule__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./../../ApplicationPageModule */ "./src/app/Rentals Management/ApplicationPageModule.ts");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _modals_create_notice_create_notice_component__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../../modals/create-notice/create-notice.component */ "./src/app/Rentals Management/modals/create-notice/create-notice.component.ts");
/* harmony import */ var _verifyitProductinfo_page__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./verifyitProductinfo.page */ "./src/app/Rentals Management/pages/verifyitProductinfo/verifyitProductinfo.page.ts");
/* harmony import */ var _modals_tellusifyoubuyit_tellusifyoubuyit_component__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ../../modals/tellusifyoubuyit/tellusifyoubuyit.component */ "./src/app/Rentals Management/modals/tellusifyoubuyit/tellusifyoubuyit.component.ts");
/* harmony import */ var _modals_certificatemodal_certificatemodal_component__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ../../modals/certificatemodal/certificatemodal.component */ "./src/app/Rentals Management/modals/certificatemodal/certificatemodal.component.ts");











var routes = [
    {
        path: '',
        component: _verifyitProductinfo_page__WEBPACK_IMPORTED_MODULE_8__["VerifyitProductInfoPage"]
    }
];
var VerifyitProductInfoPageModule = /** @class */ (function () {
    function VerifyitProductInfoPageModule() {
    }
    VerifyitProductInfoPageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_2__["NgModule"])({
            entryComponents: [_modals_create_notice_create_notice_component__WEBPACK_IMPORTED_MODULE_7__["CreateNoticeComponent"], _modals_tellusifyoubuyit_tellusifyoubuyit_component__WEBPACK_IMPORTED_MODULE_9__["TellUsifyouBuyitComponent"], _modals_certificatemodal_certificatemodal_component__WEBPACK_IMPORTED_MODULE_10__["CertificateModalComponent"]],
            imports: [
                _angular_common__WEBPACK_IMPORTED_MODULE_3__["CommonModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormsModule"],
                _ApplicationPageModule__WEBPACK_IMPORTED_MODULE_1__["ApplicationPageModule"],
                _ionic_angular__WEBPACK_IMPORTED_MODULE_6__["IonicModule"],
                _angular_router__WEBPACK_IMPORTED_MODULE_5__["RouterModule"].forChild(routes)
            ],
            providers: [
                // BarcodeScanner
                _modals_tellusifyoubuyit_tellusifyoubuyit_component__WEBPACK_IMPORTED_MODULE_9__["TellUsifyouBuyitComponent"], _modals_certificatemodal_certificatemodal_component__WEBPACK_IMPORTED_MODULE_10__["CertificateModalComponent"]
            ],
            declarations: [_verifyitProductinfo_page__WEBPACK_IMPORTED_MODULE_8__["VerifyitProductInfoPage"], _modals_tellusifyoubuyit_tellusifyoubuyit_component__WEBPACK_IMPORTED_MODULE_9__["TellUsifyouBuyitComponent"], _modals_certificatemodal_certificatemodal_component__WEBPACK_IMPORTED_MODULE_10__["CertificateModalComponent"]]
        })
    ], VerifyitProductInfoPageModule);
    return VerifyitProductInfoPageModule;
}());



/***/ }),

/***/ "./src/app/Rentals Management/pages/verifyitProductinfo/verifyitProductinfo.page.html":
/*!********************************************************************************************!*\
  !*** ./src/app/Rentals Management/pages/verifyitProductinfo/verifyitProductinfo.page.html ***!
  \********************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ion-header no-border>\r\n  <ion-toolbar color=\"primary\">\r\n    <ion-buttons slot=\"start\">\r\n      <ion-menu-button></ion-menu-button>\r\n    </ion-buttons>\r\n    <!-- <ion-buttons slot=\"end\" expand=\"full\" class=\"ion-button\" (click)=\"openScanner()\">\r\n      <ion-button style=\"color: black\">\r\n          <img src=\"../../../../assets/icons.png\" width=\"30px\" height=\"30px\"/>\r\n      </ion-button>\r\n    </ion-buttons> -->\r\n\r\n    <ion-title>Product Information</ion-title>\r\n  </ion-toolbar>\r\n\r\n</ion-header>\r\n<ion-content   *ngIf=\"callgettagresult\" no-padding>\r\n    <section [style.background-color]=\"this.brand_color\">\r\n\r\n    <!-- <ion-card class=\"mapp-card\">\r\n    <ion-card-header  text-center>\r\n\t    <h3 ion-text  class=\"write-head\" color=\"primary\" >{{credKeys.key12}}</h3>\r\n    </ion-card-header> -->\r\n\r\n\r\n    <ion-row>\r\n      <ion-col class=\"product-image\">\r\n        <img tyle=\"margin-right: -15vh;\r\n      margin-top: 6vh;\r\n      position: absolute;\r\n      height: 500px;\r\n      width: 500px;\" src={{callgettagresult.img1}} />\r\n\r\n\r\n        <img *ngIf=\"callgettagresult.verified=='Yes' \" style=\"margin-right: -15vh;\r\n      margin-top: 6vh;\r\n      position: absolute;\r\n      height: 200px;\r\n      width: 200px;\" src=\"assets/approved.png\">\r\n\r\n        <img *ngIf=\"callgettagresult.verified=='No'\" style=\"margin-right: -15vh;\r\n      margin-top: 6vh;\r\n      position: absolute;\r\n      height: 100px;\r\n      width: 100px;\" src=\"assets/fake.png\">\r\n      </ion-col>\r\n\r\n    </ion-row>\r\n\r\n    <ion-row>\r\n      <!-- <ion-col size=\"6\" class=\"product-label\">{{credKeys.key1}} :</ion-col> -->\r\n      <ion-col size=\"10\">\r\n        <h2 class=\"product-name\">\r\n          {{callgettagresult.product_name}}\r\n        </h2>\r\n      </ion-col>\r\n      <ion-col size=\"2\">\r\n        <ion-icon style=\"display: inline;\" (click)=\"socialShare();\" ios=\"ios-share\" md=\"md-share\"></ion-icon>\r\n\r\n      </ion-col>\r\n    </ion-row>\r\n\r\n    <!--ion-input [(ngModel)]=\"cred.img.default.main\"></ion-input-->\r\n\r\n\r\n\r\n    <ion-row>\r\n      <ion-col class=\"product-image\">\r\n        <!-- <ion-label class=\"product-name\"> {{cred.product_name}}</ion-label> -->\r\n      </ion-col>\r\n\r\n    </ion-row>\r\n\r\n\r\n    <ion-grid>\r\n\r\n\r\n      <!-- <ion-row>\r\n          <ion-col size=\"6\" class=\"product-label\">{{credKeys.key1}} :</ion-col>\r\n          <ion-col class=\"float-right\"> {{callgettagresult.product_name}}</ion-col>\r\n        </ion-row> -->\r\n      <ion-row>\r\n        <ion-col size=\"5\" class=\"product-label\">{{credKeys.key4}} :</ion-col>\r\n        <ion-col class=\"float-right\"> {{callgettagresult.brand}}</ion-col>\r\n      </ion-row>\r\n      <ion-row>\r\n        <ion-col size=\"5\" class=\"product-label\">{{credKeys.key2}} :</ion-col>\r\n        <ion-col class=\"float-right\"> {{callgettagresult.model_number}}</ion-col>\r\n      </ion-row>\r\n      <ion-row>\r\n        <ion-col size=\"5\" class=\"product-label\">{{credKeys.key10}} :</ion-col>\r\n        <ion-col class=\"float-right\"> {{callgettagresult.manufactured}}</ion-col>\r\n      </ion-row>\r\n      <ion-row *ngIf=\"callgettagresult.serial_number != '0' || callgettagresult.serial_number.length > 2\">\r\n        <ion-col size=\"5\" class=\"product-label\">{{credKeys.key3}} :</ion-col>\r\n        <ion-col class=\"float-right\"> {{callgettagresult.serial_number}}</ion-col>\r\n      </ion-row>\r\n\r\n      <ion-row *ngFor=\"let item of jsonToBeUsed\">\r\n        <ion-col text-capitalize\r\n          *ngIf=\"item.key!='Instruction' && item.key!='purchase_type' && jsonToBeUsed.length && item.key!='product_catalogue' && item.key!='certificates' && item.key!='purchase online' && item.key!='review' && item.key!='brand_color'\"\r\n          size=\"5\" class=\"product-label\">{{item.key.split('_').join(' ')}}:</ion-col>\r\n        <ion-col text-capitalize\r\n          *ngIf=\"item.key!='Instruction' && item.key!='purchase_type' && jsonToBeUsed.length && item.key!='product_catalogue' && item.key!='certificates' && item.key!='purchase online' && item.key!='review' && item.key!='brand_color'\"\r\n          class=\"float-right\">{{item.value}}</ion-col>\r\n\r\n\r\n        <ion-col text-capitalize\r\n          *ngIf=\"item.key!='Instruction' && item.key!='purchase_type' && jsonToBeUsed.length && item.key=='product_catalogue' && item.key!='certificates' && item.key!='purchase online' && item.key!='review' && item.key!='brand_color'\"\r\n          size=\"6\" class=\"product-label\">{{item.key.split('_').join(' ')}}:</ion-col>\r\n        <ion-col text-capitalize\r\n          *ngIf=\"item.key!='Instruction' && item.key!='purchase_type' && jsonToBeUsed.length && item.key=='product_catalogue' && item.key!='certificates' && item.key!='purchase online' && item.key!='review' && item.key!='brand_color'\"\r\n          class=\"float-right\"> <a style=\"text-decoration: underline;\r\n        color: blue;\" (click)=\"showCatalog(callgettagresult.product_id)\">Show catalog</a></ion-col>\r\n\r\n\r\n        <ion-col text-capitalize\r\n          *ngIf=\"item.key!='Instruction' && item.key!='purchase_type' && jsonToBeUsed.length && item.key!='product_catalogue' && item.key=='certificates' && item.key!='purchase online' && item.key!='review' && item.key!='brand_color'\"\r\n          size=\"6\" class=\"product-label\">{{item.key.split('_').join(' ')}}:</ion-col>\r\n        <ion-col text-capitalize\r\n          *ngIf=\"item.key!='Instruction' && item.key!='purchase_type' && jsonToBeUsed.length && item.key!='product_catalogue' && item.key=='certificates' && item.key!='purchase online' && item.key!='review' && item.key!='brand_color'\"\r\n          class=\"float-right\"> <a style=\"text-decoration: underline;\r\n  color: blue;\"\r\n            (click)=\"showCertificates(item.value)\">{{item.value[0].text}}{{item.value[1]? ','+item.value[1].text+'...' : '..'}}</a>\r\n        </ion-col>\r\n\r\n\r\n\r\n        <ion-col text-capitalize\r\n          *ngIf=\"item.key!='Instruction' && item.key!='purchase_type' && jsonToBeUsed.length && item.key!='product_catalogue' && item.key!='certificates' && item.key=='purchase online' && item.key!='review' && item.key!='brand_color'\"\r\n          size=\"6\" class=\"product-label\">{{item.key.split('_').join(' ')}}:</ion-col>\r\n        <ion-col text-capitalize\r\n          *ngIf=\"item.key!='Instruction' && item.key!='purchase_type' && item.key!='review' && jsonToBeUsed.length && item.key!='product_catalogue' && item.key!='certificates' && item.key=='purchase online' && item.key!='brand_color'\"\r\n          class=\"float-right\"> <a style=\"text-decoration: underline;\r\ncolor: blue;\"\r\n            (click)=\"presentActionSheet(item.value)\">{{item.value[0].text}}{{item.value[1]? ','+item.value[1].text+'...' : '..'}}</a>\r\n        </ion-col>\r\n\r\n\r\n\r\n\r\n\r\n        <ion-col text-capitalize\r\n        *ngIf=\"item.key!='Instruction' && item.key!='purchase_type' && jsonToBeUsed.length && item.key!='product_catalogue' && item.key!='certificates' && item.key!='purchase online'   && item.key=='review' && item.key!='brand_color'\"\r\n        size=\"6\" class=\"product-label\">{{item.key.split('_').join(' ')}}:</ion-col>\r\n      <ion-col text-capitalize\r\n        *ngIf=\"item.key!='Instruction' && item.key!='purchase_type' && jsonToBeUsed.length && item.key!='product_catalogue' && item.key!='certificates' && item.key!='purchase online'   && item.key=='review' && item.key!='brand_color'\"\r\n        class=\"float-right\"> <a style=\"text-decoration: underline;\r\ncolor: blue;\"\r\n          (click)=\"presentActionSheet(item.value)\">Feedback</a>\r\n      </ion-col>\r\n\r\n\r\n      </ion-row>\r\n\r\n\r\n    \r\n\r\n\r\n      <!-- \r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n    <ion-row>\r\n      <ion-col size=\"6\" class=\"product-label\">{{credKeys.key6}} :</ion-col>\r\n      <ion-col class=\"float-right\"> {{cred.product_details.display_type}}</ion-col>\r\n    </ion-row>\r\n    <ion-row>\r\n      <ion-col size=\"6\" class=\"product-label\">{{credKeys.key7}} :</ion-col>\r\n      <ion-col class=\"float-right\"> {{cred.product_details.series}}</ion-col>\r\n    </ion-row>\r\n    <ion-row>\r\n      <ion-col size=\"6\" class=\"product-label\">{{credKeys.key8}} :</ion-col>\r\n      <ion-col class=\"float-right\"> {{cred.product_details.occassion}}</ion-col>\r\n    </ion-row>\r\n    <ion-row>\r\n      <ion-col size=\"6\" class=\"product-label\">{{credKeys.key9}} :</ion-col>\r\n      <ion-col class=\"float-right\"> {{cred.product_details.strap}}</ion-col>\r\n    </ion-row>\r\n    <ion-row>\r\n      <ion-col size=\"6\" class=\"product-label\">{{credKeys.key10}}:</ion-col>\r\n      <ion-col class=\"float-right\"> {{cred.manufactured}}</ion-col>\r\n    </ion-row> -->\r\n\r\n\r\n\r\n    </ion-grid>\r\n    <ion-row>\r\n      <ion-col>\r\n        <h2 class=\"instruction-label\">{{credKeys.key11}}</h2>\r\n      </ion-col>\r\n      <ng-container *ngFor=\"let item of jsonToBeUsed\">\r\n\r\n        <ion-col *ngIf=\"item.key=='Instruction' && jsonToBeUsed.length\" size=\"12\">\r\n          <p class=\"instruction\">\r\n            {{item.value}}\r\n          </p>\r\n        </ion-col>\r\n      </ng-container>\r\n    </ion-row>\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n    <ion-row>\r\n      <ng-container *ngFor=\"let item of jsonToBeUsed\">\r\n        <ion-col *ngIf=\"item.value=='offline' && jsonToBeUsed.length\" class=\"col-btn\">\r\n          <!-- \r\n      <ion-button *ngIf=\"!cred.tagId\" ion-button type=\"submit\" [disabled]=\"writingTag\" text-uppercase\r\n        class=\"write-btn margin-top-15\" block (click)=\"readTag();\">Get Product Information</ion-button> -->\r\n          <ion-button ion-button type=\"submit\" text-uppercase class=\"write-btn\" block (click)=\"presentModal2();\">Tell us\r\n            if\r\n            you buy it.\r\n          </ion-button>\r\n\r\n        </ion-col>\r\n\r\n\r\n        <ion-col *ngIf=\"item.value=='online' && jsonToBeUsed.length\" class=\"col-btn\">\r\n          <!-- \r\n        <ion-button *ngIf=\"!cred.tagId\" ion-button type=\"submit\" [disabled]=\"writingTag\" text-uppercase\r\n          class=\"write-btn margin-top-15\" block (click)=\"readTag();\">Get Product Information</ion-button> -->\r\n          <ion-button *ngIf=\"!hasLogin\" ion-button type=\"submit\" text-uppercase class=\"write-btn\" block\r\n            [routerLink]=\"['/login']\">Log In for better exprience.\r\n          </ion-button>\r\n\r\n          <ion-button *ngIf=\"hasLogin\" ion-button type=\"submit\" text-uppercase class=\"write-btn\" block\r\n            [routerLink]=\"['/verifyit-dashboard']\">Home\r\n\r\n          </ion-button>\r\n\r\n          <!-- <ion-button ion-button type=\"submit\"  text-uppercase class=\"write-btn\" block\r\n        [routerLink]=\"['/verifyit-dashboard']\">Home\r\n       </ion-button> -->\r\n\r\n        </ion-col>\r\n        <!-- <ion-button  ion-button type=\"submit\" text-uppercase class=\"write-btn\" block (click)=\"socialShare();\" >social share\r\n\r\n      </ion-button> -->\r\n      </ng-container>\r\n\r\n    </ion-row>\r\n  </section>\r\n<ion-footer>\r\n  <!--ion-toolbar>\r\n    <p><b> NFC Status:</b>&nbsp;{{ statusMessage }}</p>\r\n  </ion-toolbar-->\r\n</ion-footer>"

/***/ }),

/***/ "./src/app/Rentals Management/pages/verifyitProductinfo/verifyitProductinfo.page.scss":
/*!********************************************************************************************!*\
  !*** ./src/app/Rentals Management/pages/verifyitProductinfo/verifyitProductinfo.page.scss ***!
  \********************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "ion-button {\n  display: inline-flex;\n  justify-content: center; }\n\nion-list {\n  display: inline-flex;\n  justify-content: center; }\n\n.transparentBody {\n  background: transparent !important; }\n\n.product-image {\n  display: flex;\n  justify-content: center;\n  align-items: center;\n  width: 100%; }\n\n.product-image img {\n    height: 180px;\n    width: 180px; }\n\n.float-right {\n  text-align: right; }\n\n.product-label {\n  font-weight: 500; }\n\n.col-btn {\n  display: inline-flex;\n  justify-content: center;\n  align-items: center; }\n\n.instruction-label {\n  margin-top: 19px;\n  font-size: 23px;\n  text-transform: uppercase;\n  text-decoration: underline;\n  text-align: center;\n  margin-bottom: 0px; }\n\n.product-name {\n  margin-top: 19px;\n  font-size: 23px;\n  text-transform: uppercase;\n  text-align: center;\n  margin-bottom: -10px; }\n\n.instruction {\n  text-align: justify;\n  margin-left: 1vh;\n  margin-right: 1vh;\n  font-size: 13px; }\n\n.product-name {\n  margin-top: 19px;\n  font-size: 20px;\n  text-transform: uppercase;\n  text-decoration: underline;\n  text-align: center;\n  margin-bottom: 0px;\n  font-weight: 500; }\n\nabc {\n  --ion-background-color: #111d12; }\n\nsection {\n  min-height: 100%; }\n\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvUmVudGFscyBNYW5hZ2VtZW50L3BhZ2VzL3ZlcmlmeWl0UHJvZHVjdGluZm8vRDpcXG5hdmpvdFxcdmVyaWZ5L3NyY1xcYXBwXFxSZW50YWxzIE1hbmFnZW1lbnRcXHBhZ2VzXFx2ZXJpZnlpdFByb2R1Y3RpbmZvXFx2ZXJpZnlpdFByb2R1Y3RpbmZvLnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNFLG9CQUFvQjtFQUNwQix1QkFBdUIsRUFBQTs7QUFFekI7RUFDRSxvQkFBb0I7RUFDcEIsdUJBQXVCLEVBQUE7O0FBR3pCO0VBQ0Usa0NBQWtDLEVBQUE7O0FBR3BDO0VBQ0UsYUFBYTtFQUNYLHVCQUF1QjtFQUN2QixtQkFBbUI7RUFDbkIsV0FBVyxFQUFBOztBQUpmO0lBTU0sYUFBYTtJQUNiLFlBQVksRUFBQTs7QUFHbEI7RUFDRSxpQkFBaUIsRUFBQTs7QUFFbkI7RUFDRSxnQkFBZ0IsRUFBQTs7QUFFbEI7RUFDRSxvQkFBb0I7RUFDcEIsdUJBQXVCO0VBQ3ZCLG1CQUFtQixFQUFBOztBQUVyQjtFQUNFLGdCQUFnQjtFQUNoQixlQUFlO0VBQ2YseUJBQXlCO0VBQ3pCLDBCQUEwQjtFQUMxQixrQkFBa0I7RUFDbEIsa0JBQWtCLEVBQUE7O0FBRXBCO0VBQ0UsZ0JBQWdCO0VBQ2hCLGVBQWU7RUFDZix5QkFBeUI7RUFFekIsa0JBQWtCO0VBQ2xCLG9CQUFvQixFQUFBOztBQUl0QjtFQUVFLG1CQUFtQjtFQUNuQixnQkFBZ0I7RUFDaEIsaUJBQWlCO0VBQ2pCLGVBQWUsRUFBQTs7QUFJakI7RUFDRSxnQkFBZ0I7RUFDaEIsZUFBZTtFQUNmLHlCQUF5QjtFQUN6QiwwQkFBMEI7RUFDMUIsa0JBQWtCO0VBQ2xCLGtCQUFrQjtFQUNsQixnQkFBZ0IsRUFBQTs7QUFFbEI7RUFDRSwrQkFBdUIsRUFBQTs7QUFFekI7RUFDRSxnQkFBZ0IsRUFBQSIsImZpbGUiOiJzcmMvYXBwL1JlbnRhbHMgTWFuYWdlbWVudC9wYWdlcy92ZXJpZnlpdFByb2R1Y3RpbmZvL3ZlcmlmeWl0UHJvZHVjdGluZm8ucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiaW9uLWJ1dHRvbntcclxuICBkaXNwbGF5OiBpbmxpbmUtZmxleDtcclxuICBqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlcjtcclxufVxyXG5pb24tbGlzdHtcclxuICBkaXNwbGF5OiBpbmxpbmUtZmxleDtcclxuICBqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlcjtcclxufVxyXG5cclxuLnRyYW5zcGFyZW50Qm9keSB7XHJcbiAgYmFja2dyb3VuZDogdHJhbnNwYXJlbnQgIWltcG9ydGFudDtcclxufVxyXG5cclxuLnByb2R1Y3QtaW1hZ2V7XHJcbiAgZGlzcGxheTogZmxleDtcclxuICAgIGp1c3RpZnktY29udGVudDogY2VudGVyO1xyXG4gICAgYWxpZ24taXRlbXM6IGNlbnRlcjtcclxuICAgIHdpZHRoOiAxMDAlO1xyXG4gICAgaW1ne1xyXG4gICAgICBoZWlnaHQ6IDE4MHB4O1xyXG4gICAgICB3aWR0aDogMTgwcHg7XHJcbiAgICB9XHJcbn1cclxuLmZsb2F0LXJpZ2h0e1xyXG4gIHRleHQtYWxpZ246IHJpZ2h0O1xyXG59XHJcbi5wcm9kdWN0LWxhYmVse1xyXG4gIGZvbnQtd2VpZ2h0OiA1MDA7XHJcbn1cclxuLmNvbC1idG57XHJcbiAgZGlzcGxheTogaW5saW5lLWZsZXg7XHJcbiAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XHJcbiAgYWxpZ24taXRlbXM6IGNlbnRlcjtcclxufVxyXG4uaW5zdHJ1Y3Rpb24tbGFiZWx7XHJcbiAgbWFyZ2luLXRvcDogMTlweDtcclxuICBmb250LXNpemU6IDIzcHg7XHJcbiAgdGV4dC10cmFuc2Zvcm06IHVwcGVyY2FzZTtcclxuICB0ZXh0LWRlY29yYXRpb246IHVuZGVybGluZTtcclxuICB0ZXh0LWFsaWduOiBjZW50ZXI7XHJcbiAgbWFyZ2luLWJvdHRvbTogMHB4O1xyXG59XHJcbi5wcm9kdWN0LW5hbWV7XHJcbiAgbWFyZ2luLXRvcDogMTlweDtcclxuICBmb250LXNpemU6IDIzcHg7XHJcbiAgdGV4dC10cmFuc2Zvcm06IHVwcGVyY2FzZTtcclxuICAvLyB0ZXh0LWRlY29yYXRpb246IHVuZGVybGluZTtcclxuICB0ZXh0LWFsaWduOiBjZW50ZXI7XHJcbiAgbWFyZ2luLWJvdHRvbTogLTEwcHg7XHJcbn1cclxuXHJcblxyXG4uaW5zdHJ1Y3Rpb257XHJcblxyXG4gIHRleHQtYWxpZ246IGp1c3RpZnk7XHJcbiAgbWFyZ2luLWxlZnQ6IDF2aDtcclxuICBtYXJnaW4tcmlnaHQ6IDF2aDtcclxuICBmb250LXNpemU6IDEzcHg7XHJcbn1cclxuXHJcblxyXG4ucHJvZHVjdC1uYW1le1xyXG4gIG1hcmdpbi10b3A6IDE5cHg7XHJcbiAgZm9udC1zaXplOiAyMHB4O1xyXG4gIHRleHQtdHJhbnNmb3JtOiB1cHBlcmNhc2U7XHJcbiAgdGV4dC1kZWNvcmF0aW9uOiB1bmRlcmxpbmU7XHJcbiAgdGV4dC1hbGlnbjogY2VudGVyO1xyXG4gIG1hcmdpbi1ib3R0b206IDBweDtcclxuICBmb250LXdlaWdodDogNTAwO1xyXG59XHJcbmFiYyB7XHJcbiAgLS1pb24tYmFja2dyb3VuZC1jb2xvcjogIzExMWQxMjtcclxufVxyXG5zZWN0aW9ue1xyXG4gIG1pbi1oZWlnaHQ6IDEwMCU7XHJcbn0iXX0= */"

/***/ }),

/***/ "./src/app/Rentals Management/pages/verifyitProductinfo/verifyitProductinfo.page.ts":
/*!******************************************************************************************!*\
  !*** ./src/app/Rentals Management/pages/verifyitProductinfo/verifyitProductinfo.page.ts ***!
  \******************************************************************************************/
/*! exports provided: VerifyitProductInfoPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "VerifyitProductInfoPage", function() { return VerifyitProductInfoPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _ionic_native_nfc_ngx__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ionic-native/nfc/ngx */ "./node_modules/@ionic-native/nfc/ngx/index.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _services_naila_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../services/naila.service */ "./src/app/Rentals Management/services/naila.service.ts");
/* harmony import */ var _ionic_native_qr_scanner_ngx__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic-native/qr-scanner/ngx */ "./node_modules/@ionic-native/qr-scanner/ngx/index.js");
/* harmony import */ var _services_utils_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../../services/utils.service */ "./src/app/Rentals Management/services/utils.service.ts");
/* harmony import */ var src_app_common_services_alert_service_service__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! src/app/common-services/alert-service.service */ "./src/app/common-services/alert-service.service.ts");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _ionic_native_social_sharing_ngx__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @ionic-native/social-sharing/ngx */ "./node_modules/@ionic-native/social-sharing/ngx/index.js");
/* harmony import */ var _modals_tellusifyoubuyit_tellusifyoubuyit_component__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ../../modals/tellusifyoubuyit/tellusifyoubuyit.component */ "./src/app/Rentals Management/modals/tellusifyoubuyit/tellusifyoubuyit.component.ts");
/* harmony import */ var _modals_certificatemodal_certificatemodal_component__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ../../modals/certificatemodal/certificatemodal.component */ "./src/app/Rentals Management/modals/certificatemodal/certificatemodal.component.ts");
/* harmony import */ var _ionic_native_in_app_browser_ngx__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! @ionic-native/in-app-browser/ngx */ "./node_modules/@ionic-native/in-app-browser/ngx/index.js");














var VerifyitProductInfoPage = /** @class */ (function () {
    function VerifyitProductInfoPage(nfc, ndef, platform, iab, ngZone, socialSharing, qrScanner, utilservice, alertService, router, alertController, apiSvc, modalController, actionSheetController) {
        var _this_1 = this;
        this.nfc = nfc;
        this.ndef = ndef;
        this.platform = platform;
        this.iab = iab;
        this.ngZone = ngZone;
        this.socialSharing = socialSharing;
        this.qrScanner = qrScanner;
        this.utilservice = utilservice;
        this.alertService = alertService;
        this.router = router;
        this.alertController = alertController;
        this.apiSvc = apiSvc;
        this.modalController = modalController;
        this.actionSheetController = actionSheetController;
        this.cred = {
            tagId: null,
            verified: null,
            product_name: null,
            manufactured: null,
            model_number: null,
            serial_number: null,
            brand: null,
            img: {
                default: {
                    main: null
                }
            },
            product_details: {
                water_resistant: null,
                display_type: null,
                series: null,
                occassion: null,
                strap: null
            },
            how_to_use_it: { english: null, spanish: null, portugues: null }
        };
        this.trackingData = {
            user_id: '',
            tag_id: '',
            product_id: '',
            device_id: '',
        };
        this.credKeys = {
            key12: null,
            key1: null,
            key2: null,
            key3: null,
            key4: null,
            key5: null,
            key6: null,
            key7: null,
            key8: null,
            key9: null,
            key10: null,
            key11: null,
            key13: null
        };
        this.canNFC = false;
        this.jsonToBeUsed = [];
        // trying
        this.callgettagresult = {
            product_name: "",
            brand: "",
            product_id: ''
        };
        this.readingTag = false;
        this.writingTag = false;
        this.isWriting = false;
        this.writtenInput = "";
        this.subscriptions = new Array();
        // ionViewDidLoad() {
        //   debugger
        //   this.platform.ready().then(() => {
        //     this.nfc.enabled().then((resolve) => {
        //       this.canNFC = true;
        //       this.setStatus('NFC Compatable.');
        //       this.tagListenerSuccess();
        //     }).catch((reject) => {
        //       this.canNFC = false;
        //       this.alertService.presentAlert('',JSON.stringify("NFC is not supported by your Device"));
        //       this.setStatus('NFC Not Compatable.');
        //     });
        //   });
        // }
        this.res = {};
        this.options = {
            hidden: 'no',
            // clearcache : 'yes',
            // clearsessioncache : 'yes',
            // zoom : 'yes',//Android only ,shows browser zoom controls 
            hardwareback: 'yes',
            mediaPlaybackRequiresUserAction: 'no',
            shouldPauseOnSuspend: 'no',
            closebuttoncaption: 'Close',
            // toolbar : 'yes', //iOS only 
            // enableViewportScale : 'yes', //iOS only 
            allowInlineMediaPlayback: 'no',
            // disallowoverscroll : 'no', //iOS only 
            presentationstyle: 'fullscreen',
            fullscreen: 'no',
            hideurlbar: 'yes',
            toolbar: 'yes',
            location: 'no',
            hidenavigationbuttons: 'yes',
            zoom: 'no'
        };
        this.product_title = this.callgettagresult.product_name;
        this.brand = this.callgettagresult.brand;
        this.product_link = "";
        this.hasLogin = window.localStorage.getItem("name");
        // alert('=================='+this.hasLogin)
        // this.ionViewDidLoad()
        this.callgettagresult = this.utilservice.callgettagresult;
        // this.callgettagresult  =  JSON.parse(this.callgettagresult)
        console.log(this.callgettagresult);
        if (this.utilservice.callgettagresult.meta_data) {
            // this.callgettagresult= this.callgettagresult
            Object.keys(this.utilservice.callgettagresult.meta_data).forEach(function (e) {
                return _this_1.jsonToBeUsed.push({
                    key: e,
                    value: _this_1.utilservice.callgettagresult.meta_data[e]
                });
            });
        }
        else {
        }
        //   for (var type in this.callgettagresult) {
        //    let item = {
        //     key: '',
        //     value: ''
        //    };
        //     item.key = type;
        //     item.value = this.callgettagresult[type];
        //     this.jsonToBeUsed.push(item);
        // }
        console.log(this.jsonToBeUsed);
        this.credKeys.key1 = "Product Name";
        this.credKeys.key2 = "Model Number";
        this.credKeys.key3 = "Serial Number";
        this.credKeys.key4 = "Brand";
        this.credKeys.key5 = "Water Resistant";
        this.credKeys.key6 = "Display Type";
        this.credKeys.key7 = "Series";
        this.credKeys.key8 = "Occassion";
        this.credKeys.key9 = "Strap";
        this.credKeys.key10 = "Manufactured";
        this.credKeys.key11 = "Instructions";
        this.credKeys.key12 = "Wine Information";
        this.credKeys.key13 = "Verified";
        this.jsonToBeUsed.forEach(function (element) {
            if (element.key == "brand_color") {
                _this_1.brand_color = element.value;
            }
        });
    }
    // tagListenerSuccess() {
    //   this.subscriptions.push(this.nfc.addNdefListener()
    //     .subscribe(data => {
    //       if (this.readingTag) {
    //         let payload = data.tag.ndefMessage[0].payload;
    //         let tagId = this.nfc.bytesToString(payload).substring(3);
    //         this.readingTag = false;
    //         this.apiSvc.callGetTag(tagId).subscribe((res) => {
    //           this.res = res
    //           this.cred.product_name = this.res.product_name;
    //           this.alertService.presentAlert('',this.cred.product_name)
    //           this.cred.verified = this.res.verified;
    //           this.cred.tagId = tagId;
    //           // this.apiSvc.callRecordScan(tagId).subscribe((res) => {
    //           // });
    //           this.cred.model_number = this.res.model_number;
    //           this.cred.serial_number = this.res.serial_number;
    //           this.cred.brand = this.res.brand;
    //           this.cred.img = this.res.img;
    //           this.cred.product_details = this.res.product_details;
    //           this.cred.how_to_use_it = this.res.how_to_use_it;
    //           this.cred.manufactured = this.res.manufactured;
    //           this.credKeys.key1 = "Product Name";
    //           this.credKeys.key2 = "Model Number";
    //           this.credKeys.key3 = "Serial Number";
    //           this.credKeys.key4 = "Brand";
    //           this.credKeys.key5 = "Water Resistant";
    //           this.credKeys.key6 = "Display Type";
    //           this.credKeys.key7 = "Series";
    //           this.credKeys.key8 = "Occassion";
    //           this.credKeys.key9 = "Strap";
    //           this.credKeys.key10 = "Manufactured";
    //           this.credKeys.key11 = "Instructions";
    //           this.credKeys.key12 = "Wine Information";
    //           this.credKeys.key13 = "Verified";
    //           // this.helperSvc.hideLoading();
    //         });
    //       }
    //     },
    //       err => {
    //       })
    //   );
    // }
    VerifyitProductInfoPage.prototype.setStatus = function (message) {
        var _this_1 = this;
        this.alertService.presentAlert("", message);
        this.ngZone.run(function () {
            _this_1.statusMessage = message;
        });
    };
    VerifyitProductInfoPage.prototype.presentAlertBoughtIt = function () {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function () {
            var alert;
            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.alertController.create({
                            cssClass: "my-custom-class",
                            inputs: [
                                {
                                    name: "Mobile",
                                    type: "tel",
                                    min: -5,
                                    max: 10
                                }
                            ],
                            buttons: [
                                {
                                    text: "Cancel",
                                    role: "cancel",
                                    cssClass: "secondary",
                                    handler: function () {
                                        console.log("Confirm Cancel");
                                    }
                                },
                                {
                                    text: "Ok",
                                    handler: function (alertData) {
                                        //takes the data
                                        console.log(alertData.Mobile);
                                    }
                                }
                            ]
                        })];
                    case 1:
                        alert = _a.sent();
                        return [4 /*yield*/, alert.present()];
                    case 2:
                        _a.sent();
                        return [2 /*return*/];
                }
            });
        });
    };
    VerifyitProductInfoPage.prototype.showCatalog = function (id) {
        this.utilservice.productId = id;
        this.router.navigateByUrl("/verifyit-product-catalog");
    };
    // readTag() {
    //   if (this.canNFC) {
    //     setTimeout(() => {
    //       this.alertService.presentAlert('','Connecting with Server.....');
    //       this.readingTag = true;
    //       this.tagListenerSuccess();
    //     }, 100);
    //   } else {
    //     this.alertService.presentAlert('','NFC is not supported by your Device');
    //   }
    // }
    // boughtIt(tagId){
    //       this.apiSvc.callPostBoughtIt(tagId).subscribe((res) => {
    //         this.alertService.presentAlert('',res);
    //         // this.helperSvc.hideLoading();
    //   });
    //   // this.navCtrl.push(ThankyouPage,{})
    //   this.alertService.presentAlert('','thank you')
    // }
    VerifyitProductInfoPage.prototype.ionViewWillLeave = function () {
        this.subscriptions.forEach(function (sub) {
            sub.unsubscribe();
        });
    };
    // scanqrcode() {
    //   var context = this;
    //   // Optionally request the permission early
    //   this.qrScanner.prepare()
    //     .then((status: QRScannerStatus) => {
    //       if (status.authorized) {
    //         // camera permission was granted
    //         this.alertService.presentAlert('',"scanning");
    //         var ionApp = <HTMLElement>document.getElementsByTagName("ion-app")[0];
    //         // start scanning
    //         let scanSub = this.qrScanner.scan().subscribe((scannedAddress: string) => {
    //           this.alertService.presentAlert('',scannedAddress);
    //           // this.friendAddress = scannedAddress;
    //           this.qrScanner.hide(); // hide camera preview
    //           scanSub.unsubscribe(); // stop scanning
    //           ionApp.style.display = "block";
    //           // this.friendAddressInput.setFocus();
    //         });
    //         // show camera preview
    //         ionApp.style.display = "none";
    //         context.qrScanner.show();
    //         // setTimeout(() => {
    //         //   ionApp.style.display = "block";
    //         //   scanSub.unsubscribe(); // stop scanning
    //         //   // context.friendAddressInput.setFocus();
    //         //   context.qrScanner.hide();
    //         // }, 500000);
    //         // wait for user to scan something, then the observable callback will be called
    //       } else if (status.denied) {
    //         this.alertService.presentAlert('',"Denied permission to access camera");
    //       } else {
    //         this.alertService.presentAlert('',"Something else is happening with the camera");
    //       }
    //     })
    //     .catch((e: any) => console.log('Error is', e));
    // }
    VerifyitProductInfoPage.prototype.boughtIt = function (tagId) {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function () {
            var _this_1 = this;
            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                this.apiSvc.callPostBoughtIt(tagId).subscribe(function (res) {
                    console.log(res);
                    _this_1.alertService.presentAlert("", "Thank you so much for letting us know about your purchase. We wish you a great buying experience.");
                    _this_1.router.navigateByUrl("/");
                    // this.helperSvc.hideLoading();
                });
                return [2 /*return*/];
            });
        });
    };
    VerifyitProductInfoPage.prototype.showCertificates = function (data) {
        this.utilservice.certificateData = data;
        // alert(JSON.stringify(data))
        this.presentModal();
        debugger;
    };
    VerifyitProductInfoPage.prototype.presentModal = function () {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function () {
            var modal;
            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.modalController.create({
                            component: _modals_certificatemodal_certificatemodal_component__WEBPACK_IMPORTED_MODULE_11__["CertificateModalComponent"]
                        })];
                    case 1:
                        modal = _a.sent();
                        return [4 /*yield*/, modal.present()];
                    case 2: return [2 /*return*/, _a.sent()];
                }
            });
        });
    };
    VerifyitProductInfoPage.prototype.presentActionSheet = function (data) {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function () {
            var buttons, _this, actionSheet;
            var _this_1 = this;
            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                switch (_a.label) {
                    case 0:
                        buttons = [];
                        _this = this;
                        data.forEach(function (element) {
                            var button = {
                                text: element.text,
                                // icon:data.icon,
                                handler: function () {
                                    // console.log('setting icon ' + this.data.icon);
                                    // const browser = this.iab.create(element.link);
                                    _this_1.browser = _this_1.iab.create(element.link, "_blank", _this_1.options);
                                    _this_1.browser.on("loadstart").subscribe(function (event) {
                                        setInterval(function () {
                                            if (event.url.includes("thankyou")) {
                                                //   setInterval(function(){ 
                                                //     //this code runs every second 
                                                // }, 1000);
                                                // await this.ngZone.run(() => this.navigateTomsgPage());
                                                // alert('purchaseproductreview')
                                                // this.router.navigateByUrl("/verifyit-message");
                                                // this.routemessage='purchaseproductreview'
                                                try {
                                                    _this.routemessage = "thankyou";
                                                    _this.browser.close();
                                                }
                                                catch (error) {
                                                    alert(error);
                                                }
                                            }
                                        }, 2000);
                                    });
                                    _this_1.browser.on("exit").subscribe(function (data) { return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](_this_1, void 0, void 0, function () {
                                        return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                                            debugger;
                                            if (_this.routemessage == 'thankyou') {
                                                _this.trackingData.user_id = window.localStorage.getItem('userid');
                                                _this.trackingData.tag_id = window.localStorage.getItem('tagId');
                                                _this.trackingData.product_id = this.callgettagresult.product_id;
                                                _this.trackingData.device_id = "xxx";
                                                this.apiSvc.reviewTracking(_this.trackingData).subscribe(function (res) {
                                                }, function (err) {
                                                    alert(JSON.stringify(err));
                                                });
                                                // _this.router.navigateByUrl('/verifyit-message')
                                            }
                                            else {
                                                // _this.router.navigateByUrl('/verifyit-account')
                                                // alert('Review not submitted.')
                                            }
                                            return [2 /*return*/];
                                        });
                                    }); }, function (err) {
                                        // alert(err);
                                    });
                                    return true;
                                }
                            };
                            buttons.push(button);
                        });
                        return [4 /*yield*/, this.actionSheetController.create({
                                header: "Useful Links",
                                cssClass: "my-custom-class",
                                buttons: buttons
                            })];
                    case 1:
                        actionSheet = _a.sent();
                        return [4 /*yield*/, actionSheet.present()];
                    case 2:
                        _a.sent();
                        return [2 /*return*/];
                }
            });
        });
    };
    VerifyitProductInfoPage.prototype.thankyouRedirect = function () {
        this.browser.close();
        this.router.navigateByUrl("/verifyit-message");
    };
    // createButtons(data) {
    //   let buttons = [];
    //   for (var index in data) {
    //     let button = {
    //       text: data.text,
    //       // icon:data.icon,
    //       handler: () => {
    //         // console.log('setting icon ' + this.data.icon);
    //         return true;
    //       }
    //     }
    //     buttons.push(button);
    //   }
    //   return buttons;
    // }
    VerifyitProductInfoPage.prototype.presentModal2 = function () {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function () {
            var modal;
            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.modalController.create({
                            component: _modals_tellusifyoubuyit_tellusifyoubuyit_component__WEBPACK_IMPORTED_MODULE_10__["TellUsifyouBuyitComponent"]
                        })];
                    case 1:
                        modal = _a.sent();
                        return [4 /*yield*/, modal.present()];
                    case 2: return [2 /*return*/, _a.sent()];
                }
            });
        });
    };
    VerifyitProductInfoPage.prototype.socialShare = function () {
        var _this_1 = this;
        // console.log('kkkkkkk=================',this.brand_color)
        this.jsonToBeUsed.forEach(function (element) {
            if (element.key == "purchase online") {
                console.log(element);
                _this_1.product_link = element.value[0].link;
            }
        });
        this.product_title = this.callgettagresult.product_name;
        this.brand = this.callgettagresult.brand;
        // this.product_link= this.product_link;
        this.socialSharing
            .share("Hey, Checkout" +
            " " +
            this.product_title +
            " from " +
            this.brand +
            "." +
            "\n", "", "", this.product_link)
            .then(function () {
            console.log("===============shared================== to whatsapp========");
        })
            .catch(function () {
            console.log("===============shared===========not======= to whatsapp========");
        });
    };
    VerifyitProductInfoPage.prototype.navigateTomsgPage = function () {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function () {
            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                this.router.navigateByUrl('/verifyit-message');
                return [2 /*return*/];
            });
        });
    };
    VerifyitProductInfoPage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: "app-verifyitProductinfo",
            template: __webpack_require__(/*! ./verifyitProductinfo.page.html */ "./src/app/Rentals Management/pages/verifyitProductinfo/verifyitProductinfo.page.html"),
            styles: [__webpack_require__(/*! ./verifyitProductinfo.page.scss */ "./src/app/Rentals Management/pages/verifyitProductinfo/verifyitProductinfo.page.scss")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_ionic_native_nfc_ngx__WEBPACK_IMPORTED_MODULE_2__["NFC"],
            _ionic_native_nfc_ngx__WEBPACK_IMPORTED_MODULE_2__["Ndef"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["Platform"],
            _ionic_native_in_app_browser_ngx__WEBPACK_IMPORTED_MODULE_12__["InAppBrowser"],
            _angular_core__WEBPACK_IMPORTED_MODULE_1__["NgZone"],
            _ionic_native_social_sharing_ngx__WEBPACK_IMPORTED_MODULE_9__["SocialSharing"],
            _ionic_native_qr_scanner_ngx__WEBPACK_IMPORTED_MODULE_5__["QRScanner"],
            _services_utils_service__WEBPACK_IMPORTED_MODULE_6__["Utils"],
            src_app_common_services_alert_service_service__WEBPACK_IMPORTED_MODULE_7__["AlertServiceService"],
            _angular_router__WEBPACK_IMPORTED_MODULE_8__["Router"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["AlertController"],
            _services_naila_service__WEBPACK_IMPORTED_MODULE_4__["NailaService"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["ModalController"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["ActionSheetController"]])
    ], VerifyitProductInfoPage);
    return VerifyitProductInfoPage;
}());



/***/ })

}]);
//# sourceMappingURL=Rentals-Management-pages-verifyitProductinfo-verifyitProductinfo-module.js.map