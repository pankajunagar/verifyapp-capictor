(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["Rentals-Management-pages-estimate-estimate-module"],{

/***/ "./src/app/Rentals Management/pages/estimate/estimate.module.ts":
/*!**********************************************************************!*\
  !*** ./src/app/Rentals Management/pages/estimate/estimate.module.ts ***!
  \**********************************************************************/
/*! exports provided: EstimatePageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "EstimatePageModule", function() { return EstimatePageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _estimate_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./estimate.page */ "./src/app/Rentals Management/pages/estimate/estimate.page.ts");







var routes = [
    {
        path: '',
        component: _estimate_page__WEBPACK_IMPORTED_MODULE_6__["EstimatePage"]
    }
];
var EstimatePageModule = /** @class */ (function () {
    function EstimatePageModule() {
    }
    EstimatePageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            imports: [
                _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
                _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["IonicModule"],
                _angular_router__WEBPACK_IMPORTED_MODULE_4__["RouterModule"].forChild(routes)
            ],
            declarations: [_estimate_page__WEBPACK_IMPORTED_MODULE_6__["EstimatePage"]]
        })
    ], EstimatePageModule);
    return EstimatePageModule;
}());



/***/ }),

/***/ "./src/app/Rentals Management/pages/estimate/estimate.page.html":
/*!**********************************************************************!*\
  !*** ./src/app/Rentals Management/pages/estimate/estimate.page.html ***!
  \**********************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ion-header>\r\n  <ion-toolbar color=\"primary\">\r\n    <ion-buttons slot=\"start\">\r\n      <ion-back-button defaultHref=\"/rentals-home\" class=\"font-weight-600 font-20\"></ion-back-button>\r\n    </ion-buttons>\r\n    <ion-title class=\"font-weight-600 font-20\">Estimate</ion-title>\r\n\r\n  </ion-toolbar>\r\n</ion-header>\r\n\r\n<ion-content class=\"grey-back \">\r\n  <div class=\"full-width grey-back max-available-height\">\r\n    <div class=\"margin-padding-zero bg-img-overlay-paymentdetails\">\r\n      <ion-row class=\"\">\r\n        <ion-col class=\" txt-white padding-left-10\">\r\n          Estimate ID # {{estimate.referenceNumber}}\r\n        </ion-col>\r\n        <ion-col class=\" txt-white txt-align-right padding-right-10 \" style=\"text-transform: capitalize\">\r\n          <!-- <button class=\"button button-small\"> -->\r\n          <ion-badge color=\"light\" mode=\"md\" color=\"warning\">\r\n            <ion-label>{{estimate.status}} </ion-label>\r\n          </ion-badge>\r\n          <!-- </button> -->\r\n        </ion-col>\r\n      </ion-row>\r\n      <ion-row class=\"padding-24\">\r\n        <ion-col class=\"center-text margin-top-10\">\r\n          <p class=\" txt-white center-text font-25 margin-0\">\r\n            Rs. {{estimate.totalAmount|currency:'INR'}} </p>,\r\n          <p class=\" center-text margin-top-minus-10  margin-bottom-10 txt-white font-12 \">\r\n            Raised on :- {{estimate.createdAt | date:'dd MMM yyyy'}} </p>\r\n          <p class=\" txt-white txt-small margin-top-0 margin-bottom-10 \"> {{estimate.status}} :-\r\n            {{estimate.estimateBelongsTo}} </p>\r\n\r\n        </ion-col>\r\n      </ion-row>\r\n    </div>\r\n    <ion-list class=\"padding-bottom-0\">\r\n      <ion-item lines=\"full\">\r\n        <ion-grid>\r\n          <ion-row>\r\n            <ion-col size=\"6\" class=\"padding-left-10\">ITEM</ion-col>\r\n            <ion-col size=\"3\">\r\n              PRICE\r\n            </ion-col>\r\n            <ion-col size=\"3\">\r\n              TAX\r\n            </ion-col>\r\n          </ion-row>\r\n        </ion-grid>\r\n      </ion-item>\r\n\r\n    </ion-list>\r\n    <ion-list class=\"padding-top-0\">\r\n      <ion-item lines=\"full\" *ngFor=\"let data of estimate.itemDetails\">\r\n        <ion-grid>\r\n          <ion-row class=\"padding-0\">\r\n            <ion-col size=\"6\">\r\n              <p class=\" font-12 margin-top-5 margin-bottom-5\">Amazon basics Mesh dustbin</p>\r\n            </ion-col>\r\n            <ion-col size=\"3\">\r\n              <p class=\" font-12 margin-top-5 margin-bottom-5\">Rs. {{data.amount | currency:'INR'}}</p>\r\n            </ion-col>\r\n            <ion-col size=\"3\">\r\n              <p class=\" font-12 margin-top-5 margin-bottom-5\">Rs. {{data.taxAmount | currency:'INR'}}</p>\r\n            </ion-col>\r\n          </ion-row>\r\n        </ion-grid>\r\n      </ion-item>\r\n      <ion-item lines=\"none\">\r\n        <ion-grid>\r\n          <ion-row>\r\n            <ion-col size=\"6\">\r\n              <p class=\" font-12 margin-top-bottom-5\"></p>\r\n            </ion-col>\r\n            <ion-col size=\"3\">\r\n              <p class=\" font-12 margin-top-bottom-5\">TOTAL</p>\r\n            </ion-col>\r\n            <ion-col size=\"3\">\r\n              <p class=\"gotham font-12 margin-top-bottom-5\">Rs. 14,00</p>\r\n            </ion-col>\r\n          </ion-row>\r\n        </ion-grid>\r\n      </ion-item>\r\n    </ion-list>\r\n  </div>\r\n\r\n</ion-content>"

/***/ }),

/***/ "./src/app/Rentals Management/pages/estimate/estimate.page.scss":
/*!**********************************************************************!*\
  !*** ./src/app/Rentals Management/pages/estimate/estimate.page.scss ***!
  \**********************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ".bg-img-overlay-paymentdetails {\n  border-top: none !important;\n  background-image: url(\"/assets/bedroom3.png\");\n  background-repeat: no-repeat;\n  background-size: 100%;\n  position: relative;\n  box-shadow: inset 0 0 0 1000px rgba(0, 0, 0, 0.7); }\n\nion-content {\n  --ion-background-color: #ecebe6; }\n\nion-item {\n  --inner-padding-end: 0px;\n  --inner-padding-start: 0px;\n  --padding-end: 0px;\n  --padding-start: 0px; }\n\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvUmVudGFscyBNYW5hZ2VtZW50L3BhZ2VzL2VzdGltYXRlL0Q6XFxuYXZqb3RcXHZlcmlmeS9zcmNcXGFwcFxcUmVudGFscyBNYW5hZ2VtZW50XFxwYWdlc1xcZXN0aW1hdGVcXGVzdGltYXRlLnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNJLDJCQUEyQjtFQUMzQiw2Q0FBNkM7RUFDN0MsNEJBQTRCO0VBQzVCLHFCQUFxQjtFQUNyQixrQkFBa0I7RUFDbEIsaURBQWlELEVBQUE7O0FBRW5EO0VBQ0UsK0JBQXVCLEVBQUE7O0FBRXpCO0VBQ0Usd0JBQW9CO0VBQ3BCLDBCQUFzQjtFQUN0QixrQkFBYztFQUNkLG9CQUFnQixFQUFBIiwiZmlsZSI6InNyYy9hcHAvUmVudGFscyBNYW5hZ2VtZW50L3BhZ2VzL2VzdGltYXRlL2VzdGltYXRlLnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIi5iZy1pbWctb3ZlcmxheS1wYXltZW50ZGV0YWlscyB7XHJcbiAgICBib3JkZXItdG9wOiBub25lICFpbXBvcnRhbnQ7XHJcbiAgICBiYWNrZ3JvdW5kLWltYWdlOiB1cmwoXCIvYXNzZXRzL2JlZHJvb20zLnBuZ1wiKTtcclxuICAgIGJhY2tncm91bmQtcmVwZWF0OiBuby1yZXBlYXQ7XHJcbiAgICBiYWNrZ3JvdW5kLXNpemU6IDEwMCU7XHJcbiAgICBwb3NpdGlvbjogcmVsYXRpdmU7XHJcbiAgICBib3gtc2hhZG93OiBpbnNldCAwIDAgMCAxMDAwcHggcmdiYSgwLCAwLCAwLCAwLjcpO1xyXG4gIH1cclxuICBpb24tY29udGVudCB7XHJcbiAgICAtLWlvbi1iYWNrZ3JvdW5kLWNvbG9yOiAjZWNlYmU2O1xyXG4gIH1cclxuICBpb24taXRlbSB7XHJcbiAgICAtLWlubmVyLXBhZGRpbmctZW5kOiAwcHg7XHJcbiAgICAtLWlubmVyLXBhZGRpbmctc3RhcnQ6IDBweDtcclxuICAgIC0tcGFkZGluZy1lbmQ6IDBweDtcclxuICAgIC0tcGFkZGluZy1zdGFydDogMHB4O1xyXG4gIH1cclxuICAiXX0= */"

/***/ }),

/***/ "./src/app/Rentals Management/pages/estimate/estimate.page.ts":
/*!********************************************************************!*\
  !*** ./src/app/Rentals Management/pages/estimate/estimate.page.ts ***!
  \********************************************************************/
/*! exports provided: EstimatePage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "EstimatePage", function() { return EstimatePage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var src_app_common_services_alert_service_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/common-services/alert-service.service */ "./src/app/common-services/alert-service.service.ts");
/* harmony import */ var _services_estimate_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../services/estimate.service */ "./src/app/Rentals Management/services/estimate.service.ts");






var EstimatePage = /** @class */ (function () {
    function EstimatePage(route, estimateService, alertService, loadingCtrl) {
        var _this = this;
        this.route = route;
        this.estimateService = estimateService;
        this.alertService = alertService;
        this.loadingCtrl = loadingCtrl;
        this.estimate = {};
        this.estimateToBeUpdated = {};
        this.route.queryParamMap.subscribe(function (params) {
            _this.presentLoading();
            _this.getEstimateById(params.params.estimateId);
        });
    }
    EstimatePage.prototype.ngOnInit = function () {
    };
    EstimatePage.prototype.presentLoading = function () {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function () {
            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.loadingCtrl.create({
                            spinner: 'lines'
                        }).then(function (loading) {
                            loading.present();
                        })];
                    case 1:
                        _a.sent();
                        return [2 /*return*/];
                }
            });
        });
    };
    EstimatePage.prototype.getEstimateById = function (id) {
        var _this = this;
        this.estimateService.getEstimateById(id).subscribe(function (data) {
            console.log(data);
            _this.estimate = data;
            _this.loadingCtrl.dismiss();
        }, function (err) {
            _this.alertService.presentAlert('Error', JSON.stringify(err));
        });
    };
    EstimatePage.prototype.updateEstimate = function () {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function () {
            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                this.estimateToBeUpdated = Object.assign({}, this.estimate);
                this.estimateService.updateEstimate(this.estimateToBeUpdated).subscribe(function (data) {
                    console.log(data);
                });
                return [2 /*return*/];
            });
        });
    };
    EstimatePage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_2__["Component"])({
            selector: 'app-estimate',
            template: __webpack_require__(/*! ./estimate.page.html */ "./src/app/Rentals Management/pages/estimate/estimate.page.html"),
            styles: [__webpack_require__(/*! ./estimate.page.scss */ "./src/app/Rentals Management/pages/estimate/estimate.page.scss")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_router__WEBPACK_IMPORTED_MODULE_3__["ActivatedRoute"],
            _services_estimate_service__WEBPACK_IMPORTED_MODULE_5__["EstimateService"],
            src_app_common_services_alert_service_service__WEBPACK_IMPORTED_MODULE_4__["AlertServiceService"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_1__["LoadingController"]])
    ], EstimatePage);
    return EstimatePage;
}());



/***/ }),

/***/ "./src/app/Rentals Management/services/estimate.service.ts":
/*!*****************************************************************!*\
  !*** ./src/app/Rentals Management/services/estimate.service.ts ***!
  \*****************************************************************/
/*! exports provided: EstimateService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "EstimateService", function() { return EstimateService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/fesm5/http.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var src_app_conatants_MainAppSetting__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/conatants/MainAppSetting */ "./src/app/conatants/MainAppSetting.ts");




var EstimateService = /** @class */ (function () {
    function EstimateService(http, appSettings) {
        this.http = http;
        this.appSettings = appSettings;
    }
    EstimateService.prototype.getEstimateById = function (id) {
        return this.http.get(this.appSettings.getApi() + "/api/estimate/" + id + "?populate=statusChangedBy", {
            headers: new _angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpHeaders"]({
                'Content-Type': 'application/json',
                Authorization: localStorage.getItem('token')
            })
        });
    };
    EstimateService.prototype.updateEstimate = function (data) {
        return this.http.post(this.appSettings.getApi() + "/api/estimate/" + data._id, data, {
            headers: new _angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpHeaders"]({
                'Content-Type': 'application/json',
                Authorization: localStorage.getItem('token')
            })
        });
    };
    EstimateService = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_2__["Injectable"])({
            providedIn: 'root'
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpClient"],
            src_app_conatants_MainAppSetting__WEBPACK_IMPORTED_MODULE_3__["MainAppSetting"]])
    ], EstimateService);
    return EstimateService;
}());



/***/ })

}]);
//# sourceMappingURL=Rentals-Management-pages-estimate-estimate-module.js.map