(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["Rentals-Management-pages-contact-us-contact-us-module"],{

/***/ "./src/app/Rentals Management/pages/contact-us/contact-us.module.ts":
/*!**************************************************************************!*\
  !*** ./src/app/Rentals Management/pages/contact-us/contact-us.module.ts ***!
  \**************************************************************************/
/*! exports provided: ContactUsPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ContactUsPageModule", function() { return ContactUsPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _contact_us_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./contact-us.page */ "./src/app/Rentals Management/pages/contact-us/contact-us.page.ts");







var routes = [
    {
        path: '',
        component: _contact_us_page__WEBPACK_IMPORTED_MODULE_6__["ContactUsPage"]
    }
];
var ContactUsPageModule = /** @class */ (function () {
    function ContactUsPageModule() {
    }
    ContactUsPageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            imports: [
                _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
                _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["IonicModule"],
                _angular_router__WEBPACK_IMPORTED_MODULE_4__["RouterModule"].forChild(routes)
            ],
            declarations: [_contact_us_page__WEBPACK_IMPORTED_MODULE_6__["ContactUsPage"]]
        })
    ], ContactUsPageModule);
    return ContactUsPageModule;
}());



/***/ }),

/***/ "./src/app/Rentals Management/pages/contact-us/contact-us.page.html":
/*!**************************************************************************!*\
  !*** ./src/app/Rentals Management/pages/contact-us/contact-us.page.html ***!
  \**************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ion-header>\r\n  <ion-toolbar color=\"primary\">\r\n    <ion-buttons slot=\"start\">\r\n      <ion-back-button></ion-back-button>\r\n    </ion-buttons>\r\n    <ion-title class=\"gotham-bold center-text\">{{transService.getTranslatedData('contact-us.title')}}</ion-title>\r\n  </ion-toolbar>\r\n</ion-header>\r\n\r\n<ion-content>\r\n  <div class=\"grey-back full-width max-available-height\">\r\n    <ion-grid>\r\n      <p class=\"txt-medium margin-bottom-20 gotham-medium center-text\">\r\n        {{transService.getTranslatedData('contact-us.note')}}</p>\r\n      <ion-row class=\"padding-20 \">\r\n        <ion-col>\r\n          <textarea [(ngModel)]=\"contactUsData.feedback\" no-border rows=\"10\"\r\n            class=\"font-12 full-width txt-warm-grey gotham border-0 padding-20 \"\r\n            placeholder=\"{{transService.getTranslatedData('contact-us.placeholder')}}\" autofocus>\r\n                </textarea>\r\n          <ion-button (click)=\"sendContactUsRequest()\" class=\"full-button margin-0 height-50 margin-top-20\"\r\n            color=\"danger\">\r\n            <p class=\"gotham font-14 margin-padding-zero\">{{transService.getTranslatedData('contact-us.submit-button')}}\r\n            </p>\r\n          </ion-button>\r\n        </ion-col>\r\n      </ion-row>\r\n    </ion-grid>\r\n\r\n  </div>\r\n\r\n</ion-content>"

/***/ }),

/***/ "./src/app/Rentals Management/pages/contact-us/contact-us.page.scss":
/*!**************************************************************************!*\
  !*** ./src/app/Rentals Management/pages/contact-us/contact-us.page.scss ***!
  \**************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL1JlbnRhbHMgTWFuYWdlbWVudC9wYWdlcy9jb250YWN0LXVzL2NvbnRhY3QtdXMucGFnZS5zY3NzIn0= */"

/***/ }),

/***/ "./src/app/Rentals Management/pages/contact-us/contact-us.page.ts":
/*!************************************************************************!*\
  !*** ./src/app/Rentals Management/pages/contact-us/contact-us.page.ts ***!
  \************************************************************************/
/*! exports provided: ContactUsPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ContactUsPage", function() { return ContactUsPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _services_contact_us_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../services/contact-us.service */ "./src/app/Rentals Management/services/contact-us.service.ts");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var src_app_common_services_alert_service_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! src/app/common-services/alert-service.service */ "./src/app/common-services/alert-service.service.ts");
/* harmony import */ var src_app_common_services_translate_translate_service_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! src/app/common-services/translate/translate-service.service */ "./src/app/common-services/translate/translate-service.service.ts");







var ContactUsPage = /** @class */ (function () {
    function ContactUsPage(loadingCtrl, modalController, contactUsService, router, route, alertService, transService) {
        this.loadingCtrl = loadingCtrl;
        this.modalController = modalController;
        this.contactUsService = contactUsService;
        this.router = router;
        this.route = route;
        this.alertService = alertService;
        this.transService = transService;
        this.contactUsData = {
            user: {
            // _id: window.localStorage.getItem('user_id'),
            // countryCode: window.localStorage.getItem('countryCode'),
            // phoneNumber: window.localStorage.getItem('phoneNumber'),
            // firstName: window.localStorage.getItem('firstName'),
            // lastName: window.localStorage.getItem('lastName'),
            },
            // 'roles' : JSON.parse(window.localStorage.getItem('roles')),
            createdAt: new Date(),
            source: 'Business App'
        };
    }
    ContactUsPage.prototype.presentLoading = function () {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function () {
            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.loadingCtrl.create({
                            spinner: "lines"
                        }).then(function (loading) {
                            loading.present();
                        })];
                    case 1:
                        _a.sent();
                        return [2 /*return*/];
                }
            });
        });
    };
    ContactUsPage.prototype.ngOnInit = function () {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function () {
            var _this = this;
            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.alertService.getDataFromLoaclStorage('user_id').then(function (val) {
                            _this.contactUsData.user._id = val;
                        })];
                    case 1:
                        _a.sent();
                        return [4 /*yield*/, this.alertService.getDataFromLoaclStorage('countryCode').then(function (val) {
                                _this.contactUsData.user.countryCode = val;
                            })];
                    case 2:
                        _a.sent();
                        return [4 /*yield*/, this.alertService.getDataFromLoaclStorage('phoneNumber').then(function (val) {
                                _this.contactUsData.user.phoneNumber = val;
                            })];
                    case 3:
                        _a.sent();
                        return [4 /*yield*/, this.alertService.getDataFromLoaclStorage('firstName').then(function (val) {
                                _this.contactUsData.user.firstName = val;
                            })];
                    case 4:
                        _a.sent();
                        return [4 /*yield*/, this.alertService.getDataFromLoaclStorage('lastName').then(function (val) {
                                _this.contactUsData.user.lastName = val;
                            })];
                    case 5:
                        _a.sent();
                        return [2 /*return*/];
                }
            });
        });
    };
    ContactUsPage.prototype.sendContactUsRequest = function () {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function () {
            var _this = this;
            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.presentLoading()];
                    case 1:
                        _a.sent();
                        this.contactUsService.createContactUs(this.contactUsData)
                            .subscribe(function (data) { return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](_this, void 0, void 0, function () {
                            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                                switch (_a.label) {
                                    case 0:
                                        this.loadingCtrl.dismiss();
                                        return [4 /*yield*/, this.alertService.presentAlert(this.transService.getTranslatedData('alert-title'), this.transService.getTranslatedData('contact-us.message'))];
                                    case 1:
                                        _a.sent();
                                        this.router.navigateByUrl('/rentals-home');
                                        return [2 /*return*/];
                                }
                            });
                        }); }, function (err) {
                            _this.loadingCtrl.dismiss();
                            _this.alertService.presentAlert(_this.transService.getTranslatedData('alert-title'), err.error.error);
                        });
                        return [2 /*return*/];
                }
            });
        });
    };
    ContactUsPage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-contact-us',
            template: __webpack_require__(/*! ./contact-us.page.html */ "./src/app/Rentals Management/pages/contact-us/contact-us.page.html"),
            styles: [__webpack_require__(/*! ./contact-us.page.scss */ "./src/app/Rentals Management/pages/contact-us/contact-us.page.scss")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_ionic_angular__WEBPACK_IMPORTED_MODULE_2__["LoadingController"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["ModalController"],
            _services_contact_us_service__WEBPACK_IMPORTED_MODULE_3__["ContactUsService"],
            _angular_router__WEBPACK_IMPORTED_MODULE_4__["Router"],
            _angular_router__WEBPACK_IMPORTED_MODULE_4__["ActivatedRoute"],
            src_app_common_services_alert_service_service__WEBPACK_IMPORTED_MODULE_5__["AlertServiceService"],
            src_app_common_services_translate_translate_service_service__WEBPACK_IMPORTED_MODULE_6__["translateService"]])
    ], ContactUsPage);
    return ContactUsPage;
}());



/***/ }),

/***/ "./src/app/Rentals Management/services/contact-us.service.ts":
/*!*******************************************************************!*\
  !*** ./src/app/Rentals Management/services/contact-us.service.ts ***!
  \*******************************************************************/
/*! exports provided: ContactUsService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ContactUsService", function() { return ContactUsService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/fesm5/http.js");
/* harmony import */ var src_app_conatants_MainAppSetting__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/conatants/MainAppSetting */ "./src/app/conatants/MainAppSetting.ts");




var ContactUsService = /** @class */ (function () {
    function ContactUsService(http, appSettings) {
        this.http = http;
        this.appSettings = appSettings;
    }
    ContactUsService.prototype.createContactUs = function (data) {
        return this.http.post(this.appSettings.getApi() + "/api/support/help/send-troubleshoot-mail", data, {
            headers: new _angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpHeaders"]({
                'Content-Type': 'application/json',
                Authorization: localStorage.getItem('token')
            })
        });
    };
    ContactUsService = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
            providedIn: 'root'
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpClient"],
            src_app_conatants_MainAppSetting__WEBPACK_IMPORTED_MODULE_3__["MainAppSetting"]])
    ], ContactUsService);
    return ContactUsService;
}());



/***/ })

}]);
//# sourceMappingURL=Rentals-Management-pages-contact-us-contact-us-module.js.map