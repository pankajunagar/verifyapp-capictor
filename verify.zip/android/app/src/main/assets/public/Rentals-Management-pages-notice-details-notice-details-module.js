(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["Rentals-Management-pages-notice-details-notice-details-module"],{

/***/ "./src/app/Rentals Management/pages/notice-details/notice-details.module.ts":
/*!**********************************************************************************!*\
  !*** ./src/app/Rentals Management/pages/notice-details/notice-details.module.ts ***!
  \**********************************************************************************/
/*! exports provided: NoticeDetailsPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "NoticeDetailsPageModule", function() { return NoticeDetailsPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _ApplicationPageModule__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./../../ApplicationPageModule */ "./src/app/Rentals Management/ApplicationPageModule.ts");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var ngx_avatar__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ngx-avatar */ "./node_modules/ngx-avatar/fesm5/ngx-avatar.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _notice_details_page__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./notice-details.page */ "./src/app/Rentals Management/pages/notice-details/notice-details.page.ts");









var routes = [
    {
        path: '',
        component: _notice_details_page__WEBPACK_IMPORTED_MODULE_8__["NoticeDetailsPage"]
    }
];
var NoticeDetailsPageModule = /** @class */ (function () {
    function NoticeDetailsPageModule() {
    }
    NoticeDetailsPageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_2__["NgModule"])({
            imports: [
                _angular_common__WEBPACK_IMPORTED_MODULE_3__["CommonModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormsModule"],
                _ionic_angular__WEBPACK_IMPORTED_MODULE_7__["IonicModule"],
                _ApplicationPageModule__WEBPACK_IMPORTED_MODULE_1__["ApplicationPageModule"],
                _angular_router__WEBPACK_IMPORTED_MODULE_5__["RouterModule"].forChild(routes),
                ngx_avatar__WEBPACK_IMPORTED_MODULE_6__["AvatarModule"]
            ],
            declarations: [_notice_details_page__WEBPACK_IMPORTED_MODULE_8__["NoticeDetailsPage"]]
        })
    ], NoticeDetailsPageModule);
    return NoticeDetailsPageModule;
}());



/***/ }),

/***/ "./src/app/Rentals Management/pages/notice-details/notice-details.page.html":
/*!**********************************************************************************!*\
  !*** ./src/app/Rentals Management/pages/notice-details/notice-details.page.html ***!
  \**********************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ion-header>\r\n  <ion-toolbar color=\"primary\">\r\n    <ion-buttons slot=\"start\">\r\n      <ion-back-button></ion-back-button>\r\n    </ion-buttons>\r\n    <ion-title class=\"padding-0\" >{{transService.getTranslatedData('notice-details.title')}}</ion-title>\r\n  </ion-toolbar>\r\n</ion-header>\r\n<ion-content>\r\n  <div>\r\n    <ion-card class=\"ticket-details-list padding-10 margin-5\">\r\n      <ion-row class=\"padding-top-5\">\r\n        <ion-col size=\"2\" class=\"padding-top-0\">\r\n          <ngx-avatar name=\"{{notice.createdBy?.firstName}}\r\n            {{notice.createdBy?.lastName}}\"></ngx-avatar>\r\n        </ion-col>\r\n        <ion-col size=\"6\" class=\"margin-left-8\">\r\n          <p class=\"gotham-medium font-14 dark-grey margin-padding-zero\">{{notice.createdBy?.firstName}}\r\n            {{notice.createdBy?.lastName}}</p>\r\n          <p class=\"txt-warm-grey font-14 Gotham-medium margin-bottom-0\r\n            margin-top-5 font-weight-500 txt-nowrap\">\r\n            {{notice.listing?.block}} {{notice.listing?.door}} {{notice.listing?.block?notice.listing?.door?'-':'-':''}} \r\n            {{notice.createdBy?.types}}\r\n          </p>\r\n        </ion-col>\r\n        <ion-col class=\"text-right\">\r\n          <ion-badge color=\"warning\" *ngIf=\"notice.discussionType\" class=\"border-radius-10\">{{notice.discussionType}}\r\n          </ion-badge>\r\n          <p class=\"txt-warm-grey font-11 Gotham-medium margin-bottom-0\r\n            margin-padding-zero font-weight-500 txt-nowrap\">\r\n            {{notice.createdAt |agoFilter}}\r\n          </p>\r\n        </ion-col>\r\n      </ion-row>\r\n      <div class=\"padding-5\">\r\n        <p class=\"Gotham-medium font-14 font-weight-500 margin-bottom-5\r\n          dark-grey margin-top-5\">\r\n          {{notice.title}}\r\n        </p>\r\n        <p class=\"txt-warm-grey font-14 Gotham-medium margin-bottom-0\r\n          margin-top-5 font-weight-500\" [innerHTML]=\"notice.body\">\r\n        </p>\r\n      </div>\r\n\r\n      <ion-row class=\"center-text\" *ngIf=\"notice.files?.length> 0\">\r\n        <br>\r\n        <ion-col class=\"display-flex justify-center\">\r\n          <img src=\"{{notice.files[0].aws_original_url}}\" style=\"max-width:100%; max-height:250px !important; width:auto;\r\n            height:auto;\">\r\n        </ion-col>\r\n        <br><br>\r\n      </ion-row>\r\n\r\n      <ion-grid>\r\n        <ion-row>\r\n          <ion-col>\r\n            <span class=\"padding-right-20\">\r\n              <ion-icon (click)=\"likeDiscussion(notice._id)\" [ngClass]=\"{'btn-color':notice.hasLiked}\"\r\n                class=\"icon font-25 gotham margin-right-5\" name=\"heart-empty\"></ion-icon>\r\n              <!-- <ion-icon *ngIf=\"!notice.hasLiked\" (click)=\"likeDiscussion(notice._id)\"\r\n                class=\"icon font-25 gotham margin-right-5\" name=\"heart-empty\"></ion-icon>\r\n              <ion-icon *ngIf=\"notice.hasLiked\" (click)=\"likeDiscussion(notice._id)\" color=\"danger\"\r\n                class=\"icon font-25 gotham margin-right-5\" name=\"heart-empty\"></ion-icon> -->\r\n              <span class=\"text font-20\">{{notice.likesCount}}</span>\r\n            </span>\r\n            <span class=\"padding-right-20\">\r\n              <ion-icon class=\"icon font-25 gotham margin-right-5\" name=\"eye\"></ion-icon>\r\n              <span class=\"text font-20\">{{notice.seenByCount}}</span>\r\n            </span>\r\n            <span class=\"padding-right-20\">\r\n              <ion-icon class=\"icon font-25 gotham margin-right-5\" name=\"chatboxes\"></ion-icon>\r\n              <span class=\"text font-20\">{{notice.commentCount}}</span>\r\n            </span>\r\n          </ion-col>\r\n        </ion-row>\r\n      </ion-grid>\r\n    </ion-card>\r\n\r\n    <div class=\"ticket-comment-detail\" *ngFor=\"let comment of comments\">\r\n      <ion-row class=\"\">\r\n        <ion-col size=\"2\">\r\n          <ngx-avatar name=\"{{comment.createdBy.firstName}}\r\n            {{comment.createdBy.lastName}}\"></ngx-avatar>\r\n        </ion-col>\r\n        <ion-col class=\"margin-left-8\">\r\n          <ion-col class=\"padding-left-0\">\r\n            <span class=\"gotham-medium font-14 dark-grey margin-padding-zero\">\r\n              {{comment.createdBy.firstName}} {{comment.createdBy.lastName}}\r\n            </span>\r\n            <!-- <br>\r\n            <span class=\"txt-warm-grey gotham-medium  font-14 font-weight-500 margin-top-8 txt-nowrap\">\r\n              Admin\r\n            </span> -->\r\n          </ion-col>\r\n          <ion-col class=\"padding-0\">\r\n            <span class=\"float-right font-12 txt-warm-grey gotham-medium font-weight-500\">\r\n              {{comment.createdAt |agoFilter}}</span>\r\n          </ion-col>\r\n          <ion-row>\r\n            <ion-col size=\"9\" class=\"padding-0\">\r\n              <p class=\"txt-warm-grey gotham-medium font-14 font-weight-500 margin-0 comment-full-visible\">\r\n                {{comment.text}}\r\n              </p>\r\n            </ion-col>\r\n            <ion-col size=\"3\" class=\"padding-0\">\r\n              <a (click)='deleteComment(comment._id)'\r\n                class=\"gotham-medium float-right font-12 dark-grey margin-padding-zero margin-top-1 underline-text\">delete</a>\r\n            </ion-col>\r\n\r\n          </ion-row>\r\n\r\n\r\n        </ion-col>\r\n      </ion-row>\r\n    </div>\r\n\r\n  </div>\r\n\r\n</ion-content>\r\n\r\n<ion-footer>\r\n  <ion-item no-padding lines=\"none\">\r\n    <label class=\"grey-back full-width\">\r\n      <ion-input placeholder=\"{{transService.getTranslatedData('notice-details.comment')}}\"\r\n        [(ngModel)]=\"notice.commentText\" class=\"font-14 height-50 gotham border-0 padding-left-10\"></ion-input>\r\n    </label>\r\n    <ion-button (click)=\"createComment()\">\r\n      <ion-icon style=\"font-size: x-large !important\" name=\"paper-plane\"></ion-icon>\r\n    </ion-button>\r\n  </ion-item>\r\n</ion-footer>"

/***/ }),

/***/ "./src/app/Rentals Management/pages/notice-details/notice-details.page.scss":
/*!**********************************************************************************!*\
  !*** ./src/app/Rentals Management/pages/notice-details/notice-details.page.scss ***!
  \**********************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "ion-content {\n  --ion-background-color: #ecebe6; }\n\n.icon {\n  display: inline-block;\n  vertical-align: middle; }\n\n.text {\n  display: inline-block;\n  vertical-align: middle; }\n\nion-item {\n  padding: 5px !important; }\n\nion-item {\n  -webkit-padding-end: 0px !important;\n  padding-inline-end: 0px !important;\n  --inner-padding-bottom: 0px !important;\n  --inner-padding-end: 0px !important;\n  --inner-padding-start: 0px !important;\n  --inner-padding-top: 0px !important;\n  --padding-bottom: 0px !important;\n  --padding-end: 0px !important;\n  --padding-start: 0px !important;\n  --padding-top: 0px !important; }\n\n.comment-button {\n  height: 40px !important;\n  width: 100% !important;\n  margin-left: 10px !important; }\n\nion-button {\n  height: 100%;\n  width: 14%;\n  margin-right: 9px;\n  margin-left: 9px; }\n\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvUmVudGFscyBNYW5hZ2VtZW50L3BhZ2VzL25vdGljZS1kZXRhaWxzL0Q6XFxuYXZqb3RcXHZlcmlmeS9zcmNcXGFwcFxcUmVudGFscyBNYW5hZ2VtZW50XFxwYWdlc1xcbm90aWNlLWRldGFpbHNcXG5vdGljZS1kZXRhaWxzLnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNFLCtCQUF1QixFQUFBOztBQUV6QjtFQUNFLHFCQUFxQjtFQUNyQixzQkFBc0IsRUFBQTs7QUFHeEI7RUFDRSxxQkFBcUI7RUFDckIsc0JBQXNCLEVBQUE7O0FBRXhCO0VBQ0UsdUJBQXVCLEVBQUE7O0FBRXpCO0VBQ0UsbUNBQW1DO0VBQ25DLGtDQUFrQztFQUNsQyxzQ0FBdUI7RUFDdkIsbUNBQW9CO0VBQ3BCLHFDQUFzQjtFQUN0QixtQ0FBb0I7RUFDcEIsZ0NBQWlCO0VBQ2pCLDZCQUFjO0VBQ2QsK0JBQWdCO0VBQ2hCLDZCQUFjLEVBQUE7O0FBRWhCO0VBQ0UsdUJBQXVCO0VBQ3ZCLHNCQUFzQjtFQUN0Qiw0QkFBNEIsRUFBQTs7QUFHOUI7RUFDRSxZQUFZO0VBQ1osVUFBVTtFQUNWLGlCQUFpQjtFQUNqQixnQkFBZ0IsRUFBQSIsImZpbGUiOiJzcmMvYXBwL1JlbnRhbHMgTWFuYWdlbWVudC9wYWdlcy9ub3RpY2UtZGV0YWlscy9ub3RpY2UtZGV0YWlscy5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyJpb24tY29udGVudCB7XHJcbiAgLS1pb24tYmFja2dyb3VuZC1jb2xvcjogI2VjZWJlNjtcclxufVxyXG4uaWNvbiB7XHJcbiAgZGlzcGxheTogaW5saW5lLWJsb2NrO1xyXG4gIHZlcnRpY2FsLWFsaWduOiBtaWRkbGU7XHJcbn1cclxuXHJcbi50ZXh0IHtcclxuICBkaXNwbGF5OiBpbmxpbmUtYmxvY2s7XHJcbiAgdmVydGljYWwtYWxpZ246IG1pZGRsZTtcclxufVxyXG5pb24taXRlbSB7XHJcbiAgcGFkZGluZzogNXB4ICFpbXBvcnRhbnQ7XHJcbn1cclxuaW9uLWl0ZW0ge1xyXG4gIC13ZWJraXQtcGFkZGluZy1lbmQ6IDBweCAhaW1wb3J0YW50O1xyXG4gIHBhZGRpbmctaW5saW5lLWVuZDogMHB4ICFpbXBvcnRhbnQ7XHJcbiAgLS1pbm5lci1wYWRkaW5nLWJvdHRvbTogMHB4ICFpbXBvcnRhbnQ7XHJcbiAgLS1pbm5lci1wYWRkaW5nLWVuZDogMHB4ICFpbXBvcnRhbnQ7XHJcbiAgLS1pbm5lci1wYWRkaW5nLXN0YXJ0OiAwcHggIWltcG9ydGFudDtcclxuICAtLWlubmVyLXBhZGRpbmctdG9wOiAwcHggIWltcG9ydGFudDtcclxuICAtLXBhZGRpbmctYm90dG9tOiAwcHggIWltcG9ydGFudDtcclxuICAtLXBhZGRpbmctZW5kOiAwcHggIWltcG9ydGFudDtcclxuICAtLXBhZGRpbmctc3RhcnQ6IDBweCAhaW1wb3J0YW50O1xyXG4gIC0tcGFkZGluZy10b3A6IDBweCAhaW1wb3J0YW50O1xyXG59XHJcbi5jb21tZW50LWJ1dHRvbiB7XHJcbiAgaGVpZ2h0OiA0MHB4ICFpbXBvcnRhbnQ7XHJcbiAgd2lkdGg6IDEwMCUgIWltcG9ydGFudDtcclxuICBtYXJnaW4tbGVmdDogMTBweCAhaW1wb3J0YW50O1xyXG59XHJcblxyXG5pb24tYnV0dG9uIHtcclxuICBoZWlnaHQ6IDEwMCU7XHJcbiAgd2lkdGg6IDE0JTtcclxuICBtYXJnaW4tcmlnaHQ6IDlweDtcclxuICBtYXJnaW4tbGVmdDogOXB4O1xyXG59XHJcbiJdfQ== */"

/***/ }),

/***/ "./src/app/Rentals Management/pages/notice-details/notice-details.page.ts":
/*!********************************************************************************!*\
  !*** ./src/app/Rentals Management/pages/notice-details/notice-details.page.ts ***!
  \********************************************************************************/
/*! exports provided: NoticeDetailsPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "NoticeDetailsPage", function() { return NoticeDetailsPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _services_notice_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../services/notice.service */ "./src/app/Rentals Management/services/notice.service.ts");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var src_app_common_services_alert_service_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! src/app/common-services/alert-service.service */ "./src/app/common-services/alert-service.service.ts");
/* harmony import */ var src_app_common_services_translate_translate_service_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! src/app/common-services/translate/translate-service.service */ "./src/app/common-services/translate/translate-service.service.ts");







var NoticeDetailsPage = /** @class */ (function () {
    function NoticeDetailsPage(noticeService, loading, modalController, route, router, alertService, transService) {
        var _this = this;
        this.noticeService = noticeService;
        this.loading = loading;
        this.modalController = modalController;
        this.route = route;
        this.router = router;
        this.alertService = alertService;
        this.transService = transService;
        this.notice = {};
        this.noticeId = '';
        this.user_id = '';
        this.route.queryParamMap.subscribe(function (params) {
            params.params.noticeId ? _this.noticeId = params.params.noticeId : '';
            params.params.did ? _this.noticeId = params.params.did : '';
            console.log(_this.noticeId);
        });
        this.user_id = window.localStorage.getItem('user_id');
    }
    NoticeDetailsPage.prototype.ngOnInit = function () {
        this.getNotice();
        this.getAllComments();
    };
    NoticeDetailsPage.prototype.presentLoading = function () {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function () {
            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.loading.create({
                            spinner: 'lines'
                        }).then(function (loading) {
                            loading.present();
                        })];
                    case 1:
                        _a.sent();
                        return [2 /*return*/];
                }
            });
        });
    };
    NoticeDetailsPage.prototype.getNotice = function () {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function () {
            var userId;
            var _this = this;
            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                switch (_a.label) {
                    case 0:
                        this.presentLoading();
                        return [4 /*yield*/, this.alertService.getDataFromLoaclStorage('user_id').then(function (value) {
                                userId = value;
                            })];
                    case 1:
                        _a.sent();
                        this.noticeService.getNoticeById(this.noticeId)
                            .subscribe(function (data) {
                            _this.notice = data;
                            _this.notice.likes.indexOf(userId) > -1 ? _this.notice.hasLiked = true : _this.notice.hasLiked = false;
                            console.log(_this.notice);
                            _this.loading.dismiss();
                        }, function (err) {
                            _this.loading.dismiss();
                            _this.alertService.presentAlert(_this.transService.getTranslatedData('alert-title'), err.error.error);
                        });
                        return [2 /*return*/];
                }
            });
        });
    };
    NoticeDetailsPage.prototype.getAllComments = function () {
        var _this = this;
        this.noticeService.getAllComments(this.noticeId)
            .subscribe(function (data) {
            _this.comments = data;
            console.log(_this.comments);
        }, function (err) {
            _this.alertService.presentAlert(_this.transService.getTranslatedData('alert-title'), err.error.error);
        });
    };
    NoticeDetailsPage.prototype.changeLikeIcon = function (id) {
        this.notice.hasLiked = !this.notice.hasLiked;
        if (this.notice.hasLiked === false) {
            this.notice.likesCount = this.notice.likesCount - 1;
        }
        else if (this.notice.hasLiked === true) {
            this.notice.likesCount = this.notice.likesCount + 1;
        }
    };
    NoticeDetailsPage.prototype.likeDiscussion = function (id) {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function () {
            var _this = this;
            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.presentLoading()];
                    case 1:
                        _a.sent();
                        this.noticeService.likeNotice(id)
                            .subscribe(function (data) {
                            _this.changeLikeIcon(id);
                            _this.loading.dismiss();
                        }, function (err) {
                            _this.loading.dismiss();
                            _this.alertService.presentAlert(_this.transService.getTranslatedData('alert-title'), err.error.error);
                        });
                        return [2 /*return*/];
                }
            });
        });
    };
    NoticeDetailsPage.prototype.createComment = function () {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function () {
            var data;
            var _this = this;
            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                switch (_a.label) {
                    case 0:
                        data = {
                            text: this.notice.commentText,
                            discussion: this.noticeId,
                        };
                        return [4 /*yield*/, this.presentLoading()];
                    case 1:
                        _a.sent();
                        this.noticeService.createComment(data)
                            .subscribe(function (data) {
                            _this.notice.commentText = '';
                            _this.loading.dismiss();
                            _this.getAllComments();
                            // this.router.navigateByUrl('/tickets');
                        }, function (err) {
                            _this.loading.dismiss();
                            _this.alertService.presentAlert(_this.transService.getTranslatedData('alert-title'), err.error.error);
                        });
                        return [2 /*return*/];
                }
            });
        });
    };
    NoticeDetailsPage.prototype.deleteComment = function (id) {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function () {
            var _this = this;
            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.presentLoading()];
                    case 1:
                        _a.sent();
                        this.noticeService.deleteComment(id)
                            .subscribe(function (data) {
                            _this.loading.dismiss();
                            _this.getAllComments();
                            // this.router.navigateByUrl('/tickets');
                        }, function (err) {
                            _this.loading.dismiss();
                            _this.alertService.presentAlert(_this.transService.getTranslatedData('alert-title'), err.error.error);
                        });
                        return [2 /*return*/];
                }
            });
        });
    };
    NoticeDetailsPage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-notice-details',
            template: __webpack_require__(/*! ./notice-details.page.html */ "./src/app/Rentals Management/pages/notice-details/notice-details.page.html"),
            styles: [__webpack_require__(/*! ./notice-details.page.scss */ "./src/app/Rentals Management/pages/notice-details/notice-details.page.scss")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_services_notice_service__WEBPACK_IMPORTED_MODULE_2__["NoticeService"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["LoadingController"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["ModalController"],
            _angular_router__WEBPACK_IMPORTED_MODULE_4__["ActivatedRoute"],
            _angular_router__WEBPACK_IMPORTED_MODULE_4__["Router"],
            src_app_common_services_alert_service_service__WEBPACK_IMPORTED_MODULE_5__["AlertServiceService"],
            src_app_common_services_translate_translate_service_service__WEBPACK_IMPORTED_MODULE_6__["translateService"]])
    ], NoticeDetailsPage);
    return NoticeDetailsPage;
}());



/***/ })

}]);
//# sourceMappingURL=Rentals-Management-pages-notice-details-notice-details-module.js.map