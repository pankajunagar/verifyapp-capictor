(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["default~Rentals-Management-pages-verifyitProductinfo-verifyitProductinfo-module~Rentals-Management-p~8f8ff555"],{

/***/ "./src/app/Rentals Management/modals/certificatemodal/certificatemodal.component.html":
/*!********************************************************************************************!*\
  !*** ./src/app/Rentals Management/modals/certificatemodal/certificatemodal.component.html ***!
  \********************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ion-header no-border>\r\n  <ion-toolbar color=\"primary\">\r\n    <ion-buttons slot=\"start\">\r\n      <ion-menu-button></ion-menu-button>\r\n    </ion-buttons>\r\n    <!-- <ion-buttons slot=\"end\" expand=\"full\" class=\"ion-button\" (click)=\"openScanner()\">\r\n      <ion-button style=\"color: black\">\r\n          <img src=\"../../../../assets/icons.png\" width=\"30px\" height=\"30px\"/>\r\n      </ion-button>\r\n    </ion-buttons> -->\r\n\r\n    <ion-title>Product catalog</ion-title>\r\n  </ion-toolbar>\r\n\r\n</ion-header>\r\n\r\n\r\n<ion-content padding>\r\n\r\n    <ion-searchbar placeholder=\"Browse certificates\" mode=\"ios\"\r\n    [(ngModel)]=\"searchTerm\" (ionChange)=\"setFilteredItems()\"\r\n  ></ion-searchbar>\r\n  <ion-row class=\"center-text\">\r\n    <ion-col  *ngFor=\"let item of items\" size=\"12\">\r\n\r\n      <ion-card  class=\"myCard\">\r\n        <img *ngIf=\"item.link\" (click)=\"showProductInfo(item)\"\r\n          src={{item.link}} />\r\n        <div class=\"myOverlay\">\r\n          <div class=\"card-title\">{{item.text}}</div>\r\n        </div>\r\n      </ion-card>\r\n\r\n    </ion-col>\r\n    <!-- <ion-col>\r\n\r\n      <ion-card class=\"myCard\">\r\n        <img style=\"    height: 155px;\"\r\n          src=\"assets/imgs/dryer.jpg\" />\r\n        <div class=\"myOverlay\">\r\n          <div class=\"card-title\">Styling</div>\r\n        </div>\r\n      </ion-card>\r\n    </ion-col> -->\r\n\r\n  </ion-row>\r\n</ion-content>"

/***/ }),

/***/ "./src/app/Rentals Management/modals/certificatemodal/certificatemodal.component.scss":
/*!********************************************************************************************!*\
  !*** ./src/app/Rentals Management/modals/certificatemodal/certificatemodal.component.scss ***!
  \********************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ".aclass {\n  width: 100%; }\n\nh4 {\n  text-align: center;\n  text-transform: capitalize; }\n\nion-label {\n  display: flex;\n  justify-content: center;\n  font-weight: 500; }\n\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvUmVudGFscyBNYW5hZ2VtZW50L21vZGFscy9jZXJ0aWZpY2F0ZW1vZGFsL0Q6XFxuYXZqb3RcXHZlcmlmeS9zcmNcXGFwcFxcUmVudGFscyBNYW5hZ2VtZW50XFxtb2RhbHNcXGNlcnRpZmljYXRlbW9kYWxcXGNlcnRpZmljYXRlbW9kYWwuY29tcG9uZW50LnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDSSxXQUFXLEVBQUE7O0FBR2Y7RUFDSSxrQkFBa0I7RUFDbEIsMEJBQTBCLEVBQUE7O0FBRTlCO0VBQ0ksYUFBYTtFQUNiLHVCQUF1QjtFQUN2QixnQkFBZ0IsRUFBQSIsImZpbGUiOiJzcmMvYXBwL1JlbnRhbHMgTWFuYWdlbWVudC9tb2RhbHMvY2VydGlmaWNhdGVtb2RhbC9jZXJ0aWZpY2F0ZW1vZGFsLmNvbXBvbmVudC5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiLmFjbGFzc3tcclxuICAgIHdpZHRoOiAxMDAlO1xyXG59XHJcblxyXG5oNHtcclxuICAgIHRleHQtYWxpZ246IGNlbnRlcjtcclxuICAgIHRleHQtdHJhbnNmb3JtOiBjYXBpdGFsaXplO1xyXG59XHJcbmlvbi1sYWJlbHtcclxuICAgIGRpc3BsYXk6IGZsZXg7XHJcbiAgICBqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlcjtcclxuICAgIGZvbnQtd2VpZ2h0OiA1MDA7XHJcbn0iXX0= */"

/***/ }),

/***/ "./src/app/Rentals Management/modals/certificatemodal/certificatemodal.component.ts":
/*!******************************************************************************************!*\
  !*** ./src/app/Rentals Management/modals/certificatemodal/certificatemodal.component.ts ***!
  \******************************************************************************************/
/*! exports provided: CertificateModalComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CertificateModalComponent", function() { return CertificateModalComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _services_naila_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../services/naila.service */ "./src/app/Rentals Management/services/naila.service.ts");
/* harmony import */ var _services_utils_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../services/utils.service */ "./src/app/Rentals Management/services/utils.service.ts");





// import { Slides } from 'ionic-angular';
var CertificateModalComponent = /** @class */ (function () {
    function CertificateModalComponent(nailaservice, utils, router) {
        this.nailaservice = nailaservice;
        this.utils = utils;
        this.router = router;
    }
    CertificateModalComponent.prototype.ngOnInit = function () {
        this.items = this.utils.certificateData;
        this.utils.certificateData.forEach(function (element) {
            debugger;
            element.text = element.text;
        });
        // this.nailaservice.listRelatedProducts(this.utils.).subscribe(data => {
        // this.listbanner=data;
        // this.items=this.listbanner.data
        //   this.listbanner.data.forEach(element => {
        //     element.text= element.product_text
        //   });
        // console.log(this.listbanner);
        // })
    };
    CertificateModalComponent.prototype.setFilteredItems = function () {
        this.items = this.utils.certificateData;
        this.items = this.filterItems(this.searchTerm);
    };
    CertificateModalComponent.prototype.filterItems = function (searchTerm) {
        return this.items.filter(function (item) {
            return item.text.toLowerCase().indexOf(searchTerm.toLowerCase()) > -1;
        });
    };
    CertificateModalComponent.prototype.showProductInfo = function (item) {
        // this.utils.productCatalogInfo=item;
        // this.router.navigateByUrl('/verifyit-product-catalog-info')
    };
    CertificateModalComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-certificatemodal',
            template: __webpack_require__(/*! ./certificatemodal.component.html */ "./src/app/Rentals Management/modals/certificatemodal/certificatemodal.component.html"),
            styles: [__webpack_require__(/*! ./certificatemodal.component.scss */ "./src/app/Rentals Management/modals/certificatemodal/certificatemodal.component.scss")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_services_naila_service__WEBPACK_IMPORTED_MODULE_3__["NailaService"], _services_utils_service__WEBPACK_IMPORTED_MODULE_4__["Utils"], _angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"]])
    ], CertificateModalComponent);
    return CertificateModalComponent;
}());



/***/ }),

/***/ "./src/app/Rentals Management/modals/tellusifyoubuyit/tellusifyoubuyit.component.html":
/*!********************************************************************************************!*\
  !*** ./src/app/Rentals Management/modals/tellusifyoubuyit/tellusifyoubuyit.component.html ***!
  \********************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ion-header *ngIf=\"hidebutton\">\r\n  <ion-toolbar color=\"primary\">\r\n    <ion-title style=\"text-transform: capitalize;\">Please verify your mobile number.</ion-title>\r\n    <!-- <ion-title *ngIf=\"!hidenfc\" style=\"    text-transform: capitalize;\">NFC</ion-title> -->\r\n\r\n    <ion-buttons slot=\"end\">\r\n      <ion-button color=\"primary\" (click)=\"closeModal()\">\r\n        <ion-icon style=\"    color: white;\" slot=\"icon-only\" name=\"close\"></ion-icon>\r\n      </ion-button>\r\n    </ion-buttons>\r\n  </ion-toolbar>\r\n</ion-header>\r\n\r\n<ion-content>\r\n  <ion-row>\r\n    <ion-col  size=\"12\">\r\n      <ion-item lines=\"none\">\r\n        <ion-label position=\"floating\">Enter Your Mobile Number.</ion-label>\r\n        <ion-input type=\"text\" maxlength=\"10\" minlength=\"10\" inputmode=\"tel\" placeholder=\"\" [(ngModel)]=\"usercontactNumber\"> </ion-input>\r\n      </ion-item>\r\n    </ion-col>\r\n\r\n    <ion-col *ngIf=\"!showOTP\">\r\n      <ion-item lines=\"none\">\r\n        <ion-label position=\"floating\">Enter OTP.</ion-label>\r\n        <ion-input type=\"text\" maxlength=\"4\" minlength=\"4\" inputmode=\"tel\" placeholder=\" \" [(ngModel)]=\"mobileOTP\"> </ion-input>\r\n      </ion-item>\r\n    </ion-col>\r\n  </ion-row>\r\n\r\n\r\n  <ion-row>\r\n    <ion-col style=\"margin-top: 5vh;\r\n    margin-bottom: 5vh;\r\n    width: 100%;\r\n    display: inline-flex;\r\n    justify-content: center;\">\r\n      <ion-button *ngIf=\"showOTP\" [disabled]=\"usercontactNumber.length < 9\"  (click)=\"generateOTP()\" class=\"half-button\" expand=\"full\" color=\"primary\">Generate OTP\r\n        </ion-button>\r\n\r\n        <ion-button *ngIf=\"!showOTP\" [disabled]=\"mobileOTP.length < 3\" (click)=\"submitOTP()\" class=\"half-button\" expand=\"full\" color=\"primary\">Submit OTP\r\n          </ion-button>\r\n  \r\n    \r\n\r\n    </ion-col>\r\n  </ion-row>\r\n  <ion-row  class=\"ion-text-justify\">\r\n    <ion-col>\r\n      <p style=\"font-size: 10px;margin-left:1vh;margin-right:1vh\">\r\n        Note: This process of mobile verification helps us keep authentication process full proof.\r\n    </p>\r\n    </ion-col>\r\n  </ion-row>\r\n</ion-content>"

/***/ }),

/***/ "./src/app/Rentals Management/modals/tellusifyoubuyit/tellusifyoubuyit.component.scss":
/*!********************************************************************************************!*\
  !*** ./src/app/Rentals Management/modals/tellusifyoubuyit/tellusifyoubuyit.component.scss ***!
  \********************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ".aclass {\n  width: 100%; }\n\nh4 {\n  text-align: center;\n  text-transform: capitalize; }\n\nion-label {\n  display: flex;\n  justify-content: center;\n  font-weight: 500; }\n\niOn-input {\n  border-bottom: 1px solid black; }\n\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvUmVudGFscyBNYW5hZ2VtZW50L21vZGFscy90ZWxsdXNpZnlvdWJ1eWl0L0Q6XFxuYXZqb3RcXHZlcmlmeS9zcmNcXGFwcFxcUmVudGFscyBNYW5hZ2VtZW50XFxtb2RhbHNcXHRlbGx1c2lmeW91YnV5aXRcXHRlbGx1c2lmeW91YnV5aXQuY29tcG9uZW50LnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDSSxXQUFXLEVBQUE7O0FBR2Y7RUFDSSxrQkFBa0I7RUFDbEIsMEJBQTBCLEVBQUE7O0FBRTlCO0VBQ0ksYUFBYTtFQUNiLHVCQUF1QjtFQUN2QixnQkFBZ0IsRUFBQTs7QUFFcEI7RUFDSSw4QkFBOEIsRUFBQSIsImZpbGUiOiJzcmMvYXBwL1JlbnRhbHMgTWFuYWdlbWVudC9tb2RhbHMvdGVsbHVzaWZ5b3VidXlpdC90ZWxsdXNpZnlvdWJ1eWl0LmNvbXBvbmVudC5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiLmFjbGFzc3tcclxuICAgIHdpZHRoOiAxMDAlO1xyXG59XHJcblxyXG5oNHtcclxuICAgIHRleHQtYWxpZ246IGNlbnRlcjtcclxuICAgIHRleHQtdHJhbnNmb3JtOiBjYXBpdGFsaXplO1xyXG59XHJcbmlvbi1sYWJlbHtcclxuICAgIGRpc3BsYXk6IGZsZXg7XHJcbiAgICBqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlcjtcclxuICAgIGZvbnQtd2VpZ2h0OiA1MDA7XHJcbn1cclxuaU9uLWlucHV0e1xyXG4gICAgYm9yZGVyLWJvdHRvbTogMXB4IHNvbGlkIGJsYWNrO1xyXG59Il19 */"

/***/ }),

/***/ "./src/app/Rentals Management/modals/tellusifyoubuyit/tellusifyoubuyit.component.ts":
/*!******************************************************************************************!*\
  !*** ./src/app/Rentals Management/modals/tellusifyoubuyit/tellusifyoubuyit.component.ts ***!
  \******************************************************************************************/
/*! exports provided: TellUsifyouBuyitComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "TellUsifyouBuyitComponent", function() { return TellUsifyouBuyitComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _services_notice_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./../../services/notice.service */ "./src/app/Rentals Management/services/notice.service.ts");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var src_app_common_services_alert_service_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! src/app/common-services/alert-service.service */ "./src/app/common-services/alert-service.service.ts");
/* harmony import */ var _ionic_native_ionic_webview_ngx__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic-native/ionic-webview/ngx */ "./node_modules/@ionic-native/ionic-webview/ngx/index.js");
/* harmony import */ var src_app_common_services_translate_translate_service_service__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! src/app/common-services/translate/translate-service.service */ "./src/app/common-services/translate/translate-service.service.ts");
/* harmony import */ var _services_utils_service__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../../services/utils.service */ "./src/app/Rentals Management/services/utils.service.ts");
/* harmony import */ var _ionic_native_screenshot_ngx__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @ionic-native/screenshot/ngx */ "./node_modules/@ionic-native/screenshot/ngx/index.js");
/* harmony import */ var _services_naila_service__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ../../services/naila.service */ "./src/app/Rentals Management/services/naila.service.ts");











// import { Platform } from 'ionic-angular';
var TellUsifyouBuyitComponent = /** @class */ (function () {
    function TellUsifyouBuyitComponent(modalController, loadingCtrl, noticeService, router, alertService, route, webView, utils, transService, actionSheet, screenshot, apiSvc) {
        // this.ionViewDidLoad()
        this.modalController = modalController;
        this.loadingCtrl = loadingCtrl;
        this.noticeService = noticeService;
        this.router = router;
        this.alertService = alertService;
        this.route = route;
        this.webView = webView;
        this.utils = utils;
        this.transService = transService;
        this.actionSheet = actionSheet;
        this.screenshot = screenshot;
        this.apiSvc = apiSvc;
        this.title = 'Nowverifyit';
        this.hidebutton = true;
        this.canNFC = false;
        this.elementType = 'elementType';
        this.value = 'QR code not generated successfully';
        this.flag = false;
        this.images = [];
        this.hasLoading = false;
        this.hidenfc = true;
        this.mobileOTP = '';
        this.showOTP = true;
        // this.ionViewDidLoad()
    }
    TellUsifyouBuyitComponent.prototype.ngOnInit = function () {
        // this.value = this.utils.storage
        // this.takescreenshot()
        //     this.utils.LoadPage.subscribe(data=>{
        // // this.ionViewDidLoad()
        //      })
        if (window.localStorage.getItem('mobile')) {
            this.usercontactNumber = window.localStorage.getItem('mobile');
        }
        else {
            this.usercontactNumber = '';
        }
    };
    TellUsifyouBuyitComponent.prototype.ionViewWillEnter = function () {
        // this.alertService.presentAlert("",'dgdsgd'+)
        if (this.utils.NFCsuccessmsg) {
            this.hidenfc = false;
        }
        else {
            this.hidenfc = true;
        }
    };
    TellUsifyouBuyitComponent.prototype.presentLoading = function () {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function () {
            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                this.loadingCtrl.create({
                    spinner: "lines"
                }).then(function (loading) {
                    loading.present();
                });
                return [2 /*return*/];
            });
        });
    };
    TellUsifyouBuyitComponent.prototype.closeModal = function () {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function () {
            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.modalController.dismiss()];
                    case 1:
                        _a.sent();
                        return [2 /*return*/];
                }
            });
        });
    };
    TellUsifyouBuyitComponent.prototype.takescreenshot = function () {
        var _this = this;
        this.hidebutton = false;
        setTimeout(function () {
            _this.screenshot.save('jpg', 80, 'myscreenshot.jpg').then(function (onSuccess) {
                _this.hidebutton = true;
                _this.alertService.presentAlert("", 'Screenshot done successfully');
            }, function (onError) {
                _this.alertService.presentAlert("", 'error');
            });
        }, 900);
    };
    TellUsifyouBuyitComponent.prototype.generateOTP = function () {
        this.showOTP = false;
        this.apiSvc.genetateOTP(this.usercontactNumber).subscribe(function (res) {
            // this.showOTP = true
        }, function (err) {
        });
    };
    TellUsifyouBuyitComponent.prototype.submitOTP = function () {
        var _this = this;
        var otpData = {
            otp: Number(this.mobileOTP),
            tagId: window.localStorage.getItem('tagId'),
            mobile: this.usercontactNumber
        };
        this.apiSvc.submitOTP(otpData).subscribe(function (res) {
            if (res.error == 1) {
                _this.alertService.presentAlert('', res.description);
            }
            else {
                // this.showOTP = false;
                _this.alertService.presentAlert('', 'Thank you so much for letting us know about your purchase. We wish you a great buying experience.');
                _this.modalController.dismiss();
                _this.router.navigateByUrl('/');
            }
        });
    };
    TellUsifyouBuyitComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_4__["Component"])({
            selector: 'app-tellusifyoubuyit',
            template: __webpack_require__(/*! ./tellusifyoubuyit.component.html */ "./src/app/Rentals Management/modals/tellusifyoubuyit/tellusifyoubuyit.component.html"),
            styles: [__webpack_require__(/*! ./tellusifyoubuyit.component.scss */ "./src/app/Rentals Management/modals/tellusifyoubuyit/tellusifyoubuyit.component.scss")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_ionic_angular__WEBPACK_IMPORTED_MODULE_3__["ModalController"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["LoadingController"],
            _services_notice_service__WEBPACK_IMPORTED_MODULE_2__["NoticeService"],
            _angular_router__WEBPACK_IMPORTED_MODULE_1__["Router"],
            src_app_common_services_alert_service_service__WEBPACK_IMPORTED_MODULE_5__["AlertServiceService"],
            _angular_router__WEBPACK_IMPORTED_MODULE_1__["ActivatedRoute"],
            _ionic_native_ionic_webview_ngx__WEBPACK_IMPORTED_MODULE_6__["WebView"],
            _services_utils_service__WEBPACK_IMPORTED_MODULE_8__["Utils"],
            src_app_common_services_translate_translate_service_service__WEBPACK_IMPORTED_MODULE_7__["translateService"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["ActionSheetController"],
            _ionic_native_screenshot_ngx__WEBPACK_IMPORTED_MODULE_9__["Screenshot"],
            _services_naila_service__WEBPACK_IMPORTED_MODULE_10__["NailaService"]])
    ], TellUsifyouBuyitComponent);
    return TellUsifyouBuyitComponent;
}());



/***/ })

}]);
//# sourceMappingURL=default~Rentals-Management-pages-verifyitProductinfo-verifyitProductinfo-module~Rentals-Management-p~8f8ff555.js.map