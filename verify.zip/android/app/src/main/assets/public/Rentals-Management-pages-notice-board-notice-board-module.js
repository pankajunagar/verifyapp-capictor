(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["Rentals-Management-pages-notice-board-notice-board-module"],{

/***/ "./src/app/Rentals Management/pages/notice-board/notice-board.module.ts":
/*!******************************************************************************!*\
  !*** ./src/app/Rentals Management/pages/notice-board/notice-board.module.ts ***!
  \******************************************************************************/
/*! exports provided: NoticeBoardPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "NoticeBoardPageModule", function() { return NoticeBoardPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _modals_create_notice_create_notice_component__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./../../modals/create-notice/create-notice.component */ "./src/app/Rentals Management/modals/create-notice/create-notice.component.ts");
/* harmony import */ var _ApplicationPageModule__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./../../ApplicationPageModule */ "./src/app/Rentals Management/ApplicationPageModule.ts");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var ngx_avatar__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ngx-avatar */ "./node_modules/ngx-avatar/fesm5/ngx-avatar.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _notice_board_page__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ./notice-board.page */ "./src/app/Rentals Management/pages/notice-board/notice-board.page.ts");










var routes = [
    {
        path: '',
        component: _notice_board_page__WEBPACK_IMPORTED_MODULE_9__["NoticeBoardPage"]
    }
];
var NoticeBoardPageModule = /** @class */ (function () {
    function NoticeBoardPageModule() {
    }
    NoticeBoardPageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["NgModule"])({
            entryComponents: [_modals_create_notice_create_notice_component__WEBPACK_IMPORTED_MODULE_1__["CreateNoticeComponent"]],
            imports: [
                _angular_common__WEBPACK_IMPORTED_MODULE_4__["CommonModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_5__["FormsModule"],
                _ionic_angular__WEBPACK_IMPORTED_MODULE_8__["IonicModule"],
                ngx_avatar__WEBPACK_IMPORTED_MODULE_7__["AvatarModule"],
                _ApplicationPageModule__WEBPACK_IMPORTED_MODULE_2__["ApplicationPageModule"],
                _angular_router__WEBPACK_IMPORTED_MODULE_6__["RouterModule"].forChild(routes)
            ],
            declarations: [_notice_board_page__WEBPACK_IMPORTED_MODULE_9__["NoticeBoardPage"]]
        })
    ], NoticeBoardPageModule);
    return NoticeBoardPageModule;
}());



/***/ }),

/***/ "./src/app/Rentals Management/pages/notice-board/notice-board.page.html":
/*!******************************************************************************!*\
  !*** ./src/app/Rentals Management/pages/notice-board/notice-board.page.html ***!
  \******************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ion-header>\r\n  <ion-toolbar color=\"primary\">\r\n    <ion-buttons slot=\"start\">\r\n      <ion-back-button></ion-back-button>\r\n    </ion-buttons>\r\n    <ion-title class=\"padding-0\" >{{transService.getTranslatedData('notice-board.title')}}</ion-title>\r\n  </ion-toolbar>\r\n</ion-header>\r\n<ion-content class=\"\">\r\n\r\n  <div>\r\n\r\n    <p class=\"center-text gotham\" *ngIf=\"notices.length==0\">\r\n      {{transService.getTranslatedData('notice-board.empty-array')}}</p>\r\n    <ion-card class=\"ticket-details-list padding-10\" [routerLink]=\"['/rentals-notice-details']\"\r\n      [queryParams]=\"{noticeId: notice._id}\" *ngFor=\"let notice of notices\">\r\n\r\n      <ion-row class=\"padding-top-5\">\r\n        <ion-col size=\"2\" class=\"padding-top-0\">\r\n          <ngx-avatar name=\"{{notice.createdBy?.firstName}} {{notice.createdBy?.lastName}}\"></ngx-avatar>\r\n        </ion-col>\r\n        <ion-col size=\"6\" class=\"margin-left-8\">\r\n          <p class=\"gotham-medium font-14 dark-grey margin-padding-zero\">{{notice.createdBy?.firstName}}\r\n            {{notice.createdBy?.lastName}}</p>\r\n          <p class=\"txt-warm-grey font-14 Gotham-medium margin-bottom-0 margin-top-5 font-weight-500 txt-nowrap\">\r\n            {{notice.listing?.block}} {{notice.listing?.door}} {{notice.listing?.block?notice.listing?.door?'-':'-':''}}  {{notice.createdBy?.types}}\r\n          </p>\r\n        </ion-col>\r\n        <ion-col class=\"text-right\">\r\n          <ion-badge color=\"warning\" *ngIf=\"notice.discussionType\" class=\"border-radius-10\">{{notice.discussionType}}\r\n          </ion-badge>\r\n          <p class=\"txt-warm-grey font-11 Gotham-medium margin-bottom-0 margin-padding-zero font-weight-500 txt-nowrap\">\r\n            {{notice.createdAt |agoFilter}}\r\n          </p>\r\n        </ion-col>\r\n      </ion-row>\r\n      <div class=\"padding-5\">\r\n        <p class=\"Gotham-medium font-14 font-weight-500 margin-bottom-5 dark-grey margin-top-5\">\r\n          {{notice.title}}\r\n        </p>\r\n        <p class=\"margin-bottom-0 margin-top-5 font-weight-500  txt-warm-grey font-14 Gotham-medium\" [innerHTML]=\"notice.body\"> \r\n        </p>\r\n      </div>\r\n\r\n      <ion-row class=\"center-text\" *ngIf=\"notice.files.length > 0\">\r\n        <br>\r\n        <ion-col class=\"display-flex justify-center\">\r\n          <img src=\"{{notice.files[0].aws_original_url}}\"\r\n            style=\"max-width:100%; max-height:250px !important; width:auto; height:auto;\">\r\n        </ion-col>\r\n        <br><br>\r\n      </ion-row>\r\n\r\n      <ion-grid (click)=\"stopEvent($event)\">\r\n        <ion-row>\r\n          <ion-col>\r\n            <span class=\"padding-right-20\">\r\n              <ion-icon *ngIf=\"!notice.hasLiked\" (click)=\"likeDiscussion(notice._id)\"\r\n                class=\"icon font-25 gotham margin-right-5\" name=\"heart-empty\"></ion-icon>\r\n              <ion-icon *ngIf=\"notice.hasLiked\" (click)=\"likeDiscussion(notice._id)\" color=\"danger\"\r\n                class=\"icon font-25 gotham margin-right-5\" name=\"heart-empty\"></ion-icon>\r\n              <span class=\"text font-20\">{{notice.likesCount}}</span>\r\n            </span>\r\n            <span class=\"padding-right-20\">\r\n              <ion-icon class=\"icon font-25 gotham margin-right-5\" name=\"eye\"></ion-icon>\r\n              <span class=\"text font-20\">{{notice.seenByCount}}</span>\r\n            </span>\r\n            <span class=\"padding-right-20\">\r\n              <ion-icon class=\"icon font-25 gotham margin-right-5\" name=\"chatboxes\"></ion-icon>\r\n              <span class=\"text font-20\">{{notice.commentCount}}</span>\r\n            </span>\r\n          </ion-col>\r\n          <!-- <ion-col size=\"4\">\r\n            <span class=\"font-25 Gotham float-right\">\r\n              <ion-icon name=\"trash\"></ion-icon>\r\n            </span>\r\n          </ion-col> -->\r\n        </ion-row>\r\n      </ion-grid>\r\n    </ion-card>\r\n\r\n    <ion-infinite-scroll [hidden]=\"disableInfiniteScroll\" threshold=\"5px\" (ionInfinite)=\"getNoices($event)\">\r\n      <ion-infinite-scroll-content loadingSpinner=\"bubbles\"\r\n        loadingText=\"{{transService.getTranslatedData('infinite-scroll')}}\">\r\n      </ion-infinite-scroll-content>\r\n    </ion-infinite-scroll>\r\n\r\n  </div>\r\n\r\n  <ion-fab (click)=\"openCreateNoticeModal()\" vertical=\"bottom\" horizontal=\"end\" slot=\"fixed\">\r\n    <ion-fab-button color=\"primary\">\r\n      <ion-icon name=\"add\"></ion-icon>\r\n    </ion-fab-button>\r\n  </ion-fab>\r\n</ion-content>"

/***/ }),

/***/ "./src/app/Rentals Management/pages/notice-board/notice-board.page.scss":
/*!******************************************************************************!*\
  !*** ./src/app/Rentals Management/pages/notice-board/notice-board.page.scss ***!
  \******************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "ion-content {\n  --ion-background-color: #ecebe6; }\n\n.icon {\n  display: inline-block;\n  vertical-align: middle; }\n\n.text {\n  display: inline-block;\n  vertical-align: middle; }\n\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvUmVudGFscyBNYW5hZ2VtZW50L3BhZ2VzL25vdGljZS1ib2FyZC9EOlxcbmF2am90XFx2ZXJpZnkvc3JjXFxhcHBcXFJlbnRhbHMgTWFuYWdlbWVudFxccGFnZXNcXG5vdGljZS1ib2FyZFxcbm90aWNlLWJvYXJkLnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNFLCtCQUF1QixFQUFBOztBQUV6QjtFQUNFLHFCQUFxQjtFQUNyQixzQkFBc0IsRUFBQTs7QUFHeEI7RUFDRSxxQkFBcUI7RUFDckIsc0JBQXNCLEVBQUEiLCJmaWxlIjoic3JjL2FwcC9SZW50YWxzIE1hbmFnZW1lbnQvcGFnZXMvbm90aWNlLWJvYXJkL25vdGljZS1ib2FyZC5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyJpb24tY29udGVudCB7XHJcbiAgLS1pb24tYmFja2dyb3VuZC1jb2xvcjogI2VjZWJlNjtcclxufVxyXG4uaWNvbiB7XHJcbiAgZGlzcGxheTogaW5saW5lLWJsb2NrO1xyXG4gIHZlcnRpY2FsLWFsaWduOiBtaWRkbGU7XHJcbn1cclxuXHJcbi50ZXh0IHtcclxuICBkaXNwbGF5OiBpbmxpbmUtYmxvY2s7XHJcbiAgdmVydGljYWwtYWxpZ246IG1pZGRsZTtcclxufVxyXG4iXX0= */"

/***/ }),

/***/ "./src/app/Rentals Management/pages/notice-board/notice-board.page.ts":
/*!****************************************************************************!*\
  !*** ./src/app/Rentals Management/pages/notice-board/notice-board.page.ts ***!
  \****************************************************************************/
/*! exports provided: NoticeBoardPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "NoticeBoardPage", function() { return NoticeBoardPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _services_notice_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../services/notice.service */ "./src/app/Rentals Management/services/notice.service.ts");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _notice_create_notice_create_page__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../notice-create/notice-create.page */ "./src/app/Rentals Management/pages/notice-create/notice-create.page.ts");
/* harmony import */ var src_app_common_services_alert_service_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! src/app/common-services/alert-service.service */ "./src/app/common-services/alert-service.service.ts");
/* harmony import */ var _modals_create_notice_create_notice_component__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../../modals/create-notice/create-notice.component */ "./src/app/Rentals Management/modals/create-notice/create-notice.component.ts");
/* harmony import */ var src_app_common_services_translate_translate_service_service__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! src/app/common-services/translate/translate-service.service */ "./src/app/common-services/translate/translate-service.service.ts");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");









var NoticeBoardPage = /** @class */ (function () {
    function NoticeBoardPage(noticeService, loading, modalController, alertService, transService, router) {
        this.noticeService = noticeService;
        this.loading = loading;
        this.modalController = modalController;
        this.alertService = alertService;
        this.transService = transService;
        this.router = router;
        this.notices = [];
        this.disableInfiniteScroll = false;
        this.filterData = {
            skip: 0
        };
    }
    NoticeBoardPage.prototype.ngOnInit = function () {
    };
    NoticeBoardPage.prototype.ionViewDidEnter = function () {
        this.filterData.skip = 0;
        this.notices = [];
        this.disableInfiniteScroll = false;
        this.getNoices('');
    };
    NoticeBoardPage.prototype.presentLoading = function () {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function () {
            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.loading.create({
                            spinner: "lines"
                        }).then(function (loading) {
                            loading.present();
                        })];
                    case 1:
                        _a.sent();
                        return [2 /*return*/];
                }
            });
        });
    };
    NoticeBoardPage.prototype.getNoices = function (event) {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function () {
            var _this = this;
            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                switch (_a.label) {
                    case 0:
                        if (!!event) return [3 /*break*/, 2];
                        return [4 /*yield*/, this.presentLoading()];
                    case 1:
                        _a.sent();
                        _a.label = 2;
                    case 2:
                        this.noticeService.getNotices(this.filterData)
                            .subscribe(function (data) {
                            _this.notices = _this.notices.concat(data.data.data);
                            _this.filterData.skip = data.data.query.skip + 5;
                            console.log(_this.notices);
                            event ? event.target.complete() : _this.loading.dismiss();
                            if (data.data.query.current >= data.data.query.total) {
                                _this.disableInfiniteScroll = true;
                            }
                        }, function (err) { return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](_this, void 0, void 0, function () {
                            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                                switch (_a.label) {
                                    case 0: return [4 /*yield*/, this.loading.dismiss()];
                                    case 1:
                                        _a.sent();
                                        console.log(err);
                                        if (err.error == "You don't have permission for this operation!") {
                                            this.alertService.presentAlert('', "You don't have permission for this operation!");
                                            this.router.navigateByUrl('rentals-home');
                                        }
                                        else {
                                            this.alertService.presentAlert(this.transService.getTranslatedData('alert-title'), err.error.error);
                                        }
                                        return [2 /*return*/];
                                }
                            });
                        }); });
                        return [2 /*return*/];
                }
            });
        });
    };
    NoticeBoardPage.prototype.changeLikeIcon = function (id) {
        this.notices.map(function (item) {
            if (item._id === id) {
                item.hasLiked = !item.hasLiked;
                if (item.hasLiked === false) {
                    item.likesCount = item.likesCount - 1;
                }
                else if (item.hasLiked === true) {
                    item.likesCount = item.likesCount + 1;
                }
            }
        });
    };
    NoticeBoardPage.prototype.openCreateNoticeModal = function () {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function () {
            var modal;
            var _this = this;
            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.modalController.create({
                            component: _modals_create_notice_create_notice_component__WEBPACK_IMPORTED_MODULE_6__["CreateNoticeComponent"]
                        })];
                    case 1:
                        modal = _a.sent();
                        modal.onDidDismiss().then(function (data) {
                            if (data.data === true) {
                                console.log(data.data);
                                _this.notices = [];
                                _this.filterData.skip = 0;
                                _this.getNoices('');
                            }
                        });
                        return [4 /*yield*/, modal.present()];
                    case 2: return [2 /*return*/, _a.sent()];
                }
            });
        });
    };
    NoticeBoardPage.prototype.stopEvent = function (event) {
        event.preventDefault();
        event.stopPropagation();
    };
    NoticeBoardPage.prototype.likeDiscussion = function (id) {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function () {
            var _this = this;
            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.presentLoading()];
                    case 1:
                        _a.sent();
                        this.noticeService.likeNotice(id)
                            .subscribe(function (data) {
                            _this.changeLikeIcon(id);
                            _this.loading.dismiss();
                        }, function (err) {
                            _this.loading.dismiss();
                            _this.alertService.presentAlert(_this.transService.getTranslatedData('alert-title'), err.error.error);
                        });
                        return [2 /*return*/];
                }
            });
        });
    };
    NoticeBoardPage.prototype.openNoticeCreateModal = function () {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function () {
            var modal;
            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.modalController.create({
                            component: _notice_create_notice_create_page__WEBPACK_IMPORTED_MODULE_4__["NoticeCreatePage"],
                            componentProps: { value: 123 }
                        })];
                    case 1:
                        modal = _a.sent();
                        return [4 /*yield*/, modal.present()];
                    case 2: return [2 /*return*/, _a.sent()];
                }
            });
        });
    };
    NoticeBoardPage.prototype.closeModal = function () {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function () {
            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.modalController.dismiss()];
                    case 1:
                        _a.sent();
                        return [2 /*return*/];
                }
            });
        });
    };
    NoticeBoardPage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-notice-board',
            template: __webpack_require__(/*! ./notice-board.page.html */ "./src/app/Rentals Management/pages/notice-board/notice-board.page.html"),
            styles: [__webpack_require__(/*! ./notice-board.page.scss */ "./src/app/Rentals Management/pages/notice-board/notice-board.page.scss")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_services_notice_service__WEBPACK_IMPORTED_MODULE_2__["NoticeService"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["LoadingController"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["ModalController"],
            src_app_common_services_alert_service_service__WEBPACK_IMPORTED_MODULE_5__["AlertServiceService"],
            src_app_common_services_translate_translate_service_service__WEBPACK_IMPORTED_MODULE_7__["translateService"],
            _angular_router__WEBPACK_IMPORTED_MODULE_8__["Router"]])
    ], NoticeBoardPage);
    return NoticeBoardPage;
}());



/***/ })

}]);
//# sourceMappingURL=Rentals-Management-pages-notice-board-notice-board-module.js.map