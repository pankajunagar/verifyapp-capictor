(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["Rentals-Management-pages-nailacart-nailacart-module"],{

/***/ "./src/app/Rentals Management/pages/nailacart/nailabooking.ts":
/*!********************************************************************!*\
  !*** ./src/app/Rentals Management/pages/nailacart/nailabooking.ts ***!
  \********************************************************************/
/*! exports provided: NailaCartPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "NailaCartPage", function() { return NailaCartPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _services_naila_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../services/naila.service */ "./src/app/Rentals Management/services/naila.service.ts");
/* harmony import */ var _services_utils_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../services/utils.service */ "./src/app/Rentals Management/services/utils.service.ts");
/* harmony import */ var _modals_approvalpopup_approvalpopup_component__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../../modals/approvalpopup/approvalpopup.component */ "./src/app/Rentals Management/modals/approvalpopup/approvalpopup.component.ts");







var NailaCartPage = /** @class */ (function () {
    function NailaCartPage(loadingCtrl, nailaservice, utils, popOver, router, platform) {
        this.loadingCtrl = loadingCtrl;
        this.nailaservice = nailaservice;
        this.utils = utils;
        this.popOver = popOver;
        this.router = router;
        this.platform = platform;
        this.paymentAmount = 0;
        this.currency = 'INR';
        this.currencyIcon = '₹';
        this.razor_key = 'rzp_live_4c3CzCuqiz6qHi';
        this.cardDetails = {};
        this.totalNumberofMinutes = 0;
        this.a = false;
        this.searchTerm = "";
        this.partialcoupon = false;
        this.foundcoupon = false;
        this.servicecount = 0;
        this.servicediscount = 0;
        this.cart = [];
        this.hidecartscreen = true;
        this.todaysdate = new Date();
        this.beauticiandata = [];
        this.items = [
            { title: "one" },
            { title: "two" },
            { title: "three" },
            { title: "four" },
            { title: "five" },
            { title: "six" }
        ];
        this.count = 0;
        this.itemcounter = 0;
        this.temp3 = {
            data: ''
        };
        // this.apartmentList = {
        //   id: 0,
        //   name: "BILLPAYMENT",
        //   value: "Wallet_1002"
        // };
    }
    NailaCartPage.prototype.presentLoading = function () {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function () {
            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.loadingCtrl.create({
                            spinner: "lines"
                        }).then(function (loading) {
                            loading.present();
                        })];
                    case 1:
                        _a.sent();
                        return [2 /*return*/];
                }
            });
        });
    };
    NailaCartPage.prototype.ngOnInit = function () {
        var _this_1 = this;
        var myDate = new Date(new Date().getTime() + (2 * 24 * 60 * 60 * 1000));
        var date = new Date();
        this.currentmindate = this.formatDate(date);
        this.currentplusthreedays = this.formatDate(myDate);
        if (window.localStorage.getItem('apartment_name')) {
            this.flat = window.localStorage.getItem('apartment_name');
        }
        else {
            this.flat = 'Select apartment';
        }
        window.localStorage.getItem('apartment_id');
        this.nailaservice.apartmentList().subscribe(function (data) {
            _this_1.apartmentList = data;
            _this_1.items = data;
            _this_1.apartmentList.forEach(function (element) {
                if (window.localStorage.getItem('apartment_id') === element.id) {
                    _this_1.selectedapartment = element.name;
                }
            });
        });
        this.setFilteredItems();
        var user_id = window.localStorage.getItem('user_id');
        this.utils.cartitem = JSON.parse(window.localStorage.getItem('cartitem'));
        if (window.localStorage.getItem('cartitemcount')) {
            this.utils.cartdata = window.localStorage.getItem('cartitemcount');
        }
        else {
            this.utils.cartdata = [];
        }
        if (this.utils.cartitem) {
            this.temp = (this.utils.cartitem.reduce(function (acc, val) {
                if (!acc.find(function (el) { return el.service.name === val.service.name && val.servicecount == 0; })) {
                    acc.push(val);
                }
                return acc;
            }, []));
            this.calculatePrice('');
            this.calculateMinute();
        }
    };
    NailaCartPage.prototype.setFilteredItems = function () {
        this.items = this.filterItems(this.searchTerm);
    };
    NailaCartPage.prototype.filterItems = function (searchTerm) {
        return this.items.filter(function (item) {
            return item.title.toLowerCase().indexOf(searchTerm.toLowerCase()) > -1;
        });
    };
    NailaCartPage.prototype.itemCounter = function (plusminus, data) {
        this.temp.forEach(function (element, i, object) {
            if (element.servicecount == 0)
                object.splice(i, 1);
        });
        if (plusminus == "plus" && data.servicecount >= 0) {
            this.temp.forEach(function (element) {
                if (element.service.name === data.service.name) {
                    data.servicecount = data.servicecount + 1;
                    // element.servicecount = this.itemcounter;
                    // this.calculatePrice()
                }
            });
        }
        else if (plusminus == "minus" && data.servicecount > 0) {
            this.temp.forEach(function (element, i, object) {
                if (element.service.name === data.service.name) {
                    data.servicecount = data.servicecount - 1;
                }
            });
        }
        // this.temp=this.temp3
        this.temp = (this.utils.cartitem.reduce(function (acc, val) {
            if (!acc.find(function (el) { return el.service.name === val.service.name && val.servicecount == 0; })) {
                acc.push(val);
            }
            return acc;
        }, []));
        window.localStorage.setItem('cartitem', JSON.stringify(this.temp));
        this.calculatePrice('');
        this.calculateMinute();
        this.calculateItemcount();
        if (this.coupon) {
            this.applyCoupon(this.coupon);
        }
    };
    NailaCartPage.prototype.calculateItemcount = function () {
        var _this_1 = this;
        this.cartitemcounter = 0;
        this.temp.forEach(function (element) {
            _this_1.cartitemcounter = element.servicecount + _this_1.cartitemcounter;
        });
        if (this.cartitemcounter <= 0) {
            window.localStorage.removeItem('cartitemcount');
            window.localStorage.removeItem('cartitem');
            this.utils.cartitem = false;
        }
        else {
            window.localStorage.setItem('cartitemcount', this.cartitemcounter);
        }
    };
    NailaCartPage.prototype.calculatePrice = function (manualcoupon) {
        var _this_1 = this;
        this.partialcoupon = true;
        this.servicecount = 0;
        this.servicediscount = 0;
        var swap = [this.totalprice];
        this.coupontemp = swap.slice();
        this.totalprice = 0;
        var totalitem = JSON.parse(window.localStorage.getItem('cartitem'));
        totalitem.forEach(function (serviceElement) {
            // if (element.service.coupons.length && element.service.coupons[0].is_active && element.service.coupons[0].coupon_type == 'percent') {
            //   this.itemDiscount = element.service.offer_price * (element.service.coupons[0].value / 100);
            //   this.itemPrice = element.service.offer_price - this.itemDiscount
            //   this.totalprice = (Number(this.itemPrice) * element.servicecount + Number(this.totalprice))
            // } else if (element.service.coupons.length && element.service.coupons[0].is_active && element.service.coupons[0].coupon_type == 'fixed_value') {
            //   this.itemDiscount = element.service.coupons[0].value
            //   this.itemPrice = element.service.offer_price - this.itemDiscount
            //   this.totalprice = (Number(this.itemPrice) * element.servicecount + Number(this.totalprice))
            // }      else 
            // serviceElement.forEach(element => {
            //   if(element.id)
            // });
            _this_1.foundcoupon = false;
            // this.partialcoupon=false
            if (manualcoupon && manualcoupon.coupon_type == 'percent' && serviceElement.service.coupons.length) {
                debugger;
                serviceElement.service.coupons.forEach(function (element) {
                    if (element.id == manualcoupon.id && element.name.toLowerCase() == manualcoupon.name.toLowerCase()) {
                        _this_1.foundcoupon = true;
                        _this_1.partialcoupon = true;
                        _this_1.discount = serviceElement.service.offer_price * (manualcoupon.value / 100);
                        _this_1.servicediscount = _this_1.discount * serviceElement.servicecount + _this_1.servicediscount;
                        _this_1.servicecount = _this_1.servicecount + serviceElement.servicecount;
                        _this_1.itemPrice = serviceElement.service.offer_price - _this_1.discount;
                        _this_1.totalprice = (Number(_this_1.itemPrice) * serviceElement.servicecount + Number(_this_1.totalprice));
                    }
                });
                if (!_this_1.foundcoupon) {
                    _this_1.totalprice = Number(serviceElement.service.offer_price) * serviceElement.servicecount + Number(_this_1.totalprice);
                    _this_1.partialcoupon = true;
                }
            }
            else if (manualcoupon && manualcoupon.coupon_type == 'fixed_value' && serviceElement.service.coupons.length) {
                serviceElement.service.coupons.forEach(function (element) {
                    if (element.id == manualcoupon.id && element.name.toLowerCase() == manualcoupon.name.toLowerCase()) {
                        _this_1.foundcoupon = true;
                        _this_1.partialcoupon = true;
                        _this_1.discount = manualcoupon.value;
                        _this_1.servicediscount = _this_1.discount * serviceElement.servicecount + _this_1.servicediscount;
                        // this.servicecount= this.servicecount + 
                        _this_1.itemPrice = serviceElement.service.offer_price - _this_1.discount;
                        _this_1.totalprice = (Number(_this_1.itemPrice) * serviceElement.servicecount + Number(_this_1.totalprice));
                    }
                });
                if (!_this_1.foundcoupon) {
                    _this_1.totalprice = Number(serviceElement.service.offer_price) * serviceElement.servicecount + Number(_this_1.totalprice);
                    // this.partialcoupon=true
                }
            }
            else {
                _this_1.totalprice = Number(serviceElement.service.offer_price) * serviceElement.servicecount + Number(_this_1.totalprice);
                _this_1.totalprice.toFixed(2);
                if (manualcoupon && !_this_1.partialcoupon && !_this_1.foundcoupon) {
                    alert('This coupon is not applicable on this service.');
                    _this_1.coupon = '';
                }
            }
            _this_1.cgst = _this_1.totalprice * 0.09;
            _this_1.sgst = _this_1.totalprice * 0.09;
        });
        // this.totalprice = cgst + sgst + this.totalprice;
        // if (manualcoupon && !this.foundcoupon) {
        //   this.totalprice = this.coupontemp[0];
        //   this.totalprice = Number(this.totalprice).toFixed(2)
        //   alert('This coupon is not applicable on this service.')
        //   this.coupon = ''
        // }
    };
    NailaCartPage.prototype.applyCoupon = function (data) {
        var _this_1 = this;
        this.nailaservice.applyCoupon(data).subscribe(function (item) {
            _this_1.coupondetail = item;
            window.localStorage.setItem('coupon_id', _this_1.coupondetail.id);
            if (_this_1.coupondetail.is_active) {
                _this_1.calculatePrice(_this_1.coupondetail);
            }
            else {
                // this.totalprice = this.coupontemp[0];
                // this.totalprice = Number(this.totalprice).toFixed(2)
                alert('This coupon is not applicable on this service.');
                _this_1.coupon = '';
            }
            // if (this.coupondetail.coupon_type == 'percent' && item) {
            //   this.discount = this.totalprice * (this.coupondetail.value / 100)
            //   this.totalprice = this.totalprice - this.discount
            // } else {
            //   this.totalprice = this.totalprice - this.coupondetail.value
            // }
        }, function (err) {
            alert('This coupon is not applicable on this service.');
            _this_1.coupon = '';
        });
    };
    NailaCartPage.prototype.removeCoupon = function () {
        this.totalprice = Number(this.totalprice) + Number(this.servicediscount);
        this.totalprice = this.totalprice.toFixed(2);
        this.discount = '';
        this.coupon = '';
    };
    NailaCartPage.prototype.calculateMinute = function () {
        var _this_1 = this;
        this.totalNumberofMinutes = 0;
        this.temp.forEach(function (element) {
            _this_1.totalNumberofMinutes = (element.service.no_of_minuties * element.servicecount) + _this_1.totalNumberofMinutes;
        });
        console.log("=================", this.totalNumberofMinutes, "======================================");
        this.slotdata = {
            "apartment_id": window.localStorage.getItem('apartment_id'),
            "no_of_minites": this.totalNumberofMinutes
        };
        var selectedapartment = this.slotdata;
        // this.getAvailabaleSlot(selectedapartment);
    };
    NailaCartPage.prototype.getAvailabaleSlot = function (event) {
        var _this_1 = this;
        this.beauticiandata = [];
        debugger;
        if (event.selected_date) {
            this.slotdate = event.selected_date.toDateString().split("T");
        }
        else {
            this.slotdate = event.split("T")[0];
        }
        this.selectedapartment = window.localStorage.getItem('apartment_id');
        var data = {
            "apartment_id": this.selectedapartment,
            "no_of_minites": this.totalNumberofMinutes,
            "selected_date": this.slotdate
        };
        if (data.apartment_id && data.no_of_minites) {
            this.nailaservice.getAvailbleSlots(data).subscribe(function (data) {
                _this_1.beauticiandata = data;
            });
        }
    };
    NailaCartPage.prototype.selectedbeautician = function (data) {
        debugger;
        console.log(data.target.value);
        this.selectedBeauticiandata = data.target.value;
        this.scheduledondate = data.target.value.start_datetime;
        this.scheduledend_datetime = data.target.value.start_datetime;
    };
    NailaCartPage.prototype.createBooking = function (paymentid, status, selectedmodeofpayment) {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function () {
            var temp, data;
            var _this_1 = this;
            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                this.presentLoading();
                temp = this.temp.filter(function (element) {
                    return (element.servicecount > 0);
                });
                temp.forEach(function (element) {
                    _this_1.cart.push({
                        "service_id": element.service.id,
                        "quantity": element.servicecount
                    });
                });
                try {
                    data = {
                        "apartment_id": Number(window.localStorage.getItem('apartment_id')),
                        "user_id": Number(window.localStorage.getItem('user_id')),
                        "beautician_id": this.selectedBeauticiandata.beauticians[0],
                        "total_amount": this.totalprice,
                        "c_gst": this.cgst,
                        "s_gst": this.sgst,
                        "address": this.selectedaddress,
                        "flat_no": this.selectedflat,
                        "schedule_on": this.scheduledondate,
                        "schedule_till": this.scheduledend_datetime,
                        "total_no_of_minutes": this.totalNumberofMinutes,
                        "payment_status": status,
                        "payment_mode": selectedmodeofpayment,
                        "payment_id": paymentid,
                        "transaction_id": '',
                        "coupon_id": window.localStorage.getItem('coupon_id'),
                        "services": this.cart
                    };
                    this.nailaservice.createBooking(data).subscribe(function (data) {
                        _this_1.loadingCtrl.dismiss();
                        _this_1.router.navigateByUrl('/rentals-naila-search-page');
                        alert('Your booking has been done successfully.');
                        window.localStorage.removeItem('cartitem');
                        window.localStorage.removeItem('cartitemcount');
                        // this.hidecartscreen=false;
                    }, function (err) {
                        // this.router.navigateByUrl('/rentals-naila-search-page')
                        alert("something went wrong");
                        // window.localStorage.removeItem('cartitem')	
                        // window.localStorage.removeItem('cartitemcount')	
                    });
                }
                catch (e) {
                    console.log("error => ", e.response);
                }
                return [2 /*return*/];
            });
        });
    };
    NailaCartPage.prototype.presentPopover = function () {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function () {
            var popOver;
            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.popOver.create({
                            component: _modals_approvalpopup_approvalpopup_component__WEBPACK_IMPORTED_MODULE_6__["ApprovalpopupComponent"],
                            backdropDismiss: false,
                            componentProps: {
                                val: ''
                            }
                        })];
                    case 1:
                        popOver = _a.sent();
                        popOver.onDidDismiss().then(function (data) {
                            if (data.data) {
                                if (data.data.val == 'approve') {
                                    // this.approvalUser(id)
                                }
                                else if (data.data.val == 'reject') {
                                    // this.rejectUser(id, data.data.notes)
                                }
                            }
                        });
                        return [4 /*yield*/, popOver.present()];
                    case 2: return [2 /*return*/, _a.sent()];
                }
            });
        });
    };
    NailaCartPage.prototype.selectedApartment = function (event) {
        debugger;
        this.selectedapartment = event.target.value.id;
        var slectedbuilding = window.localStorage.setItem('apartment_id', this.selectedapartment);
        // this.slotdata = {
        //   "apartment_id": window.localStorage.getItem('apartment_id'),
        //   "no_of_minites": this.totalNumberofMinutes,
        //   "selected_date": this.todaysdate
        // }
        var selectedapartment = this.slotdata;
        this.date = '';
        this.selecteddate = '';
        this.beauticiandata = [];
        // this.getAvailabaleSlot(selectedapartment);
    };
    NailaCartPage.prototype.payWithRazor = function () {
        var _this = this;
        var options = {
            description: 'Naila app product of Mayuri International group.',
            image: 'https://naila-proj.s3.ap-south-1.amazonaws.com/production/uploads/Assets/razorpaynailalogo.png',
            currency: this.currency,
            key: this.razor_key,
            amount: this.totalprice * 100,
            name: 'Naila Beauty Redefined',
            theme: {
                color: '#000000'
            },
            modal: {
                ondismiss: function () {
                    alert('dismissed');
                }
            }
        };
        var successCallback = function (payment_id) {
            _this.createBooking(payment_id, 'online_paid', 'online');
        };
        var cancelCallback = function (error) {
            // this.selectedmodeofpayment="by_cash"
            _this.createBooking('No payment id', 'Not paid', 'by_cash');
        };
        RazorpayCheckout.open(options, successCallback, cancelCallback);
    };
    NailaCartPage.prototype.ionViewWillLeave = function () {
        var _this_1 = this;
        window.localStorage.removeItem('coupon_id');
        this.cartitemcounter = 0;
        this.utils.cartitem = JSON.parse(window.localStorage.getItem('cartitem'));
        this.locatemp = this.utils.cartitem;
        if (!this.utils.cartitem) {
            this.utils.cartitem = [];
        }
        var filtercartitem = this.utils.cartitem.filter(function (element) {
            return (element.servicecount > 0);
        });
        if (filtercartitem.length) {
            filtercartitem.forEach(function (element) {
                _this_1.cartitemcounter = element.servicecount + _this_1.cartitemcounter;
            });
            window.localStorage.setItem('cartitem', JSON.stringify(filtercartitem));
            window.localStorage.setItem('cartitemcount', this.cartitemcounter);
        }
    };
    NailaCartPage.prototype.formatDate = function (date) {
        var d = new Date(date), day = '' + d.getDate(), month = '' + (d.getMonth() + 1), year = d.getFullYear();
        if (month.length < 2)
            month = '0' + month;
        if (day.length < 2)
            day = '0' + day;
        return [year, month, day].join('-');
    };
    NailaCartPage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-nailacart',
            template: __webpack_require__(/*! ./nailacart.html */ "./src/app/Rentals Management/pages/nailacart/nailacart.html"),
            styles: [__webpack_require__(/*! ./nailacart.scss */ "./src/app/Rentals Management/pages/nailacart/nailacart.scss")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_ionic_angular__WEBPACK_IMPORTED_MODULE_2__["LoadingController"], _services_naila_service__WEBPACK_IMPORTED_MODULE_4__["NailaService"], _services_utils_service__WEBPACK_IMPORTED_MODULE_5__["Utils"], _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["PopoverController"], _angular_router__WEBPACK_IMPORTED_MODULE_3__["Router"], _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["Platform"]])
    ], NailaCartPage);
    return NailaCartPage;
}());



/***/ }),

/***/ "./src/app/Rentals Management/pages/nailacart/nailacart.html":
/*!*******************************************************************!*\
  !*** ./src/app/Rentals Management/pages/nailacart/nailacart.html ***!
  \*******************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ion-header no-border>\r\n  <ion-toolbar color=\"primary\">\r\n    <ion-buttons slot=\"start\">\r\n      <ion-menu-button></ion-menu-button>\r\n    </ion-buttons>\r\n    <!-- <ion-buttons slot=\"end\" expand=\"full\" class=\"ion-button\" (click)=\"openScanner()\">\r\n      <ion-button style=\"color: black\">\r\n          <img src=\"../../../../assets/icons.png\" width=\"30px\" height=\"30px\"/>\r\n      </ion-button>\r\n    </ion-buttons> -->\r\n\r\n    <ion-title style=\"display: inline-flex;\r\n    vertical-align: -webkit-baseline-middle;\">Salon at Home</ion-title>\r\n\r\n    <ion-buttons  routerLink=\"/rentals-naila-search-page\" style=\"float:right;outline: none;\r\n    zoom:2;\" end>\r\n      <ion-icon style=\"margin-right: 3vw;\" ios=\"ios-home\" md=\"md-home\"></ion-icon>\r\n      <!-- <p *ngIf=\"this.utils.cartdata.length\" class=\"cart-number\">{{this.utils.cartdata}}</p> -->\r\n    </ion-buttons>\r\n  </ion-toolbar>\r\n</ion-header>\r\n\r\n<!-- {{temp.length}} -->\r\n<ion-content *ngIf=\"this.utils.cartitem\" padding>\r\n  <ion-row *ngFor=\"let item of temp\">\r\n    <div style=\"\r\n    width: 100% !important;\r\n    display: flex !important;\"\r\n    *ngIf=\"item.servicecount\">\r\n      <ion-col size=\"3\">\r\n        <img class=\"float-left\" style=\"width: 100px;\r\n          height: 45px;\r\n          margin-top: 5px;\r\n          position: absolute;\r\n          border-radius: 5px;\" src={{item.service.image.url}} alt=\"\">\r\n      </ion-col>\r\n      <ion-col size=\"9\">\r\n\r\n\r\n        <ion-list class=\"padding-bottom-0\">\r\n          <ion-item lines=\"none\">\r\n            <ion-label style=\"text-align: start;\" class=\"margin-0\">\r\n              <p class=\"gotham-medium\" text-wrap>\r\n                <small class=\"float-left font-weight-600 text-black\">{{item.service.name}}</small>\r\n                <!-- <span class=\"center-text\"> hello</span>-->\r\n              </p>\r\n              <small class=\"font-10  txt-grey\">\r\n                {{item.service.no_of_minuties}} min\r\n              </small>\r\n            </ion-label>\r\n            <!-- <small class=\"float-right gotham\">Rs.900</small>  -->\r\n            <!-- <ion-label style=\"text-align: end;     padding-right: 10px;\" class=\"margin-0 \"> -->\r\n            <!-- <p class=\"gotham-medium\" text-wrap>\r\n              <small class=\"font-10\">15|02|2020</small>\r\n            <span class=\"center-text\"> hello</span>-->\r\n            <!-- </p>\r\n            <small class=\"font-10 txt-grey\">\r\n              Rs. 900\r\n            </small> -->\r\n\r\n            <ion-item class=\"center-text\" lines=\"none\">\r\n              <ion-icon (click)=\"itemCounter('minus',item)\" name=\"remove-circle\" style=\"zoom: 1.1;color: black;\">\r\n                </ion-icon>\r\n              <p class=\"add-sub\">{{item.servicecount}}</p>\r\n                <ion-icon (click)=\"itemCounter('plus',item)\" name=\"add-circle\" style=\"zoom: 1.1; color: black;\">\r\n                </ion-icon>\r\n              <!-- <button ion-button (click)=\"addCart()\">Add to cart</button> -->\r\n            </ion-item>\r\n            <!-- </ion-label> -->\r\n            <!-- <small class=\"float-right gotham\">Details</small>  -->\r\n\r\n          </ion-item>\r\n        </ion-list>\r\n\r\n      </ion-col>\r\n    </div>\r\n  </ion-row>\r\n\r\n  <!-- <hr> -->\r\n\r\n  <ion-row class=\"margin-top-25\">\r\n    <ion-col size=\"6\">\r\n      <ion-input [(ngModel)]=\"coupon\" style=\"border-radius: 6px;\r\n      background: #F0F0F0;\"></ion-input>\r\n    </ion-col>\r\n\r\n    <ion-col size=\"6\">\r\n      <ion-button *ngIf=\"!discount\" (click)=\"applyCoupon(coupon)\" class=\"float-right font-10 margin-top-0\">Apply Coupon\r\n      </ion-button>\r\n      <ion-button *ngIf=\"discount\" (click)=\"removeCoupon()\" class=\"float-right font-10 margin-top-0 danger-button\">\r\n        Remove Coupon</ion-button>\r\n\r\n    </ion-col>\r\n\r\n  </ion-row>\r\n  <ion-row>\r\n    <ion-col size=\"6\">\r\n\r\n\r\n      <ion-list style=\"margin-left: -15px;\">\r\n        <ion-item style=\"height: 50px;\r\n       \r\n        width: 100%;\" lines=\"none\">\r\n          <ion-label class=\"cart-details\">Total Price</ion-label>\r\n          <!-- <small>(included of 9% cgst and sgst)</small> -->\r\n        </ion-item>\r\n        <ion-item style=\"height: 44px;\" lines=\"none\">\r\n          <ion-label class=\"cart-details\">Total Time</ion-label>\r\n        </ion-item>\r\n        <ion-item style=\"height: 44px;\" lines=\"none\">\r\n          <ion-label class=\"cart-details\">Payment Method</ion-label>\r\n        </ion-item>\r\n        <ion-item style=\"height: 44px;\" lines=\"none\">\r\n          <ion-label class=\"cart-details\">Select Apartment</ion-label>\r\n        </ion-item>\r\n\r\n        <ion-item style=\"height: 44px;\" lines=\"none\">\r\n          <ion-label class=\"cart-details\">Address</ion-label>\r\n        </ion-item>\r\n        <ion-item style=\"height: 44px;\" lines=\"none\">\r\n          <ion-label class=\"cart-details\">Flat No</ion-label>\r\n        </ion-item>\r\n        <ion-item style=\"height: 44px;\" lines=\"none\">\r\n          <ion-label class=\"cart-details\">Select Date</ion-label>\r\n        </ion-item>\r\n        <ion-item style=\"height: 44px;\" lines=\"none\">\r\n          <ion-label class=\"cart-details\">Select Time slot</ion-label>\r\n        </ion-item>\r\n        <!-- <ion-item style=\"height: 44px;\" lines=\"none\">\r\n                    <ion-label class=\"cart-details\">Super Mario World</ion-label>\r\n                  </ion-item> -->\r\n      </ion-list>\r\n\r\n    </ion-col>\r\n\r\n    <ion-col size=\"6\">\r\n      <ion-list>\r\n        <ion-item style=\"height: 44px;\r\n       height: 50px;\r\n    float: right;\r\n    text-align: end;\r\n    width: 100%;\" lines=\"none\">\r\n          <ion-label class=\"cart-details\">Rs.{{totalprice| number}}</ion-label>\r\n        </ion-item>\r\n        <br>\r\n        <small style=\"    float: right;\r\n        text-align: end;\r\n        width: 100%;\r\n        font-size: 8px;\r\n        position: absolute;\r\n        top: 10vw;\">(*GST included 18%.)</small>\r\n        <br>\r\n        <ion-item style=\"height: 44px; float:right\" lines=\"none\">\r\n          <ion-label class=\"cart-details\">{{totalNumberofMinutes}} min</ion-label>\r\n        </ion-item>\r\n\r\n        <ion-item style=\"height: 44px; float:right\" lines=\"none\">\r\n          <ion-select [(ngModel)]=\"selectedmodeofpayment\" style=\"border-radius: 6px;\r\n    background: #F0F0F0;\r\n        height: 33px;\r\n    float: right;\r\n    min-width: 123px;\r\n    width: 123px;\r\n    font-size: 9px;\" placeholder=\"Select One\">\r\n            <ion-select-option value=\"online\">Online</ion-select-option>\r\n            <ion-select-option value=\"by_cash\">Cash</ion-select-option>\r\n          </ion-select>\r\n        </ion-item>\r\n        <ion-item style=\"height: 44px; float:right\" lines=\"none\">\r\n          <ion-select  (ionChange)=\"selectedApartment($event)\" [(ngModel)]=\"flat\"  style=\"border-radius: 6px;\r\n          background: #F0F0F0;\r\n          height: 33px;\r\n          float: right;\r\n          min-width: 123px;\r\n          width: 123px;\r\n          font-size: 9px;\" placeholder={{flat}}>\r\n            <ion-select-option (ionSelect)=\"selectedApartment(flat)\" *ngFor=\"let flat of apartmentList\" [value]=\"flat\">\r\n              {{flat.name}}</ion-select-option>\r\n          </ion-select>\r\n        </ion-item>\r\n\r\n\r\n        <ion-item style=\"height: 44px; float:right\" lines=\"none\">\r\n\r\n\r\n          <ion-input placeholder=\"Enter Address\" [(ngModel)]=\"selectedaddress\" style=\"border-radius: 6px;\r\n          background: #F0F0F0;\r\n          height: 33px;\r\n          min-width: 123px;\r\n          width: 123px;\r\n          font-size: 9px;\r\n          padding-left: 17px !important;\r\n          float: right;\">\r\n          </ion-input>\r\n        </ion-item>\r\n\r\n        <ion-item style=\"height: 44px; float:right\" lines=\"none\">\r\n\r\n\r\n          <ion-input placeholder=\"Enter Flat\" [(ngModel)]=\"selectedflat\" style=\"border-radius: 6px;\r\n          background: #F0F0F0;\r\n          height: 33px;\r\n          font-size: 9px;\r\n          min-width: 123px;\r\n          width: 123px;\r\n          padding-left: 17px !important;\r\n          float: right;\">\r\n          </ion-input>\r\n        </ion-item>\r\n        <ion-item  style=\"height: 44px; float:right\" lines=\"none\">\r\n          <!-- {{currentmindate}} -->\r\n          <ion-datetime   (ngModelChange)=\"getAvailabaleSlot($event,false)\" [(ngModel)]=\"selecteddate\"  style=\"border-radius: 6px;\r\n          background: #F0F0F0;\r\n              height: 33px;\r\n          float: right;\r\n          width: 123px;\r\n          font-size: 9px;\" placeholder=\"Select Date\" min={{currentmindate}} max={{currentplusthreedays}}  >\r\n                        <!-- <ion-input-option  boolean=\"true\"\r\n                        disabled=true  *ngIf=\"!beauticiandata\"\r\n                      >\r\n                    No slots available\r\n                    \r\n                    </ion-input-option>\r\n\r\n            <ion-input-option *ngFor=\"let date of beauticiandata\">{{date.start_datetime|date :  \"dd.MMM.y\"}}\r\n            </ion-input-option> -->\r\n\r\n          </ion-datetime>\r\n\r\n        </ion-item>\r\n        <ion-item style=\"height: 44px; float:right\" lines=\"none\">\r\n          <ion-select interface=\"action-sheet\" (ionChange)=\"selectedbeautician($event)\" [(ngModel)]=\"date\"  style=\"border-radius: 6px;\r\n          background: #F0F0F0;\r\n              height: 33px;\r\n          float: right;\r\n          min-width: 123px;\r\n          width: 123px;\r\n          font-size: 9px;\" placeholder=\"Select Slot\">\r\n               <ion-select-option disabled=true *ngIf=\"!beauticiandata\"\r\n               >\r\n             No slots available\r\n             \r\n             </ion-select-option>\r\n            <ion-select-option  (ionSelect)=\"selectedbeautician(date)\" *ngFor=\"let date of beauticiandata\"\r\n              [value]=\"date\"> Slots: {{date.start_datetime| date :  \"HH:mm\"}}-{{date.end_datetime| date : \"HH:mm\"}}\r\n              <!-- <ng-container>\r\n                Date:{{date.start_datetime|date :  \"dd-MMM-yyy\"}}\r\n              </ng-container> -->\r\n              \r\n            </ion-select-option>\r\n          </ion-select>\r\n        </ion-item>\r\n\r\n\r\n        <!-- <ion-datetime [(ngModel)]=\"startTime\" display-format=\"HH:mm\" min=\"10:00\" max=\"21:00\">\r\n\r\n        <ion-item style=\"height: 44px;\" lines=\"none\">\r\n                    <ion-label class=\"cart-details\">Super Mario World</ion-label>\r\n                  </ion-item> -->\r\n      </ion-list>\r\n    </ion-col>\r\n\r\n  </ion-row>\r\n\r\n  <ion-row>\r\n    <ion-col *ngIf=\"selectedmodeofpayment=='online'\" style=\"max-width: 100%;\r\n    text-align: center;\" size=\"12 \">\r\n      <ion-button [disabled]=\"!(selectedmodeofpayment && flat && selectedaddress && date )\" (click)=\"payWithRazor()\" style=\"width: 50%;\" class=\"font-10 \">Book</ion-button>\r\n    </ion-col>\r\n\r\n        <ion-col *ngIf=\"selectedmodeofpayment=='by_cash'\" style=\"max-width: 100%;\r\n    text-align: center;\" size=\"12 \">\r\n      <ion-button [disabled]=\"!(selectedmodeofpayment && flat && selectedaddress && date )\" (click)=\"createBooking('No payment id','Not paid','by_cash')\" style=\"width: 50%;\" class=\"font-10 \">Book</ion-button>\r\n    </ion-col>\r\n\r\n  </ion-row>\r\n  <!-- \r\n  <ion-infinite-scroll [hidden]=\"disableInfiniteScroll\" threshold=\"5px\" (ionInfinite)=\"searchTicket($event)\">\r\n    <ion-infinite-scroll-content loadingSpinner=\"bubbles\"\r\n      loadingText=\"{{transService.getTranslatedData('infinite-scroll')}}\">\r\n    </ion-infinite-scroll-content>\r\n  </ion-infinite-scroll> -->\r\n</ion-content>\r\n\r\n<ion-content *ngIf=\"!this.utils.cartitem\">\r\n  <ion-item size=\"12\" lines=\"none\">\r\n    <p style=\"text-align: center;\r\n    display: inline-flex;\r\n    width: 100%;\r\n    margin-top: 80%;\r\n    justify-content: center;\">Your shopping cart is empty.</p>\r\n\r\n</ion-item>\r\n<ion-item size=\"12\" lines=\"none\">\r\n  <ion-button style=\"    display: inline-flex;\r\n  justify-content: center;\r\n  width: 100%;\r\n  margin-left: 20vw;\r\n  margin-right: 20vw;\" size=\"12\" routerLink=\"/rentals-naila-search-page\" class=\"btn\">Continue shopping</ion-button>\r\n\r\n  </ion-item>\r\n\r\n\r\n \r\n</ion-content>"

/***/ }),

/***/ "./src/app/Rentals Management/pages/nailacart/nailacart.module.ts":
/*!************************************************************************!*\
  !*** ./src/app/Rentals Management/pages/nailacart/nailacart.module.ts ***!
  \************************************************************************/
/*! exports provided: NailaCartPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "NailaCartPageModule", function() { return NailaCartPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _ApplicationPageModule__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../ApplicationPageModule */ "./src/app/Rentals Management/ApplicationPageModule.ts");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _modals_create_notice_create_notice_component__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../../modals/create-notice/create-notice.component */ "./src/app/Rentals Management/modals/create-notice/create-notice.component.ts");
/* harmony import */ var _nailabooking__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./nailabooking */ "./src/app/Rentals Management/pages/nailacart/nailabooking.ts");








// import { BarcodeScanner } from '@ionic-native/barcode-scanner/ngx';

// import { NailaCartPage } from './nailabooking';
// import { NailaCartPage } from './nailaofferslisting';
// import { ApprovalpopupComponent } from '../../modals/approvalpopup/approvalpopup.component';
var routes = [
    {
        path: '',
        component: _nailabooking__WEBPACK_IMPORTED_MODULE_8__["NailaCartPage"]
    }
];
var NailaCartPageModule = /** @class */ (function () {
    function NailaCartPageModule() {
    }
    NailaCartPageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_2__["NgModule"])({
            entryComponents: [_modals_create_notice_create_notice_component__WEBPACK_IMPORTED_MODULE_7__["CreateNoticeComponent"]],
            imports: [
                _angular_common__WEBPACK_IMPORTED_MODULE_3__["CommonModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormsModule"],
                _ApplicationPageModule__WEBPACK_IMPORTED_MODULE_1__["ApplicationPageModule"],
                _ionic_angular__WEBPACK_IMPORTED_MODULE_6__["IonicModule"],
                _angular_router__WEBPACK_IMPORTED_MODULE_5__["RouterModule"].forChild(routes)
            ],
            providers: [
            // BarcodeScanner
            ],
            declarations: [_nailabooking__WEBPACK_IMPORTED_MODULE_8__["NailaCartPage"]]
        })
    ], NailaCartPageModule);
    return NailaCartPageModule;
}());



/***/ }),

/***/ "./src/app/Rentals Management/pages/nailacart/nailacart.scss":
/*!*******************************************************************!*\
  !*** ./src/app/Rentals Management/pages/nailacart/nailacart.scss ***!
  \*******************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "ion-navbar {\n  border-bottom-right-radius: 15px;\n  border-bottom-left-radius: 15px;\n  background-color: black; }\n\nion-card {\n  position: relative;\n  text-align: center;\n  border-radius: 20px !important; }\n\n.card-title {\n  position: absolute;\n  top: 20vh;\n  background-color: yellow;\n  font-size: 2.0em;\n  height: 15vh;\n  width: 100%;\n  font-weight: bold;\n  color: #fff; }\n\nion-card-content {\n  text-align: left;\n  background: red;\n  line-height: 1.5;\n  width: 100%;\n  padding-top: 7px;\n  padding-bottom: 7px; }\n\nlabel {\n  padding-left: 3vw; }\n\n.service ion-card-content {\n  text-align: center;\n  line-height: 1.5;\n  width: 100%;\n  font-size: 6px;\n  background: transparent;\n  padding: 5px 1px 3px; }\n\n.service ion-card {\n  position: relative;\n  text-align: center;\n  border-radius: 10px !important; }\n\nion-list {\n  padding-top: 0px !important; }\n\nion-toolbar {\n  border-bottom-left-radius: 25px;\n  border-bottom-right-radius: 25px; }\n\n.list-offers {\n  margin-right: 5px; }\n\nh6 {\n  padding-left: 4vw;\n  font-weight: 500; }\n\nhr {\n  border-width: 0.2px !important;\n  height: 0px !important; }\n\n.cart-details {\n  font-size: 13px;\n  margin-top: 0px;\n  margin-bottom: 0px; }\n\nion-select {\n  max-width: 100% !important;\n  font-size: 13px; }\n\nion-datetime {\n  font-size: 13px; }\n\nion-item {\n  --detail-icon-color: goldenrod;\n  --detail-icon-opacity:1; }\n\n.add-sub {\n  margin-right: 2px;\n  margin-left: 2px; }\n\n.sc-ion-alert-md-h {\n  --min-width: 100% !important;\n  --max-width: 100% !important;\n  font-size: 12px; }\n\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvUmVudGFscyBNYW5hZ2VtZW50L3BhZ2VzL25haWxhY2FydC9EOlxcbmF2am90XFx2ZXJpZnkvc3JjXFxhcHBcXFJlbnRhbHMgTWFuYWdlbWVudFxccGFnZXNcXG5haWxhY2FydFxcbmFpbGFjYXJ0LnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDRSxnQ0FBZ0M7RUFDaEMsK0JBQStCO0VBQy9CLHVCQUF1QixFQUFBOztBQU9uQjtFQUNFLGtCQUFrQjtFQUNsQixrQkFBa0I7RUFDbEIsOEJBQThCLEVBQUE7O0FBR2hDO0VBQ0ksa0JBQWtCO0VBQ2xCLFNBQVM7RUFDVCx3QkFBd0I7RUFDeEIsZ0JBQWdCO0VBQ2hCLFlBQVk7RUFDWixXQUFXO0VBQ1gsaUJBQWlCO0VBQ2pCLFdBQVcsRUFBQTs7QUFRbkI7RUFDSSxnQkFBZ0I7RUFDUixlQUFlO0VBQ3ZCLGdCQUFnQjtFQUNoQixXQUFXO0VBQ1gsZ0JBQWdCO0VBQ2hCLG1CQUFtQixFQUFBOztBQUd2QjtFQUNJLGlCQUFpQixFQUFBOztBQUVyQjtFQUVRLGtCQUFrQjtFQUNsQixnQkFBZ0I7RUFDaEIsV0FBVztFQUNYLGNBQWM7RUFDZCx1QkFBdUI7RUFDdkIsb0JBQW9CLEVBQUE7O0FBUDVCO0VBVVEsa0JBQWtCO0VBQ2xCLGtCQUFrQjtFQUNsQiw4QkFBOEIsRUFBQTs7QUFtQnRDO0VBQ0UsMkJBQTJCLEVBQUE7O0FBSTdCO0VBQ0UsK0JBQStCO0VBQy9CLGdDQUFnQyxFQUFBOztBQUdsQztFQUNFLGlCQUFpQixFQUFBOztBQUduQjtFQUNFLGlCQUFpQjtFQUNqQixnQkFBZ0IsRUFBQTs7QUFHbkI7RUFDRSw4QkFBOEI7RUFDOUIsc0JBQXNCLEVBQUE7O0FBSXRCO0VBQ0MsZUFBZTtFQUNmLGVBQWU7RUFDZixrQkFBa0IsRUFBQTs7QUFHckI7RUFDQywwQkFBMEI7RUFDMUIsZUFBZSxFQUFBOztBQUdoQjtFQUNDLGVBQWUsRUFBQTs7QUFJaEI7RUFFQyw4QkFBb0I7RUFDcEIsdUJBQXNCLEVBQUE7O0FBRXhCO0VBQ0UsaUJBQWlCO0VBQ2pCLGdCQUFnQixFQUFBOztBQUdsQjtFQUNFLDRCQUFZO0VBQ1osNEJBQVk7RUFDWixlQUFlLEVBQUEiLCJmaWxlIjoic3JjL2FwcC9SZW50YWxzIE1hbmFnZW1lbnQvcGFnZXMvbmFpbGFjYXJ0L25haWxhY2FydC5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiaW9uLW5hdmJhcntcclxuICBib3JkZXItYm90dG9tLXJpZ2h0LXJhZGl1czogMTVweDtcclxuICBib3JkZXItYm90dG9tLWxlZnQtcmFkaXVzOiAxNXB4O1xyXG4gIGJhY2tncm91bmQtY29sb3I6IGJsYWNrO1xyXG59XHJcblxyXG5cclxuXHJcblxyXG5cclxuICAgICAgaW9uLWNhcmQge1xyXG4gICAgICAgIHBvc2l0aW9uOiByZWxhdGl2ZTtcclxuICAgICAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XHJcbiAgICAgICAgYm9yZGVyLXJhZGl1czogMjBweCAhaW1wb3J0YW50O1xyXG4gICAgICB9XHJcblxyXG4gICAgICAuY2FyZC10aXRsZSB7XHJcbiAgICAgICAgICBwb3NpdGlvbjogYWJzb2x1dGU7XHJcbiAgICAgICAgICB0b3A6IDIwdmg7XHJcbiAgICAgICAgICBiYWNrZ3JvdW5kLWNvbG9yOiB5ZWxsb3c7XHJcbiAgICAgICAgICBmb250LXNpemU6IDIuMGVtO1xyXG4gICAgICAgICAgaGVpZ2h0OiAxNXZoO1xyXG4gICAgICAgICAgd2lkdGg6IDEwMCU7XHJcbiAgICAgICAgICBmb250LXdlaWdodDogYm9sZDtcclxuICAgICAgICAgIGNvbG9yOiAjZmZmO1xyXG4gICAgICB9XHJcblxyXG4gICAgIFxyXG4gICAgICAvLyBpb24tc2xpZGV7XHJcbiAgICAgIC8vICAgICB3aWR0aDogMjQ1cHggIWltcG9ydGFudDtcclxuICAgICAgLy8gfVxyXG5cclxuICBpb24tY2FyZC1jb250ZW50e1xyXG4gICAgICB0ZXh0LWFsaWduOiBsZWZ0O1xyXG4gICAgICAgICAgICAgIGJhY2tncm91bmQ6IHJlZDtcclxuICAgICAgbGluZS1oZWlnaHQ6IDEuNTtcclxuICAgICAgd2lkdGg6IDEwMCU7XHJcbiAgICAgIHBhZGRpbmctdG9wOiA3cHg7XHJcbiAgICAgIHBhZGRpbmctYm90dG9tOiA3cHg7XHJcbiAgfVxyXG5cclxuICBsYWJlbHtcclxuICAgICAgcGFkZGluZy1sZWZ0OiAzdnc7XHJcbiAgfVxyXG4gIC5zZXJ2aWNle1xyXG4gICAgICBpb24tY2FyZC1jb250ZW50e1xyXG4gICAgICAgICAgdGV4dC1hbGlnbjogY2VudGVyO1xyXG4gICAgICAgICAgbGluZS1oZWlnaHQ6IDEuNTtcclxuICAgICAgICAgIHdpZHRoOiAxMDAlO1xyXG4gICAgICAgICAgZm9udC1zaXplOiA2cHg7XHJcbiAgICAgICAgICBiYWNrZ3JvdW5kOiB0cmFuc3BhcmVudDtcclxuICAgICAgICAgIHBhZGRpbmc6IDVweCAxcHggM3B4O1xyXG4gICAgICB9XHJcbiAgICAgIGlvbi1jYXJke1xyXG4gICAgICAgICAgcG9zaXRpb246IHJlbGF0aXZlO1xyXG4gICAgICAgICAgdGV4dC1hbGlnbjogY2VudGVyO1xyXG4gICAgICAgICAgYm9yZGVyLXJhZGl1czogMTBweCAhaW1wb3J0YW50OyAgXHJcbiAgICAgICAgICBcclxuICAgICAgfVxyXG4gIH1cclxuXHJcbiAgLy8gLmJvcmRlci10b3Age1xyXG4gIC8vICAgYm9yZGVyLXRvcDogMXB4IHNvbGlkIGxpZ2h0Z3JheTtcclxuICAvLyB9XHJcbiAgXHJcbiAgaW9uLWl0ZW0ge1xyXG4gICAgLy8gYm9yZGVyLXRvcDogMXB4IHNvbGlkIGxpZ2h0Z3JheTtcclxuICAgIC8vIGJvcmRlci1ib3R0b206IDFweCBzb2xpZCBsaWdodGdyYXk7XHJcbiAgfVxyXG4gIFxyXG4gIC8vIGlvbi1sYWJlbCB7XHJcbiAgLy8gICBwYWRkaW5nLXRvcDogMTBweCAhaW1wb3J0YW50O1xyXG4gIC8vICAgcGFkZGluZy1ib3R0b206IDEwcHggIWltcG9ydGFudDtcclxuICAvLyB9XHJcbiAgXHJcbiAgaW9uLWxpc3Qge1xyXG4gICAgcGFkZGluZy10b3A6IDBweCAhaW1wb3J0YW50O1xyXG4gIH1cclxuICBcclxuXHJcbiAgaW9uLXRvb2xiYXJ7XHJcbiAgICBib3JkZXItYm90dG9tLWxlZnQtcmFkaXVzOiAyNXB4O1xyXG4gICAgYm9yZGVyLWJvdHRvbS1yaWdodC1yYWRpdXM6IDI1cHg7XHJcbiAgfVxyXG5cclxuICAubGlzdC1vZmZlcnN7XHJcbiAgICBtYXJnaW4tcmlnaHQ6IDVweDtcclxuICB9XHJcblxyXG4gIGg2e1xyXG4gICAgcGFkZGluZy1sZWZ0OiA0dnc7XHJcbiAgICBmb250LXdlaWdodDogNTAwO1xyXG4gICAgfVxyXG5cclxuIGhye1xyXG4gICBib3JkZXItd2lkdGg6IDAuMnB4ICFpbXBvcnRhbnQ7XHJcbiAgIGhlaWdodDogMHB4ICFpbXBvcnRhbnQ7XHJcbiB9XHJcblxyXG4gXHJcbiAgIC5jYXJ0LWRldGFpbHN7XHJcbiAgICBmb250LXNpemU6IDEzcHg7XHJcbiAgICBtYXJnaW4tdG9wOiAwcHg7XHJcbiAgICBtYXJnaW4tYm90dG9tOiAwcHg7XHJcbiAgIFxyXG4gfVxyXG4gaW9uLXNlbGVjdHtcclxuICBtYXgtd2lkdGg6IDEwMCUgIWltcG9ydGFudDtcclxuICBmb250LXNpemU6IDEzcHg7XHJcblxyXG4gfVxyXG4gaW9uLWRhdGV0aW1le1xyXG4gIGZvbnQtc2l6ZTogMTNweDtcclxuXHJcbiB9XHJcblxyXG4gaW9uLWl0ZW0ge1xyXG4gIC8vIGJvcmRlci10b3A6IDFweCBzb2xpZCBsaWdodGdyYXk7XHJcbiAgLS1kZXRhaWwtaWNvbi1jb2xvcjogZ29sZGVucm9kO1xyXG4gIC0tZGV0YWlsLWljb24tb3BhY2l0eToxO1xyXG59XHJcbi5hZGQtc3Vie1xyXG4gIG1hcmdpbi1yaWdodDogMnB4O1xyXG4gIG1hcmdpbi1sZWZ0OiAycHg7XHJcbn1cclxuXHJcbi5zYy1pb24tYWxlcnQtbWQtaCB7XHJcbiAgLS1taW4td2lkdGg6IDEwMCUgIWltcG9ydGFudDsgXHJcbiAgLS1tYXgtd2lkdGg6IDEwMCUgIWltcG9ydGFudDtcclxuICBmb250LXNpemU6IDEycHg7XHJcbn0iXX0= */"

/***/ })

}]);
//# sourceMappingURL=Rentals-Management-pages-nailacart-nailacart-module.js.map