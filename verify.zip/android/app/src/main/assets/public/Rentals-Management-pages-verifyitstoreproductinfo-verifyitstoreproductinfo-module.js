(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["Rentals-Management-pages-verifyitstoreproductinfo-verifyitstoreproductinfo-module"],{

/***/ "./src/app/Rentals Management/modals/generatedqrcodemodal/generatedqrcodemodal.component.html":
/*!****************************************************************************************************!*\
  !*** ./src/app/Rentals Management/modals/generatedqrcodemodal/generatedqrcodemodal.component.html ***!
  \****************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ion-header *ngIf=\"hidebutton\">\r\n  <ion-toolbar color=\"primary\">\r\n    <ion-title *ngIf=\"hidenfc\" style=\"    text-transform: capitalize;\">QR code</ion-title>\r\n    <ion-title *ngIf=\"!hidenfc\" style=\"    text-transform: capitalize;\">NFC</ion-title>\r\n\r\n    <ion-buttons slot=\"end\">\r\n      <ion-button color=\"primary\" (click)=\"closeModal()\">\r\n        <ion-icon style=\"    color: white;\" slot=\"icon-only\" name=\"close\"></ion-icon>\r\n      </ion-button>\r\n    </ion-buttons>\r\n  </ion-toolbar>\r\n</ion-header>\r\n\r\n\r\n<ion-content *ngIf=\"hidenfc\">\r\n\r\n  <ion-row>\r\n    <ion-col style=\"margin-top: 6vh;\">\r\n\r\n      <ngx-qrcode [elementType]=\"elementType\" [value]=\"value\" errorCorrectionLevel=\"L\">\r\n      </ngx-qrcode>\r\n\r\n    </ion-col>\r\n\r\n  </ion-row>\r\n\r\n\r\n\r\n  <ion-row>\r\n\r\n    <ion-col style=\"margin-top: 5vh;\r\n    margin-bottom: 5vh;\r\n    width: 100%;\r\n    display: inline-flex;\r\n    justify-content: center;\">\r\n      <ion-button *ngIf=\"hidebutton\" (click)=\"takescreenshot()\">\r\n        Take Screenshot\r\n      </ion-button>\r\n\r\n      <ion-button *ngIf=\"!hidebutton\">\r\n        {{this.utils.storage.name}} QR code\r\n      </ion-button>\r\n\r\n\r\n    </ion-col>\r\n\r\n\r\n  </ion-row>\r\n\r\n\r\n</ion-content>\r\n<ion-content *ngIf=\"!hidenfc\">\r\n  <ion-row>\r\n    <ion-col size=\"12\">\r\n\r\n      <ion-img src=\"assets/Tick-Image.png\"></ion-img>\r\n\r\n    </ion-col>\r\n    <ion-col size=\"12\">\r\n      <ion-label>NFC tag written successfully!</ion-label>\r\n    </ion-col>\r\n  </ion-row>\r\n\r\n\r\n\r\n\r\n</ion-content>"

/***/ }),

/***/ "./src/app/Rentals Management/modals/generatedqrcodemodal/generatedqrcodemodal.component.scss":
/*!****************************************************************************************************!*\
  !*** ./src/app/Rentals Management/modals/generatedqrcodemodal/generatedqrcodemodal.component.scss ***!
  \****************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ".aclass {\n  width: 100%; }\n\nh4 {\n  text-align: center;\n  text-transform: capitalize; }\n\nion-label {\n  display: flex;\n  justify-content: center;\n  font-weight: 500; }\n\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvUmVudGFscyBNYW5hZ2VtZW50L21vZGFscy9nZW5lcmF0ZWRxcmNvZGVtb2RhbC9EOlxcbmF2am90XFx2ZXJpZnkvc3JjXFxhcHBcXFJlbnRhbHMgTWFuYWdlbWVudFxcbW9kYWxzXFxnZW5lcmF0ZWRxcmNvZGVtb2RhbFxcZ2VuZXJhdGVkcXJjb2RlbW9kYWwuY29tcG9uZW50LnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDSSxXQUFXLEVBQUE7O0FBR2Y7RUFDSSxrQkFBa0I7RUFDbEIsMEJBQTBCLEVBQUE7O0FBRTlCO0VBQ0ksYUFBYTtFQUNiLHVCQUF1QjtFQUN2QixnQkFBZ0IsRUFBQSIsImZpbGUiOiJzcmMvYXBwL1JlbnRhbHMgTWFuYWdlbWVudC9tb2RhbHMvZ2VuZXJhdGVkcXJjb2RlbW9kYWwvZ2VuZXJhdGVkcXJjb2RlbW9kYWwuY29tcG9uZW50LnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyIuYWNsYXNze1xyXG4gICAgd2lkdGg6IDEwMCU7XHJcbn1cclxuXHJcbmg0e1xyXG4gICAgdGV4dC1hbGlnbjogY2VudGVyO1xyXG4gICAgdGV4dC10cmFuc2Zvcm06IGNhcGl0YWxpemU7XHJcbn1cclxuaW9uLWxhYmVse1xyXG4gICAgZGlzcGxheTogZmxleDtcclxuICAgIGp1c3RpZnktY29udGVudDogY2VudGVyO1xyXG4gICAgZm9udC13ZWlnaHQ6IDUwMDtcclxufSJdfQ== */"

/***/ }),

/***/ "./src/app/Rentals Management/modals/generatedqrcodemodal/generatedqrcodemodal.component.ts":
/*!**************************************************************************************************!*\
  !*** ./src/app/Rentals Management/modals/generatedqrcodemodal/generatedqrcodemodal.component.ts ***!
  \**************************************************************************************************/
/*! exports provided: GeneratedQRcodeModalComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "GeneratedQRcodeModalComponent", function() { return GeneratedQRcodeModalComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _services_notice_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./../../services/notice.service */ "./src/app/Rentals Management/services/notice.service.ts");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var src_app_common_services_alert_service_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! src/app/common-services/alert-service.service */ "./src/app/common-services/alert-service.service.ts");
/* harmony import */ var _ionic_native_ionic_webview_ngx__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic-native/ionic-webview/ngx */ "./node_modules/@ionic-native/ionic-webview/ngx/index.js");
/* harmony import */ var src_app_common_services_translate_translate_service_service__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! src/app/common-services/translate/translate-service.service */ "./src/app/common-services/translate/translate-service.service.ts");
/* harmony import */ var _services_utils_service__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../../services/utils.service */ "./src/app/Rentals Management/services/utils.service.ts");
/* harmony import */ var _ionic_native_screenshot_ngx__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @ionic-native/screenshot/ngx */ "./node_modules/@ionic-native/screenshot/ngx/index.js");
/* harmony import */ var _services_naila_service__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ../../services/naila.service */ "./src/app/Rentals Management/services/naila.service.ts");











// import { Platform } from 'ionic-angular';
var GeneratedQRcodeModalComponent = /** @class */ (function () {
    function GeneratedQRcodeModalComponent(modalController, loadingCtrl, noticeService, router, alertService, route, webView, utils, transService, actionSheet, screenshot, nviservice) {
        // this.ionViewDidLoad()
        this.modalController = modalController;
        this.loadingCtrl = loadingCtrl;
        this.noticeService = noticeService;
        this.router = router;
        this.alertService = alertService;
        this.route = route;
        this.webView = webView;
        this.utils = utils;
        this.transService = transService;
        this.actionSheet = actionSheet;
        this.screenshot = screenshot;
        this.nviservice = nviservice;
        this.title = 'Nowverifyit';
        this.hidebutton = true;
        this.canNFC = false;
        this.elementType = 'elementType';
        this.value = 'QR code not generated successfully';
        this.flag = false;
        this.images = [];
        this.hasLoading = false;
        this.hidenfc = true;
        // this.ionViewDidLoad()
    }
    GeneratedQRcodeModalComponent.prototype.ngOnInit = function () {
        this.value = this.utils.storage;
        // this.takescreenshot()
        //     this.utils.LoadPage.subscribe(data=>{
        // // this.ionViewDidLoad()
        //      })
    };
    GeneratedQRcodeModalComponent.prototype.ionViewWillEnter = function () {
        // this.alertService.presentAlert("",'dgdsgd'+)
        if (this.utils.NFCsuccessmsg) {
            this.hidenfc = false;
        }
        else {
            this.hidenfc = true;
        }
    };
    GeneratedQRcodeModalComponent.prototype.presentLoading = function () {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function () {
            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                this.loadingCtrl.create({
                    spinner: "lines"
                }).then(function (loading) {
                    loading.present();
                });
                return [2 /*return*/];
            });
        });
    };
    GeneratedQRcodeModalComponent.prototype.closeModal = function () {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function () {
            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.modalController.dismiss()];
                    case 1:
                        _a.sent();
                        return [2 /*return*/];
                }
            });
        });
    };
    GeneratedQRcodeModalComponent.prototype.takescreenshot = function () {
        var _this = this;
        this.hidebutton = false;
        setTimeout(function () {
            _this.screenshot.save('jpg', 80, 'myscreenshot.jpg').then(function (onSuccess) {
                _this.hidebutton = true;
                _this.alertService.presentAlert("", 'Screenshot done successfully');
            }, function (onError) {
                _this.alertService.presentAlert("", 'error');
            });
        }, 900);
    };
    GeneratedQRcodeModalComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_4__["Component"])({
            selector: 'app-generatedqrcodemodal',
            template: __webpack_require__(/*! ./generatedqrcodemodal.component.html */ "./src/app/Rentals Management/modals/generatedqrcodemodal/generatedqrcodemodal.component.html"),
            styles: [__webpack_require__(/*! ./generatedqrcodemodal.component.scss */ "./src/app/Rentals Management/modals/generatedqrcodemodal/generatedqrcodemodal.component.scss")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_ionic_angular__WEBPACK_IMPORTED_MODULE_3__["ModalController"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["LoadingController"],
            _services_notice_service__WEBPACK_IMPORTED_MODULE_2__["NoticeService"],
            _angular_router__WEBPACK_IMPORTED_MODULE_1__["Router"],
            src_app_common_services_alert_service_service__WEBPACK_IMPORTED_MODULE_5__["AlertServiceService"],
            _angular_router__WEBPACK_IMPORTED_MODULE_1__["ActivatedRoute"],
            _ionic_native_ionic_webview_ngx__WEBPACK_IMPORTED_MODULE_6__["WebView"],
            _services_utils_service__WEBPACK_IMPORTED_MODULE_8__["Utils"],
            src_app_common_services_translate_translate_service_service__WEBPACK_IMPORTED_MODULE_7__["translateService"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["ActionSheetController"],
            _ionic_native_screenshot_ngx__WEBPACK_IMPORTED_MODULE_9__["Screenshot"],
            _services_naila_service__WEBPACK_IMPORTED_MODULE_10__["NailaService"]])
    ], GeneratedQRcodeModalComponent);
    return GeneratedQRcodeModalComponent;
}());



/***/ }),

/***/ "./src/app/Rentals Management/pages/verifyitstoreproductinfo/verifyitstoreproductinfo.module.ts":
/*!******************************************************************************************************!*\
  !*** ./src/app/Rentals Management/pages/verifyitstoreproductinfo/verifyitstoreproductinfo.module.ts ***!
  \******************************************************************************************************/
/*! exports provided: VerifyitStoreProductInfoPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "VerifyitStoreProductInfoPageModule", function() { return VerifyitStoreProductInfoPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _ApplicationPageModule__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./../../ApplicationPageModule */ "./src/app/Rentals Management/ApplicationPageModule.ts");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _modals_create_notice_create_notice_component__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../../modals/create-notice/create-notice.component */ "./src/app/Rentals Management/modals/create-notice/create-notice.component.ts");
/* harmony import */ var _verifyitstoreproductinfo_page__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./verifyitstoreproductinfo.page */ "./src/app/Rentals Management/pages/verifyitstoreproductinfo/verifyitstoreproductinfo.page.ts");
/* harmony import */ var _techiediaries_ngx_qrcode__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @techiediaries/ngx-qrcode */ "./node_modules/@techiediaries/ngx-qrcode/fesm5/techiediaries-ngx-qrcode.js");
/* harmony import */ var _modals_generatedqrcodemodal_generatedqrcodemodal_component__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ../../modals/generatedqrcodemodal/generatedqrcodemodal.component */ "./src/app/Rentals Management/modals/generatedqrcodemodal/generatedqrcodemodal.component.ts");











// import { VerifyitStoreProductInfoPage } from '../verifyitProductinfo/verifyitProductinfo.page';
// import { VerifyitStoreProductInfoPage } from './verifyitProductinfo.page';
var routes = [
    {
        path: '',
        component: _verifyitstoreproductinfo_page__WEBPACK_IMPORTED_MODULE_8__["VerifyitStoreProductInfoPage"]
    }
];
var VerifyitStoreProductInfoPageModule = /** @class */ (function () {
    function VerifyitStoreProductInfoPageModule() {
    }
    VerifyitStoreProductInfoPageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_2__["NgModule"])({
            entryComponents: [_modals_create_notice_create_notice_component__WEBPACK_IMPORTED_MODULE_7__["CreateNoticeComponent"], _modals_generatedqrcodemodal_generatedqrcodemodal_component__WEBPACK_IMPORTED_MODULE_10__["GeneratedQRcodeModalComponent"]],
            imports: [
                _techiediaries_ngx_qrcode__WEBPACK_IMPORTED_MODULE_9__["NgxQRCodeModule"],
                _angular_common__WEBPACK_IMPORTED_MODULE_3__["CommonModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormsModule"],
                _ApplicationPageModule__WEBPACK_IMPORTED_MODULE_1__["ApplicationPageModule"],
                _ionic_angular__WEBPACK_IMPORTED_MODULE_6__["IonicModule"],
                _angular_router__WEBPACK_IMPORTED_MODULE_5__["RouterModule"].forChild(routes)
            ],
            providers: [
                // BarcodeScanner
                _modals_generatedqrcodemodal_generatedqrcodemodal_component__WEBPACK_IMPORTED_MODULE_10__["GeneratedQRcodeModalComponent"]
            ],
            declarations: [_verifyitstoreproductinfo_page__WEBPACK_IMPORTED_MODULE_8__["VerifyitStoreProductInfoPage"], _modals_generatedqrcodemodal_generatedqrcodemodal_component__WEBPACK_IMPORTED_MODULE_10__["GeneratedQRcodeModalComponent"]]
        })
    ], VerifyitStoreProductInfoPageModule);
    return VerifyitStoreProductInfoPageModule;
}());



/***/ }),

/***/ "./src/app/Rentals Management/pages/verifyitstoreproductinfo/verifyitstoreproductinfo.page.html":
/*!******************************************************************************************************!*\
  !*** ./src/app/Rentals Management/pages/verifyitstoreproductinfo/verifyitstoreproductinfo.page.html ***!
  \******************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ion-header no-border>\r\n  <ion-toolbar color=\"primary\">\r\n    <ion-buttons slot=\"start\">\r\n      <ion-menu-button></ion-menu-button>\r\n    </ion-buttons>\r\n    <!-- <ion-buttons slot=\"end\" expand=\"full\" class=\"ion-button\" (click)=\"openScanner()\">\r\n      <ion-button style=\"color: black\">\r\n          <img src=\"../../../../assets/icons.png\" width=\"30px\" height=\"30px\"/>\r\n      </ion-button>\r\n    </ion-buttons> -->\r\n\r\n    <ion-title>Store Product Information</ion-title>\r\n  </ion-toolbar>\r\n\r\n</ion-header>\r\n<ion-content >\r\n\r\n  <ion-row class=\"margin-top-10\" class=\"text-left\">\r\n\r\n    <ion-col>\r\n      <ion-item lines=\"none\">\r\n        <ion-label position=\"floating\">Product Name</ion-label>\r\n        <ion-input inputmode=\"text\" placeholder=\" \" [(ngModel)]=\"productdetail.name\"> </ion-input>\r\n      </ion-item>\r\n    </ion-col>\r\n  </ion-row>\r\n\r\n\r\n  <ion-row class=\" text-left\">\r\n\r\n    <ion-col>\r\n      <ion-item lines=\"none\">\r\n        <ion-label position=\"floating\">Place</ion-label>\r\n\r\n        <ion-input inputmode=\"text\" placeholder=\" \" [(ngModel)]=\"productdetail.place\"> </ion-input>\r\n      </ion-item>\r\n    </ion-col>\r\n  </ion-row>\r\n\r\n\r\n\r\n\r\n  <ion-row>\r\n    <ion-col style=\"margin-top: 5vh;\r\n    margin-bottom: 5vh;\r\n    width: 100%;\r\n    display: inline-flex;\r\n    justify-content: center;\">\r\n      <ion-button (click)=\"openGeneratedQRcodeModal('qr')\" class=\"half-button\" expand=\"full\" color=\"primary\">Generate QR code\r\n      </ion-button>\r\n\r\n    \r\n\r\n    </ion-col>\r\n\r\n    <ion-col style=\"    margin-top: 5vh;\r\n    margin-bottom: 5vh;\r\n    width: 100%;\r\n    display: inline-flex;\r\n    justify-content: center;\">\r\n      <ion-button [disabled]=\"!disableButton\" (click)=\"openGeneratedQRcodeModal('nfc')\" class=\"half-button\" expand=\"full\" color=\"primary\">Write NFC\r\n        </ion-button>\r\n\r\n    \r\n\r\n    </ion-col>\r\n\r\n\r\n  </ion-row>\r\n\r\n</ion-content>\r\n<ion-footer>\r\n  <!--ion-toolbar>\r\n    <p><b> NFC Status:</b>&nbsp;{{ statusMessage }}</p>\r\n  </ion-toolbar-->\r\n</ion-footer>"

/***/ }),

/***/ "./src/app/Rentals Management/pages/verifyitstoreproductinfo/verifyitstoreproductinfo.page.scss":
/*!******************************************************************************************************!*\
  !*** ./src/app/Rentals Management/pages/verifyitstoreproductinfo/verifyitstoreproductinfo.page.scss ***!
  \******************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "ion-button {\n  width: 100% !important;\n  padding-left: 5vh;\n  padding-right: 5vh; }\n\nion-list {\n  display: inline-flex;\n  justify-content: center; }\n\n.transparentBody {\n  background: transparent !important; }\n\n.product-image {\n  display: flex;\n  justify-content: center;\n  align-items: center;\n  width: 100%; }\n\n.product-image img {\n    height: 180px;\n    width: 180px; }\n\n.float-right {\n  text-align: right; }\n\n.product-label {\n  font-weight: 500; }\n\n.col-btn {\n  display: inline-flex;\n  justify-content: center;\n  align-items: center; }\n\n.instruction-label {\n  margin-top: 19px;\n  font-size: 23px;\n  text-transform: uppercase;\n  text-decoration: underline;\n  text-align: center;\n  margin-bottom: 0px; }\n\n.instruction {\n  text-align: justify;\n  margin-left: 1vh;\n  margin-right: 1vh;\n  font-size: 13px; }\n\n.product-name {\n  margin-top: 19px;\n  font-size: 20px;\n  text-transform: uppercase;\n  text-decoration: underline;\n  text-align: center;\n  margin-bottom: 0px;\n  font-weight: 500; }\n\nion-label {\n  font-weight: 500 !important;\n  font-size: 25px !important; }\n\nion-input {\n  border-bottom: 1px solid black; }\n\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvUmVudGFscyBNYW5hZ2VtZW50L3BhZ2VzL3ZlcmlmeWl0c3RvcmVwcm9kdWN0aW5mby9EOlxcbmF2am90XFx2ZXJpZnkvc3JjXFxhcHBcXFJlbnRhbHMgTWFuYWdlbWVudFxccGFnZXNcXHZlcmlmeWl0c3RvcmVwcm9kdWN0aW5mb1xcdmVyaWZ5aXRzdG9yZXByb2R1Y3RpbmZvLnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUVFLHNCQUFzQjtFQUN0QixpQkFBaUI7RUFDakIsa0JBQWtCLEVBQUE7O0FBRXBCO0VBQ0Usb0JBQW9CO0VBQ3BCLHVCQUF1QixFQUFBOztBQUd6QjtFQUNFLGtDQUFrQyxFQUFBOztBQUdwQztFQUNFLGFBQWE7RUFDYix1QkFBdUI7RUFDdkIsbUJBQW1CO0VBQ25CLFdBQVcsRUFBQTs7QUFKYjtJQU1JLGFBQWE7SUFDYixZQUFZLEVBQUE7O0FBR2hCO0VBQ0UsaUJBQWlCLEVBQUE7O0FBRW5CO0VBQ0UsZ0JBQWdCLEVBQUE7O0FBRWxCO0VBQ0Usb0JBQW9CO0VBQ3BCLHVCQUF1QjtFQUN2QixtQkFBbUIsRUFBQTs7QUFFckI7RUFDRSxnQkFBZ0I7RUFDaEIsZUFBZTtFQUNmLHlCQUF5QjtFQUN6QiwwQkFBMEI7RUFDMUIsa0JBQWtCO0VBQ2xCLGtCQUFrQixFQUFBOztBQUdwQjtFQUNFLG1CQUFtQjtFQUNuQixnQkFBZ0I7RUFDaEIsaUJBQWlCO0VBQ2pCLGVBQWUsRUFBQTs7QUFHakI7RUFDRSxnQkFBZ0I7RUFDaEIsZUFBZTtFQUNmLHlCQUF5QjtFQUN6QiwwQkFBMEI7RUFDMUIsa0JBQWtCO0VBQ2xCLGtCQUFrQjtFQUNsQixnQkFBZ0IsRUFBQTs7QUFFbEI7RUFDRSwyQkFBMkI7RUFDM0IsMEJBQTBCLEVBQUE7O0FBRzVCO0VBQ0UsOEJBQThCLEVBQUEiLCJmaWxlIjoic3JjL2FwcC9SZW50YWxzIE1hbmFnZW1lbnQvcGFnZXMvdmVyaWZ5aXRzdG9yZXByb2R1Y3RpbmZvL3ZlcmlmeWl0c3RvcmVwcm9kdWN0aW5mby5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyJpb24tYnV0dG9uIHtcclxuXHJcbiAgd2lkdGg6IDEwMCUgIWltcG9ydGFudDtcclxuICBwYWRkaW5nLWxlZnQ6IDV2aDtcclxuICBwYWRkaW5nLXJpZ2h0OiA1dmg7XHJcbn1cclxuaW9uLWxpc3Qge1xyXG4gIGRpc3BsYXk6IGlubGluZS1mbGV4O1xyXG4gIGp1c3RpZnktY29udGVudDogY2VudGVyO1xyXG59XHJcblxyXG4udHJhbnNwYXJlbnRCb2R5IHtcclxuICBiYWNrZ3JvdW5kOiB0cmFuc3BhcmVudCAhaW1wb3J0YW50O1xyXG59XHJcblxyXG4ucHJvZHVjdC1pbWFnZSB7XHJcbiAgZGlzcGxheTogZmxleDtcclxuICBqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlcjtcclxuICBhbGlnbi1pdGVtczogY2VudGVyO1xyXG4gIHdpZHRoOiAxMDAlO1xyXG4gIGltZyB7XHJcbiAgICBoZWlnaHQ6IDE4MHB4O1xyXG4gICAgd2lkdGg6IDE4MHB4O1xyXG4gIH1cclxufVxyXG4uZmxvYXQtcmlnaHQge1xyXG4gIHRleHQtYWxpZ246IHJpZ2h0O1xyXG59XHJcbi5wcm9kdWN0LWxhYmVsIHtcclxuICBmb250LXdlaWdodDogNTAwO1xyXG59XHJcbi5jb2wtYnRuIHtcclxuICBkaXNwbGF5OiBpbmxpbmUtZmxleDtcclxuICBqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlcjtcclxuICBhbGlnbi1pdGVtczogY2VudGVyO1xyXG59XHJcbi5pbnN0cnVjdGlvbi1sYWJlbCB7XHJcbiAgbWFyZ2luLXRvcDogMTlweDtcclxuICBmb250LXNpemU6IDIzcHg7XHJcbiAgdGV4dC10cmFuc2Zvcm06IHVwcGVyY2FzZTtcclxuICB0ZXh0LWRlY29yYXRpb246IHVuZGVybGluZTtcclxuICB0ZXh0LWFsaWduOiBjZW50ZXI7XHJcbiAgbWFyZ2luLWJvdHRvbTogMHB4O1xyXG59XHJcblxyXG4uaW5zdHJ1Y3Rpb24ge1xyXG4gIHRleHQtYWxpZ246IGp1c3RpZnk7XHJcbiAgbWFyZ2luLWxlZnQ6IDF2aDtcclxuICBtYXJnaW4tcmlnaHQ6IDF2aDtcclxuICBmb250LXNpemU6IDEzcHg7XHJcbn1cclxuXHJcbi5wcm9kdWN0LW5hbWUge1xyXG4gIG1hcmdpbi10b3A6IDE5cHg7XHJcbiAgZm9udC1zaXplOiAyMHB4O1xyXG4gIHRleHQtdHJhbnNmb3JtOiB1cHBlcmNhc2U7XHJcbiAgdGV4dC1kZWNvcmF0aW9uOiB1bmRlcmxpbmU7XHJcbiAgdGV4dC1hbGlnbjogY2VudGVyO1xyXG4gIG1hcmdpbi1ib3R0b206IDBweDtcclxuICBmb250LXdlaWdodDogNTAwO1xyXG59XHJcbmlvbi1sYWJlbCB7XHJcbiAgZm9udC13ZWlnaHQ6IDUwMCAhaW1wb3J0YW50O1xyXG4gIGZvbnQtc2l6ZTogMjVweCAhaW1wb3J0YW50O1xyXG59XHJcblxyXG5pb24taW5wdXQge1xyXG4gIGJvcmRlci1ib3R0b206IDFweCBzb2xpZCBibGFjaztcclxufVxyXG5cclxuLy8gaW9uLWJ1dHRvbntcclxuLy8gICBkaXNwbGF5OiBpbmxpbmUtZmxleDtcclxuLy8gICBqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlcjtcclxuLy8gfVxyXG4iXX0= */"

/***/ }),

/***/ "./src/app/Rentals Management/pages/verifyitstoreproductinfo/verifyitstoreproductinfo.page.ts":
/*!****************************************************************************************************!*\
  !*** ./src/app/Rentals Management/pages/verifyitstoreproductinfo/verifyitstoreproductinfo.page.ts ***!
  \****************************************************************************************************/
/*! exports provided: VerifyitStoreProductInfoPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "VerifyitStoreProductInfoPage", function() { return VerifyitStoreProductInfoPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _ionic_native_nfc_ngx__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ionic-native/nfc/ngx */ "./node_modules/@ionic-native/nfc/ngx/index.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _services_naila_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../services/naila.service */ "./src/app/Rentals Management/services/naila.service.ts");
/* harmony import */ var _services_utils_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../services/utils.service */ "./src/app/Rentals Management/services/utils.service.ts");
/* harmony import */ var src_app_common_services_alert_service_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! src/app/common-services/alert-service.service */ "./src/app/common-services/alert-service.service.ts");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _modals_generatedqrcodemodal_generatedqrcodemodal_component__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../../modals/generatedqrcodemodal/generatedqrcodemodal.component */ "./src/app/Rentals Management/modals/generatedqrcodemodal/generatedqrcodemodal.component.ts");









var VerifyitStoreProductInfoPage = /** @class */ (function () {
    function VerifyitStoreProductInfoPage(utilservice, alertservice, router, platform, modalController, apiSvc, nfc, ndef, ngZone, loading) {
        this.utilservice = utilservice;
        this.alertservice = alertservice;
        this.router = router;
        this.platform = platform;
        this.modalController = modalController;
        this.apiSvc = apiSvc;
        this.nfc = nfc;
        this.ndef = ndef;
        this.ngZone = ngZone;
        this.loading = loading;
        this.canNFC = false;
        this.disableButton = true;
        this.subscriptions = new Array();
        this.res = {};
        this.productdetail = {};
        // this.openGeneratedQRcodeModal()
    }
    VerifyitStoreProductInfoPage.prototype.ngOnInit = function () { };
    VerifyitStoreProductInfoPage.prototype.presentLoading = function (message) {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function () {
            var loading;
            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.loading.create({
                            message: message,
                        })];
                    case 1:
                        loading = _a.sent();
                        return [4 /*yield*/, loading.present()];
                    case 2:
                        _a.sent();
                        return [2 /*return*/];
                }
            });
        });
    };
    VerifyitStoreProductInfoPage.prototype.openGeneratedQRcodeModal = function (role) {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function () {
            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                this.utilservice.LoadPageOnrouteChange();
                if (role == "qr") {
                    this.utilservice.hidenfc = true;
                    this.generateqrcode(role);
                }
                else {
                    this.generateqrcode(role);
                    this.utilservice.hidenfc = false;
                }
                return [2 /*return*/];
            });
        });
    };
    VerifyitStoreProductInfoPage.prototype.ionViewWillLeave = function () {
        this.subscriptions.forEach(function (sub) {
            sub.unsubscribe();
        });
        this.NFCListener.unsubscribe();
    };
    VerifyitStoreProductInfoPage.prototype.generateqrcode = function (role) {
        var _this = this;
        this.disableButton = false;
        this.presentLoading('Place your NFC Tag on the top of your mobile phone.');
        this.apiSvc.writeNFCQRcodedata(this.productdetail).subscribe(function (res) { return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](_this, void 0, void 0, function () {
            var modal;
            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                switch (_a.label) {
                    case 0:
                        console.log(res, '======================');
                        this.loading.dismiss();
                        this.disableButton = true;
                        if (!(role == "qr")) return [3 /*break*/, 3];
                        // this.presentLoading();
                        this.utilservice.NFCsuccessmsg = false;
                        // this.value = JSON.stringify(res.id)
                        this.utilservice.storage = JSON.stringify(res.id);
                        return [4 /*yield*/, this.modalController.create({
                                component: _modals_generatedqrcodemodal_generatedqrcodemodal_component__WEBPACK_IMPORTED_MODULE_8__["GeneratedQRcodeModalComponent"]
                            })];
                    case 1:
                        modal = _a.sent();
                        return [4 /*yield*/, modal.present()];
                    case 2: 
                    // this.loading.dismiss();
                    return [2 /*return*/, _a.sent()];
                    case 3:
                        // this.loading.dismiss();
                        // this.writingNFC(JSON.stringify(res.id));
                        this.tagListenerSuccess(JSON.stringify(res.id));
                        _a.label = 4;
                    case 4: return [2 /*return*/];
                }
            });
        }); }, function (err) {
            _this.disableButton = true;
            _this.loading.dismiss();
            _this.loading.dismiss();
            // alert("write record scan went wrong");
            _this.alertservice.presentAlert("", "write record scan went wrong");
        });
    };
    // setStatus(message) {
    //   this.alertservice.presentAlert("", message);
    //   this.ngZone.run(() => {
    //     this.statusMessage = message;
    //   });
    // }
    VerifyitStoreProductInfoPage.prototype.readTag = function () {
        var _this = this;
        if (this.canNFC) {
            setTimeout(function () {
                // alert("Please place your mobile near NFC tag.");
                _this.alertservice.presentAlert("", "Please place your mobile near NFC tag.");
                // this.readingTag = true;
                // this.tagListenerSuccess();
            }, 100);
        }
        else {
            this.alertservice.presentAlert("NFC is not supported by your Device", "");
        }
    };
    VerifyitStoreProductInfoPage.prototype.ionViewDidLoad = function () {
        var _this = this;
        this.platform.ready().then(function () {
            _this.nfc.enabled().then(function (resolve) {
                _this.canNFC = true;
                _this.setStatus('NFC Compatable.');
            }).catch(function (reject) {
                _this.canNFC = false;
                // this.helperSvc.showResponseAlert(JSON.stringify("NFC is not supported by your Device"));
                _this.setStatus('NFC Not Compatable.');
            });
        });
    };
    // writingNFC(productData) {
    //   // this.presentLoading()
    //   this.nfc
    //     .enabled()
    //     .then(resolve => {
    //       this.canNFC = true;
    //       this.readTag();
    //       // this.setStatus("NFC Compatable.");
    //       // this.tagListenerSuccess();
    //     })
    //     .catch(reject => {
    //       this.canNFC = false;
    //       // this.loading.dismiss()
    //       // this.alertservice.presentAlert("", JSON.stringify("NFC is not supported by your Device"));
    //       // this.setStatus("NFC Not Compatable.");
    //     });
    //   // this.NFCListener =
    //     this.nfc.addNdefListener(
    //       () => {
    //         // this.alertservice.presentAlert("", "Successfully attached NDEF listener.");
    //       },
    //       (err: any) => {
    //         this.loading.dismiss()
    //         this.alertservice.presentAlert("", "error attaching ndef listener.");
    //       }
    //     )
    //       .subscribe(event => {
    //         // this.alertservice.presentAlert("", "received NDF message.");
    //         if (this.canNFC) {
    //           const a = this.ndef.textRecord(productData);
    //           this.nfc
    //             .write([a])
    //             .then(() => {
    //               this.loading.dismiss()
    //               this.router.navigateByUrl('/verifyit-message')
    //               // this.alertservice.presentAlert("", "We wrote to the tag successfully.");
    //               // this.utilservice.NFCsuccessmsg = true
    //             })
    //             .catch((err: any) => {
    //               this.loading.dismiss()
    //               this.alertservice.presentAlert("", "We could not write to the tag.something went wrong");
    //               // this.NFCsuccessmsg =
    //               //   "Product info not written successfully on NFC tag.";
    //             });
    //         }
    //       });
    // }
    VerifyitStoreProductInfoPage.prototype.tagListenerSuccess = function (data) {
        var _this = this;
        if (this.platform.is('android')) {
            this.subscriptions.push(this.nfc.addNdefListener()
                .subscribe(function (tagEvent) {
                // if (this.writingTag) {
                // if (!this.isWriting) {
                // this.isWriting = true;
                var a = _this.ndef.textRecord(data);
                _this.nfc.write([a])
                    .then(function () {
                    // this.cred.name = '';
                    // this.cred.place = '';
                    setTimeout(function () {
                        // this.helperSvc.showResponseAlert(JSON.stringify('NFC Updated'));
                        // this.helperSvc.hideLoading();
                        // console.log("written");
                        // this.writingTag = false;
                        _this.router.navigateByUrl('/verifyit-message');
                        // this.isWriting = false;
                    }, 100);
                })
                    .catch(function (err) {
                    // this.writingTag = false;
                    // this.isWriting = false;
                    // this.cred.name = '';
                    // this.cred.place = '';
                    alert('NFC not Connected.');
                    // this.helperSvc.hideLoading();
                });
                // }
            }, function (err) {
            }));
        }
        else {
            this.readAndWriteNFCIos(data);
        }
    };
    VerifyitStoreProductInfoPage.prototype.setStatus = function (message) {
        var _this = this;
        console.log(message);
        this.ngZone.run(function () {
            _this.statusMessage = message;
        });
    };
    // writeTag(writeText: string) {
    //   if (this.canNFC) {
    //     this.tagListenerSuccess();
    //     if (this.cred.name && this.cred.place) {
    //       // this.helperSvc.showLoading('Processing. Plese wait.');
    //       this.apiSvc.callPostTag(this.cred.name, this.cred.place).subscribe((res) => {
    //         console.log(res);
    //         // this.helperSvc.hideLoading();
    //         setTimeout(() => {
    //           this.helperSvc.showLoading('Place NFC Tag Near device to write.');
    //           this.writingTag = true;
    //           this.ndefMsg = this.ndef.textRecord(res.id);
    //         }, 100);
    //       });
    //     } else {
    //       // this.helperSvc.showErrorAlert('Name and Place is Required.');
    //     }
    //   } else {
    //     // this.helperSvc.showErrorAlert('NFC is not supported by your Device');
    //   }
    // }
    VerifyitStoreProductInfoPage.prototype.readAndWriteNFCIos = function (data) {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function () {
            var tag, a, err_1;
            var _this = this;
            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                switch (_a.label) {
                    case 0:
                        _a.trys.push([0, 2, , 3]);
                        return [4 /*yield*/, this.nfc.scanNdef({ keepSessionOpen: true })];
                    case 1:
                        tag = _a.sent();
                        a = this.ndef.textRecord(data);
                        this.nfc.write([a])
                            .then(function () {
                            // this.cred.name = '';
                            // this.cred.place = '';
                            setTimeout(function () {
                                // this.helperSvc.showResponseAlert(JSON.stringify('NFC Updated'));
                                // this.helperSvc.hideLoading();
                                // console.log("written");
                                // this.writingTag = false;
                                _this.router.navigateByUrl('/verifyit-message');
                                // this.isWriting = false;
                            }, 100);
                        })
                            .catch(function (err) {
                            // this.writingTag = false;
                            // this.isWriting = false;
                            // this.cred.name = '';
                            // this.cred.place = '';
                            alert('NFC not Connected.');
                            // this.helperSvc.hideLoading();
                        });
                        return [3 /*break*/, 3];
                    case 2:
                        err_1 = _a.sent();
                        console.log(err_1);
                        return [3 /*break*/, 3];
                    case 3: return [2 /*return*/];
                }
            });
        });
    };
    VerifyitStoreProductInfoPage.prototype.presentModal = function () {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function () {
            var modal;
            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.modalController.create({
                            component: _modals_generatedqrcodemodal_generatedqrcodemodal_component__WEBPACK_IMPORTED_MODULE_8__["GeneratedQRcodeModalComponent"]
                        })];
                    case 1:
                        modal = _a.sent();
                        return [4 /*yield*/, modal.present()];
                    case 2: return [2 /*return*/, _a.sent()];
                }
            });
        });
    };
    VerifyitStoreProductInfoPage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: "app-verifyitstoreproductinfo",
            template: __webpack_require__(/*! ./verifyitstoreproductinfo.page.html */ "./src/app/Rentals Management/pages/verifyitstoreproductinfo/verifyitstoreproductinfo.page.html"),
            styles: [__webpack_require__(/*! ./verifyitstoreproductinfo.page.scss */ "./src/app/Rentals Management/pages/verifyitstoreproductinfo/verifyitstoreproductinfo.page.scss")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_services_utils_service__WEBPACK_IMPORTED_MODULE_5__["Utils"],
            src_app_common_services_alert_service_service__WEBPACK_IMPORTED_MODULE_6__["AlertServiceService"],
            _angular_router__WEBPACK_IMPORTED_MODULE_7__["Router"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["Platform"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["ModalController"],
            _services_naila_service__WEBPACK_IMPORTED_MODULE_4__["NailaService"],
            _ionic_native_nfc_ngx__WEBPACK_IMPORTED_MODULE_2__["NFC"],
            _ionic_native_nfc_ngx__WEBPACK_IMPORTED_MODULE_2__["Ndef"],
            _angular_core__WEBPACK_IMPORTED_MODULE_1__["NgZone"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["LoadingController"]])
    ], VerifyitStoreProductInfoPage);
    return VerifyitStoreProductInfoPage;
}());



/***/ })

}]);
//# sourceMappingURL=Rentals-Management-pages-verifyitstoreproductinfo-verifyitstoreproductinfo-module.js.map