(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["Rentals-Management-pages-create-ticket-create-ticket-module"],{

/***/ "./src/app/Rentals Management/pages/create-ticket/create-ticket.module.ts":
/*!********************************************************************************!*\
  !*** ./src/app/Rentals Management/pages/create-ticket/create-ticket.module.ts ***!
  \********************************************************************************/
/*! exports provided: CreateTicketPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CreateTicketPageModule", function() { return CreateTicketPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _create_ticket_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./create-ticket.page */ "./src/app/Rentals Management/pages/create-ticket/create-ticket.page.ts");







var routes = [
    {
        path: '',
        component: _create_ticket_page__WEBPACK_IMPORTED_MODULE_6__["CreateTicketPage"]
    }
];
var CreateTicketPageModule = /** @class */ (function () {
    function CreateTicketPageModule() {
    }
    CreateTicketPageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            imports: [
                _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
                _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["IonicModule"],
                _angular_router__WEBPACK_IMPORTED_MODULE_4__["RouterModule"].forChild(routes)
            ],
            declarations: [_create_ticket_page__WEBPACK_IMPORTED_MODULE_6__["CreateTicketPage"]]
        })
    ], CreateTicketPageModule);
    return CreateTicketPageModule;
}());



/***/ }),

/***/ "./src/app/Rentals Management/pages/create-ticket/create-ticket.page.html":
/*!********************************************************************************!*\
  !*** ./src/app/Rentals Management/pages/create-ticket/create-ticket.page.html ***!
  \********************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ion-header>\r\n  <ion-toolbar color=\"primary\">\r\n    <ion-buttons slot=\"start\">\r\n      <ion-back-button></ion-back-button>\r\n    </ion-buttons>\r\n    <ion-title class=\"padding-0\" >{{title}}</ion-title>\r\n  </ion-toolbar>\r\n</ion-header>\r\n\r\n<ion-content>\r\n\r\n  <div class=\"\">\r\n    <!-- input -->\r\n    <div *ngIf=\"flow == 'createTicket'\">\r\n      <ion-row>\r\n        <ion-col>\r\n          <p class=\"gotham font-16 margin-left-10 margin-bottom-0\">\r\n            {{transService.getTranslatedData('create-ticket.raise-ticket-for')}}{{ticketData.raisedFor}}</p>\r\n        </ion-col>\r\n      </ion-row>\r\n\r\n      <ion-row>\r\n        <ion-col class=\"padding-left-10\">\r\n          <ion-chip [ngClass]=\"ticketData.ticketBelongsTo == 'Home' ? 'Home' : 'a'\" outline=\"true\" color=\"primary\"\r\n            (click)=\"selectTicketBelongsTo('Home')\">\r\n            <ion-label class=\"font-16 font-weight-500\">{{transService.getTranslatedData('create-ticket.unit')}}\r\n            </ion-label>\r\n          </ion-chip>\r\n\r\n          <ion-chip [ngClass]=\"ticketData.ticketBelongsTo == 'Project' ? 'Project' : 'b'\" outline=\"true\" color=\"primary\"\r\n            (click)=\"selectTicketBelongsTo('Project')\">\r\n            <ion-label class=\"font-16 font-weight-500\">{{transService.getTranslatedData('create-ticket.common-area')}}\r\n            </ion-label>\r\n          </ion-chip>\r\n        </ion-col>\r\n      </ion-row>\r\n    </div>\r\n\r\n    <!-- imput -->\r\n    <div *ngIf=\"flow == 'createTicket'\">\r\n      <ion-row>\r\n        <ion-col>\r\n          <p class=\"font-weight-500 font-16 gotham margin-left-10 margin-bottom-5 \">\r\n            {{transService.getTranslatedData('create-ticket.priority')}}</p>\r\n        </ion-col>\r\n      </ion-row>\r\n\r\n      <ion-row>\r\n        <ion-col class=\"padding-left-10\">\r\n          <ion-chip [ngClass]=\"ticketData.priority == 'low' ? 'low' : 'a'\" outline=\"true\" color=\"primary\"\r\n            (click)=\"selectPriority('low')\">\r\n            <ion-label class=\"font-16 font-weight-500\">{{transService.getTranslatedData('create-ticket.low')}}\r\n            </ion-label>\r\n          </ion-chip>\r\n\r\n          <ion-chip [ngClass]=\"ticketData.priority == 'high' ? 'high' : 'b'\" outline=\"true\" color=\"primary\"\r\n            (click)=\"selectPriority('high')\">\r\n            <ion-label class=\"font-16 font-weight-500\">{{transService.getTranslatedData('create-ticket.high')}}\r\n            </ion-label>\r\n          </ion-chip>\r\n        </ion-col>\r\n      </ion-row>\r\n    </div>\r\n\r\n    <ion-list *ngIf=\"flow == 'createTicket'\">\r\n      <ion-list-header class=\"gotham font-16 font-weight-500\">\r\n        {{ticketData.ticketBelongsTo == 'Home' ? transService.getTranslatedData('create-ticket.unit') : transService.getTranslatedData('create-ticket.project')}}\r\n      </ion-list-header>\r\n      <ion-item>\r\n        <ion-input inputmode=\"text\" readonly [(ngModel)]=\"ticketData.ticketBelongsToName\" class=\"gotham  margin-left-10\"\r\n          placeholder=\"{{transService.getTranslatedData('create-ticket.click-here-to')}} {{ticketData.ticketBelongsTo == 'Home' ? transService.getTranslatedData('create-ticket.a-unit') : transService.getTranslatedData('create-ticket.a-project')}}\"\r\n          (click)=\"openModal(ticketData.ticketBelongsTo)\">\r\n        </ion-input>\r\n        <ion-icon class=\"float-right\" name=\"arrow-dropdown\"></ion-icon>\r\n      </ion-item>\r\n    </ion-list>\r\n\r\n    <ion-list>\r\n      <ion-list-header class=\"gotham font-16 font-weight-500\">\r\n        {{transService.getTranslatedData('create-ticket.category')}}</ion-list-header>\r\n      <ion-item>\r\n        <ion-input inputmode=\"text\" [(ngModel)]=\"ticketData.ticketCategoryName\" class=\"gotham  margin-left-10\"\r\n          placeholder=\"{{transService.getTranslatedData('create-ticket.select-category')}}\"\r\n          (click)=\"openModal('ticketCategory')\" readonly>\r\n        </ion-input>\r\n        <ion-icon class=\"float-right\" name=\"arrow-dropdown\"></ion-icon>\r\n      </ion-item>\r\n    </ion-list>\r\n\r\n    <ion-list *ngIf=\"subCategories.length>0\">\r\n      <ion-list-header class=\"gotham font-16 font-weight-500\">\r\n        {{transService.getTranslatedData('create-ticket.sub-category')}}</ion-list-header>\r\n      <ion-item>\r\n        <ion-input inputmode=\"text\" [(ngModel)]=\"ticketData.ticketSubCategoryName\" class=\"gotham  margin-left-10\"\r\n          placeholder=\"{{transService.getTranslatedData('create-ticket.select-sub-category')}}\"\r\n          (click)=\"openModal('ticketSubCategory')\" readonly>\r\n        </ion-input>\r\n        <ion-icon class=\"float-right\" name=\"arrow-dropdown\"></ion-icon>\r\n      </ion-item>\r\n    </ion-list>\r\n\r\n  </div>\r\n\r\n  <div class=\"webkit-center\">\r\n\r\n    <ion-list *ngIf=\"flow == 'createTicket'\">\r\n\r\n      <p class=\"gotham font-16 margin-bottom-0 margin-left-15 float-left\">\r\n        {{transService.getTranslatedData('create-ticket.ticket-description')}}</p>\r\n      <ion-item>\r\n        <ion-textarea active placeholder=\"{{transService.getTranslatedData('create-ticket.description-placeholder')}}\"\r\n          rows=\"3\" [(ngModel)]=\"ticketData.notes\">\r\n        </ion-textarea>\r\n      </ion-item>\r\n\r\n    </ion-list>\r\n\r\n    <ion-list>\r\n      <ion-list-header class=\"gotham font-16 font-weight-500\">{{transService.getTranslatedData('create-ticket.poc')}}\r\n      </ion-list-header>\r\n      <ion-item>\r\n        <ion-input inputmode=\"text\" [(ngModel)]=\"ticketData.contactPointName\" class=\"gotham  margin-left-10\"\r\n          placeholder=\"{{transService.getTranslatedData('create-ticket.poc-placeholder')}}\" (click)=\"openModal('poc')\"\r\n          readonly>\r\n        </ion-input>\r\n        <ion-icon class=\"float-right\" name=\"arrow-dropdown\"></ion-icon>\r\n      </ion-item>\r\n    </ion-list>\r\n    <ion-list>\r\n      <ion-list-header class=\"gotham font-16 font-weight-500\">\r\n        {{transService.getTranslatedData('create-ticket.technical-staff')}}</ion-list-header>\r\n      <ion-item>\r\n        <ion-input inputmode=\"text\" [(ngModel)]=\"ticketData.agentName\" class=\"gotham  margin-left-10\"\r\n          placeholder=\"{{transService.getTranslatedData('create-ticket.t-s')}}\" (click)=\"openModal('agent')\" readonly>\r\n\r\n        </ion-input>\r\n        <ion-icon class=\"float-right\" name=\"arrow-dropdown\"></ion-icon>\r\n      </ion-item>\r\n    </ion-list>\r\n    <ion-row>\r\n      <ion-col>\r\n        <ion-list>\r\n          <ion-list-header class=\"gotham font-16 font-weight-500\">\r\n            {{transService.getTranslatedData('create-ticket.start-date')}}</ion-list-header>\r\n          <ion-item>\r\n            <ion-datetime placeholder=\"{{transService.getTranslatedData('create-ticket.date-placeholder')}}\"\r\n              class=\"gotham padding-left-0\" display-format=\"DD-MMM-YYYY\" picker-format=\"DD-MMM-YYYY\"\r\n              [(ngModel)]=\"ticketData.jobDate\"></ion-datetime>\r\n            <ion-icon class=\"float-right\" name=\"arrow-dropdown\"></ion-icon>\r\n          </ion-item>\r\n        </ion-list>\r\n      </ion-col>\r\n      <ion-col>\r\n        <ion-list>\r\n          <ion-list-header class=\"gotham font-16 font-weight-500\">\r\n            {{transService.getTranslatedData('create-ticket.start-time')}}</ion-list-header>\r\n          <ion-item>\r\n            <ion-datetime placeholder=\"{{transService.getTranslatedData('create-ticket.time-placeholder')}}\"\r\n              class=\"gotham padding-left-0\" display-format=\"hh:mm A\" picker-format=\"hh:mm A\"\r\n              [(ngModel)]=\"ticketData.jobStartTime\"></ion-datetime>\r\n            <ion-icon class=\"float-right\" name=\"arrow-dropdown\"></ion-icon>\r\n          </ion-item>\r\n        </ion-list>\r\n      </ion-col>\r\n    </ion-row>\r\n    <ion-row>\r\n      <ion-col>\r\n        <ion-list>\r\n          <ion-list-header class=\"gotham font-16 font-weight-500\">\r\n            {{transService.getTranslatedData('create-ticket.end-date')}}</ion-list-header>\r\n          <ion-item>\r\n            <ion-datetime placeholder=\"{{transService.getTranslatedData('create-ticket.date-placeholder')}}\"\r\n              class=\"gotham padding-left-0\" display-format=\"DD-MMM-YYYY\" picker-format=\"DD-MMM-YYYY\"\r\n              [(ngModel)]=\"ticketData.jobEndDate\"></ion-datetime>\r\n            <ion-icon class=\"float-right\" name=\"arrow-dropdown\"></ion-icon>\r\n          </ion-item>\r\n        </ion-list>\r\n      </ion-col>\r\n      <ion-col>\r\n        <ion-list>\r\n          <ion-list-header class=\"gotham font-16 font-weight-500\">\r\n            {{transService.getTranslatedData('create-ticket.end-time')}}</ion-list-header>\r\n          <ion-item>\r\n            <ion-datetime placeholder=\"{{transService.getTranslatedData('create-ticket.time-placeholder')}}\"\r\n              class=\"gotham padding-left-0\" display-format=\"hh:mm A\" picker-format=\"hh:mm A\"\r\n              [(ngModel)]=\"ticketData.jobEndTime\"></ion-datetime>\r\n            <ion-icon class=\"float-right\" name=\"arrow-dropdown\"></ion-icon>\r\n          </ion-item>\r\n        </ion-list>\r\n      </ion-col>\r\n    </ion-row>\r\n    <ion-row *ngIf=\"images.length == 0\" class=\"width-80-percent justify-center margin-10 margin-bottom-20\">\r\n      <ion-col class=\"padding-0\">\r\n        <ion-item lines=\"none\" class=\"ion-item\">\r\n          <ion-card class=\"full-width margin-1\" (click)=\"presentActionSheet()\">\r\n            <ion-item lines=\"none\" class=\"ion-item\">\r\n              <ion-icon slot=\"start\" class=\"margin-right-5 margin-left-10 icon-20 gotham\" name=\"camera\"></ion-icon>\r\n              <ion-label>{{transService.getTranslatedData('create-ticket.add-picture')}}</ion-label>\r\n            </ion-item>\r\n          </ion-card>\r\n        </ion-item>\r\n      </ion-col>\r\n    </ion-row>\r\n    <ion-row class=\"width-80-percent margin-10 justify-center margin-10 margin-bottom-20\">\r\n      <div *ngIf=\"images.length > 0\">\r\n        <ion-item *ngFor=\"let url of images\" lines='none' class=\"ion-image-item\">\r\n          <ion-thumbnail class=\"margin-0 icon-90 image\" (click)=\"openImage(webview.convertFileSrc(url))\">\r\n            <ion-icon class=\"img-icon\" (click)=\"removeImage()\" color=\"danger\" name=\"close-circle\">\r\n            </ion-icon>\r\n            <ion-img src=\"{{webview.convertFileSrc(url)}}\"></ion-img>\r\n          </ion-thumbnail>\r\n        </ion-item>\r\n      </div>\r\n    </ion-row>\r\n  </div>\r\n\r\n</ion-content>\r\n<ion-button [disabled]=\"!ticketData.ticketBelongsToRefId || !ticketData.ticketCategory || !ticketData.notes\"\r\n  *ngIf=\"flow == 'createTicket'\" size=\"large\" (click)=\"raiseTicket()\" color=\"danger\">\r\n  {{transService.getTranslatedData('create-ticket.submit-button')}}</ion-button>\r\n<ion-button [disabled]=\"!ticketData.ticketBelongsToRefId || !ticketData.ticketCategory || !ticketData.notes\"\r\n  *ngIf=\"flow == 'editTicket'\" size=\"large\" (click)=\"updateTicket()\" color=\"danger\">\r\n  {{transService.getTranslatedData('create-ticket.submit-button')}}</ion-button>"

/***/ }),

/***/ "./src/app/Rentals Management/pages/create-ticket/create-ticket.page.scss":
/*!********************************************************************************!*\
  !*** ./src/app/Rentals Management/pages/create-ticket/create-ticket.page.scss ***!
  \********************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "label > .customRadio {\n  /* HIDE RADIO */\n  visibility: hidden;\n  /* Makes input not-clickable */\n  position: absolute;\n  /* Remove input from document flow */ }\n\nlabel > input + div {\n  /* IMAGE STYLES */\n  cursor: pointer;\n  /*border:2px solid transparent;*/ }\n\nlabel > input:checked + div > div {\n  /* (RADIO CHECKED) IMAGE STYLES */\n  color: #ff5252 !important;\n  background-color: #f7f7f7 !important;\n  /*border : 1px solid #ff5252 !important;*/ }\n\n.item-radio input:checked + .radio-content .item-content {\n  background: white !important;\n  /*color: #f84940 !important;*/\n  color: #1bb293 !important; }\n\n.ion-click:hover {\n  border: 1px solid #f04141 !important; }\n\n.width-80-percent {\n  width: 80% !important; }\n\n.center-data-in-label {\n  display: grid !important;\n  justify-content: center !important;\n  margin-top: -15px !important; }\n\n.Home,\n.Project,\n.low,\n.high {\n  background-color: #9d4065 !important;\n  color: #f7f7f7 !important; }\n\nion-input {\n  margin-left: 0 !important; }\n\npadding-left-0 {\n  padding-left: 0 !important; }\n\n.ion-image-item {\n  --inner-padding-bottom: 0px;\n  --inner-padding-end: 0px;\n  --inner-padding-start: 0px;\n  --inner-padding-top: 0px;\n  --min-height: 24px;\n  --padding-bottom: 0px;\n  --padding-end: 0px;\n  --padding-start: 0px;\n  --padding-top: 0px;\n  --transition: background-color 15ms linear; }\n\n.img-icon {\n  font-size: x-large !important;\n  position: absolute !important; }\n\n.image {\n  justify-content: flex-end !important;\n  display: flex !important; }\n\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvUmVudGFscyBNYW5hZ2VtZW50L3BhZ2VzL2NyZWF0ZS10aWNrZXQvRDpcXG5hdmpvdFxcdmVyaWZ5L3NyY1xcYXBwXFxSZW50YWxzIE1hbmFnZW1lbnRcXHBhZ2VzXFxjcmVhdGUtdGlja2V0XFxjcmVhdGUtdGlja2V0LnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNFLGVBQUE7RUFDQSxrQkFBa0I7RUFDbEIsOEJBQUE7RUFDQSxrQkFBa0I7RUFDbEIsb0NBQUEsRUFBcUM7O0FBR3ZDO0VBQ0UsaUJBQUE7RUFDQSxlQUFlO0VBQ2YsZ0NBQUEsRUFBaUM7O0FBR25DO0VBQ0UsaUNBQUE7RUFDQSx5QkFBeUI7RUFDekIsb0NBQW9DO0VBQ3BDLHlDQUFBLEVBQTBDOztBQUc1QztFQUNFLDRCQUE0QjtFQUM1Qiw2QkFBQTtFQUNBLHlCQUF5QixFQUFBOztBQUUzQjtFQUNFLG9DQUFvQyxFQUFBOztBQUV0QztFQUNFLHFCQUFxQixFQUFBOztBQUd2QjtFQUNFLHdCQUF3QjtFQUN4QixrQ0FBa0M7RUFDbEMsNEJBQTRCLEVBQUE7O0FBTzlCOzs7O0VBSUUsb0NBQW9DO0VBQ3BDLHlCQUF5QixFQUFBOztBQUczQjtFQUNFLHlCQUF5QixFQUFBOztBQUczQjtFQUNFLDBCQUEwQixFQUFBOztBQUc1QjtFQUNFLDJCQUF1QjtFQUN2Qix3QkFBb0I7RUFDcEIsMEJBQXNCO0VBQ3RCLHdCQUFvQjtFQUNwQixrQkFBYTtFQUNiLHFCQUFpQjtFQUNqQixrQkFBYztFQUNkLG9CQUFnQjtFQUNoQixrQkFBYztFQUNkLDBDQUFhLEVBQUE7O0FBR2Y7RUFDRSw2QkFBNkI7RUFDN0IsNkJBQTZCLEVBQUE7O0FBRS9CO0VBQ0Usb0NBQW9DO0VBQ3BDLHdCQUF3QixFQUFBIiwiZmlsZSI6InNyYy9hcHAvUmVudGFscyBNYW5hZ2VtZW50L3BhZ2VzL2NyZWF0ZS10aWNrZXQvY3JlYXRlLXRpY2tldC5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyJsYWJlbCA+IC5jdXN0b21SYWRpbyB7XHJcbiAgLyogSElERSBSQURJTyAqL1xyXG4gIHZpc2liaWxpdHk6IGhpZGRlbjtcclxuICAvKiBNYWtlcyBpbnB1dCBub3QtY2xpY2thYmxlICovXHJcbiAgcG9zaXRpb246IGFic29sdXRlO1xyXG4gIC8qIFJlbW92ZSBpbnB1dCBmcm9tIGRvY3VtZW50IGZsb3cgKi9cclxufVxyXG5cclxubGFiZWwgPiBpbnB1dCArIGRpdiB7XHJcbiAgLyogSU1BR0UgU1RZTEVTICovXHJcbiAgY3Vyc29yOiBwb2ludGVyO1xyXG4gIC8qYm9yZGVyOjJweCBzb2xpZCB0cmFuc3BhcmVudDsqL1xyXG59XHJcblxyXG5sYWJlbCA+IGlucHV0OmNoZWNrZWQgKyBkaXYgPiBkaXYge1xyXG4gIC8qIChSQURJTyBDSEVDS0VEKSBJTUFHRSBTVFlMRVMgKi9cclxuICBjb2xvcjogI2ZmNTI1MiAhaW1wb3J0YW50O1xyXG4gIGJhY2tncm91bmQtY29sb3I6ICNmN2Y3ZjcgIWltcG9ydGFudDtcclxuICAvKmJvcmRlciA6IDFweCBzb2xpZCAjZmY1MjUyICFpbXBvcnRhbnQ7Ki9cclxufVxyXG5cclxuLml0ZW0tcmFkaW8gaW5wdXQ6Y2hlY2tlZCArIC5yYWRpby1jb250ZW50IC5pdGVtLWNvbnRlbnQge1xyXG4gIGJhY2tncm91bmQ6IHdoaXRlICFpbXBvcnRhbnQ7XHJcbiAgLypjb2xvcjogI2Y4NDk0MCAhaW1wb3J0YW50OyovXHJcbiAgY29sb3I6ICMxYmIyOTMgIWltcG9ydGFudDtcclxufVxyXG4uaW9uLWNsaWNrOmhvdmVyIHtcclxuICBib3JkZXI6IDFweCBzb2xpZCAjZjA0MTQxICFpbXBvcnRhbnQ7XHJcbn1cclxuLndpZHRoLTgwLXBlcmNlbnQge1xyXG4gIHdpZHRoOiA4MCUgIWltcG9ydGFudDtcclxufVxyXG5cclxuLmNlbnRlci1kYXRhLWluLWxhYmVsIHtcclxuICBkaXNwbGF5OiBncmlkICFpbXBvcnRhbnQ7XHJcbiAganVzdGlmeS1jb250ZW50OiBjZW50ZXIgIWltcG9ydGFudDtcclxuICBtYXJnaW4tdG9wOiAtMTVweCAhaW1wb3J0YW50O1xyXG59XHJcblxyXG4vLyBpb24tY2FyZCB7XHJcbi8vICAgbWFyZ2luOiAwICFpbXBvcnRhbnQ7XHJcbi8vIH1cclxuXHJcbi5Ib21lLFxyXG4uUHJvamVjdCxcclxuLmxvdyxcclxuLmhpZ2gge1xyXG4gIGJhY2tncm91bmQtY29sb3I6ICM5ZDQwNjUgIWltcG9ydGFudDtcclxuICBjb2xvcjogI2Y3ZjdmNyAhaW1wb3J0YW50O1xyXG59XHJcblxyXG5pb24taW5wdXQge1xyXG4gIG1hcmdpbi1sZWZ0OiAwICFpbXBvcnRhbnQ7XHJcbn1cclxuXHJcbnBhZGRpbmctbGVmdC0wIHtcclxuICBwYWRkaW5nLWxlZnQ6IDAgIWltcG9ydGFudDtcclxufVxyXG5cclxuLmlvbi1pbWFnZS1pdGVtIHtcclxuICAtLWlubmVyLXBhZGRpbmctYm90dG9tOiAwcHg7XHJcbiAgLS1pbm5lci1wYWRkaW5nLWVuZDogMHB4O1xyXG4gIC0taW5uZXItcGFkZGluZy1zdGFydDogMHB4O1xyXG4gIC0taW5uZXItcGFkZGluZy10b3A6IDBweDtcclxuICAtLW1pbi1oZWlnaHQ6IDI0cHg7XHJcbiAgLS1wYWRkaW5nLWJvdHRvbTogMHB4O1xyXG4gIC0tcGFkZGluZy1lbmQ6IDBweDtcclxuICAtLXBhZGRpbmctc3RhcnQ6IDBweDtcclxuICAtLXBhZGRpbmctdG9wOiAwcHg7XHJcbiAgLS10cmFuc2l0aW9uOiBiYWNrZ3JvdW5kLWNvbG9yIDE1bXMgbGluZWFyO1xyXG59XHJcblxyXG4uaW1nLWljb24ge1xyXG4gIGZvbnQtc2l6ZTogeC1sYXJnZSAhaW1wb3J0YW50O1xyXG4gIHBvc2l0aW9uOiBhYnNvbHV0ZSAhaW1wb3J0YW50O1xyXG59XHJcbi5pbWFnZSB7XHJcbiAganVzdGlmeS1jb250ZW50OiBmbGV4LWVuZCAhaW1wb3J0YW50O1xyXG4gIGRpc3BsYXk6IGZsZXggIWltcG9ydGFudDtcclxufVxyXG4iXX0= */"

/***/ }),

/***/ "./src/app/Rentals Management/pages/create-ticket/create-ticket.page.ts":
/*!******************************************************************************!*\
  !*** ./src/app/Rentals Management/pages/create-ticket/create-ticket.page.ts ***!
  \******************************************************************************/
/*! exports provided: CreateTicketPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CreateTicketPage", function() { return CreateTicketPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _services_ticket_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../services/ticket.service */ "./src/app/Rentals Management/services/ticket.service.ts");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _unit_search_unit_search_page__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../unit-search/unit-search.page */ "./src/app/Rentals Management/pages/unit-search/unit-search.page.ts");
/* harmony import */ var _project_search_project_search_page__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../project-search/project-search.page */ "./src/app/Rentals Management/pages/project-search/project-search.page.ts");
/* harmony import */ var _user_search_user_search_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../user-search/user-search.page */ "./src/app/Rentals Management/pages/user-search/user-search.page.ts");
/* harmony import */ var _ticket_category_search_ticket_category_search_page__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../ticket-category-search/ticket-category-search.page */ "./src/app/Rentals Management/pages/ticket-category-search/ticket-category-search.page.ts");
/* harmony import */ var _ticket_sub_category_search_ticket_sub_category_search_page__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../ticket-sub-category-search/ticket-sub-category-search.page */ "./src/app/Rentals Management/pages/ticket-sub-category-search/ticket-sub-category-search.page.ts");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var src_app_common_services_alert_service_service__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! src/app/common-services/alert-service.service */ "./src/app/common-services/alert-service.service.ts");
/* harmony import */ var src_app_common_services_translate_translate_service_service__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! src/app/common-services/translate/translate-service.service */ "./src/app/common-services/translate/translate-service.service.ts");
/* harmony import */ var _ionic_native_ionic_webview_ngx__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! @ionic-native/ionic-webview/ngx */ "./node_modules/@ionic-native/ionic-webview/ngx/index.js");
/* harmony import */ var src_app_common_services_storage_service_service__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! src/app/common-services/storage-service.service */ "./src/app/common-services/storage-service.service.ts");
/* harmony import */ var src_app_common_components_picture_picture_component__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! src/app/common-components/picture/picture.component */ "./src/app/common-components/picture/picture.component.ts");















var CreateTicketPage = /** @class */ (function () {
    function CreateTicketPage(ticketService, loadingCtrl, modalController, router, route, alertService, transService, webview, storageService, actionSheet) {
        var _this = this;
        this.ticketService = ticketService;
        this.loadingCtrl = loadingCtrl;
        this.modalController = modalController;
        this.router = router;
        this.route = route;
        this.alertService = alertService;
        this.transService = transService;
        this.webview = webview;
        this.storageService = storageService;
        this.actionSheet = actionSheet;
        this.ticketData = {
            ticketBelongsTo: 'Home',
            priority: 'low',
        };
        this.images = [];
        this.flag = false;
        this.subCategories = [];
        this.flow = 'createTicket';
        this.title = this.transService.getTranslatedData('create-ticket.raise-ticket');
        this.date = new Date();
        this.route.queryParamMap.subscribe(function (params) {
            _this.ticketId = params.params.ticketId;
            console.log(_this.ticketId);
        });
    }
    CreateTicketPage.prototype.presentLoading = function () {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function () {
            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.loadingCtrl.create({
                            spinner: "lines"
                        }).then(function (loading) {
                            loading.present();
                        })];
                    case 1:
                        _a.sent();
                        return [2 /*return*/];
                }
            });
        });
    };
    CreateTicketPage.prototype.ionViewDidEnter = function () {
        this.flag = false;
    };
    CreateTicketPage.prototype.ngOnInit = function () {
        if (this.ticketId) {
            this.flow = 'editTicket';
            this.title = this.transService.getTranslatedData('create-ticket.update-ticket');
            this.getTicketDetails();
        }
        else {
            this.ticketData.jobStartTime = this.date.toISOString();
            this.ticketData.jobDate = this.date.toISOString();
            this.ticketData.jobEndDate = this.date.toISOString();
            this.ticketData.jobEndTime = new Date(this.date.setDate(this.date.getMinutes() + 30)).toISOString(); // new Date(this.date.setDate(this.date.getDate() + 1)).toISOString();
            if (this.date.getMinutes() < 30) {
                this.date.setMinutes(30);
            }
            else {
                this.date.setMinutes(0);
                this.date.setHours(new Date().getHours() + 1);
            }
            this.ticketData.jobStartTime = this.date.toISOString();
            this.date.setMinutes(this.date.getMinutes() + 30);
            this.ticketData.jobEndTime = this.date.toISOString();
        }
    };
    CreateTicketPage.prototype.getTicketDetails = function () {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function () {
            var _this = this;
            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.presentLoading()];
                    case 1:
                        _a.sent();
                        this.ticketService.getTicketById(this.ticketId)
                            .subscribe(function (data) {
                            _this.loadingCtrl.dismiss();
                            _this.ticketData = data;
                            if (data.ticketCategory) {
                                _this.ticketData.ticketCategoryName = data.ticketCategory;
                            }
                            if (data.ticketSubCategory) {
                                _this.ticketData.ticketSubCategoryName = data.ticketSubCategory;
                            }
                            if (data.contactPoint) {
                                if (data.contactPoint.firstName) {
                                    _this.ticketData.contactPointName = data.contactPoint.firstName;
                                }
                                if (data.contactPoint.lastName) {
                                    _this.ticketData.contactPointName = _this.ticketData.contactPointName + ' ' + data.contactPoint.lastName;
                                }
                            }
                            if (data.agent) {
                                if (data.agent.firstName) {
                                    _this.ticketData.agentName = data.agent.firstName;
                                }
                                if (data.agent.lastName) {
                                    _this.ticketData.agentName = _this.ticketData.agentName + ' ' + data.agent.lastName;
                                }
                            }
                            console.log(_this.ticketData);
                        }, function (err) {
                            _this.loadingCtrl.dismiss();
                            _this.alertService.presentAlert(_this.transService.getTranslatedData('alert-title'), err.error.error);
                        });
                        return [2 /*return*/];
                }
            });
        });
    };
    CreateTicketPage.prototype.selectTicketBelongsTo = function (value) {
        this.ticketData.ticketBelongsTo = value;
        delete this.ticketData.ticketBelongsToName;
        delete this.ticketData.ticketBelongsToRefId;
        delete this.ticketData.ticketCategoryName;
        delete this.ticketData.ticketCategory;
        delete this.ticketData.ticketCategoryId;
    };
    CreateTicketPage.prototype.selectPriority = function (value) {
        this.ticketData.priority = value;
    };
    CreateTicketPage.prototype.openUnitSearchModal = function () {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function () {
            var modal;
            var _this = this;
            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.modalController.create({
                            component: _unit_search_unit_search_page__WEBPACK_IMPORTED_MODULE_4__["UnitSearchPage"],
                            componentProps: {
                                id: this.ticketData.ticketBelongsToRefId,
                                name: this.ticketData.ticketBelongsToName
                            }
                        })];
                    case 1:
                        modal = _a.sent();
                        modal.onDidDismiss().then(function (unit) {
                            if (unit !== null && unit.data) {
                                console.log(unit);
                                delete _this.ticketData.ticketCategoryName;
                                delete _this.ticketData.ticketCategory;
                                delete _this.ticketData.ticketCategoryId;
                                _this.ticketData.ticketBelongsToName = unit.data.ticketBelongsToName;
                                _this.ticketData.ticketBelongsToRefId = unit.data.ticketBelongsToRefId;
                                console.log(_this.ticketData);
                            }
                        });
                        return [4 /*yield*/, modal.present()];
                    case 2: return [2 /*return*/, _a.sent()];
                }
            });
        });
    };
    CreateTicketPage.prototype.openProjectSearchModal = function () {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function () {
            var modal;
            var _this = this;
            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.modalController.create({
                            component: _project_search_project_search_page__WEBPACK_IMPORTED_MODULE_5__["ProjectSearchPage"],
                            componentProps: {
                                id: this.ticketData.ticketBelongsToRefId,
                                name: this.ticketData.ticketBelongsToName
                            }
                        })];
                    case 1:
                        modal = _a.sent();
                        modal.onDidDismiss().then(function (project) {
                            if (project !== null && project.data) {
                                delete _this.ticketData.ticketCategoryName;
                                delete _this.ticketData.ticketCategory;
                                delete _this.ticketData.ticketCategoryId;
                                _this.ticketData.ticketBelongsToName = project.data.ticketBelongsToName;
                                _this.ticketData.ticketBelongsToRefId = project.data.ticketBelongsToRefId;
                                console.log(_this.ticketData);
                            }
                        });
                        return [4 /*yield*/, modal.present()];
                    case 2: return [2 /*return*/, _a.sent()];
                }
            });
        });
    };
    CreateTicketPage.prototype.openUserSearchModal = function (type) {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function () {
            var id, name, modal;
            var _this = this;
            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                switch (_a.label) {
                    case 0:
                        if (type === 'agent') {
                            id = this.ticketData.agent;
                            name = this.ticketData.agentName;
                        }
                        else if (type === 'poc') {
                            id = this.ticketData.contactPoint;
                            name = this.ticketData.contactPointName;
                        }
                        return [4 /*yield*/, this.modalController.create({
                                component: _user_search_user_search_page__WEBPACK_IMPORTED_MODULE_6__["UserSearchPage"],
                                componentProps: {
                                    id: id,
                                    name: name
                                }
                            })];
                    case 1:
                        modal = _a.sent();
                        modal.onDidDismiss().then(function (user) {
                            if (user !== null && user.data) {
                                if (type === 'agent') {
                                    _this.ticketData.agentName = user.data.name;
                                    _this.ticketData.agent = user.data.id;
                                }
                                else if (type === 'poc') {
                                    _this.ticketData.contactPointName = user.data.name;
                                    _this.ticketData.contactPoint = user.data.id;
                                }
                                console.log(_this.ticketData);
                            }
                        });
                        return [4 /*yield*/, modal.present()];
                    case 2: return [2 /*return*/, _a.sent()];
                }
            });
        });
    };
    CreateTicketPage.prototype.openTicketCategorySearchModal = function () {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function () {
            var modal;
            var _this = this;
            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.modalController.create({
                            component: _ticket_category_search_ticket_category_search_page__WEBPACK_IMPORTED_MODULE_7__["TicketCategorySearchPage"],
                            componentProps: {
                                ticketBelongsTo: this.ticketData.ticketBelongsTo,
                                ticketBelongsToRefId: this.ticketData.ticketBelongsToRefId,
                                name: this.ticketData.ticketCategoryName,
                                ticketCategory: this.ticketData.ticketCategory,
                                subCategories: this.subCategories
                            }
                        })];
                    case 1:
                        modal = _a.sent();
                        modal.onDidDismiss().then(function (category) {
                            if (category !== null && category.data) {
                                console.log(_this.ticketData);
                                _this.ticketData.ticketCategoryName = category.data.name;
                                _this.ticketData.ticketCategory = category.data.ticketCategory;
                                _this.ticketData.ticketCategoryId = category.data.ticketCategory;
                                delete _this.ticketData.ticketSubCategory;
                                delete _this.ticketData.ticketSubCategoryName;
                                delete _this.ticketData.ticketSubCategoryId;
                                _this.subCategories = category.data.subCategory;
                                console.log(_this.subCategories);
                            }
                        });
                        if (!this.ticketData.ticketBelongsToRefId) return [3 /*break*/, 3];
                        return [4 /*yield*/, modal.present()];
                    case 2: return [2 /*return*/, _a.sent()];
                    case 3:
                        this.alertService.presentAlert(this.transService.getTranslatedData('alert-title'), this.transService.getTranslatedData('create-ticket.select-unit-project-alert'));
                        _a.label = 4;
                    case 4: return [2 /*return*/];
                }
            });
        });
    };
    CreateTicketPage.prototype.openTicketSubCategorySearchModal = function () {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function () {
            var modal;
            var _this = this;
            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.modalController.create({
                            component: _ticket_sub_category_search_ticket_sub_category_search_page__WEBPACK_IMPORTED_MODULE_8__["TicketSubCategorySearchPage"],
                            componentProps: {
                                subCategories: this.subCategories,
                                name: this.ticketData.ticketSubCategoryName,
                                ticketSubCategory: this.ticketData.ticketSubCategory
                            }
                        })];
                    case 1:
                        modal = _a.sent();
                        modal.onDidDismiss().then(function (subCategory) {
                            if (subCategory !== null && subCategory.data) {
                                console.log(subCategory);
                                _this.ticketData.ticketSubCategoryName = subCategory.data.name;
                                _this.ticketData.ticketSubCategory = subCategory.data.ticketSubCategory;
                                _this.ticketData.ticketSubCategoryId = subCategory.data.ticketSubCategory;
                            }
                        });
                        if (!this.ticketData.ticketCategory) return [3 /*break*/, 3];
                        return [4 /*yield*/, modal.present()];
                    case 2: return [2 /*return*/, _a.sent()];
                    case 3:
                        this.alertService.presentAlert(this.transService.getTranslatedData('alert-title'), this.transService.getTranslatedData('create-ticket.select-cat-alert'));
                        _a.label = 4;
                    case 4: return [2 /*return*/];
                }
            });
        });
    };
    CreateTicketPage.prototype.closeModal = function () {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function () {
            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.modalController.dismiss()];
                    case 1:
                        _a.sent();
                        return [2 /*return*/];
                }
            });
        });
    };
    CreateTicketPage.prototype.openModal = function (value) {
        if (value === 'Home') {
            this.openUnitSearchModal();
        }
        else if (value === 'Project') {
            this.openProjectSearchModal();
        }
        else if (value === 'agent') {
            this.openUserSearchModal('agent');
        }
        else if (value === 'poc') {
            this.openUserSearchModal('poc');
        }
        else if (value === 'ticketCategory') {
            this.openTicketCategorySearchModal();
        }
        else if (value === 'ticketSubCategory') {
            this.openTicketSubCategorySearchModal();
        }
    };
    CreateTicketPage.prototype.raiseTicket = function () {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function () {
            var _this = this;
            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.presentLoading()];
                    case 1:
                        _a.sent();
                        return [4 /*yield*/, this.storageService.getDatafromIonicStorage('user_id').then(function (val) {
                                _this.ticketData.raisedBy = val;
                                _this.ticketData.createdBy = val;
                            })];
                    case 2:
                        _a.sent();
                        console.log(this.ticketData);
                        if (this.images.length > 0) {
                            this.alertService.upload(this.images[0], this.ticketData, 'RAISETICKET').then(function () { return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](_this, void 0, void 0, function () {
                                return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                                    switch (_a.label) {
                                        case 0: return [4 /*yield*/, this.loadingCtrl.dismiss()];
                                        case 1:
                                            _a.sent();
                                            this.alertService.presentAlert(this.transService.getTranslatedData('alert-title'), this.transService.getTranslatedData('create-ticket.ticket-create-success'));
                                            this.router.navigateByUrl("/rentals-tickets?ticketId=" + this.ticketData._id, { replaceUrl: true });
                                            return [2 /*return*/];
                                    }
                                });
                            }); }, function (error) {
                                _this.loadingCtrl.dismiss();
                                _this.alertService.presentAlert(_this.transService.getTranslatedData('alert-title'), JSON.stringify(error));
                            });
                        }
                        else {
                            this.ticketService.createTicket(this.ticketData)
                                .subscribe(function (data) {
                                console.log(_this.ticketData);
                                _this.loadingCtrl.dismiss();
                                _this.alertService.presentAlert(_this.transService.getTranslatedData('alert-title'), _this.transService.getTranslatedData('create-ticket.ticket-create-success'));
                                _this.router.navigateByUrl("/rentals-tickets?ticketId=" + _this.ticketData._id, { replaceUrl: true });
                            }, function (err) {
                                _this.loadingCtrl.dismiss();
                                _this.alertService.presentAlert(_this.transService.getTranslatedData('alert-title'), err.error.error);
                            });
                        }
                        return [2 /*return*/];
                }
            });
        });
    };
    CreateTicketPage.prototype.updateTicket = function () {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function () {
            var _this = this;
            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                switch (_a.label) {
                    case 0:
                        if (this.ticketData.ticketCategory) {
                            this.ticketData.ticketCategory = this.ticketData.ticketCategoryId;
                        }
                        if (this.ticketData.ticketSubCategory) {
                            this.ticketData.ticketSubCategory = this.ticketData.ticketSubCategoryId;
                        }
                        return [4 /*yield*/, this.presentLoading()];
                    case 1:
                        _a.sent();
                        if (this.images.length > 0) {
                            this.alertService.upload(this.images[0], this.ticketData, 'UPDATETICKET').then(function () {
                                _this.loadingCtrl.dismiss();
                                _this.alertService.presentAlert(_this.transService.getTranslatedData('alert-title'), _this.transService.getTranslatedData('create-ticket.ticket-update-success'));
                                _this.flag = true;
                                _this.router.navigateByUrl("/rentals-ticket-details?flag=" + _this.flag);
                            }, function (error) {
                                _this.loadingCtrl.dismiss();
                                _this.alertService.presentAlert(_this.transService.getTranslatedData('alert-title'), error);
                            });
                        }
                        else {
                            this.ticketService.updateTicket(this.ticketData)
                                .subscribe(function (data) {
                                _this.loadingCtrl.dismiss();
                                _this.alertService.presentAlert(_this.transService.getTranslatedData('alert-title'), _this.transService.getTranslatedData('create-ticket.ticket-update-success'));
                                _this.flag = true;
                                _this.router.navigateByUrl("/rentals-ticket-details?flag=" + _this.flag);
                                // this.router.navigateByUrl('/rentals-ticket-details');
                            }, function (err) {
                                _this.loadingCtrl.dismiss();
                                _this.alertService.presentAlert(_this.transService.getTranslatedData('alert-title'), err.error.error);
                            });
                        }
                        return [2 /*return*/];
                }
            });
        });
    };
    // async fileSourceOption(type) {
    //   if (this.images.length < 1) {
    //     const caller = await this.alertService.capturePhoto(type);
    //     console.log('in add-visitor Page\n\n ', caller);
    //     if (caller !== undefined) {
    //       console.log(caller);
    //       this.images.push(caller);
    //       console.log(this.images);
    //     }
    //   } else {
    //     this.alertService.presentAlert(this.transService.getTranslatedData('alert-title'),
    //       this.transService.getTranslatedData('create-ticket.picture-limit'));
    //   }
    // }
    CreateTicketPage.prototype.removeImage = function () {
        this.images = [];
    };
    CreateTicketPage.prototype.openImage = function (image) {
        this.modalController.create({
            component: src_app_common_components_picture_picture_component__WEBPACK_IMPORTED_MODULE_14__["PictureComponent"],
            componentProps: { image: image }
        }).then(function (modal) {
            modal.present();
        });
    };
    CreateTicketPage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-create-ticket',
            template: __webpack_require__(/*! ./create-ticket.page.html */ "./src/app/Rentals Management/pages/create-ticket/create-ticket.page.html"),
            styles: [__webpack_require__(/*! ./create-ticket.page.scss */ "./src/app/Rentals Management/pages/create-ticket/create-ticket.page.scss")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_services_ticket_service__WEBPACK_IMPORTED_MODULE_2__["TicketService"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["LoadingController"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["ModalController"],
            _angular_router__WEBPACK_IMPORTED_MODULE_9__["Router"],
            _angular_router__WEBPACK_IMPORTED_MODULE_9__["ActivatedRoute"],
            src_app_common_services_alert_service_service__WEBPACK_IMPORTED_MODULE_10__["AlertServiceService"],
            src_app_common_services_translate_translate_service_service__WEBPACK_IMPORTED_MODULE_11__["translateService"],
            _ionic_native_ionic_webview_ngx__WEBPACK_IMPORTED_MODULE_12__["WebView"],
            src_app_common_services_storage_service_service__WEBPACK_IMPORTED_MODULE_13__["StorageService"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["ActionSheetController"]])
    ], CreateTicketPage);
    return CreateTicketPage;
}());



/***/ })

}]);
//# sourceMappingURL=Rentals-Management-pages-create-ticket-create-ticket-module.js.map