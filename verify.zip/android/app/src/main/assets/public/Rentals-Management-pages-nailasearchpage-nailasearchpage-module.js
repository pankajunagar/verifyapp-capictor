(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["Rentals-Management-pages-nailasearchpage-nailasearchpage-module"],{

/***/ "./src/app/Rentals Management/pages/nailasearchpage/nailasearchpage.html":
/*!*******************************************************************************!*\
  !*** ./src/app/Rentals Management/pages/nailasearchpage/nailasearchpage.html ***!
  \*******************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ion-header no-border>\r\n  <ion-toolbar color=\"primary\">\r\n    <ion-buttons slot=\"start\">\r\n      <ion-menu-button></ion-menu-button>\r\n    </ion-buttons>\r\n    <!-- <ion-buttons slot=\"end\" expand=\"full\" class=\"ion-button\" (click)=\"openScanner()\">\r\n      <ion-button style=\"color: black\">\r\n          <img src=\"../../../../assets/icons.png\" width=\"30px\" height=\"30px\"/>\r\n      </ion-button>\r\n    </ion-buttons> -->\r\n\r\n    <ion-title style=\"display: inline-flex;\r\n    vertical-align: -webkit-baseline-middle;\">Salon at Home</ion-title>\r\n\r\n    <ion-buttons  routerLink=\"/rentals-naila-cart-page\" style=\"float:right;outline: none;\r\n    zoom:2;\" end>\r\n      <ion-icon style=\"margin-right: 3vw;\" ios=\"ios-cart\" md=\"md-cart\"></ion-icon>\r\n      <p *ngIf=\"this.utils.cartdata.length\" class=\"cart-number\">{{this.utils.cartdata}}</p>\r\n    </ion-buttons>\r\n  </ion-toolbar>\r\n</ion-header>\r\n\r\n<ion-content (click)=\"onOuterClick($event)\" class=\"ioncontent\" padding>\r\n\r\n\r\n  <ion-searchbar placeholder=\"Search your apartment\" class=\"ionsearch\" mode=\"ios\" [(ngModel)]=\"searchTerm\" (ionChange)=\"setFilteredItems()\">\r\n\r\n  </ion-searchbar>\r\n  <ion-row class=\"font-12\">\r\n\r\n\r\n\r\n    <!-- <ion-icon class=\"margin-left-1 margin-right-1 text-black\" name=\"locate\"></ion-icon>Use your current location -->\r\n    <!-- <ion-icon class=\"margin-left-1 margin-right-1\" name=\"compass\"></ion-icon> -->\r\n\r\n\r\n\r\n  </ion-row>\r\n\r\n  <ion-list style=\"margin-left: 15px;\r\n  margin-right: 15px;padding-top: 0px;\r\n  padding-bottom: 0px;\" class=\"list\" *ngIf=\"a\">\r\n    <ion-item style=\"margin-left: -15px;\r\n    margin-right: -15px;\" class=\"font-12\" (click)=\"selectedApartment(item)\" lines=\"none\" *ngFor=\"let item of items\">\r\n      {{ item.name }}\r\n    </ion-item>\r\n  </ion-list>\r\n\r\n\r\n  <ion-list class=\"padding-top-12\">\r\n    <label *ngIf=\"listofBanner\" class=\"font-12 font-weight-500\">Offers</label>\r\n\r\n    <ion-slides [options]=\"sliderConfig\">\r\n      <ion-slide *ngFor=\"let item of listofBanner\">\r\n        <ion-card class=\"myCard\">\r\n          <img style=\"height: 31vw;\r\n              width: 100%;\" src={{item.image.url}} />\r\n          <div class=\"myOverlay\">\r\n            <div class=\"card-title\">{{item.title}}</div>\r\n          </div>\r\n        </ion-card>\r\n      </ion-slide>\r\n\r\n\r\n\r\n\r\n    </ion-slides>\r\n  </ion-list>\r\n  <ion-list>\r\n    <label class=\"font-12 font-weight-500\" for=\"\">\r\n      Browse by service\r\n    </label>\r\n    <ion-slides class=\"service\" [options]=\"sliderConfig2\">\r\n      <ion-slide (click)=\"this.selectedCategory(slide);\" *ngFor=\"let slide of categories\" class=\"center-text\">\r\n        <ion-row>\r\n          <ion-card [style.background-color]=\"slide.name == cardName ? 'black' : 'white'\" style=\"height: 65px;\r\n        background: black;\r\n        width: 75px;\" class=\"margin-bottom-0\" size=\"12\">\r\n            <img style=\"position: absolute;\r\n          top: 50%;\r\n          left: 50%;\r\n          width: 25px;\r\n          height: 25px;\r\n          margin-top: -11px;\r\n          margin-left: -13px;\" src={{slide.image.url}} />\r\n\r\n\r\n          </ion-card>\r\n          <ion-col class=\"padding-top-0\" size=\"12\">\r\n\r\n            <label style=\"padding-right: 15vw;\" class=\"font-9 \">{{slide.name}}</label>\r\n          </ion-col>\r\n        </ion-row>\r\n      </ion-slide>\r\n    </ion-slides>\r\n  </ion-list>\r\n\r\n  <ng-container *ngFor=\"let item of characters\">\r\n\r\n\r\n\r\n\r\n    <ion-list *ngIf=\"showSubheading\" lines=\"none\">\r\n      <ion-item style=\"border-bottom:none;margin-left: -2.5vw;\" lines=\"none\">\r\n        <h6>{{item.name}}</h6>\r\n      </ion-item>\r\n    </ion-list>\r\n    <ion-list style=\"    display: flex;border-bottom: 1px solid lightgray;\" size=\"12\"\r\n      (click)=\"setDetailsofservice(item)\" *ngFor=\"let item of item.data\" class=\" padding-bottom-0\">\r\n\r\n\r\n      <ion-col *ngIf=\"showSubheading && item.data.image.url\" size=\"3\">\r\n        <img  class=\"float-left\" style=\"width: 100px;\r\n            height: 45px;\r\n            margin-top: 10px;\r\n            position: absolute;\r\n            border-radius: 5px;\" src={{item.data.image.url}} alt=\"sfsdf\">\r\n      </ion-col>\r\n      <ion-col *ngIf=\"!showSubheading && item.image.url\" size=\"3\">\r\n          <img  class=\"float-left\" style=\"width: 100px;\r\n              height: 45px;\r\n              margin-top: 10px;\r\n              position: absolute;\r\n              border-radius: 5px;\" src={{item.image.url}} alt=\"sfsdf\">\r\n        </ion-col>\r\n\r\n      <ion-col>\r\n\r\n\r\n        <ion-item detail-icon-color=\"red\" detail=\"true\" lines=\"none\">\r\n          <ion-label class=\"margin-0\">\r\n            <p class=\"margin-bottom-0\" text-wrap>\r\n              <small *ngIf=\"showSubheading\"\r\n                class=\"float-left text-black font-12 font-weight-500 margin-bottom-0\">{{item.data.name}}</small>\r\n              <small *ngIf=\"!showSubheading\"\r\n                class=\"float-left text-black font-12 font-weight-500 margin-bottom-0\">{{item.name}}</small>\r\n\r\n              <!-- <span class=\"center-text\"> hello</span>-->\r\n            </p>\r\n            <small *ngIf=\"showSubheading\" class=\"font-9 txt-grey margin-top-0\">\r\n              {{item.data.no_of_minuties}} min\r\n            </small>\r\n\r\n            <small *ngIf=\"!showSubheading\" class=\"font-9 txt-grey margin-top-0\">\r\n              {{item.no_of_minuties}} min\r\n            </small>\r\n          </ion-label>\r\n          <small *ngIf=\"showSubheading\" class=\"float-right\">Rs.{{item.data.offer_price}}</small>\r\n          <small *ngIf=\"!showSubheading\" class=\"float-right\">Rs.{{item.offer_price}}</small>\r\n\r\n        </ion-item>\r\n\r\n\r\n\r\n      </ion-col>\r\n\r\n    </ion-list>\r\n\r\n\r\n  </ng-container>\r\n\r\n\r\n\r\n\r\n  <!-- \r\n  <ion-infinite-scroll [hidden]=\"disableInfiniteScroll\" threshold=\"5px\" (ionInfinite)=\"searchTicket($event)\">\r\n    <ion-infinite-scroll-content loadingSpinner=\"bubbles\"\r\n      loadingText=\"{{transService.getTranslatedData('infinite-scroll')}}\">\r\n    </ion-infinite-scroll-content>\r\n  </ion-infinite-scroll> -->\r\n\r\n</ion-content>"

/***/ }),

/***/ "./src/app/Rentals Management/pages/nailasearchpage/nailasearchpage.module.ts":
/*!************************************************************************************!*\
  !*** ./src/app/Rentals Management/pages/nailasearchpage/nailasearchpage.module.ts ***!
  \************************************************************************************/
/*! exports provided: NailasearchPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "NailasearchPageModule", function() { return NailasearchPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _ApplicationPageModule__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../ApplicationPageModule */ "./src/app/Rentals Management/ApplicationPageModule.ts");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _modals_create_notice_create_notice_component__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../../modals/create-notice/create-notice.component */ "./src/app/Rentals Management/modals/create-notice/create-notice.component.ts");
/* harmony import */ var _nailasearchpage__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./nailasearchpage */ "./src/app/Rentals Management/pages/nailasearchpage/nailasearchpage.ts");
/* harmony import */ var _services_naila_service__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ../../services/naila.service */ "./src/app/Rentals Management/services/naila.service.ts");








// import { BarcodeScanner } from '@ionic-native/barcode-scanner/ngx';


var routes = [
    {
        path: '',
        component: _nailasearchpage__WEBPACK_IMPORTED_MODULE_8__["NailasearchPage"]
    }
];
var NailasearchPageModule = /** @class */ (function () {
    function NailasearchPageModule() {
    }
    NailasearchPageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_2__["NgModule"])({
            entryComponents: [_modals_create_notice_create_notice_component__WEBPACK_IMPORTED_MODULE_7__["CreateNoticeComponent"]],
            imports: [
                _angular_common__WEBPACK_IMPORTED_MODULE_3__["CommonModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormsModule"],
                _ApplicationPageModule__WEBPACK_IMPORTED_MODULE_1__["ApplicationPageModule"],
                _ionic_angular__WEBPACK_IMPORTED_MODULE_6__["IonicModule"],
                _angular_router__WEBPACK_IMPORTED_MODULE_5__["RouterModule"].forChild(routes)
            ],
            providers: [
                // BarcodeScanner,
                _services_naila_service__WEBPACK_IMPORTED_MODULE_9__["NailaService"]
            ],
            declarations: [_nailasearchpage__WEBPACK_IMPORTED_MODULE_8__["NailasearchPage"]]
        })
    ], NailasearchPageModule);
    return NailasearchPageModule;
}());



/***/ }),

/***/ "./src/app/Rentals Management/pages/nailasearchpage/nailasearchpage.scss":
/*!*******************************************************************************!*\
  !*** ./src/app/Rentals Management/pages/nailasearchpage/nailasearchpage.scss ***!
  \*******************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "ion-navbar {\n  border-bottom-right-radius: 15px;\n  border-bottom-left-radius: 15px;\n  background-color: black; }\n\nion-card {\n  position: relative;\n  text-align: center;\n  border-radius: 20px !important; }\n\n.card-title {\n  position: absolute;\n  font-size: 12px;\n  color: #fff;\n  margin-top: 4.5px;\n  margin-left: 14px; }\n\nion-card-content {\n  text-align: left;\n  background: red;\n  line-height: 1.5;\n  width: 100%;\n  padding-top: 7px;\n  padding-bottom: 7px; }\n\nlabel {\n  padding-left: 3vw; }\n\n.service ion-card-content {\n  text-align: center;\n  line-height: 1.5;\n  width: 100%;\n  font-size: 6px;\n  background: transparent;\n  padding: 5px 1px 3px; }\n\n.service ion-card {\n  position: relative;\n  text-align: center;\n  border-radius: 10px !important; }\n\nion-item {\n  --detail-icon-color: goldenrod;\n  --detail-icon-opacity:1; }\n\nion-label {\n  padding-top: 10px !important;\n  padding-bottom: 10px !important; }\n\nion-toolbar {\n  border-bottom-left-radius: 25px;\n  border-bottom-right-radius: 25px; }\n\n.myCard {\n  position: relative; }\n\n.myOverlay {\n  width: 100%;\n  height: 22px;\n  position: absolute;\n  z-index: 99;\n  bottom: 0px;\n  background: #000;\n  background: linear-gradient(to bottom, transparent, black);\n  color: #fff; }\n\n.custom-skeleton ion-skeleton-text {\n  line-height: 13px; }\n\n.custom-skeleton ion-skeleton-text:last-child {\n  margin-bottom: 5px; }\n\nimg {\n  transform: unset !important; }\n\nh6 {\n  font-size: 14px; }\n\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvUmVudGFscyBNYW5hZ2VtZW50L3BhZ2VzL25haWxhc2VhcmNocGFnZS9EOlxcbmF2am90XFx2ZXJpZnkvc3JjXFxhcHBcXFJlbnRhbHMgTWFuYWdlbWVudFxccGFnZXNcXG5haWxhc2VhcmNocGFnZVxcbmFpbGFzZWFyY2hwYWdlLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDRSxnQ0FBZ0M7RUFDaEMsK0JBQStCO0VBQy9CLHVCQUF1QixFQUFBOztBQU9uQjtFQUNFLGtCQUFrQjtFQUNsQixrQkFBa0I7RUFDbEIsOEJBQThCLEVBQUE7O0FBR2hDO0VBQ0Usa0JBQWtCO0VBQ2xCLGVBQWU7RUFDZixXQUFXO0VBQ1gsaUJBQWlCO0VBQ2pCLGlCQUFpQixFQUFBOztBQVF2QjtFQUNJLGdCQUFnQjtFQUNSLGVBQWU7RUFDdkIsZ0JBQWdCO0VBQ2hCLFdBQVc7RUFDWCxnQkFBZ0I7RUFDaEIsbUJBQW1CLEVBQUE7O0FBR3ZCO0VBQ0ksaUJBQWlCLEVBQUE7O0FBRXJCO0VBRVEsa0JBQWtCO0VBQ2xCLGdCQUFnQjtFQUNoQixXQUFXO0VBQ1gsY0FBYztFQUNkLHVCQUF1QjtFQUN2QixvQkFBb0IsRUFBQTs7QUFQNUI7RUFVUSxrQkFBa0I7RUFDbEIsa0JBQWtCO0VBQ2xCLDhCQUE4QixFQUFBOztBQVN0QztFQUdFLDhCQUFvQjtFQUNwQix1QkFBc0IsRUFBQTs7QUFHeEI7RUFDRSw0QkFBNEI7RUFDNUIsK0JBQStCLEVBQUE7O0FBUWpDO0VBQ0UsK0JBQStCO0VBQy9CLGdDQUFnQyxFQUFBOztBQUdsQztFQUNFLGtCQUFpQixFQUFBOztBQUluQjtFQUNFLFdBQVc7RUFDWCxZQUFZO0VBQ1osa0JBQWtCO0VBQ2xCLFdBQVc7RUFDWCxXQUFXO0VBQ1gsZ0JBQWdCO0VBQ2hCLDBEQUF5RDtFQUN6RCxXQUFXLEVBQUE7O0FBS2I7RUFDRSxpQkFBaUIsRUFBQTs7QUFHbkI7RUFDRSxrQkFBa0IsRUFBQTs7QUFFcEI7RUFDRSwyQkFBMkIsRUFBQTs7QUFJN0I7RUFDRSxlQUFlLEVBQUEiLCJmaWxlIjoic3JjL2FwcC9SZW50YWxzIE1hbmFnZW1lbnQvcGFnZXMvbmFpbGFzZWFyY2hwYWdlL25haWxhc2VhcmNocGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiaW9uLW5hdmJhcntcclxuICBib3JkZXItYm90dG9tLXJpZ2h0LXJhZGl1czogMTVweDtcclxuICBib3JkZXItYm90dG9tLWxlZnQtcmFkaXVzOiAxNXB4O1xyXG4gIGJhY2tncm91bmQtY29sb3I6IGJsYWNrO1xyXG59XHJcblxyXG5cclxuXHJcblxyXG5cclxuICAgICAgaW9uLWNhcmQge1xyXG4gICAgICAgIHBvc2l0aW9uOiByZWxhdGl2ZTtcclxuICAgICAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XHJcbiAgICAgICAgYm9yZGVyLXJhZGl1czogMjBweCAhaW1wb3J0YW50O1xyXG4gICAgICB9XHJcblxyXG4gICAgICAuY2FyZC10aXRsZSB7XHJcbiAgICAgICAgcG9zaXRpb246IGFic29sdXRlO1xyXG4gICAgICAgIGZvbnQtc2l6ZTogMTJweDtcclxuICAgICAgICBjb2xvcjogI2ZmZjtcclxuICAgICAgICBtYXJnaW4tdG9wOiA0LjVweDtcclxuICAgICAgICBtYXJnaW4tbGVmdDogMTRweDtcclxuICAgICAgfVxyXG5cclxuICAgICBcclxuICAgICAgLy8gaW9uLXNsaWRle1xyXG4gICAgICAvLyAgICAgd2lkdGg6IDI0NXB4ICFpbXBvcnRhbnQ7XHJcbiAgICAgIC8vIH1cclxuXHJcbiAgaW9uLWNhcmQtY29udGVudHtcclxuICAgICAgdGV4dC1hbGlnbjogbGVmdDtcclxuICAgICAgICAgICAgICBiYWNrZ3JvdW5kOiByZWQ7XHJcbiAgICAgIGxpbmUtaGVpZ2h0OiAxLjU7XHJcbiAgICAgIHdpZHRoOiAxMDAlO1xyXG4gICAgICBwYWRkaW5nLXRvcDogN3B4O1xyXG4gICAgICBwYWRkaW5nLWJvdHRvbTogN3B4O1xyXG4gIH1cclxuXHJcbiAgbGFiZWx7XHJcbiAgICAgIHBhZGRpbmctbGVmdDogM3Z3O1xyXG4gIH1cclxuICAuc2VydmljZXtcclxuICAgICAgaW9uLWNhcmQtY29udGVudHtcclxuICAgICAgICAgIHRleHQtYWxpZ246IGNlbnRlcjtcclxuICAgICAgICAgIGxpbmUtaGVpZ2h0OiAxLjU7XHJcbiAgICAgICAgICB3aWR0aDogMTAwJTtcclxuICAgICAgICAgIGZvbnQtc2l6ZTogNnB4O1xyXG4gICAgICAgICAgYmFja2dyb3VuZDogdHJhbnNwYXJlbnQ7XHJcbiAgICAgICAgICBwYWRkaW5nOiA1cHggMXB4IDNweDtcclxuICAgICAgfVxyXG4gICAgICBpb24tY2FyZHtcclxuICAgICAgICAgIHBvc2l0aW9uOiByZWxhdGl2ZTtcclxuICAgICAgICAgIHRleHQtYWxpZ246IGNlbnRlcjtcclxuICAgICAgICAgIGJvcmRlci1yYWRpdXM6IDEwcHggIWltcG9ydGFudDsgIFxyXG4gICAgICAgICAgXHJcbiAgICAgIH1cclxuICB9XHJcblxyXG4gIC8vIC5ib3JkZXItdG9wIHtcclxuICAvLyAgIGJvcmRlci10b3A6IDFweCBzb2xpZCBsaWdodGdyYXk7XHJcbiAgLy8gfVxyXG4gIFxyXG4gIGlvbi1pdGVtIHtcclxuICAgIC8vIGJvcmRlci10b3A6IDFweCBzb2xpZCBsaWdodGdyYXk7XHJcbiAgICAvLyBib3JkZXItYm90dG9tOiAxcHggc29saWQgbGlnaHRncmF5O1xyXG4gICAgLS1kZXRhaWwtaWNvbi1jb2xvcjogZ29sZGVucm9kO1xyXG4gICAgLS1kZXRhaWwtaWNvbi1vcGFjaXR5OjE7XHJcbiAgfVxyXG4gIFxyXG4gIGlvbi1sYWJlbCB7XHJcbiAgICBwYWRkaW5nLXRvcDogMTBweCAhaW1wb3J0YW50O1xyXG4gICAgcGFkZGluZy1ib3R0b206IDEwcHggIWltcG9ydGFudDtcclxuICB9XHJcbiAgXHJcbiAgLy8gaW9uLWxpc3Qge1xyXG4gIC8vICAgcGFkZGluZy10b3A6IDBweCAhaW1wb3J0YW50O1xyXG4gIC8vIH1cclxuICBcclxuXHJcbiAgaW9uLXRvb2xiYXJ7XHJcbiAgICBib3JkZXItYm90dG9tLWxlZnQtcmFkaXVzOiAyNXB4O1xyXG4gICAgYm9yZGVyLWJvdHRvbS1yaWdodC1yYWRpdXM6IDI1cHg7XHJcbiAgfVxyXG5cclxuICAubXlDYXJke1xyXG4gICAgcG9zaXRpb246cmVsYXRpdmU7XHJcbiAgXHJcbiAgfVxyXG4gIFxyXG4gIC5teU92ZXJsYXl7XHJcbiAgICB3aWR0aDogMTAwJTtcclxuICAgIGhlaWdodDogMjJweDtcclxuICAgIHBvc2l0aW9uOiBhYnNvbHV0ZTtcclxuICAgIHotaW5kZXg6IDk5O1xyXG4gICAgYm90dG9tOiAwcHg7XHJcbiAgICBiYWNrZ3JvdW5kOiAjMDAwO1xyXG4gICAgYmFja2dyb3VuZDogbGluZWFyLWdyYWRpZW50KHRvIGJvdHRvbSx0cmFuc3BhcmVudCwgYmxhY2spO1xyXG4gICAgY29sb3I6ICNmZmY7XHJcbiAgXHJcbiAgfVxyXG5cclxuXHJcbiAgLmN1c3RvbS1za2VsZXRvbiBpb24tc2tlbGV0b24tdGV4dCB7XHJcbiAgICBsaW5lLWhlaWdodDogMTNweDtcclxuICB9XHJcbiAgXHJcbiAgLmN1c3RvbS1za2VsZXRvbiBpb24tc2tlbGV0b24tdGV4dDpsYXN0LWNoaWxkIHtcclxuICAgIG1hcmdpbi1ib3R0b206IDVweDtcclxuICB9XHJcbiAgaW1ne1xyXG4gICAgdHJhbnNmb3JtOiB1bnNldCAhaW1wb3J0YW50O1xyXG4gIH1cclxuXHJcblxyXG4gIGg2e1xyXG4gICAgZm9udC1zaXplOiAxNHB4O1xyXG4gIH1cclxuXHJcbiJdfQ== */"

/***/ }),

/***/ "./src/app/Rentals Management/pages/nailasearchpage/nailasearchpage.ts":
/*!*****************************************************************************!*\
  !*** ./src/app/Rentals Management/pages/nailasearchpage/nailasearchpage.ts ***!
  \*****************************************************************************/
/*! exports provided: NailasearchPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "NailasearchPage", function() { return NailasearchPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _services_naila_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../services/naila.service */ "./src/app/Rentals Management/services/naila.service.ts");
/* harmony import */ var _services_utils_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../services/utils.service */ "./src/app/Rentals Management/services/utils.service.ts");





var NailasearchPage = /** @class */ (function () {
    function NailasearchPage(nailaService, utils, router) {
        this.nailaService = nailaService;
        this.utils = utils;
        this.router = router;
        this.sliderConfig = {
            slidesPerView: 1.2,
            spaceBetween: 5,
        };
        this.sliderConfig2 = {
            slidesPerView: 3.2,
            spaceBetween: -50,
        };
        this.searchTerm = "";
        this.serviceList = [];
        this.showSubheading = false;
        this.a = false;
        this.characters = [];
    }
    NailasearchPage.prototype.ngOnInit = function () {
        var _this = this;
        this.nailaService.apartmentList().subscribe(function (data) {
            _this.apartmentList = data;
            _this.items = data;
            // console.log(this.apartmentList)
        });
        this.browseBycategory();
        this.nailaService.listBanners().subscribe(function (data) {
            _this.listofBanner = data;
        });
    };
    NailasearchPage.prototype.ionViewWillEnter = function () {
        debugger;
        if (window.localStorage.getItem('cartitemcount')) {
            this.utils.cartdata = window.localStorage.getItem('cartitemcount');
        }
        else {
            this.utils.cartdata = [];
        }
        if (this.utils.bookingdata) {
            alert(this.utils.bookingdata);
            this.nailaService.createBooking(this.utils.bookingdata).subscribe(function (data) {
            });
        }
    };
    NailasearchPage.prototype.browseBycategory = function () {
        var _this = this;
        debugger;
        this.nailaService.browseBycategory().subscribe(function (data) {
            console.log(data);
            _this.categories = data;
            _this.selectedCategory(data[0]);
        });
    };
    NailasearchPage.prototype.selectedCategory = function (data) {
        var _this = this;
        this.cardName = data.name;
        var list = [];
        this.nailaService.selectedCategory(data.id).subscribe(function (data) {
            console.log("selected", data);
            _this.categoryList = data;
            _this.filterserviceData(data);
        });
    };
    NailasearchPage.prototype.filterserviceData = function (data) {
        var _this = this;
        this.characters = [];
        this.serviceList = [];
        this.showSubheading = false;
        if (data.length && data[0].sub_category_id && data[0].sub_category) {
            data.forEach(function (element) {
                if (element.sub_category && element.category_id == element.sub_category.category_id) {
                    _this.serviceList.push({
                        data: element,
                        name: element.sub_category.name
                    });
                    _this.showSubheading = true;
                }
            });
            var result = this.serviceList.reduce(function (h, _a) {
                var data = _a.data, name = _a.name;
                var _b;
                return Object.assign(h, (_b = {}, _b[name] = (h[name] || []).concat({ data: data, name: name }), _b));
            }, {});
            var results = Object.keys(result);
            // var characters = [ ];
            for (var prop in result) {
                if (result.hasOwnProperty(prop)) {
                    this.characters.push({
                        name: prop,
                        data: result[prop]
                    });
                }
            }
            this.serviceList = [];
            this.serviceList.push(this.characters);
        }
        else {
            this.characters = [];
            data.forEach(function (element) {
                _this.characters.push({
                    name: '',
                    data: [element]
                });
            });
            // this.characters=data
            // console.log("elseeeeeepart",this.serviceList)
            console.log("=========================change", this.characters, "================================");
            this.showSubheading = false;
        }
    };
    NailasearchPage.prototype.filterItems = function (searchTerm) {
        return this.items.filter(function (item) {
            return item.name.toLowerCase().indexOf(searchTerm.toLowerCase()) > -1;
        });
    };
    NailasearchPage.prototype.setFilteredItems = function () {
        this.items = this.apartmentList;
        this.items = this.filterItems(this.searchTerm);
    };
    NailasearchPage.prototype.selectedApartment = function (item) {
        this.searchTerm = item.name;
        window.localStorage.setItem('apartment_name', item.name);
        window.localStorage.setItem('apartment_id', item.id);
    };
    NailasearchPage.prototype.onOuterClick = function (e) {
        if (e.target.classList.contains('ioncontent')) {
            console.log('ioncontent');
            this.a = false;
        }
        else if (e.target.classList.contains('searchbar-input')) {
            console.log('ionsearch');
            this.a = true;
        }
        else if (e.target.classList.contains('item') && e.target.classList.contains('in-list')) {
            console.log('list');
            this.a = false;
        }
    };
    // listofservices
    NailasearchPage.prototype.setDetailsofservice = function (data) {
        debugger;
        if (data.data) {
            this.utils.storage = data.data;
        }
        else {
            this.utils.storage = data;
        }
        this.router.navigateByUrl('/rentals-naila-service-page');
    };
    NailasearchPage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-nailasearchpage',
            template: __webpack_require__(/*! ./nailasearchpage.html */ "./src/app/Rentals Management/pages/nailasearchpage/nailasearchpage.html"),
            styles: [__webpack_require__(/*! ./nailasearchpage.scss */ "./src/app/Rentals Management/pages/nailasearchpage/nailasearchpage.scss")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_services_naila_service__WEBPACK_IMPORTED_MODULE_3__["NailaService"], _services_utils_service__WEBPACK_IMPORTED_MODULE_4__["Utils"], _angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"]])
    ], NailasearchPage);
    return NailasearchPage;
}());



/***/ })

}]);
//# sourceMappingURL=Rentals-Management-pages-nailasearchpage-nailasearchpage-module.js.map