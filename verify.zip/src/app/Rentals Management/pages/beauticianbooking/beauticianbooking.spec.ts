import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { NailaoffersListingPage } from './nailaofferslisting';

describe('NailaoffersListingPage', () => {
  let component: NailaoffersListingPage;
  let fixture: ComponentFixture<NailaoffersListingPage>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ NailaoffersListingPage ],
      schemas: [CUSTOM_ELEMENTS_SCHEMA],
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(NailaoffersListingPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
