// import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
// import { async, ComponentFixture, TestBed } from '@angular/core/testing';
// import { NailaOffersPage } from './nailaofferspage';


// describe('NailaOffersPage', () => {
//   let component: NailaOffersPage;
//   let fixture: ComponentFixture<NailaOffersPage>;

//   beforeEach(async(() => {
//     TestBed.configureTestingModule({
//       declarations: [ NailaOffersPage ],
//       schemas: [CUSTOM_ELEMENTS_SCHEMA],
//     })
//     .compileComponents();
//   }));

//   beforeEach(() => {
//     fixture = TestBed.createComponent(NailaOffersPage);
//     component = fixture.componentInstance;
//     fixture.detectChanges();
//   });

//   it('should create', () => {
//     expect(component).toBeTruthy();
//   });
// });
